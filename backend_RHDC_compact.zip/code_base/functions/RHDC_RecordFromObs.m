function rec = RHDC_RecordFromObs(obs, params, point, D, chi, cfg, alphaSeed, alphaPattern)
%RHDC_RECORDFROMOBS Convert observable structure into a CSV-ready record.

    rec = RHDC_EmptyRecord();

    rec.pointLabel = point.label;
    rec.pointDescription = point.description;
    rec.lambda = point.lambda;
    rec.thetaOverPi = point.thetaOverPi;
    rec.D = D;
    rec.chi = chi;
    rec.dph = cfg.dph;
    rec.alphaSeed = alphaSeed;
    rec.alphaPattern = alphaPattern;
    rec.backend = cfg.observableMode;
    rec.diagonalEstimator = cfg.diagonalEstimator;

    rec.energyNNCTM = local_get(obs,'energyPerSite',NaN);
    rec.energyNNNCoh = local_get(obs,'energyNNNCohPerSite',NaN);
    rec.energyPerSite = local_get(obs,'energyApproxPerSite',rec.energyNNCTM);

    rec.rhoSR = local_get(obs,'superradiantDensity',NaN);
    rec.meanPhotonNumber = local_get(obs,'meanPhotonNumber',NaN);

    Ly = size(obs.jRight,1);
    yy = mod(1,Ly)+1;

    rec.j12 = local_pick(obs.jRight,1,1);
    rec.j23 = local_pick(obs.jDown,1,yy);  % I23: site 2 down, with 2=(x+1,y)
    rec.j34 = -local_pick(obs.jRight,yy,1);
    rec.j41 = -local_pick(obs.jDown,1,1);

    rec.j13 = local_pick(obs.jDiagP,1,1);
    rec.j24 = -local_pick(obs.jDiagM,yy,1);

    rec.chiSquare = local_pick(obs.chiSquare,1,1);
    rec.meanAbsChiTri = local_get(obs,'meanAbsTriangularChirality',NaN);
    rec.triangularImbalance = local_get(obs,'triangularImbalance',NaN);
    rec.diagSelectionSigned = rec.j13 - rec.j24;
    rec.Rtri = rec.meanAbsChiTri/(abs(rec.chiSquare)+eps);
    rec.Rdiag = abs(rec.j13-rec.j24)/(abs(rec.j13)+abs(rec.j24)+eps);

    if isfield(obs,'chiTri123') && isfield(obs,'chiTri134') && isfield(obs,'chiTri124') && isfield(obs,'chiTri234')
        c123 = local_pick(obs.chiTri123,1,1);
        c134 = local_pick(obs.chiTri134,1,1);
        c124 = local_pick(obs.chiTri124,1,1);
        c234 = local_pick(obs.chiTri234,1,1);
        rec.loopIdentityError = max(abs(c123+c134-rec.chiSquare), abs(c124+c234-rec.chiSquare));
    else
        rec.loopIdentityError = NaN;
    end

    rec.phaseCode = RHDC_ClassifyTexture(rec.rhoSR, abs(rec.chiSquare), rec.Rtri, rec.Rdiag, cfg.thr);
    rec.patternLabel = RHDC_LabelFromCode(rec.phaseCode);
end

function v = local_get(s, name, defaultVal)
    if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
        x = s.(name);
        if isnumeric(x) || islogical(x)
            v = real(double(x(1)));
        else
            v = defaultVal;
        end
    else
        v = defaultVal;
    end
end

function v = local_pick(A, y, x)
    if isnumeric(A) && ~isempty(A) && size(A,1) >= y && size(A,2) >= x
        v = real(double(A(y,x)));
    else
        v = NaN;
    end
end
