function [params, opts] = RHDC_BuildParamsOpts(cfg, point, D, chi, alphaSeed, alphaPattern)
%RHDC_BUILDPARAMSOPTS Build params/opts for one high-D point.

    if exist('RabiH_DefaultArticleParams','file') == 2
        try
            params = RabiH_DefaultArticleParams();
        catch
            params = struct();
        end
    else
        params = struct();
    end

    params.omega = cfg.omega;
    params.Delta = cfg.Delta;
    params.dph = cfg.dph;
    params.g = cfg.g;
    params.gR = cfg.g;
    params.J1 = cfg.J1;
    params.J2 = point.lambda * cfg.J1;
    params.lambda = point.lambda;
    params.lambda2 = point.lambda;
    params.t = cfg.J1;
    params.tX = cfg.J1;
    params.tY = cfg.J1;
    params.Phi = cfg.Phi;
    params.PhiSquare = cfg.Phi;
    params.thetaTri = point.thetaOverPi*pi;
    params.includeNNN = true;
    params.nnnPhaseMode = cfg.nnnPhaseMode;
    params.alphaSeed = alphaSeed;
    params.alphaPattern = alphaPattern;

    opts = struct();
    opts.Lx = 2;
    opts.Ly = 2;
    opts.Dmax = D;
    opts.chiMax = chi;

    opts.useNNNPathUpdate = true;
    opts.tauList = cfg.tauList;
    opts.suTauList = cfg.tauList;
    opts.nSweeps = cfg.nSweeps;
    opts.suNSweeps = cfg.nSweeps;
    opts.maxIter = cfg.maxIter;
    opts.sharedMaxIter = cfg.maxIter;

    % High-D safe route: do not use exact torus.
    opts.ctmBackend = 'splitFactored';
    opts.backend = 'splitFactored';
    opts.splitBackendMode = 'production';
    opts.enableSplitExactTorus = false;
    opts.useExactTorus = false;
    opts.forceExactTorus = false;

    opts.skipCTMNormHistory = cfg.skipCTMNormHistory;
    opts.autoSkipIterNorm = cfg.autoSkipIterNorm;
    opts.iterNormMaxElements = cfg.iterNormMaxElements;
    opts.verbose = cfg.verbose;
    opts.debug = cfg.debug;
end
