function [bestRec, branchRecords] = RHDC_RunOnePoint(cfg, point, D, chi)
%RHDC_RUNONEPOINT Run one representative point and select the best branch.
%
% Branch selection uses the approximate energy available in high-D mode:
% split/factored CTM local+NN energy plus coherent diagonal energy.  The
% current-texture classification is based on dimensionless ratios and labels,
% not on high-precision energy extrapolation.

    RHDC_SafetyCheck(cfg, D);

    branchTemplate = RHDC_EmptyRecord();
    branchRecords = branchTemplate;
    branchRecords(1) = [];

    bestRec = branchTemplate;
    bestEnergy = inf;
    firstErr = '';
    tAll = tic;

    for ia = 1:numel(cfg.alphaSeedList)
        for ip = 1:numel(cfg.alphaPatternList)
            alphaSeed = cfg.alphaSeedList(ia);
            alphaPattern = cfg.alphaPatternList{ip};
            rec = RHDC_EmptyRecord();
            rec.pointLabel = point.label;
            rec.pointDescription = point.description;
            rec.lambda = point.lambda;
            rec.thetaOverPi = point.thetaOverPi;
            rec.D = D;
            rec.chi = chi;
            rec.dph = cfg.dph;
            rec.alphaSeed = alphaSeed;
            rec.alphaPattern = alphaPattern;
            rec.backend = cfg.observableMode;
            rec.diagonalEstimator = cfg.diagonalEstimator;

            try
                [params, opts] = RHDC_BuildParamsOpts(cfg, point, D, chi, alphaSeed, alphaPattern);

                seedOpts = struct();
                seedOpts.alpha = alphaSeed;
                seedOpts.pattern = alphaPattern;

                uc0 = RabiH_InitCoherentUnitCell(2,2,params,seedOpts);
                [uc, suInfo] = RabiH_RunNNNPathUpdate_Schedule(uc0, params, opts); %#ok<NASGU>

                obsOpts = opts;
                obsOpts.splitBackendMode = 'production';
                obsOpts.ctmBackend = 'splitFactored';
                obsOpts.enableSplitExactTorus = false;
                obsOpts.useExactTorus = false;
                obsOpts.forceExactTorus = false;

                obs = RabiH_CTMObservables_SplitFactoredProduction(uc, params, obsOpts);
                obs = RHDC_AddCoherentNNNDiagnostics(obs, params);

                rec = RHDC_RecordFromObs(obs, params, point, D, chi, cfg, alphaSeed, alphaPattern);
                rec.ok = true;
                rec.validObs = RHDC_IsValidRecord(rec);
                rec.message = 'ok';

                if cfg.saveUnitCell
                    recFile = fullfile(cfg.outputDir,'raw_unitcells', ...
                        sprintf('%s_D%d_chi%d_a%s.mat',point.label,D,chi,local_numkey(alphaSeed)));
                    if exist(fileparts(recFile),'dir') ~= 7, mkdir(fileparts(recFile)); end
                    save(recFile,'uc','obs','params','opts','point','D','chi','alphaSeed','alphaPattern');
                end

            catch ME
                rec.ok = false;
                rec.validObs = false;
                rec.message = local_error_msg(ME);
                if isempty(firstErr), firstErr = rec.message; end
            end

            branchRecords(end+1) = rec; %#ok<AGROW>

            if rec.validObs
                e = rec.energyPerSite;
                if isfinite(e) && e < bestEnergy
                    bestEnergy = e;
                    bestRec = rec;
                elseif ~bestRec.validObs
                    bestRec = rec;
                end
            end
        end
    end

    bestRec.runtimeSec = toc(tAll);
    if ~bestRec.validObs
        bestRec.pointLabel = point.label;
        bestRec.pointDescription = point.description;
        bestRec.lambda = point.lambda;
        bestRec.thetaOverPi = point.thetaOverPi;
        bestRec.D = D;
        bestRec.chi = chi;
        bestRec.dph = cfg.dph;
        bestRec.backend = cfg.observableMode;
        bestRec.diagonalEstimator = cfg.diagonalEstimator;
        bestRec.message = ['no valid finite-observable branch. First error: ' firstErr];
    end
end

function s = local_numkey(x)
    s = sprintf('%+.5f', x);
    s = strrep(s,'+','p');
    s = strrep(s,'-','m');
    s = strrep(s,'.','p');
end

function msg = local_error_msg(ME)
    try
        msg = getReport(ME,'extended','hyperlinks','off');
    catch
        msg = ME.message;
    end
    msg = strrep(msg, sprintf('\n'), ' | ');
    msg = strrep(msg, ',', ';');
end
