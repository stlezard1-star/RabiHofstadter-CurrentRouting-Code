function rec = RHDC_EmptyRecord()
%RHDC_EMPTYRECORD Create an empty output record with fixed field order.

    rec = struct();
    rec.pointLabel = '';
    rec.pointDescription = '';
    rec.lambda = NaN;
    rec.thetaOverPi = NaN;
    rec.D = NaN;
    rec.chi = NaN;
    rec.dph = NaN;
    rec.alphaSeed = NaN;
    rec.alphaPattern = '';
    rec.ok = false;
    rec.validObs = false;
    rec.runtimeSec = NaN;
    rec.energyPerSite = NaN;
    rec.energyNNCTM = NaN;
    rec.energyNNNCoh = NaN;
    rec.rhoSR = NaN;
    rec.meanPhotonNumber = NaN;
    rec.j12 = NaN; rec.j23 = NaN; rec.j34 = NaN; rec.j41 = NaN;
    rec.j13 = NaN; rec.j24 = NaN;
    rec.chiSquare = NaN;
    rec.meanAbsChiTri = NaN;
    rec.triangularImbalance = NaN;
    rec.diagSelectionSigned = NaN;
    rec.Rtri = NaN;
    rec.Rdiag = NaN;
    rec.loopIdentityError = NaN;
    rec.phaseCode = NaN;
    rec.patternLabel = '';
    rec.backend = '';
    rec.diagonalEstimator = '';
    rec.message = '';
end
