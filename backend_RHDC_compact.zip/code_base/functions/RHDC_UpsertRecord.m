function records = RHDC_UpsertRecord(records, rec)
%RHDC_UPSERTRECORD Insert or replace one record.

    if isempty(records)
        records = rec;
        return;
    end

    hit = [];
    for k = 1:numel(records)
        if strcmp(records(k).pointLabel, rec.pointLabel) && ...
                records(k).D == rec.D && records(k).chi == rec.chi && ...
                records(k).dph == rec.dph && ...
                abs(records(k).lambda-rec.lambda) < 1e-12 && ...
                abs(records(k).thetaOverPi-rec.thetaOverPi) < 1e-12
            hit = k;
            break;
        end
    end

    if isempty(hit)
        records(end+1) = rec;
    else
        records(hit) = rec;
    end
end
