function code = RHDC_ClassifyTexture(rho, chiSq, Rtri, Rdiag, thr)
%RHDC_CLASSIFYTEXTURE Operational current-texture classifier.
%
% code:
%   0 normal
%   1 SR
%   2 square
%   3 tri-enh
%   4 diag
%   5 tri+diag
%   6 crossover

    if ~isfinite(rho) || rho < thr.rhoSR
        code = 0; return;
    end
    if ~isfinite(chiSq) || chiSq < thr.chiSq
        code = 1; return;
    end

    tri = isfinite(Rtri) && Rtri >= thr.triEnhanced;
    square = isfinite(Rtri) && Rtri <= thr.squareDominant;
    diag = isfinite(Rdiag) && Rdiag >= thr.diagSelected;

    if tri && diag
        code = 5;
    elseif diag
        code = 4;
    elseif tri
        code = 3;
    elseif square
        code = 2;
    else
        code = 6;
    end
end
