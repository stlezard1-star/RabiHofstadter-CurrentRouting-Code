function points = RHDC_RepresentativePoints()
%RHDC_REPRESENTATIVEPOINTS Points used for finite-D robustness tests.
%
% Points are deliberately chosen away from threshold boundaries.

    points = RHDC_MakePoint('square', ...
        'square-dominant chiralSR', 0.60, 0.00);

    points(2) = RHDC_MakePoint('tri_enh', ...
        'triangular-enhanced chiralSR', -0.60, 0.00);

    points(3) = RHDC_MakePoint('diag', ...
        'diagonal-selected chiralSR', 0.60, 0.25);

    points(4) = RHDC_MakePoint('tri_diag', ...
        'tri-enhanced diagonal-selected chiralSR', -0.60, -0.25);
end

function p = RHDC_MakePoint(label, description, lambda, thetaOverPi)
    p = struct();
    p.label = label;
    p.description = description;
    p.lambda = lambda;
    p.thetaOverPi = thetaOverPi;
end
