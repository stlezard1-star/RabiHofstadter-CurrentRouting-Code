function cfg = RHDC_DefaultConfig()
%RHDC_DEFAULTCONFIG Default options for SAFE high-D D-convergence checks.
%
% This SAFE version deliberately avoids exact-torus contraction and avoids
% naive plaquette impurity CTM contractions, because those can become memory
% intensive for D>=3.  It uses a split/factored CTM route and a coherent
% diagonal-current estimator for high-D robustness checks.

    cfg = struct();

    % Physical parameters.
    cfg.omega = 1.0;
    cfg.Delta = 1.0;
    cfg.g = 1.40;
    cfg.J1 = 0.16;
    cfg.Phi = pi/2;
    cfg.nnnPhaseMode = 'lineIntegral';

    % Lightweight resource defaults for finite-D robustness.
    cfg.dph = 4;
    cfg.DList = [2 3 4];
    cfg.chiForD = [6 8 10];
    cfg.tauList = [0.05 0.025];
    cfg.nSweeps = 1;
    cfg.maxIter = 5;

    % Branch initialization.
    cfg.alphaSeedList = [0 0.8 1.2];
    cfg.alphaPatternList = {'uniform'};

    % SAFE backend.
    cfg.observableMode = 'splitFactoredCTM_coherentNNN_SAFE';
    cfg.diagonalEstimator = 'coherent';  % SAFE high-D estimator
    cfg.useExactTorus = false;
    cfg.allowPlaquetteCTM = false;       % hard guard

    % Classification thresholds.
    cfg.thr = struct();
    cfg.thr.rhoSR = 1e-3;
    cfg.thr.chiSq = 1e-4;
    cfg.thr.squareDominant = 0.55;
    cfg.thr.triEnhanced = 0.70;
    cfg.thr.diagSelected = 0.60;

    % Output/checkpointing.
    cfg.outputDir = fullfile(fileparts(fileparts(mfilename('fullpath'))), 'results', 'D_convergence_SAFE');
    cfg.useCache = true;
    cfg.forceRecompute = false;
    cfg.saveUnitCell = false;

    % CTM controls.
    cfg.skipCTMNormHistory = true;
    cfg.autoSkipIterNorm = true;
    cfg.iterNormMaxElements = 5e6;
    cfg.verbose = false;
    cfg.debug = false;
end
