function records = RHDC_RunJobs(cfg, points)
%RHDC_RUNJOBS Run all point/D jobs with checkpointing.

    if exist(cfg.outputDir,'dir') ~= 7
        mkdir(cfg.outputDir);
    end
    rawDir = fullfile(cfg.outputDir,'raw_jobs');
    if exist(rawDir,'dir') ~= 7
        mkdir(rawDir);
    end

    csvFile = fullfile(cfg.outputDir,'RHDC_D_convergence_records.csv');
    matFile = fullfile(cfg.outputDir,'RHDC_D_convergence_records.mat');
    reportFile = fullfile(cfg.outputDir,'RHDC_D_convergence_report.txt');

    records = RHDC_EmptyRecord();
    records(1) = [];

    if cfg.useCache && exist(matFile,'file') == 2 && ~cfg.forceRecompute
        S = load(matFile);
        if isfield(S,'records')
            records = S.records;
            fprintf('[RHDC] loaded existing records: %d\n', numel(records));
        end
    end

    for p = 1:numel(points)
        for d = 1:numel(cfg.DList)
            D = cfg.DList(d);
            chi = cfg.chiForD(d);
            RHDC_SafetyCheck(cfg, D);
            key = sprintf('%s_D%d_chi%d_dph%d_lam_%s_th_%s', ...
                points(p).label, D, chi, cfg.dph, local_numkey(points(p).lambda), local_numkey(points(p).thetaOverPi));
            jobFile = fullfile(rawDir,[key '.mat']);

            if cfg.useCache && exist(jobFile,'file') == 2 && ~cfg.forceRecompute
                S = load(jobFile);
                if isfield(S,'bestRec')
                    bestRec = S.bestRec;
                    branchRecords = S.branchRecords;
                    fprintf('[RHDC] cache: %s valid=%d\n', key, double(bestRec.validObs));
                else
                    [bestRec, branchRecords] = RHDC_RunOnePoint(cfg, points(p), D, chi);
                    save(jobFile,'bestRec','branchRecords','cfg');
                end
            else
                fprintf('\n[RHDC] running %s\n', key);
                [bestRec, branchRecords] = RHDC_RunOnePoint(cfg, points(p), D, chi);
                save(jobFile,'bestRec','branchRecords','cfg');
            end

            records = RHDC_UpsertRecord(records, bestRec);
            save(matFile,'records','cfg','points');
            RHDC_WriteRecordsCSV(csvFile, records);
            local_write_report(reportFile, records, cfg, points);
        end
    end

    fprintf('\n[RHDC] wrote:\n  %s\n  %s\n  %s\n', csvFile, matFile, reportFile);
end

function s = local_numkey(x)
    s = sprintf('%+.5f', x);
    s = strrep(s,'+','p');
    s = strrep(s,'-','m');
    s = strrep(s,'.','p');
end

function local_write_report(filename, records, cfg, points)
    fid = fopen(filename,'w');
    if fid < 0, return; end

    fprintf(fid,'RHDC D-convergence report\n\n');
    fprintf(fid,'observableMode: %s\n', cfg.observableMode);
    fprintf(fid,'diagonalEstimator: %s\n', cfg.diagonalEstimator);
    fprintf(fid,'DList: %s\n', mat2str(cfg.DList));
    fprintf(fid,'chiForD: %s\n', mat2str(cfg.chiForD));
    fprintf(fid,'dph: %d\n\n', cfg.dph);
    fprintf(fid,'Records: %d, valid: %d\n\n', numel(records), sum([records.validObs]));

    labels = unique({records.pointLabel},'stable');
    for p = 1:numel(labels)
        fprintf(fid,'[%s]\n', labels{p});
        idx = strcmp({records.pointLabel}, labels{p});
        rr = records(idx);
        for k = 1:numel(rr)
            fprintf(fid,'  D=%d chi=%d valid=%d E=%.12g Rtri=%.6g Rdiag=%.6g label=%s msg=%s\n', ...
                rr(k).D, rr(k).chi, double(rr(k).validObs), rr(k).energyPerSite, rr(k).Rtri, rr(k).Rdiag, ...
                rr(k).patternLabel, rr(k).message);
        end
    end
    fclose(fid);
end
