function RHDC_SafetyCheck(cfg, D)
%RHDC_SAFETYCHECK Hard guards against memory-unsafe routes.

    if isfield(cfg,'useExactTorus') && cfg.useExactTorus && D >= 3
        error('RHDC:UnsafeExactTorus', ...
            ['SAFE package refuses exact-torus contraction for D>=3. ', ...
             'Use split/factored CTM and coherent diagonal estimator.']);
    end

    if isfield(cfg,'allowPlaquetteCTM') && cfg.allowPlaquetteCTM && D >= 3
        error('RHDC:UnsafePlaquetteCTM', ...
            ['SAFE package refuses naive plaquette impurity CTM for D>=3. ', ...
             'The previous plaquette ncon route can create very large intermediate tensors.']);
    end

    if isfield(cfg,'diagonalEstimator') && strcmpi(cfg.diagonalEstimator,'ctmPlaquette2x2') && D >= 3
        error('RHDC:UnsafePlaquetteEstimator', ...
            ['diagonalEstimator=ctmPlaquette2x2 is disabled in SAFE mode for D>=3. ', ...
             'Use diagonalEstimator=coherent for finite-D robustness checks.']);
    end
end
