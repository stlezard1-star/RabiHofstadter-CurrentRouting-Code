function obs = RHDC_AddCoherentNNNDiagnostics(obs, params)
%RHDC_ADDCOHERENTNNNDIAGNOSTICS Add high-D safe diagonal-current diagnostics.
%
% The split/factored production CTM backend measures local observables and
% nearest-neighbor pair observables.  It does not yet evaluate arbitrary
% diagonal two-site CTM correlators.  For high-D robustness checks, this
% routine adds the coherent contribution to the diagonal current,
%
%   I_ij^coh = 2 J_2 Im[ exp(i phi_ij) alpha_i^* alpha_j ],
%
% using the CTM-measured local coherent amplitudes alpha_i=<a_i>.
%
% This estimator is appropriate for a qualitative high-D stress test of the
% superradiant current texture.  It should not be confused with the exact
% diagonal two-site current used in the production D=2 maps.

    if ~isfield(obs,'alpha')
        error('RHDC_AddCoherentNNNDiagnostics:MissingAlpha', ...
            'obs.alpha is required for coherent diagonal-current estimator.');
    end

    alpha = obs.alpha;
    [Ly,Lx] = size(alpha);
    [J2,~,includeNNN] = RabiH_GetNNNHopping(params);

    jP = zeros(Ly,Lx);
    jM = zeros(Ly,Lx);
    eP = zeros(Ly,Lx);
    eM = zeros(Ly,Lx);

    if includeNNN && abs(J2) > 0
        for y = 1:Ly
            for x = 1:Lx
                xp = mod(x,Lx)+1;
                yp = mod(y,Ly)+1;
                ym = mod(y-2,Ly)+1;

                phP = RabiH_NNNPhase(x,y,'diagp',params);
                zP = exp(1i*phP) * conj(alpha(y,x)) * alpha(yp,xp);
                jP(y,x) = 2*J2*imag(zP);
                eP(y,x) = -2*J2*real(zP);

                phM = RabiH_NNNPhase(x,y,'diagm',params);
                zM = exp(1i*phM) * conj(alpha(y,x)) * alpha(ym,xp);
                jM(y,x) = 2*J2*imag(zM);
                eM(y,x) = -2*J2*real(zM);
            end
        end
    end

    obs.jDiagP = local_real_if_safe(jP);
    obs.jDiagM = local_real_if_safe(jM);
    obs.diagEnergyCohP = local_real_if_safe(eP);
    obs.diagEnergyCohM = local_real_if_safe(eM);
    obs.energyNNNCohPerSite = sum(eP(:)+eM(:))/(Lx*Ly);
    obs.diagonalEstimator = 'coherent_alpha_alpha';

    [pat, obs] = RabiH_CurrentPatternDiagnostics(obs, params);
    obs.currentPattern = pat;

    if isfield(obs,'energyPerSite') && isfinite(obs.energyPerSite)
        obs.energyApproxPerSite = obs.energyPerSite + obs.energyNNNCohPerSite;
    else
        obs.energyApproxPerSite = obs.energyNNNCohPerSite;
    end
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
