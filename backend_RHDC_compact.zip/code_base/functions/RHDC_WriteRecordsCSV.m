function RHDC_WriteRecordsCSV(filename, records)
%RHDC_WRITERECORDSCSV Write D-convergence records.

    fid = fopen(filename,'w');
    if fid < 0
        error('RHDC_WriteRecordsCSV:OpenFailed','Cannot open %s.', filename);
    end

    fprintf(fid, ['pointLabel,pointDescription,lambda,thetaOverPi,D,chi,dph,alphaSeed,alphaPattern,', ...
        'ok,validObs,runtimeSec,energyPerSite,energyNNCTM,energyNNNCoh,rhoSR,meanPhotonNumber,', ...
        'j12,j23,j34,j41,j13,j24,chiSquare,meanAbsChiTri,triangularImbalance,', ...
        'diagSelectionSigned,Rtri,Rdiag,loopIdentityError,phaseCode,patternLabel,backend,diagonalEstimator,message\n']);

    for k = 1:numel(records)
        r = records(k);
        fprintf(fid, ['%s,%s,%.15g,%.15g,%d,%d,%d,%.15g,%s,%d,%d,%.15g,', ...
            '%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,', ...
            '%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%d,%s,%s,%s,%s\n'], ...
            local_csv(r.pointLabel), local_csv(r.pointDescription), r.lambda, r.thetaOverPi, r.D, r.chi, r.dph, ...
            r.alphaSeed, local_csv(r.alphaPattern), double(r.ok), double(r.validObs), r.runtimeSec, ...
            r.energyPerSite, r.energyNNCTM, r.energyNNNCoh, r.rhoSR, r.meanPhotonNumber, ...
            r.j12, r.j23, r.j34, r.j41, r.j13, r.j24, r.chiSquare, r.meanAbsChiTri, ...
            r.triangularImbalance, r.diagSelectionSigned, r.Rtri, r.Rdiag, r.loopIdentityError, ...
            r.phaseCode, local_csv(r.patternLabel), local_csv(r.backend), local_csv(r.diagonalEstimator), local_csv(r.message));
    end
    fclose(fid);
end

function s = local_csv(x)
    if isnumeric(x)
        s = num2str(x);
    elseif ischar(x)
        s = x;
    else
        try
            s = char(x);
        catch
            s = '';
        end
    end
    s = strrep(s,'"','""');
    if any(s==',') || any(s=='"') || any(s==newline)
        s = ['"' s '"'];
    end
end
