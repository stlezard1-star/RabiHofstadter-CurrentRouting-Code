function label = RHDC_LabelFromCode(code)
%RHDC_LABELFROMCODE Convert texture code to label.

    labels = {'normal','SR','square','tri-enh','diag','tri+diag','crossover'};
    if isfinite(code) && code >= 0 && code <= 6
        label = labels{code+1};
    else
        label = 'unknown';
    end
end
