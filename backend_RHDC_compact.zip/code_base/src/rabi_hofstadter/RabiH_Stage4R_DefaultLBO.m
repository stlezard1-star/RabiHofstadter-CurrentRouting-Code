function [params, opts, spec] = RabiH_Stage4R_DefaultLBO()
%RABIH_STAGE4R_DEFAULTLBO Defaults for photon local-basis optimization prototype.
%
% StageRH4R addresses large photon cutoff cost.  It builds a photon isometry
% W(dFull,dEff), projects a/adag/N/Q, and checks local-spectrum and hopping
% operator consistency.  This is a controlled precursor to integrating LBO
% into the full PEPS optimization pipeline.

[params, opts, ~] = RabiH_Stage4Q_DefaultOverlay();
params.dphFull = 12;
params.dphEff = 6;
params.dph = params.dphFull;
params.gR = 1.0;
params.t = 0.08;
params.Phi = pi/2;
params.alphaSeed = 0.8;
params.alphaPattern = 'uniform';

opts.outputDir = fullfile(pwd,'results_stage4R_lbo_prototype');

spec = struct();
spec.stage = 'StageRH4R';
spec.name = 'StageRH4R_photon_lbo_prototype';
spec.description = ['Photon local-basis optimization prototype based on SVD of coherent/Fock/Rabi snapshots. ' ...
    'This is not yet the production PEPS LBO update, but it validates projected operators and local spectra.'];
spec.dFullList = [8 10 12];
spec.dEffList = [4 6];
spec.alphaList = [0 0.4 0.8 1.2 1.6];
spec.numFock = 4;
spec.numLocalStates = 6;
spec.includeFock = true;
spec.includeLocalRabi = true;
spec.nLevels = 6;
spec.maxLocalSpectrumErrorWarn = 5e-2;
spec.outputDir = opts.outputDir;
spec.writeCSV = true;
spec.stopOnError = false;
end
