function [params, opts, spec] = RabiH_Stage4N_DefaultBranchStability()
%RABIH_STAGE4N_DEFAULTBRANCHSTABILITY Defaults for StageRH4N branch stability checks.
%
% StageRH4N follows the StageRH4M stress scan.  Stage4M has located visible
% SR/chiralSR branches in the high-gR window.  This diagnostic does not try
% to discover new phases; it fixes a few representative branches and checks
% their stability against D, chi, dph, sharedBoundaryMix, and sourceEta.
%
% The default demo is deliberately small.  Enlarge the scan axes only after
% this test passes.

[params, opts, ~] = RabiH_Stage4M_DefaultStressScan();

params.dph = 5;
params.gR = 1.00;
params.t = 0.08;
params.tX = params.t;
params.tY = params.t;
params.Phi = pi/2;
params.alphaSeed = 0.80;
params.alphaPattern = 'uniform';
params.sourceEta = 0;
params.sourcePhase = 0;

opts.Dmax = 2;
opts.chiMax = 6;
opts.maxIter = 5;
opts.sharedMaxIter = 5;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.sharedBoundaryMix = 0.0;
opts.outputDir = fullfile(pwd,'results_stage4N_branch_stability');
opts.saveEachPoint = true;

rep = RabiH_Stage4N_RepresentativePoints();

spec = struct();
spec.name = 'StageRH4N_branch_stability';
spec.description = ['Representative-branch stability scan after StageRH4M. ' ...
    'The scan fixes normal/SR/chiralSR branches and checks convergence axes ' ...
    'instead of re-running a broad exploratory seed scan.'];
spec.backend = 'splitFactoredShared';
spec.representativePoints = rep;
spec.DmaxList = 2;
spec.chiMaxList = 6;
spec.dphList = 5;
spec.sharedBoundaryMixList = 0;
spec.sourceEtaList = 0;
spec.sourcePhaseList = 0;
spec.stopOnError = false;
spec.maxRecords = Inf;
spec.phaseThresholds = struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5);
spec.tag = datestr(now,'yyyymmdd_HHMMSS');
end
