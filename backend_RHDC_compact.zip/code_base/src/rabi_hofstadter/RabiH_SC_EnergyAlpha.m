function E = RabiH_SC_EnergyAlpha(alpha, params)
%RabiH_SC_EnergyAlpha  Coherent-state energy from complex alpha vector.
alpha = alpha(:).';
if numel(alpha) ~= 4
    error('alpha must contain four complex amplitudes.');
end
omega = local_get(params,'omega',1.0);
Delta = local_get(params,'Delta',1.0);
g = local_get(params,'g',1.0);
J1 = local_get(params,'J1',0.16);
J2 = RabiH_SC_GetJ2(params);
ph = RabiH_SC_FluxPhases(params);

% Local Rabi coherent-state energy. The spin is minimized exactly for a
% given classical photon displacement alpha.
E = 0;
for k = 1:4
    q = alpha(k) + conj(alpha(k));
    E = E + omega*abs(alpha(k))^2 - 0.5*sqrt(Delta^2 + 4*g^2*real(q)^2);
end

% NN hopping on the square boundary.
E = E - 2*J1*real(exp(1i*ph.A12)*conj(alpha(1))*alpha(2));
E = E - 2*J1*real(exp(1i*ph.A23)*conj(alpha(2))*alpha(3));
E = E - 2*J1*real(exp(1i*ph.A34)*conj(alpha(3))*alpha(4));
E = E - 2*J1*real(exp(1i*ph.A41)*conj(alpha(4))*alpha(1));

% NNN diagonal hopping.
E = E - 2*J2*real(exp(1i*ph.B13)*conj(alpha(1))*alpha(3));
E = E - 2*J2*real(exp(1i*ph.B24)*conj(alpha(2))*alpha(4));

if ~isfinite(E)
    E = 1e100;
end
end

function v = local_get(s, name, defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
