function paths = RabiH_WriteFigureSetCSVs(figSet, outDir)
%RABIH_WRITEFIGURESETCSVS Write StageRH4P figure-set tables.
if nargin < 2 || isempty(outDir)
    if isfield(figSet,'outputDir'), outDir = figSet.outputDir; else, outDir = pwd; end
end
if exist(outDir,'dir') ~= 7, mkdir(outDir); end

paths = struct();
paths.summary = fullfile(outDir,'stage4P_figure_summary.csv');
paths.map = fullfile(outDir,'stage4P_map_records.csv');
paths.fluxCuts = fullfile(outDir,'stage4P_flux_cuts.csv');
paths.representatives = fullfile(outDir,'stage4P_representatives.csv');

local_write_summary(figSet.summary, paths.summary);
local_write_rows(figSet.map.records, paths.map, 'map');
local_write_rows(figSet.fluxCuts.records, paths.fluxCuts, 'fluxCut');
local_write_rows(figSet.representatives.records, paths.representatives, 'representative');
end

function local_write_summary(summary, filename)
fid = fopen(filename,'w');
if fid < 0, error('RabiH_WriteFigureSetCSVs:OpenFailed','Cannot open %s', filename); end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'metric,value\n');
fprintf(fid,'numMapRecords,%d\n', summary.numMapRecords);
fprintf(fid,'numFluxCutRecords,%d\n', summary.numFluxCutRecords);
fprintf(fid,'numRepresentativeRecords,%d\n', summary.numRepresentativeRecords);
fprintf(fid,'countNormal,%d\n', summary.countNormal);
fprintf(fid,'countSR,%d\n', summary.countSR);
fprintf(fid,'countCurrentSR,%d\n', summary.countCurrentSR);
fprintf(fid,'countChiralSR,%d\n', summary.countChiralSR);
fprintf(fid,'energyMin,%.16g\n', summary.energyRange(1));
fprintf(fid,'energyMax,%.16g\n', summary.energyRange(2));
fprintf(fid,'rhoSRMin,%.16g\n', summary.rhoSRRange(1));
fprintf(fid,'rhoSRMax,%.16g\n', summary.rhoSRRange(2));
fprintf(fid,'maxAbsCurrent,%.16g\n', summary.maxAbsCurrent);
fprintf(fid,'maxAbsChirality,%.16g\n', summary.maxAbsChirality);
fprintf(fid,'maxCurrentDivergence,%.16g\n', summary.maxCurrentDivergence);
fprintf(fid,'maxChiralityDefinitionError,%.16g\n', summary.maxChiralityDefinitionError);
fprintf(fid,'passChiralCount,%d\n', summary.passChiralCount);
fprintf(fid,'passCurrentDivergence,%d\n', summary.passCurrentDivergence);
fprintf(fid,'passChiralityDefinition,%d\n', summary.passChiralityDefinition);
if isfield(summary,'warnings') && ~isempty(summary.warnings)
    for k = 1:numel(summary.warnings)
        fprintf(fid,'warning%d,%s\n', k, summary.warnings{k});
    end
end
end

function local_write_rows(rows, filename, role)
fid = fopen(filename,'w');
if fid < 0, error('RabiH_WriteFigureSetCSVs:OpenFailed','Cannot open %s', filename); end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,['role,repName,cutT,cutG,status,phaseLabel,gR,t,Phi,PhiOverPi,' ...
    'energyPerSite,superradiantDensity,meanAbsCurrent,meanAbsChirality,' ...
    'maxCurrentDivergence,maxChiralityDefinitionError,alphaSeed,alphaPattern,dph,Dmax,chiMax,sourceEta\n']);
for k = 1:numel(rows)
    r = rows(k);
    if ~isfield(r,'figureRole') || isempty(r.figureRole), r.figureRole = role; end
    fprintf(fid,'%s,%s,%.16g,%.16g,%s,%s,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%s,%.16g,%.16g,%.16g,%.16g\n', ...
        local_str(r,'figureRole'), local_str(r,'repName'), local_num(r,'cutT'), local_num(r,'cutG'), ...
        local_str(r,'status'), local_str(r,'phaseLabel'), local_num(r,'gR'), local_num(r,'t'), ...
        local_num(r,'Phi'), local_num(r,'PhiOverPi'), local_num(r,'energyPerSite'), ...
        local_num(r,'superradiantDensity'), local_num(r,'meanAbsCurrent'), local_num(r,'meanAbsChirality'), ...
        local_num(r,'maxCurrentDivergence'), local_num(r,'maxChiralityDefinitionError'), ...
        local_num(r,'alphaSeed'), local_str(r,'alphaPattern'), local_num(r,'dph'), ...
        local_num(r,'Dmax'), local_num(r,'chiMax'), local_num(r,'sourceEta'));
end
end

function s = local_str(S,name)
if isfield(S,name) && ~isempty(S.(name))
    s = S.(name);
else
    s = '';
end
s = regexprep(char(s),'[,\n\r]',' ');
end

function x = local_num(S,name)
if isfield(S,name) && ~isempty(S.(name))
    x = S.(name);
else
    x = NaN;
end
end
