function scan = RabiH_RunAccuracyOverlayScan(paramsBase, optsBase, spec)
%RABIH_RUNACCURACYOVERLAYSCAN Run StageRH4Q simple-update accuracy overlay.
%
% This diagnostic recomputes representative article branches across resource
% axes and SU schedules.  It is intended to compensate for the lack of a full
% update by making the residual resource/schedule dependence explicit.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4Q_DefaultOverlay();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec), spec = struct(); end

optsBase.ctmBackend = local_get(spec,'backend',RabiH_GetOpt(optsBase,'ctmBackend','splitFactoredShared'));
optsBase.splitBackendMode = 'shared';
points = RabiH_ExpandAccuracyOverlaySpec(spec, optsBase, paramsBase);
thresholds = local_get(spec,'phaseThresholds',struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5));
stopOnError = local_get(spec,'stopOnError',false);
outDir = local_get(spec,'outputDir',RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4Q_accuracy_overlay')));
saveEachPoint = RabiH_GetOpt(optsBase,'saveEachPoint',true);
if exist(outDir,'dir') ~= 7, mkdir(outDir); end

records = repmat(local_empty_record(),1,numel(points));
startAll = tic;
for k = 1:numel(points)
    p = points(k);
    params = paramsBase;
    opts = optsBase;

    params.dph = p.dph;
    params.gR = p.gR;
    params.t = p.t;
    params.tX = p.t;
    params.tY = p.t;
    params.Phi = p.Phi;
    params.alphaSeed = p.alphaSeed;
    params.alphaPattern = p.alphaPattern;
    params.sourceEta = p.sourceEta;
    params.sourcePhase = p.sourcePhase;

    opts.Dmax = p.Dmax;
    opts.chiMax = p.chiMax;
    opts.alpha = p.alphaSeed;
    opts.alphaPattern = p.alphaPattern;
    opts.sharedBoundaryMix = p.sharedBoundaryMix;
    opts.tauList = p.tauList;
    opts.nSweeps = p.nSweeps;
    opts.maxIter = p.maxIter;
    opts.sharedMaxIter = p.sharedMaxIter;
    opts.ctmBackend = optsBase.ctmBackend;
    opts.splitBackendMode = 'shared';

    rec = local_empty_record();
    rec.index = p.index;
    rec.label = p.label;
    rec.branchName = p.branchName;
    rec.targetPhase = p.targetPhase;
    rec.dph = p.dph;
    rec.Dmax = p.Dmax;
    rec.chiMax = p.chiMax;
    rec.sharedBoundaryMix = p.sharedBoundaryMix;
    rec.gR = p.gR;
    rec.t = p.t;
    rec.Phi = p.Phi;
    rec.alphaSeed = p.alphaSeed;
    rec.alphaPattern = p.alphaPattern;
    rec.sourceEta = p.sourceEta;
    rec.sourcePhase = p.sourcePhase;
    rec.scheduleName = p.scheduleName;
    rec.nSweeps = p.nSweeps;
    rec.tauListString = local_numvec_to_string(p.tauList);

    t0 = tic;
    try
        result = RabiH_RunOnePoint_AutoBackend(params, opts);
        obs = result.obs;
        diag = RabiH_CurrentChiralityDiagnostics(obs);
        rec.status = 'ok';
        rec.backend = result.backend;
        rec.stage = result.stage;
        rec.runtimeSeconds = toc(t0);
        rec.energyPerSite = local_real_scalar(result.energyPerSite);
        rec.superradiantDensity = local_real_scalar(result.superradiantDensity);
        rec.meanPhotonNumber = local_real_scalar(result.meanPhotonNumber);
        rec.meanAbsCurrent = local_real_scalar(result.meanAbsCurrent);
        rec.meanAbsChirality = local_real_scalar(result.meanAbsChirality);
        rec.maxCurrentDivergence = local_real_scalar(diag.maxCurrentDivergence);
        rec.maxChiralityDefinitionError = local_real_scalar(diag.maxChiralityDefinitionError);
        rec.phaseLabel = RabiH_ClassifyPhaseFromRecord(rec, thresholds);
        rec.matchesTarget = local_phase_matches(rec.phaseLabel, rec.targetPhase);
        if isfield(result,'backendInfo')
            rec.backendSelected = result.backendInfo.selected;
            rec.blockedTensorMB = local_real_scalar(result.backendInfo.risk.blockedTensorMB);
            rec.blockedInterMB = local_real_scalar(result.backendInfo.risk.estimatedNormIntermediateMB);
        end
        if saveEachPoint
            pointFile = fullfile(outDir,sprintf('stage4Q_point_%04d.mat',rec.index));
            save(pointFile,'result','diag','params','opts','p','rec');
            rec.pointFile = pointFile;
        end
    catch ME
        rec.status = 'error';
        rec.runtimeSeconds = toc(t0);
        rec.errorMessage = ME.message;
        if stopOnError
            records(k) = rec;
            rethrow(ME);
        end
    end
    records(k) = rec;
end

summary = RabiH_SummarizeAccuracyOverlayScan(records);
scan = struct();
scan.stage = 'StageRH4Q';
scan.description = 'Simple-update/resource accuracy overlay for article representatives.';
scan.paramsBase = paramsBase;
scan.optsBase = optsBase;
scan.scanSpec = spec;
scan.points = points;
scan.records = records;
scan.summary = summary;
scan.outputDir = outDir;
scan.runtimeSeconds = toc(startAll);
end

function rec = local_empty_record()
rec = struct();
rec.index = NaN;
rec.label = '';
rec.status = 'pending';
rec.branchName = '';
rec.targetPhase = '';
rec.phaseLabel = '';
rec.matchesTarget = false;
rec.backend = '';
rec.backendSelected = '';
rec.stage = '';
rec.dph = NaN;
rec.Dmax = NaN;
rec.chiMax = NaN;
rec.sharedBoundaryMix = NaN;
rec.gR = NaN;
rec.t = NaN;
rec.Phi = NaN;
rec.alphaSeed = NaN;
rec.alphaPattern = '';
rec.sourceEta = 0;
rec.sourcePhase = 0;
rec.scheduleName = '';
rec.nSweeps = NaN;
rec.tauListString = '';
rec.energyPerSite = NaN;
rec.superradiantDensity = NaN;
rec.meanPhotonNumber = NaN;
rec.meanAbsCurrent = NaN;
rec.meanAbsChirality = NaN;
rec.maxCurrentDivergence = NaN;
rec.maxChiralityDefinitionError = NaN;
rec.runtimeSeconds = NaN;
rec.blockedTensorMB = NaN;
rec.blockedInterMB = NaN;
rec.pointFile = '';
rec.errorMessage = '';
end

function tf = local_phase_matches(label,target)
if isempty(target)
    tf = true;
elseif strcmpi(target,'SR')
    tf = strcmpi(label,'SR') || strcmpi(label,'currentSR') || strcmpi(label,'chiralSR');
else
    tf = strcmpi(label,target);
end
end

function val = local_real_scalar(x)
if isempty(x)
    val = NaN;
else
    val = real(x(1));
end
end

function s = local_numvec_to_string(v)
if isempty(v), s = ''; return; end
s = sprintf('%.6g;',v(:));
if ~isempty(s), s = s(1:end-1); end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
