function figSet = RabiH_SC_BuildAnalyticBenchmarkFigureSet(out, outputDir)
%RabiH_SC_BuildAnalyticBenchmarkFigureSet Build StageRH4AG paper-style figures.
if nargin < 2 || isempty(outputDir), outputDir = out.spec.outputDir; end
if ~exist(outputDir,'dir'), mkdir(outputDir); end

figSet = struct();
figSet.outputDir = outputDir;
figSet.criticalFigure = local_plot_critical(out, outputDir);
figSet.phaseFigure = local_plot_phase(out, outputDir);
figSet.currentFigure = local_plot_current(out, outputDir);
end

function fileBase = local_plot_critical(out, outputDir)
crit = out.criticalMap;
fig = figure('Color','w','Position',[100 100 820 560]);
imagesc(crit.PhiList/pi, crit.lambdaList, crit.Gc);
set(gca,'YDir','normal'); colorbar;
xlabel('PhiSquare/pi','Interpreter','none');
ylabel('lambda = J2/J1','Interpreter','none');
title('Semiclassical normal-to-SR critical coupling g_c','Interpreter','none');
local_set_font(gca);
fileBase = fullfile(outputDir,'Fig_stage4AG_SC_critical_gc_map');
local_save(fig, fileBase);
close(fig);
end

function fileBase = local_plot_phase(out, outputDir)
ph = out.phaseMap;
fig = figure('Color','w','Position',[100 100 1150 760]);
subplot(2,2,1);
imagesc(ph.gList, ph.lambdaList, ph.rhoGL); set(gca,'YDir','normal'); colorbar;
xlabel('g','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('rhoSR^cl','Interpreter','none'); local_set_font(gca);
subplot(2,2,2);
imagesc(ph.gList, ph.lambdaList, ph.chiSqGL); set(gca,'YDir','normal'); colorbar;
xlabel('g','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('|chi square|','Interpreter','none'); local_set_font(gca);
subplot(2,2,3);
imagesc(ph.gList, ph.lambdaList, ph.chiTriGL); set(gca,'YDir','normal'); colorbar;
xlabel('g','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('mean |chi triangle|','Interpreter','none'); local_set_font(gca);
subplot(2,2,4);
imagesc(ph.gList, ph.lambdaList, ph.phaseCodeGL); set(gca,'YDir','normal'); colorbar;
xlabel('g','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('mean-field pattern code','Interpreter','none'); local_set_font(gca);
local_suptitle(sprintf('Stage4AG mean-field phase benchmark: Phi/pi=%.2f, thetaTri=0', ph.fixedPhi/pi));
fileBase = fullfile(outputDir,'Fig_stage4AG_SC_meanfield_phase_maps');
local_save(fig, fileBase);
close(fig);
end

function fileBase = local_plot_current(out, outputDir)
ph = out.phaseMap;
fig = figure('Color','w','Position',[100 100 1150 760]);
x = ph.thetaTriList/pi; y = ph.lambdaList;
subplot(2,2,1);
imagesc(x,y,ph.I13LT); set(gca,'YDir','normal'); colorbar;
xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('I13','Interpreter','none'); local_set_font(gca);
subplot(2,2,2);
imagesc(x,y,ph.I24LT); set(gca,'YDir','normal'); colorbar;
xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('I24','Interpreter','none'); local_set_font(gca);
subplot(2,2,3);
imagesc(x,y,ph.DiagSelLT); set(gca,'YDir','normal'); colorbar;
xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('I13 - I24','Interpreter','none'); local_set_font(gca);
subplot(2,2,4);
imagesc(x,y,ph.chiTriLT); set(gca,'YDir','normal'); colorbar;
xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none'); title('mean |chi triangle|','Interpreter','none'); local_set_font(gca);
local_suptitle(sprintf('Stage4AG semiclassical NNN current maps: g=%.2f, Phi/pi=%.2f', ph.fixedG, ph.fixedPhi/pi));
fileBase = fullfile(outputDir,'Fig_stage4AG_SC_NNN_current_maps');
local_save(fig, fileBase);
close(fig);
end

function local_save(fig, fileBase)
saveas(fig,[fileBase '.fig']);
print(fig,[fileBase '.png'],'-dpng','-r200');
print(fig,[fileBase '.pdf'],'-dpdf','-painters');
end

function local_set_font(ax)
set(ax,'FontSize',10,'LineWidth',0.8,'Box','on');
end

function local_suptitle(txt)
annotation('textbox',[0 0.955 1 0.04],'String',txt,'EdgeColor','none', ...
    'HorizontalAlignment','center','FontWeight','bold','FontSize',12,'Interpreter','none');
end
