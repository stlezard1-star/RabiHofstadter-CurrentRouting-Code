function ph = RabiH_SC_FluxPhases(params)
%RabiH_SC_FluxPhases  Gauge convention and loop fluxes for a 2x2 plaquette.
%
% Site labels:
%   4 ---- 3
%   |  \/  |
%   |  /\  |
%   1 ---- 2
%
% Directed NN bonds: 1->2, 2->3, 3->4, 4->1.
% Directed NNN bonds: 1->3 and 2->4.
%
% Gauge convention:
%   A12=0, A23=Phi/2, A34=0, A41=Phi/2, so Phi_square=sum A = Phi.
%   B13=thetaTri, B24=thetaTri for the symmetric triangular-imbalance convention.
% This gives
%   Phi123=Phi/2-theta, Phi134=Phi/2+theta,
%   Phi124=Phi/2+theta, Phi234=Phi/2-theta.

Phi = local_get(params,'PhiSquare',pi/2);
theta = local_get(params,'thetaTri',0.0);
mode = local_get(params,'thetaMode','symmetric');

ph = struct();
ph.A12 = 0.0;
ph.A23 = Phi/2;
ph.A34 = 0.0;
ph.A41 = Phi/2;

switch lower(mode)
    case {'symmetric','balanced','default'}
        ph.B13 = theta;
        ph.B24 = theta;
    case {'opposite'}
        ph.B13 = theta;
        ph.B24 = -theta;
    otherwise
        error('Unknown thetaMode: %s', mode);
end

ph.PhiSquare = ph.A12 + ph.A23 + ph.A34 + ph.A41;
ph.Phi123 = ph.A12 + ph.A23 - ph.B13;
ph.Phi134 = ph.B13 + ph.A34 + ph.A41;
ph.Phi124 = ph.A12 + ph.B24 + ph.A41;
ph.Phi234 = ph.A23 + ph.A34 - ph.B24;
ph.constraintErr13 = abs((ph.Phi123 + ph.Phi134) - ph.PhiSquare);
ph.constraintErr24 = abs((ph.Phi124 + ph.Phi234) - ph.PhiSquare);
end

function v = local_get(s, name, defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
