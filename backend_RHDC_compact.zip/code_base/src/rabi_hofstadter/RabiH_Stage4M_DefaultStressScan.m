function [params, opts, spec] = RabiH_Stage4M_DefaultStressScan()
%RABIH_STAGE4M_DEFAULTSTRESSSCAN Defaults for superradiance stress scans.
%
% StageRH4M is a diagnostic layer after StageRH4L.  Stage4L's light scan can
% easily remain in the normal phase because it uses a modest gR range and
% small coherent seeds.  This stress scan intentionally pushes stronger Rabi
% coupling, larger hopping, and larger coherent seed amplitudes.  It also
% supports an optional uniform photon source field sourceEta for branch
% selection diagnostics.  Physical article data should use sourceEta=0 or an
% eta -> 0 extrapolation.

[params, opts, spec] = RabiH_Stage4L_DefaultPrelimScan();

params.dph = 5;
params.gR = 1.00;
params.t = 0.12;
params.tX = params.t;
params.tY = params.t;
params.Phi = pi;
params.alphaSeed = 0.50;
params.alphaPattern = 'uniform';
params.sourceEta = 0;
params.sourcePhase = 0;

opts.Dmax = 2;
opts.chiMax = 6;
opts.maxIter = 5;
opts.sharedMaxIter = 5;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.sharedBoundaryMix = 0.0;
opts.outputDir = fullfile(pwd,'results_stage4M_sr_stress');
opts.saveEachPoint = true;

spec.name = 'StageRH4M_superradiance_stress_scan';
spec.description = ['Stress scan for detecting nonzero-alpha branches after ' ...
    'StageRH4L produced only normal-phase best seeds.  This diagnostic uses ' ...
    'larger gR, larger coherent seeds, and optional uniform photon sourceEta.'];
spec.backend = 'splitFactoredShared';
spec.DmaxList = 2;
spec.chiMaxList = 6;
spec.dphList = 5;
spec.alphaSeedList = [0 0.20 0.50 0.80 1.20];
spec.alphaPatternList = {'uniform','checkerboard','vortex2x2','landau'};
spec.sharedBoundaryMixList = 0;
spec.gRList = [0.60 0.90 1.20 1.50];
spec.tList = [0.08 0.14 0.20];
spec.PhiList = [0 pi/2 pi];
spec.sourceEtaList = 0;
spec.sourcePhaseList = 0;
spec.groupByFields = {'dph','Dmax','chiMax','sharedBoundaryMix','gR','t','Phi','sourceEta','sourcePhase'};
spec.bestSeedCriterion = 'minEnergy';
spec.phaseThresholds = struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5);
spec.maxPoints = Inf;
spec.stopOnError = false;
spec.tag = datestr(now,'yyyymmdd_HHMMSS');
end
