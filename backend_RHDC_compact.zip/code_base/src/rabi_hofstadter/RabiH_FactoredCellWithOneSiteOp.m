function fcell = RabiH_FactoredCellWithOneSiteOp(unitCell, op, targetX, targetY, opts)
%RABIH_FACTOREDCELLWITHONESITEOP Factored double-layer cell with one-site insertion.
%
% This is the factored analogue of CTM_BlockUnitCell_OneSiteOp, but it
% returns an unblocked cell container instead of a 4-leg blocked tensor.

    if nargin < 5 || isempty(opts), opts = struct(); end
    iPEPS_CheckUnitCell(unitCell);
    x = mod(targetX-1, unitCell.Lx) + 1;
    y = mod(targetY-1, unitCell.Ly) + 1;
    opCell = cell(unitCell.Ly, unitCell.Lx);
    for yy = 1:unitCell.Ly
        for xx = 1:unitCell.Lx
            opCell{yy,xx} = [];
        end
    end
    opCell{y,x} = op;
    fcell = RabiH_FactoredCellConstruct(unitCell, opts, opCell);
    fcell.insertionType = 'one_site';
    fcell.targetX = x;
    fcell.targetY = y;
end
