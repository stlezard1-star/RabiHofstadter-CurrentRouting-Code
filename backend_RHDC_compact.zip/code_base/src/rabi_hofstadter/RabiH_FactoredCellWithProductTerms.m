function termCells = RabiH_FactoredCellWithProductTerms(unitCell, terms, x1, y1, x2, y2, opts)
%RABIH_FACTOREDCELLWITHPRODUCTTERMS Factored cells for product-op term insertions.
%
%   termCells{k}.coeff * termCells{k}.fcell represents one product term.
%   No term is summed into a blocked tensor.  A future factored CTM backend
%   should contract each term against the same environment and sum scalars.

    if nargin < 7 || isempty(opts), opts = struct(); end
    iPEPS_CheckUnitCell(unitCell);
    x1 = mod(x1-1, unitCell.Lx) + 1;
    x2 = mod(x2-1, unitCell.Lx) + 1;
    y1 = mod(y1-1, unitCell.Ly) + 1;
    y2 = mod(y2-1, unitCell.Ly) + 1;
    if x1 == x2 && y1 == y2
        error('RabiH_FactoredCellWithProductTerms:SameSite', ...
            'Use RabiH_FactoredCellWithOneSiteOp for a same-site operator.');
    end

    termCells = repmat(struct('coeff',[],'fcell',[]), numel(terms), 1);
    for k = 1:numel(terms)
        opCell = cell(unitCell.Ly, unitCell.Lx);
        for yy = 1:unitCell.Ly
            for xx = 1:unitCell.Lx
                opCell{yy,xx} = [];
            end
        end
        opCell{y1,x1} = terms(k).opA;
        opCell{y2,x2} = terms(k).opB;
        fc = RabiH_FactoredCellConstruct(unitCell, opts, opCell);
        fc.insertionType = 'two_site_product_term';
        fc.x1 = x1; fc.y1 = y1; fc.x2 = x2; fc.y2 = y2;
        termCells(k).coeff = terms(k).coeff;
        termCells(k).fcell = fc;
    end
end
