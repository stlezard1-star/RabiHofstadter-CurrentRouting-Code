function out = RabiH_SC_RunAnalyticBenchmark(paramsBase, spec)
%RabiH_SC_RunAnalyticBenchmark StageRH4AG analytic/semi-classical benchmark maps.
if nargin < 1 || isempty(paramsBase), paramsBase = RabiH_SC_DefaultParams(); end
if nargin < 2 || isempty(spec), spec = RabiH_SC_DefaultAnalyticBenchmarkSpec(); end
if ~exist(spec.outputDir,'dir'), mkdir(spec.outputDir); end

crit = local_run_critical_map(paramsBase, spec);
phase = local_run_phase_map(paramsBase, spec);

tag = struct();
tag.stage = 'StageRH4AG';
tag.description = 'semiclassical analytic benchmark: Hessian gc + coherent-state phase maps';

out = struct();
out.stage = 'StageRH4AG';
out.paramsBase = paramsBase;
out.spec = spec;
out.criticalMap = crit;
out.phaseMap = phase;
out.summary = local_summary(crit, phase);
out.tag = tag;

RabiH_SC_WriteAnalyticBenchmarkCSV(out, spec.outputDir);
save(fullfile(spec.outputDir,'stage4AG_analytic_benchmark.mat'),'out');
end

function crit = local_run_critical_map(paramsBase, spec)
PhiList = spec.PhiList(:).';
lamList = spec.lambdaList(:).';
Gc = nan(numel(lamList),numel(PhiList));
status = cell(numel(lamList),numel(PhiList));
minEig0 = nan(size(Gc));
for a=1:numel(lamList)
    for b=1:numel(PhiList)
        p = paramsBase;
        p.J1 = spec.J1;
        p.lambda = lamList(a);
        p.J2 = [];
        p.PhiSquare = PhiList(b);
        p.thetaTri = spec.fixedThetaForCritical;
        c = RabiH_SC_CriticalG(p);
        Gc(a,b) = c.gc;
        status{a,b} = c.status;
        minEig0(a,b) = c.minEigAtZero;
    end
end
crit = struct();
crit.PhiList = PhiList;
crit.lambdaList = lamList;
crit.Gc = Gc;
crit.status = status;
crit.minEigAtZero = minEig0;
crit.fixedTheta = spec.fixedThetaForCritical;
end

function phase = local_run_phase_map(paramsBase, spec)
lamList = spec.lambdaList(:).';
thetaList = spec.thetaTriList(:).';
gList = spec.gList(:).';

% Map A: phase in (g,lambda) at fixed Phi=pi/2 and theta=0.
phaseCodeGL = nan(numel(lamList), numel(gList));
rhoGL = nan(size(phaseCodeGL));
chiSqGL = nan(size(phaseCodeGL));
chiTriGL = nan(size(phaseCodeGL));
labelGL = cell(size(phaseCodeGL));
for a=1:numel(lamList)
    for b=1:numel(gList)
        p = paramsBase;
        p.J1 = spec.J1;
        p.lambda = lamList(a); p.J2=[];
        p.g = gList(b);
        p.PhiSquare = spec.fixedPhiForNNN;
        p.thetaTri = 0;
        r = RabiH_SC_MinimizeOnePoint(p, struct('nStarts',spec.nStarts,'verbose',false));
        o = r.obs;
        phaseCodeGL(a,b) = o.patternCode;
        rhoGL(a,b) = o.rhoSR;
        chiSqGL(a,b) = abs(o.chiSquare);
        chiTriGL(a,b) = o.meanAbsTriangularChirality;
        labelGL{a,b} = o.patternLabel;
    end
end

% Map B: current redistribution in (lambda,theta) at fixed g and Phi.
phaseCodeLT = nan(numel(lamList), numel(thetaList));
rhoLT = nan(size(phaseCodeLT));
chiSqLT = nan(size(phaseCodeLT));
chiTriLT = nan(size(phaseCodeLT));
I13LT = nan(size(phaseCodeLT));
I24LT = nan(size(phaseCodeLT));
DiagSelLT = nan(size(phaseCodeLT));
labelLT = cell(size(phaseCodeLT));
for a=1:numel(lamList)
    for b=1:numel(thetaList)
        p = paramsBase;
        p.J1 = spec.J1;
        p.lambda = lamList(a); p.J2=[];
        p.g = spec.fixedGForTheta;
        p.PhiSquare = spec.fixedPhiForNNN;
        p.thetaTri = thetaList(b);
        r = RabiH_SC_MinimizeOnePoint(p, struct('nStarts',spec.nStarts,'verbose',false));
        o = r.obs;
        phaseCodeLT(a,b) = o.patternCode;
        rhoLT(a,b) = o.rhoSR;
        chiSqLT(a,b) = abs(o.chiSquare);
        chiTriLT(a,b) = o.meanAbsTriangularChirality;
        I13LT(a,b) = o.I13;
        I24LT(a,b) = o.I24;
        DiagSelLT(a,b) = o.I13-o.I24;
        labelLT{a,b} = o.patternLabel;
    end
end

phase = struct();
phase.lambdaList = lamList;
phase.gList = gList;
phase.thetaTriList = thetaList;
phase.fixedPhi = spec.fixedPhiForNNN;
phase.fixedG = spec.fixedGForTheta;
phase.phaseCodeGL = phaseCodeGL;
phase.rhoGL = rhoGL;
phase.chiSqGL = chiSqGL;
phase.chiTriGL = chiTriGL;
phase.labelGL = labelGL;
phase.phaseCodeLT = phaseCodeLT;
phase.rhoLT = rhoLT;
phase.chiSqLT = chiSqLT;
phase.chiTriLT = chiTriLT;
phase.I13LT = I13LT;
phase.I24LT = I24LT;
phase.DiagSelLT = DiagSelLT;
phase.labelLT = labelLT;
end

function s = local_summary(crit, phase)
s = struct();
s.gcMin = min(crit.Gc(:));
s.gcMax = max(crit.Gc(:));
s.maxRhoGL = max(phase.rhoGL(:));
s.maxChiSqGL = max(phase.chiSqGL(:));
s.maxChiTriGL = max(phase.chiTriGL(:));
s.maxAbsI13LT = max(abs(phase.I13LT(:)));
s.maxAbsI24LT = max(abs(phase.I24LT(:)));
s.hasDiagSignChange = (min(phase.I13LT(:)) < 0 && max(phase.I13LT(:)) > 0) || (min(phase.I24LT(:)) < 0 && max(phase.I24LT(:)) > 0);
s.hasTriangularSignal = max(phase.chiTriLT(:)) > 1e-6;
end
