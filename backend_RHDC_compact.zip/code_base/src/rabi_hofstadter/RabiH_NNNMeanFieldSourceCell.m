function [etaCell, info] = RabiH_NNNMeanFieldSourceCell(params, Lx, Ly, alphaCell)
%RABIH_NNNMEANFIELDSOURCECELL Site-resolved mean-field source from NNN hopping.
%
%   The diagonal hopping term
%       -J2 ( exp(iB_ij) a_i^dag a_j + h.c. )
%   is decoupled as a source field on each endpoint:
%       H_i^MF = -(conj(eta_i) a_i + eta_i a_i^dag)
%   with eta_i += J2 exp(iB_ij) alpha_j for an oriented bond i->j.
%
%   This is a cheap NNN-aware update layer for StageRH4X.  It is not a
%   substitute for a full plaquette/long-range diagonal PEPS update, but it
%   allows the variational state to respond to J2 and triangular phases.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(Lx), Lx = RabiH_GetOpt(params,'Lx',2); end
    if nargin < 3 || isempty(Ly), Ly = RabiH_GetOpt(params,'Ly',2); end
    if nargin < 4 || isempty(alphaCell)
        alpha0 = RabiH_GetOpt(params,'alphaSeed',RabiH_GetOpt(params,'alpha',0));
        pat = RabiH_GetOpt(params,'alphaPattern','uniform');
        alphaCell = RabiH_AlphaPattern(Lx,Ly,pat,alpha0,params);
    end
    if isscalar(alphaCell), alphaCell = alphaCell*ones(Ly,Lx); end
    if ~isequal(size(alphaCell),[Ly Lx])
        error('RabiH_NNNMeanFieldSourceCell:SizeMismatch','alphaCell must be Ly-by-Lx.');
    end

    J2 = RabiH_GetNNNHopping(params);
    includeNNN = RabiH_GetOpt(params,'includeNNN',abs(J2)>0);
    etaCell = zeros(Ly,Lx);
    if ~includeNNN || abs(J2)==0
        info = local_info(etaCell, alphaCell, J2);
        return;
    end

    wrapx = @(x) mod(x-1,Lx)+1;
    wrapy = @(y) mod(y-1,Ly)+1;
    dirs = {'diagp','diagm'};
    for y = 1:Ly
        for x = 1:Lx
            for id = 1:numel(dirs)
                bs = RabiH_BondSpec(x,y,dirs{id},params,Lx,Ly);
                y2 = bs.y2; x2 = bs.x2;
                ph = bs.phase;
                % Oriented bond i=(x,y) -> j=(x2,y2).
                etaCell(y,x)   = etaCell(y,x)   + J2*exp( 1i*ph)*alphaCell(y2,x2);
                etaCell(y2,x2) = etaCell(y2,x2) + J2*exp(-1i*ph)*alphaCell(y,x);
            end
        end
    end
    info = local_info(etaCell, alphaCell, J2);
end

function info = local_info(etaCell, alphaCell, J2)
    info = struct();
    info.J2 = J2;
    info.alphaCell = alphaCell;
    info.etaCell = etaCell;
    info.maxAbsEta = max(abs(etaCell(:)));
    info.meanAbsEta = mean(abs(etaCell(:)));
    info.note = 'StageRH4X NNN mean-field source eta_i from diagonal hopping.';
end
