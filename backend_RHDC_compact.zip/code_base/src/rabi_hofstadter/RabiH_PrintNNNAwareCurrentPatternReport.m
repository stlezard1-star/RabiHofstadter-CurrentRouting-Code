function RabiH_PrintNNNAwareCurrentPatternReport(scan)
%RABIH_PRINTNNNAWARECURRENTPATTERNREPORT Wrapper for Stage4X report.
    fprintf('--- RabiH StageRH4X NNN-aware current-pattern report ---\n');
    RabiH_PrintNNNCurrentPatternReport(scan);
end
