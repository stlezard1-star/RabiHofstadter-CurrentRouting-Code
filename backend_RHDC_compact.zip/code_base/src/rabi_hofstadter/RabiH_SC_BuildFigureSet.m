function figSet = RabiH_SC_BuildFigureSet(baselineScan, nnnScan, spec)
%RabiH_SC_BuildFigureSet  Build publication-style semiclassical figures.
if nargin < 3 || isempty(spec)
    spec = RabiH_SC_DefaultScanSpec();
end
outDir = spec.outputDir;
if ~exist(outDir,'dir'), mkdir(outDir); end

figSet = struct();
figSet.outputDir = outDir;
figSet.baselineFigure = local_plot_baseline_maps(baselineScan, spec);
figSet.nnnFigure = local_plot_nnn_maps(nnnScan, spec);
figSet.arrowFigure = local_plot_arrows(nnnScan, spec);

local_save_figure(figSet.baselineFigure, fullfile(outDir,'Fig_stage4AF_SC_baseline_maps'), spec.figure.formats);
local_save_figure(figSet.nnnFigure, fullfile(outDir,'Fig_stage4AF_SC_NNN_pattern_maps'), spec.figure.formats);
local_save_figure(figSet.arrowFigure, fullfile(outDir,'Fig_stage4AF_SC_representative_arrows'), spec.figure.formats);

figSet.baselineFigureFile = fullfile(outDir,'Fig_stage4AF_SC_baseline_maps.png');
figSet.nnnFigureFile = fullfile(outDir,'Fig_stage4AF_SC_NNN_pattern_maps.png');
figSet.arrowFigureFile = fullfile(outDir,'Fig_stage4AF_SC_representative_arrows.png');
end

function h = local_plot_baseline_maps(scan, spec)
records = scan.records(strcmp({scan.records.status},'ok') & strcmp({scan.records.scanKind},'baseline'));
if isempty(records), error('No baseline records available.'); end
x = unique([records.PhiSquare]/pi);
y = unique([records.g]);
Zrho = local_grid(records,'PhiSquare','g','rhoSR',x*pi,y);
Zchi = local_grid(records,'PhiSquare','g','absChiSquare',x*pi,y);
Zcode = local_grid(records,'PhiSquare','g','patternCode',x*pi,y);
Ztri = local_grid(records,'PhiSquare','g','meanAbsChiTri',x*pi,y);

h = figure('Color','w','Position',[100 100 1200 760]);
subplot(2,2,1); imagesc(x,y,Zrho); set(gca,'YDir','normal'); colorbar; xlabel('PhiSq/pi'); ylabel('g'); title('rho_{SR}^{cl}','Interpreter','none');
subplot(2,2,2); imagesc(x,y,Zchi); set(gca,'YDir','normal'); colorbar; xlabel('PhiSq/pi'); ylabel('g'); title('|chi_square|','Interpreter','none');
subplot(2,2,3); imagesc(x,y,Ztri); set(gca,'YDir','normal'); colorbar; xlabel('PhiSq/pi'); ylabel('g'); title('mean |chi_triangle|','Interpreter','none');
subplot(2,2,4); imagesc(x,y,Zcode); set(gca,'YDir','normal'); colorbar; xlabel('PhiSq/pi'); ylabel('g'); title('pattern code','Interpreter','none');
local_suptitle(sprintf('Semiclassical NN baseline: J1=%.3g, lambda=0', spec.baseline.J1));
end

function h = local_plot_nnn_maps(scan, spec)
records = scan.records(strcmp({scan.records.status},'ok') & strcmp({scan.records.scanKind},'nnn'));
if isempty(records), error('No NNN records available.'); end
x = unique([records.thetaTri]/pi);
y = unique([records.lambda]);
Zdiag = local_grid(records,'thetaTri','lambda','absIDiag',x*pi,y);
Ztri = local_grid(records,'thetaTri','lambda','meanAbsChiTri',x*pi,y);
Zsel = local_grid(records,'thetaTri','lambda','I13MinusI24',x*pi,y);
Zchis = local_grid(records,'thetaTri','lambda','chiTriSigned13',x*pi,y);
Zratio = local_grid(records,'thetaTri','lambda','triRatio',x*pi,y);
ZdiagSel = local_grid(records,'thetaTri','lambda','diagSelectionRatio',x*pi,y);

h = figure('Color','w','Position',[100 100 1350 860]);
subplot(2,3,1); imagesc(x,y,Zdiag); set(gca,'YDir','normal'); colorbar; xlabel('thetaTri/pi'); ylabel('lambda = J2/J1'); title('|I_diag|','Interpreter','none');
subplot(2,3,2); imagesc(x,y,Ztri); set(gca,'YDir','normal'); colorbar; xlabel('thetaTri/pi'); ylabel('lambda = J2/J1'); title('mean |chi_triangle|','Interpreter','none');
subplot(2,3,3); imagesc(x,y,Zratio); set(gca,'YDir','normal'); colorbar; xlabel('thetaTri/pi'); ylabel('lambda = J2/J1'); title('triRatio','Interpreter','none');
subplot(2,3,4); imagesc(x,y,Zsel); set(gca,'YDir','normal'); colorbar; xlabel('thetaTri/pi'); ylabel('lambda = J2/J1'); title('I13 - I24','Interpreter','none'); colormap(gca,local_redblue(256));
subplot(2,3,5); imagesc(x,y,Zchis); set(gca,'YDir','normal'); colorbar; xlabel('thetaTri/pi'); ylabel('lambda = J2/J1'); title('chi123 - chi134','Interpreter','none'); colormap(gca,local_redblue(256));
subplot(2,3,6); imagesc(x,y,ZdiagSel); set(gca,'YDir','normal'); colorbar; xlabel('thetaTri/pi'); ylabel('lambda = J2/J1'); title('diag selection ratio','Interpreter','none');
local_suptitle(sprintf('Semiclassical NNN current-pattern maps: g=%.3g, J1=%.3g, PhiSq/pi=%.3g', spec.nnn.g, spec.nnn.J1, spec.nnn.PhiSquare/pi));
end

function h = local_plot_arrows(scan, spec)
records = scan.records(strcmp({scan.records.status},'ok') & strcmp({scan.records.scanKind},'nnn'));
if isempty(records), error('No NNN records available for arrow plot.'); end
cases = spec.figure.selectedCases;
h = figure('Color','w','Position',[100 100 1200 900]);
for c = 1:size(cases,1)
    lam = cases(c,1); thpi = cases(c,2);
    rec = local_find_nearest(records, lam, thpi);
    subplot(2,2,c);
    local_draw_current_pattern(rec);
    title(sprintf('(%c) lambda=%.2g, thetaTri/pi=%.2g', char('a'+c-1), rec.lambda, rec.thetaTri/pi),'Interpreter','none');
    xlabel(sprintf('%s\n|chiSq|=%.3g, mean|chiTri|=%.3g, I13=%.3g, I24=%.3g', ...
        rec.patternLabel, abs(rec.chiSquare), rec.meanAbsChiTri, rec.I13, rec.I24),'Interpreter','none');
end
local_suptitle(sprintf('Semiclassical representative loop-current patterns: g=%.3g, J1=%.3g', spec.nnn.g, spec.nnn.J1));
end

function local_draw_current_pattern(rec)
cla; hold on; axis equal off;
pts = [0 0; 1 0; 1 1; 0 1];
plot([0 1 1 0 0],[0 0 1 1 0],'k-','LineWidth',1.5);
plot([0 1],[0 1],'k:','LineWidth',0.8);
plot([1 0],[0 1],'k:','LineWidth',0.8);
text(pts(:,1)-0.05, pts(:,2)-0.06, {'1','2','3','4'},'FontSize',10);
vals = [rec.I12 rec.I23 rec.I34 rec.I41 rec.I13 rec.I24];
maxv = max(abs(vals)); if maxv < 1e-12, maxv = 1; end
scale = 0.30/maxv;
local_arrow(pts(1,:),pts(2,:),rec.I12,scale,[0 0.4 1]);
local_arrow(pts(2,:),pts(3,:),rec.I23,scale,[0.9 0.2 0]);
local_arrow(pts(3,:),pts(4,:),rec.I34,scale,[0 0.4 1]);
local_arrow(pts(4,:),pts(1,:),rec.I41,scale,[0.9 0.2 0]);
local_arrow(pts(1,:),pts(3,:),rec.I13,scale,[0.55 0 0.65]);
local_arrow(pts(2,:),pts(4,:),rec.I24,scale,[0.95 0.55 0]);
xlim([-0.15 1.15]); ylim([-0.15 1.15]);
end

function local_arrow(p1,p2,I,scale,color)
if abs(I) < 1e-12, return; end
if I >= 0
    a = p1; b = p2;
else
    a = p2; b = p1;
end
mid = (a+b)/2; dir = b-a; len = norm(dir); if len==0, return; end
u = dir/len; L = min(0.42, abs(I)*scale);
start = mid - 0.5*L*u; delta = L*u;
quiver(start(1),start(2),delta(1),delta(2),0,'Color',color,'LineWidth',1.2+5*abs(I)*scale,'MaxHeadSize',0.8);
end

function Z = local_grid(records, xField, yField, zField, xVals, yVals)
Z = NaN(numel(yVals), numel(xVals));
for k=1:numel(records)
    rx = records(k).(xField); ry = records(k).(yField);
    [~,ix] = min(abs(xVals-rx)); [~,iy] = min(abs(yVals-ry));
    Z(iy,ix) = records(k).(zField);
end
end

function rec = local_find_nearest(records, lambda, thetaOverPi)
vals = zeros(1,numel(records));
for k=1:numel(records)
    vals(k) = abs(records(k).lambda-lambda) + abs(records(k).thetaTri/pi-thetaOverPi);
end
[~,idx] = min(vals);
rec = records(idx);
end

function local_save_figure(h, base, formats)
for k=1:numel(formats)
    fmt = formats{k};
    try
        switch lower(fmt)
            case 'fig'
                saveas(h,[base '.fig']);
            case 'pdf'
                set(h,'PaperPositionMode','auto');
                print(h,[base '.pdf'],'-dpdf','-painters');
            otherwise
                print(h,[base '.' fmt],['-d' fmt],'-r300');
        end
    catch ME
        warning('Could not save %s.%s: %s', base, fmt, ME.message);
    end
end
end

function local_suptitle(str)
annotation('textbox',[0 0.955 1 0.04],'String',str,'HorizontalAlignment','center', ...
    'VerticalAlignment','middle','EdgeColor','none','FontWeight','bold','Interpreter','none');
end

function cmap = local_redblue(n)
if nargin<1, n=256; end
x = linspace(-1,1,n)';
r = max(0,x);
b = max(0,-x);
g = 1-abs(x);
cmap = [r g b];
cmap = 0.15 + 0.85*cmap;
end
