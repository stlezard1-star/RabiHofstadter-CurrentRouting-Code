function params = RabiH_SC_DefaultParams()
%RabiH_SC_DefaultParams  Default parameters for semiclassical Rabi-Hofstadter analysis.
%
% This semiclassical module is independent of the iPEPS tensors. It treats
% alpha_i=<a_i> as complex coherent amplitudes on a 2x2 plaquette and
% minimizes a coherent-state energy functional.

params = struct();
params.omega = 1.0;
params.Delta = 1.0;
params.g = 1.0;
params.J1 = 0.16;
params.lambda = 0.0;       % J2/J1
params.J2 = [];            % if nonempty, overrides lambda*J1
params.PhiSquare = pi/2;
params.thetaTri = 0.0;
params.thetaMode = 'symmetric'; % B13=B24=thetaTri by default
params.description = 'StageRH4AF semiclassical coherent-state model';
end
