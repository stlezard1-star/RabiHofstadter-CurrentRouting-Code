function result = RabiH_RunOnePoint_CoherentSU_SplitSharedCTM(params, opts)
%RABIH_RUNONEPOINT_COHERENTSU_SPLITSHAREDCTM Coherent SU + StageRH4J CTM.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end

    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
    if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
    if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
    if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

    unitCell0 = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
    [unitCell, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(unitCell0, params, opts);

    ctmOpts = opts;
    ctmOpts.ctmBackend = 'splitFactoredShared';
    ctmOpts.splitBackendMode = 'shared';
    obs = RabiH_CTMObservables_SplitFactoredShared(unitCell, params, ctmOpts);

    result = struct();
    result.unitCell = unitCell;
    result.obs = obs;
    result.suInfo = suInfo;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanPhotonNumber = obs.meanPhotonNumber;
    result.meanAbsCurrent = obs.meanAbsCurrent;
    result.meanAbsChirality = obs.meanAbsChirality;
    result.backend = obs.backend;
    result.stage = 'StageRH4J';
    result.note = ['Coherent seed + NN simple update + StageRH4J shared/cached ' ...
                   'periodic split/factored CTM.  Use for convergence scans and profiling.'];
end
