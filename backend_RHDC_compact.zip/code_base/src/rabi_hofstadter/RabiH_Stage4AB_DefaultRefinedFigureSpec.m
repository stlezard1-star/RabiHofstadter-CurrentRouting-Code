function spec = RabiH_Stage4AB_DefaultRefinedFigureSpec()
%RABIH_STAGE4AB_DEFAULTREFINEDFIGURESPEC Defaults for refined NNN-current figures.
spec = struct();
spec.outputDir = fullfile(pwd,'results_stage4AB_refined_nnn_patterns');
spec.makeVisible = false;
spec.targetG = 1.4;
spec.targetJ1 = 0.16;
spec.triEnhancedRatio = 0.70;
spec.squareDominantRatio = 0.55;
spec.diagSelectedRatio = 0.60;
spec.rhoThreshold = 1e-4;
spec.chiralityThreshold = 1e-5;
spec.currentThreshold = 1e-6;
spec.unsignedFields = {'meanAbsDiagCurrent','meanAbsSquareChirality','meanAbsTriangularChirality','triangularImbalance'};
spec.unsignedTitles = {'|I diag|','|chi square|','mean |chi triangle|','triangular imbalance'};
spec.signedFields = {'j13','j24','j13Minusj24','chiTriSigned13'};
spec.signedTitles = {'I13','I24','I13 - I24','chi123 - chi134'};
spec.arrowCases = [-0.6 -0.25; -0.6 0; 0.6 0; 0.6 0.25];
end
