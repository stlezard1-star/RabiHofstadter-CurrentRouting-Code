function out = RabiH_WriteStage4ADManuscriptUpdate(spec)
%RABIH_WRITESTAGE4ADMANUSCRIPTUPDATE Copy NNN manuscript draft files to output folder.
if nargin < 1 || isempty(spec), spec = RabiH_Stage4AD_DefaultManuscriptSpec(); end
outDir = local_get(spec,'outputDir',fullfile(pwd,'results_stage4AD_manuscript_update'));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
srcDir = local_get(spec,'sourceDir','');
if isempty(srcDir) || exist(srcDir,'dir') ~= 7
    error('RabiH_WriteStage4ADManuscriptUpdate:MissingSource','Missing Stage4AD sourceDir: %s',srcDir);
end
names = {local_get(spec,'texName','RabiH_manuscript_NNN_draft_v2.tex'), ...
         local_get(spec,'pdfName','RabiH_manuscript_NNN_draft_v2.pdf'), ...
         local_get(spec,'bibName','references_v2.bib')};
for k = 1:numel(names)
    src = fullfile(srcDir,names{k});
    if exist(src,'file') ~= 2
        error('RabiH_WriteStage4ADManuscriptUpdate:MissingFile','Missing file: %s',src);
    end
    copyfile(src,fullfile(outDir,names{k}));
end
% Copy figures/data as subdirectories when present.
for sub = {'figures','data'}
    s = fullfile(srcDir,sub{1}); d = fullfile(outDir,sub{1});
    if exist(s,'dir') == 7
        if exist(d,'dir') == 7, rmdir(d,'s'); end
        copyfile(s,d);
    end
end
readmeFile = fullfile(outDir,local_get(spec,'readmeName','README_Stage4AD_manuscript_update.txt'));
fid = fopen(readmeFile,'w');
if fid < 0, error('Cannot write %s',readmeFile); end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'StageRH4AD manuscript update\n');
fprintf(fid,'================================\n\n');
fprintf(fid,'This folder contains a manuscript draft updated after the NNN current-pattern analysis.\n');
fprintf(fid,'Main physics line:\n');
fprintf(fid,'  NN flux establishes a square-loop chiral-superradiant background.\n');
fprintf(fid,'  NNN diagonal hopping and triangular-flux imbalance redistribute the current into diagonal and triangular loop channels.\n\n');
fprintf(fid,'Files:\n');
fprintf(fid,'  %s\n  %s\n  %s\n',names{1},names{2},names{3});
fprintf(fid,'Figures are in figures/. Data tables are in data/.\n');

out = struct();
out.stage = 'StageRH4AD';
out.outputDir = outDir;
out.texFile = fullfile(outDir,names{1});
out.pdfFile = fullfile(outDir,names{2});
out.bibFile = fullfile(outDir,names{3});
out.readmeFile = readmeFile;
end
function v = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = S.(name); else, v = defaultVal; end
end
