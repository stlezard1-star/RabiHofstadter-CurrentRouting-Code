function summary = RabiH_SummarizeLBOPEPSBenchmark(records)
%RABIH_SUMMARIZELBOPEPSBENCHMARK Summarize StageRH4S records.
summary = struct();
summary.numRecords = numel(records);
ok = arrayfun(@(r) strcmpi(r.status,'ok'), records);
summary.numOK = sum(ok);
summary.numError = sum(~ok);
if any(ok)
    rr = records(ok);
    summary.maxAbsDE = max([rr.absDE]);
    summary.maxRelRhoSR = max([rr.relRhoSR]);
    summary.maxRelCurrent = max([rr.relCurrent]);
    summary.maxRelChirality = max([rr.relChirality]);
    phaseError = arrayfun(@(r) strcmpi(r.fullPhase,'error') || strcmpi(r.lboPhase,'error') || isempty(r.fullPhase) || isempty(r.lboPhase), rr);
    summary.numPhaseError = sum(phaseError);
    if all(phaseError)
        summary.phaseMatchFraction = 0;
    else
        summary.phaseMatchFraction = mean([rr(~phaseError).phaseMatch]);
    end
    summary.phaseMatchFractionRaw = mean([rr.phaseMatch]);
    summary.minHopDimReduction = min([rr.hopDimReduction]);
    summary.maxHopDimReduction = max([rr.hopDimReduction]);
    summary.maxLocalSpectrumError = max([rr.localSpectrumMaxError]);
    summary.minLocalSpectrumError = min([rr.localSpectrumMaxError]);
    summary.meanSpeedup = mean([rr.fullRuntimeSeconds]./max([rr.lboRuntimeSeconds],eps));
else
    summary.maxAbsDE = NaN;
    summary.maxRelRhoSR = NaN;
    summary.maxRelCurrent = NaN;
    summary.maxRelChirality = NaN;
    summary.phaseMatchFraction = NaN;
    summary.phaseMatchFractionRaw = NaN;
    summary.numPhaseError = NaN;
    summary.minHopDimReduction = NaN;
    summary.maxHopDimReduction = NaN;
    summary.maxLocalSpectrumError = NaN;
    summary.minLocalSpectrumError = NaN;
    summary.meanSpeedup = NaN;
end
end
