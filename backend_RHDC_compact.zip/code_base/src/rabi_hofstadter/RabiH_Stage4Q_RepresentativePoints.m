function reps = RabiH_Stage4Q_RepresentativePoints()
%RABIH_STAGE4Q_REPRESENTATIVEPOINTS Article-figure branches for accuracy overlay.
%
% These representatives are selected from StageRH4M/4N/4O:
%   normal_weak        : no SR order
%   sr_uniform         : uniform SR, no chiral current
%   chiral_midflux     : finite current/chirality at Phi=pi/2
%   chiral_stronghop   : stronger chiral branch at larger t
%   max_chiral_stage4O : current maximum from the first refined Stage4O map

reps = repmat(local_empty_rep(),1,5);
reps(1) = local_rep('normal_weak',        'normal',   0.60, 0.08, 0,    0.00, 'uniform');
reps(2) = local_rep('sr_uniform',         'SR',       1.00, 0.08, 0,    0.80, 'uniform');
reps(3) = local_rep('chiral_midflux',     'chiralSR', 1.00, 0.08, pi/2, 0.80, 'uniform');
reps(4) = local_rep('chiral_stronghop',   'chiralSR', 1.40, 0.16, pi/2, 0.80, 'uniform');
reps(5) = local_rep('max_chiral_stage4O', 'chiralSR', 1.50, 0.16, pi/2, 1.20, 'uniform');
end

function r = local_rep(name,target,gR,t,Phi,alpha,pattern)
r = local_empty_rep();
r.name = name;
r.targetPhase = target;
r.gR = gR;
r.t = t;
r.Phi = Phi;
r.alphaSeed = alpha;
r.alphaPattern = pattern;
end

function r = local_empty_rep()
r = struct('name','','targetPhase','','gR',NaN,'t',NaN,'Phi',NaN, ...
    'alphaSeed',NaN,'alphaPattern','uniform');
end
