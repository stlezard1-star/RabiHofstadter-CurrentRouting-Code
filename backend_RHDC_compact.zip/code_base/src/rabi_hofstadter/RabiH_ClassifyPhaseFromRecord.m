function label = RabiH_ClassifyPhaseFromRecord(r, thresholds)
%RABIH_CLASSIFYPHASEFROMRECORD Lightweight diagnostic phase label.
%
% This is a plotting/triage label, not a physics proof.  Final phase
% identification must still use convergence checks, order-parameter maps,
% and seed stability.

if nargin < 2 || isempty(thresholds), thresholds = struct(); end
rhoTh = local_get(thresholds,'rhoSR',1e-4);
curTh = local_get(thresholds,'current',1e-5);
chiTh = local_get(thresholds,'chirality',1e-5);

if ~isfield(r,'status') || ~strcmpi(r.status,'ok')
    label = 'error';
    return;
end
rho = local_field(r,'superradiantDensity',NaN);
cur = local_field(r,'meanAbsCurrent',NaN);
chi = local_field(r,'meanAbsChirality',NaN);

if ~isfinite(rho) || rho < rhoTh
    label = 'normal';
elseif isfinite(chi) && chi > chiTh
    label = 'chiralSR';
elseif isfinite(cur) && cur > curTh
    label = 'currentSR';
else
    label = 'SR';
end
end

function v = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end

function v = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end
