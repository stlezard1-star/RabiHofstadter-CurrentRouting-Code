function RabiH_PrintHighDphLBOBenchmarkReport(scan)
%RABIH_PRINTHIGHDPHLBOBENCHMARKREPORT Print StageRH4T benchmark report.
if isfield(scan,'summaryT')
    s = scan.summaryT;
else
    s = RabiH_SummarizeHighDphLBOBenchmark(scan.records);
end
fprintf('--- RabiH StageRH4T high-dph LBO article benchmark report ---\n');
fprintf('records / ok / error       : %d / %d / %d\n', s.numRecords, s.numOK, s.numError);
fprintf('phase match fraction       : %.3f\n', s.phaseMatchFraction);
fprintf('phase-label errors         : %d\n', s.numPhaseError);
fprintf('max |dE| full-vs-LBO       : %.6e\n', s.maxAbsDE);
fprintf('max rel d rhoSR            : %.6e\n', s.maxRelRhoSR);
fprintf('max rel d |J|              : %.6e\n', s.maxRelCurrent);
fprintf('max rel d |chi|            : %.6e\n', s.maxRelChirality);
fprintf('local spectrum err range   : [%.6e, %.6e]\n', s.minLocalSpectrumError, s.maxLocalSpectrumError);
fprintf('hop-dim reduction range    : [%.3g, %.3g]\n', s.minHopDimReduction, s.maxHopDimReduction);
fprintf('mean full/LBO runtime ratio: %.3f\n', s.meanSpeedup);
if isfield(scan,'csvFileStage4T') && ~isempty(scan.csvFileStage4T)
    fprintf('CSV                        : %s\n', scan.csvFileStage4T);
elseif isfield(scan,'csvFile') && ~isempty(scan.csvFile)
    fprintf('CSV                        : %s\n', scan.csvFile);
end
fprintf('branch summary:\n');
fprintf('branch              n phaseMatch phaseErr max|dE|    maxRelRho maxRelJ   maxRelChi  full|chi| range             speedup\n');
for k = 1:numel(s.branchSummary)
    b = s.branchSummary(k);
    fprintf('%-18s %3d   %.3f       %3d   %.2e  %.2e  %.2e  %.2e  [%.3e, %.3e]   %.2f\n', ...
        local_trunc(b.branch,18), b.n, b.phaseMatchFraction, b.phaseErrors, b.maxAbsDE, ...
        b.maxRelRhoSR, b.maxRelCurrent, b.maxRelChirality, b.minFullChi, b.maxFullChi, b.meanSpeedup);
end
fprintf('sample records:\n');
fprintf('label                       ok branch          dFull dEff fullPhase lboPhase     dE        relRho      full|chi|   lbo|chi|  tFull tLBO\n');
for k = 1:numel(scan.records)
    r = scan.records(k);
    fprintf('%-27s %d %-14s %5g %4g %-9s %-9s %+9.2e %9.2e %10.3e %10.3e %6.3f %6.3f\n', ...
        local_trunc(r.label,27), strcmpi(r.status,'ok'), local_trunc(r.branch,14), r.dFull, r.dEff, ...
        local_trunc(r.fullPhase,9), local_trunc(r.lboPhase,9), r.dE, r.relRhoSR, ...
        r.fullAbsChirality, r.lboAbsChirality, r.fullRuntimeSeconds, r.lboRuntimeSeconds);
end
end

function s = local_trunc(s,n)
if isempty(s), s = ''; end
if numel(s) > n, s = s(1:n); end
end
