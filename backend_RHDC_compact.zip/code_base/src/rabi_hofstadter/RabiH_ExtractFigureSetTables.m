function figSet = RabiH_ExtractFigureSetTables(articleMap, spec)
%RABIH_EXTRACTFIGURESETTABLES Extract StageRH4P figure tables from map records.
%
% Output fields:
%   figSet.map.records             best-seed map records
%   figSet.fluxCuts.records        selected flux-cut records
%   figSet.representatives.records selected representative records
%   figSet.summary                 compact figure-set summary

if nargin < 2 || isempty(spec), spec = struct(); end
if nargin < 1 || isempty(articleMap)
    error('RabiH_ExtractFigureSetTables:EmptyInput','articleMap is required.');
end

records = local_get_records(articleMap);
if isempty(records)
    error('RabiH_ExtractFigureSetTables:NoRecords','No best-seed records found.');
end
okMask = arrayfun(@(r) local_is_ok(r), records);
records = records(okMask);

figSet = struct();
figSet.stage = 'StageRH4P';
figSet.map = struct('records',records);
figSet.fluxCuts = struct('records',local_extract_flux_cuts(records,spec));
figSet.representatives = struct('records',local_extract_representatives(records,spec));
figSet.summary = local_summarize(records, figSet.fluxCuts.records, figSet.representatives.records, spec);
figSet.sourceArticleMap = articleMap;
figSet.scanSpec = spec;
end

function records = local_get_records(articleMap)
records = [];
if isfield(articleMap,'best') && isfield(articleMap.best,'records')
    records = articleMap.best.records;
elseif isfield(articleMap,'prelim') && isfield(articleMap.prelim,'best') && isfield(articleMap.prelim.best,'records')
    records = articleMap.prelim.best.records;
elseif isfield(articleMap,'records')
    records = articleMap.records;
end
end

function tf = local_is_ok(r)
tf = true;
if isfield(r,'status') && ~isempty(r.status)
    tf = strcmpi(r.status,'ok');
end
end

function cuts = local_extract_flux_cuts(records, spec)
gTargets = local_get(spec,'figureCutGList',[1.0 1.4]);
tTargets = local_get(spec,'figureCutTList',local_unique_field(records,'t'));
empty = local_empty_row();
cuts = repmat(empty,1,0);
for it = 1:numel(tTargets)
    tsel = local_nearest(local_unique_field(records,'t'), tTargets(it));
    for ig = 1:numel(gTargets)
        gsel = local_nearest(local_unique_field(records,'gR'), gTargets(ig));
        mask = abs(local_arr(records,'t')-tsel) < 1e-12 & abs(local_arr(records,'gR')-gsel) < 1e-12;
        sub = records(mask);
        if isempty(sub), continue; end
        [~,ord] = sort(local_arr(sub,'Phi'));
        sub = sub(ord);
        for k = 1:numel(sub)
            row = local_record_to_row(sub(k));
            row.figureRole = 'fluxCut';
            row.cutT = tsel;
            row.cutG = gsel;
            cuts(end+1) = row; %#ok<AGROW>
        end
    end
end
end

function reps = local_extract_representatives(records, spec)
if isfield(spec,'representativePoints') && ~isempty(spec.representativePoints)
    targets = spec.representativePoints;
else
    targets = struct('name','max_chiral','gR',NaN,'t',NaN,'Phi',NaN);
end
empty = local_empty_row();
reps = repmat(empty,1,0);
for k = 1:numel(targets)
    tgt = targets(k);
    idx = local_find_nearest_record(records, tgt);
    if isempty(idx), continue; end
    row = local_record_to_row(records(idx));
    row.figureRole = 'representative';
    row.repName = local_get(tgt,'name',sprintf('rep%d',k));
    reps(end+1) = row; %#ok<AGROW>
end
end

function idx = local_find_nearest_record(records, tgt)
if isempty(records), idx = []; return; end
arrG = local_arr(records,'gR'); arrT = local_arr(records,'t'); arrP = local_arr(records,'Phi');
if ~isfield(tgt,'gR') || isnan(tgt.gR)
    chi = abs(local_arr(records,'meanAbsChirality'));
    [~,idx] = max(chi);
    return;
end
scaleG = max(eps,max(arrG)-min(arrG));
scaleT = max(eps,max(arrT)-min(arrT));
scaleP = max(eps,max(arrP)-min(arrP));
dist = ((arrG-tgt.gR)./scaleG).^2 + ((arrT-tgt.t)./scaleT).^2 + ((arrP-tgt.Phi)./scaleP).^2;
[~,idx] = min(dist);
end

function summary = local_summarize(records,cuts,reps,spec)
summary = struct();
summary.numMapRecords = numel(records);
summary.numFluxCutRecords = numel(cuts);
summary.numRepresentativeRecords = numel(reps);
labels = cell(1,numel(records));
for k = 1:numel(records)
    labels{k} = local_field(records(k),'phaseLabel','');
end
summary.countNormal = sum(strcmp(labels,'normal'));
summary.countSR = sum(strcmp(labels,'SR'));
summary.countCurrentSR = sum(strcmp(labels,'currentSR'));
summary.countChiralSR = sum(strcmp(labels,'chiralSR'));
summary.energyRange = [min(local_arr(records,'energyPerSite')) max(local_arr(records,'energyPerSite'))];
summary.rhoSRRange = [min(local_arr(records,'superradiantDensity')) max(local_arr(records,'superradiantDensity'))];
summary.maxAbsCurrent = max(abs(local_arr(records,'meanAbsCurrent')));
summary.maxAbsChirality = max(abs(local_arr(records,'meanAbsChirality')));
summary.maxCurrentDivergence = max(abs(local_arr(records,'maxCurrentDivergence')));
summary.maxChiralityDefinitionError = max(abs(local_arr(records,'maxChiralityDefinitionError')));
summary.minChiralCount = local_get(spec,'minChiralCount',0);
summary.passChiralCount = summary.countChiralSR >= summary.minChiralCount;
summary.passCurrentDivergence = summary.maxCurrentDivergence <= local_get(spec,'maxCurrentDivergenceWarn',Inf);
summary.passChiralityDefinition = summary.maxChiralityDefinitionError <= local_get(spec,'maxChiralityDefinitionErrorWarn',Inf);
summary.warnings = {};
if ~summary.passChiralCount
    summary.warnings{end+1} = sprintf('low chiralSR count: %d < %d', summary.countChiralSR, summary.minChiralCount);
end
if ~summary.passCurrentDivergence
    summary.warnings{end+1} = sprintf('large current divergence: %.3e', summary.maxCurrentDivergence);
end
if ~summary.passChiralityDefinition
    summary.warnings{end+1} = sprintf('large chirality-definition error: %.3e', summary.maxChiralityDefinitionError);
end
end

function row = local_record_to_row(r)
row = local_empty_row();
row.status = local_field(r,'status','ok');
row.phaseLabel = local_field(r,'phaseLabel','');
row.gR = local_field(r,'gR',NaN);
row.t = local_field(r,'t',NaN);
row.Phi = local_field(r,'Phi',NaN);
row.PhiOverPi = row.Phi/pi;
row.energyPerSite = local_field(r,'energyPerSite',NaN);
row.superradiantDensity = local_field(r,'superradiantDensity',NaN);
row.meanAbsCurrent = local_field(r,'meanAbsCurrent',NaN);
row.meanAbsChirality = local_field(r,'meanAbsChirality',NaN);
row.maxCurrentDivergence = local_field(r,'maxCurrentDivergence',NaN);
row.maxChiralityDefinitionError = local_field(r,'maxChiralityDefinitionError',NaN);
row.alphaSeed = local_field(r,'alphaSeed',NaN);
row.alphaPattern = local_field(r,'alphaPattern','');
row.dph = local_field(r,'dph',NaN);
row.Dmax = local_field(r,'Dmax',NaN);
row.chiMax = local_field(r,'chiMax',NaN);
row.sourceEta = local_field(r,'sourceEta',NaN);
end

function row = local_empty_row()
row = struct('figureRole','','repName','','cutT',NaN,'cutG',NaN, ...
    'status','','phaseLabel','','gR',NaN,'t',NaN,'Phi',NaN,'PhiOverPi',NaN, ...
    'energyPerSite',NaN,'superradiantDensity',NaN,'meanAbsCurrent',NaN, ...
    'meanAbsChirality',NaN,'maxCurrentDivergence',NaN,'maxChiralityDefinitionError',NaN, ...
    'alphaSeed',NaN,'alphaPattern','','dph',NaN,'Dmax',NaN,'chiMax',NaN,'sourceEta',NaN);
end

function vals = local_unique_field(records,name)
vals = unique(local_arr(records,name));
vals = vals(~isnan(vals));
end

function vals = local_arr(records,name)
vals = NaN(1,numel(records));
for k = 1:numel(records)
    vals(k) = local_field(records(k),name,NaN);
end
end

function val = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end

function x = local_nearest(vals,target)
if isempty(vals), x = NaN; return; end
[~,i] = min(abs(vals-target));
x = vals(i);
end
