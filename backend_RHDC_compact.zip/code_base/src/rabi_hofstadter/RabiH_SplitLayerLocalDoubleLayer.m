function E = RabiH_SplitLayerLocalDoubleLayer(scell, x, y, op)
%RABIH_SPLITLAYERLOCALDOUBLELAYER Lazily build one local double-layer tensor.
%
%   E = RabiH_SplitLayerLocalDoubleLayer(scell,x,y)
%   E = RabiH_SplitLayerLocalDoubleLayer(scell,x,y,op)
%
% The returned tensor has leg order [left,right,up,down], identical to
% iPEPS_BuildDoubleLayerTensor.  This function constructs only a single
% local double layer and never forms a blocked 2x2 tensor.

    if nargin < 4, op = []; end
    if nargin < 3
        error('RabiH_SplitLayerLocalDoubleLayer:MissingIndex', ...
            'Usage: E = RabiH_SplitLayerLocalDoubleLayer(scell,x,y,op).');
    end
    x = mod(x-1, scell.Lx) + 1;
    y = mod(y-1, scell.Ly) + 1;
    A = scell.Aket{y,x};

    % Use the already-tested double-layer builder for the local kernel.  The
    % split-cell guarantee is that this happens locally/on demand, not as a
    % full unit-cell blocking operation.
    if isempty(op)
        E = iPEPS_BuildDoubleLayerTensor(A);
    else
        E = iPEPS_BuildDoubleLayerTensor(A, op);
    end
end
