function [params, opts, scanSpec] = RabiH_Stage4K_DefaultConvergence()
%RABIH_STAGE4K_DEFAULTCONVERGENCE Conservative convergence-scan defaults.
%
% StageRH4K is a diagnostic layer, not a new CTM backend.  It runs a small
% grid of article-relevant convergence checks using the StageRH4J shared /
% cached split CTM backend and records current/chirality consistency metrics.
%
% The defaults are deliberately light.  Use them to check the pipeline and
% then enlarge scanSpec for production/preliminary article figures.

params = struct();
params.dph = 3;
params.omega = 1.0;
params.Delta = 1.0;
params.gR = 0.30;
params.t = 0.05;
params.tX = 0.05;
params.tY = 0.05;
params.Phi = pi;
params.alphaSeed = 0.10;
params.alphaPattern = 'vortex2x2';
params.spinSeed = 'down';

opts = struct();
opts.Lx = 2;
opts.Ly = 2;
opts.Dmax = 2;
opts.chiMax = 4;
opts.maxIter = 2;
opts.sharedMaxIter = 2;
opts.tol = 1e-8;
opts.tauList = 0.02;
opts.nSweeps = 1;
opts.svdCutoff = 1e-12;
opts.cacheGates = true;
opts.checkAfter = true;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.spinState = params.spinSeed;
opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.sharedBoundaryMix = 0.0;
opts.skipCTMNormHistory = true;
opts.enableBlockedCTMGuard = true;
opts.maxBlockedTensorElements = 2.0e7;
opts.maxBlockedTensorMB = 1024;
opts.maxBlockedNormIntermediateMB = 8192;
opts.maxExactTorusElements = 1.0e6;
opts.maxSplitLocalDoubleLayerMB = 512;
opts.maxSplitWorkspaceMB = 8192;
opts.verbose = false;
opts.outputDir = fullfile(pwd,'results_stage4K_convergence');
opts.saveEachPoint = true;

scanSpec = struct();
scanSpec.name = 'StageRH4K_default_convergence';
scanSpec.description = ['Light convergence diagnostic for the Rabi-Hofstadter ' ...
    'site-boson iPEPS package.  It varies CTM chi, virtual D, local photon ' ...
    'cutoff dph, coherent seed, and sharedBoundaryMix using the non-blocked ' ...
    'StageRH4J backend.'];
scanSpec.backend = 'splitFactoredShared';
scanSpec.DmaxList = 2;
scanSpec.chiMaxList = [4 6];
scanSpec.dphList = 3;
scanSpec.alphaSeedList = 0.10;
scanSpec.alphaPatternList = {'vortex2x2'};
scanSpec.sharedBoundaryMixList = [0.0 0.2];
scanSpec.gRList = params.gR;
scanSpec.tList = params.t;
scanSpec.PhiList = params.Phi;
scanSpec.maxPoints = Inf;
scanSpec.stopOnError = false;
scanSpec.tag = datestr(now,'yyyymmdd_HHMMSS');
end
