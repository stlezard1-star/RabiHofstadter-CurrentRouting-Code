function RabiH_WriteArticleMapSummaryCSV(summary, filename)
%RABIH_WRITEARTICLEMAPSUMMARYCSV Write compact StageRH4O summary CSV.
if nargin < 2 || isempty(filename), filename = 'stage4O_article_map_summary.csv'; end
fid = fopen(filename,'w');
if fid < 0, error('RabiH_WriteArticleMapSummaryCSV:OpenFailed','Cannot open file: %s.', filename); end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

pc = summary.phaseCounts;
fprintf(fid,'metric,value\n');
fprintf(fid,'numRecords,%d\n', summary.numRecords);
fprintf(fid,'numOK,%d\n', summary.numOK);
fprintf(fid,'energyMin,%.16g\n', summary.energyRange(1));
fprintf(fid,'energyMax,%.16g\n', summary.energyRange(2));
fprintf(fid,'rhoSRMin,%.16g\n', summary.rhoSRRange(1));
fprintf(fid,'rhoSRMax,%.16g\n', summary.rhoSRRange(2));
fprintf(fid,'maxAbsCurrent,%.16g\n', summary.maxAbsCurrent);
fprintf(fid,'maxAbsChirality,%.16g\n', summary.maxAbsChirality);
fprintf(fid,'maxCurrentDivergence,%.16g\n', summary.maxCurrentDivergence);
fprintf(fid,'maxChiralityDefinitionError,%.16g\n', summary.maxChiralityDefinitionError);
fprintf(fid,'countNormal,%d\n', pc.normal);
fprintf(fid,'countSR,%d\n', pc.SR);
fprintf(fid,'countCurrentSR,%d\n', pc.currentSR);
fprintf(fid,'countChiralSR,%d\n', pc.chiralSR);
fprintf(fid,'countError,%d\n', pc.error);
fprintf(fid,'countOther,%d\n', pc.other);

fprintf(fid,'\nperT,t,numRecords,numNormal,numSR,numCurrentSR,numChiralSR,maxRhoSR,maxAbsCurrent,maxAbsChirality\n');
if isfield(summary,'perT')
    for k = 1:numel(summary.perT)
        s = summary.perT(k);
        fprintf(fid,'perT,%.16g,%d,%d,%d,%d,%d,%.16g,%.16g,%.16g\n', ...
            s.t, s.numRecords, s.numNormal, s.numSR, s.numCurrentSR, s.numChiralSR, ...
            s.maxRhoSR, s.maxAbsCurrent, s.maxAbsChirality);
    end
end
end
