function backendInfo = RabiH_CheckCTMBackendReady(unitCell, opts)
%RABIH_CHECKCTMBACKENDREADY Decide whether the requested CTM backend is available.
%
% Backend policy:
%   auto          : use blocked CTM only when the pre-flight risk guard is safe.
%                   If blocked is unsafe and opts.splitBackendMode requests a
%                   non-blocked split route ('shared', 'periodic', or
%                   'production'), auto selects that route when its split guard
%                   is safe.  This keeps StageRH4O+ scans from falling back to
%                   the blocked backend at D>=3.
%   blocked       : require blocked CTM to pass the guard unless disabled.
%   factoredExact : use StageRH4E exact-small-cell non-blocked benchmark.
%   splitFactoredExact : use StageRH4F split/factored exact-small-cell benchmark.
%   splitFactoredPrototype : route to the StageRH4F split/factored skeleton.
%   splitFactored / splitFactoredPeriodic / splitFactoredShared : executable
%                   non-blocked split/factored CTM routes.
%
% Input compatibility:
%   The first argument may be either a unitCell struct with fields A,Lx,Ly, or
%   a params-style struct such as struct('dph',5).  In the latter case, params
%   fields are merged into opts and risks are estimated from opts.Lx/Ly/Dmax.

if nargin < 1
    unitCell = [];
end
if nargin < 2 || isempty(opts)
    opts = struct();
end

[unitCell, opts, inputKind] = local_normalize_unitcell_or_params(unitCell, opts);

backend = RabiH_GetOpt(opts,'ctmBackend','auto');
backend = lower(backend);
risk = RabiH_BlockedCTMRiskEstimate(unitCell, opts);
exactRisk = RabiH_ExactTorusCostEstimate(unitCell, opts);
splitRisk = RabiH_SplitFactoredCTMCostEstimate(unitCell, opts);

backendInfo = struct();
backendInfo.requested = backend;
backendInfo.selected = '';
backendInfo.inputKind = inputKind;
backendInfo.risk = risk;
backendInfo.exactTorusCost = exactRisk;
backendInfo.splitFactoredCost = splitRisk;
backendInfo.blocked = struct('ready',risk.isSafe, ...
                             'isReady',risk.isSafe, ...
                             'risk',risk, ...
                             'level',risk.level, ...
                             'blockedTensorMB',risk.blockedTensorMB);
backendInfo.isReady = false;
backendInfo.message = '';

switch backend
    case {'auto'}
        if risk.isSafe
            backendInfo.selected = 'blocked';
            backendInfo.isReady = true;
            backendInfo.message = 'auto selected blocked CTM because the blocked risk guard is safe';
        else
            [autoSelected, autoReady, autoMessage] = local_try_auto_split_route(opts, splitRisk);
            if ~isempty(autoSelected)
                backendInfo.selected = autoSelected;
                backendInfo.isReady = autoReady;
                backendInfo.message = autoMessage;
            elseif RabiH_GetOpt(opts,'allowAutoSplitFactoredExact',false) && exactRisk.isSafe
                backendInfo.selected = 'split_factored_exact';
                backendInfo.isReady = true;
                backendInfo.message = ['auto selected StageRH4F split/factored exact-small-cell benchmark. ' ...
                    'This is not the production infinite-PEPS CTM backend.'];
            elseif RabiH_GetOpt(opts,'allowAutoFactoredExact',false) && exactRisk.isSafe
                backendInfo.selected = 'factored_exact';
                backendInfo.isReady = true;
                backendInfo.message = ['auto selected StageRH4E factored exact-small-cell benchmark. ' ...
                    'This is not the production infinite-PEPS CTM backend.'];
            else
                backendInfo.selected = 'none';
                backendInfo.isReady = false;
                backendInfo.message = ['auto backend refused blocked CTM because the risk guard is unsafe; ' ...
                    'request a non-blocked backend such as splitFactoredShared, or set splitBackendMode=''shared'''];
            end
        end
    case {'blocked','blockedctm'}
        backendInfo.selected = 'blocked';
        backendInfo.isReady = risk.isSafe || ~RabiH_GetOpt(opts,'enableBlockedCTMGuard',true);
        if backendInfo.isReady
            backendInfo.message = 'blocked CTM selected';
        else
            backendInfo.message = 'blocked CTM requested but blocked risk guard is unsafe';
        end
    case {'factoredexact','exactfactored','exacttorus'}
        backendInfo.selected = 'factored_exact';
        backendInfo.isReady = exactRisk.isSafe;
        if backendInfo.isReady
            backendInfo.message = 'StageRH4E factored exact-small-cell benchmark selected';
        else
            backendInfo.message = ['factored exact-small-cell benchmark requested but guard is unsafe: ' ...
                                   exactRisk.reason];
        end
    case {'splitfactoredexact','splitexact','splitexacttorus','splitfactoredsmallcell'}
        backendInfo.selected = 'split_factored_exact';
        backendInfo.isReady = exactRisk.isSafe;
        if backendInfo.isReady
            backendInfo.message = 'StageRH4F split/factored exact-small-cell benchmark selected';
        else
            backendInfo.message = ['split/factored exact-small-cell benchmark requested but guard is unsafe: ' ...
                                   exactRisk.reason];
        end
    case {'splitfactoredprototype','splitprototype','splitfactoredskeleton'}
        backendInfo.selected = 'split_factored_prototype';
        backendInfo.isReady = splitRisk.isSafe;
        if backendInfo.isReady
            backendInfo.message = ['StageRH4F split/factored prototype selected.  ' ...
                'This is a safe routing/interface backend, not a production measurement backend.'];
        else
            backendInfo.message = ['split/factored prototype requested but guard is unsafe: ' splitRisk.reason];
        end
    case {'factored','factoredctm','multisite','multisitectm'}
        backendInfo.selected = 'factored';
        backendInfo.isReady = false;
        backendInfo.message = ['StageRH4D/E factored cell and exact-small-cell benchmark are present, ' ...
            'but the production multi-site CTM contraction backend is not implemented yet'];
    case {'splitfactoredshared','splitshared','sharedsplitctm','splitcachedctm','splitfactoredcached'}
        backendInfo.selected = 'split_shared';
        backendInfo.isReady = splitRisk.isSafe;
        if backendInfo.isReady
            backendInfo.message = ['StageRH4J shared/cached periodic split/factored CTM selected.  ' ...
                'This backend keeps the non-blocked route, caches local double layers, ' ...
                'and evolves all inequivalent CTM environments in global periodic sweeps.'];
        else
            backendInfo.message = ['shared/cached split/factored CTM requested but guard is unsafe: ' splitRisk.reason];
        end
    case {'splitfactoredperiodic','splitperiodic','periodicsplitctm','splitperiodicctm'}
        backendInfo.selected = 'split_periodic';
        backendInfo.isReady = splitRisk.isSafe;
        if backendInfo.isReady
            backendInfo.message = ['StageRH4H periodic-neighbor split/factored CTM selected.  ' ...
                'This is the first periodic accuracy upgrade beyond the StageRH4G site-wise kernel.'];
        else
            backendInfo.message = ['periodic split/factored CTM requested but guard is unsafe: ' splitRisk.reason];
        end
    case {'splitfactored','splitfactoredctm','splitctm','splitmultisite'}
        backendInfo.selected = 'split_factored';
        backendInfo.isReady = splitRisk.isSafe;
        if backendInfo.isReady
            backendInfo.message = ['StageRH4G executable split/factored CTM v1 selected.  ' ...
                'This is memory-safe and non-blocked, but still a site-wise first kernel; ' ...
                'final paper data should later be checked with periodic split-CTMRG.'];
        else
            backendInfo.message = ['split/factored CTM requested but guard is unsafe: ' splitRisk.reason];
        end
    otherwise
        error('RabiH_CheckCTMBackendReady:UnknownBackend','Unknown CTM backend: %s.', backend);
end
end

function [unitCell, opts, inputKind] = local_normalize_unitcell_or_params(unitCell, opts)
inputKind = 'empty';
if isempty(unitCell)
    inputKind = 'empty';
    return;
end

if isstruct(unitCell) && isfield(unitCell,'A')
    inputKind = 'unitCell';
    if ~isfield(unitCell,'Ly') || isempty(unitCell.Ly)
        unitCell.Ly = size(unitCell.A,1);
    end
    if ~isfield(unitCell,'Lx') || isempty(unitCell.Lx)
        unitCell.Lx = size(unitCell.A,2);
    end
    return;
end

% Params-style struct, e.g. struct('dph',5), was historically passed by a
% few high-level tests.  Treat it as options metadata rather than a unitCell.
if isstruct(unitCell)
    params = unitCell;
    f = fieldnames(params);
    for k = 1:numel(f)
        name = f{k};
        if ~isfield(opts,name) || isempty(opts.(name))
            opts.(name) = params.(name);
        end
    end
    unitCell = [];
    inputKind = 'params';
    return;
end

error('RabiH_CheckCTMBackendReady:BadInput', ...
    'First argument must be empty, a unitCell struct, or a params struct.');
end

function [selected, ready, message] = local_try_auto_split_route(opts, splitRisk)
selected = '';
ready = false;
message = '';
mode = lower(RabiH_GetOpt(opts,'splitBackendMode',''));
if isempty(mode)
    return;
end

switch mode
    case {'shared','cached','sharedcached','splitshared'}
        selected = 'split_shared';
        ready = splitRisk.isSafe;
        if ready
            message = ['auto selected StageRH4J shared/cached split/factored CTM because ' ...
                       'blocked CTM is unsafe and splitBackendMode=''shared''.'];
        else
            message = ['auto selected shared split route, but split guard is unsafe: ' splitRisk.reason];
        end
    case {'periodic','splitperiodic'}
        selected = 'split_periodic';
        ready = splitRisk.isSafe;
        if ready
            message = ['auto selected StageRH4H periodic split/factored CTM because ' ...
                       'blocked CTM is unsafe and splitBackendMode=''periodic''.'];
        else
            message = ['auto selected periodic split route, but split guard is unsafe: ' splitRisk.reason];
        end
    case {'production','split','splitfactored'}
        selected = 'split_factored';
        ready = splitRisk.isSafe;
        if ready
            message = ['auto selected StageRH4G split/factored CTM because ' ...
                       'blocked CTM is unsafe and splitBackendMode requests production split CTM.'];
        else
            message = ['auto selected split route, but split guard is unsafe: ' splitRisk.reason];
        end
    case {'exactsmallcell','exact','splitexact'}
        selected = '';
        ready = false;
        message = '';
    otherwise
        selected = '';
        ready = false;
        message = '';
end
end
