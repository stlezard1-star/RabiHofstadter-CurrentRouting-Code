function Anew = RabiH_ApplyOneSiteGate(A, G)
%RABIH_APPLYONESITEGATE Apply a one-site physical gate to A(s,l,r,u,d).
    A = reshape(A, PEPS_FullSize(A,5));
    sz = PEPS_FullSize(A,5);
    d = sz(1);
    if ~isequal(size(G),[d d])
        error('RabiH_ApplyOneSiteGate:GateSizeMismatch','Gate must be d-by-d.');
    end
    X = reshape(A, d, []);
    X = G * X;
    Anew = reshape(X, sz);
end
