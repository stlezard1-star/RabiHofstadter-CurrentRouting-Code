function scan = RabiH_RunLBOPrototypeScan(paramsBase, optsBase, spec)
%RABIH_RUNLBOPROTOTYPESCAN Run StageRH4R LBO prototype diagnostics.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4R_DefaultLBO();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec), spec = struct(); end

dFullList = local_get(spec,'dFullList',RabiH_GetOpt(paramsBase,'dphFull',12));
dEffList = local_get(spec,'dEffList',RabiH_GetOpt(paramsBase,'dphEff',6));
stopOnError = local_get(spec,'stopOnError',false);
outDir = local_get(spec,'outputDir',RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4R_lbo_prototype')));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
records = repmat(local_empty_record(),1,0);
idx = 0;
startAll = tic;
for ifull = 1:numel(dFullList)
for ieff = 1:numel(dEffList)
    dFull = dFullList(ifull); dEff = dEffList(ieff);
    if dEff > dFull, continue; end
    idx = idx + 1;
    rec = local_empty_record();
    rec.index = idx;
    rec.dFull = dFull;
    rec.dEff = dEff;
    rec.label = sprintf('lbo_%04d_dfull%d_deff%d',idx,dFull,dEff);
    t0 = tic;
    try
        params = paramsBase;
        params.dphFull = dFull;
        params.dphEff = dEff;
        params.dph = dFull;
        bspec = struct();
        bspec.dFull = dFull;
        bspec.dEff = dEff;
        bspec.alphaList = local_get(spec,'alphaList',[0 0.4 0.8 1.2]);
        bspec.includeFock = local_get(spec,'includeFock',true);
        bspec.numFock = local_get(spec,'numFock',min(dEff,dFull));
        bspec.includeLocalRabi = local_get(spec,'includeLocalRabi',true);
        bspec.numLocalStates = local_get(spec,'numLocalStates',min(6,2*dFull));
        basis = RabiH_PhotonBasis_FromSnapshots(params,bspec);
        ph = RabiH_PhotonBasis_ProjectOps(basis);
        sdiag = RabiH_LBO_LocalSpectrumDiagnostic(params,basis,local_get(spec,'nLevels',6));
        [Hhop,ops] = RabiH_HoppingHamiltonianLBO(params,basis,pi/2,RabiH_GetOpt(params,'t',0.08)); %#ok<ASGLU>
        rec.status = 'ok';
        rec.runtimeSeconds = toc(t0);
        rec.orthonormalError = basis.orthonormalError;
        rec.truncationHint = basis.truncationHint;
        rec.commutatorError = ph.commutatorError;
        rec.localSpectrumMaxError = sdiag.maxAbsError;
        rec.localSpectrumRMSError = sdiag.rmsError;
        rec.siteDimEff = ops.d;
        rec.hoppingDim = size(Hhop,1);
        rec.reductionFactor = (2*dFull)/(2*dEff);
        pointFile = fullfile(outDir,sprintf('stage4R_lbo_point_%04d.mat',idx));
        save(pointFile,'basis','ph','sdiag','Hhop','ops','params','bspec','rec');
        rec.pointFile = pointFile;
    catch ME
        rec.status = 'error';
        rec.runtimeSeconds = toc(t0);
        rec.errorMessage = ME.message;
        if stopOnError
            records(end+1) = rec; %#ok<AGROW>
            rethrow(ME);
        end
    end
    records(end+1) = rec; %#ok<AGROW>
end
end
summary = RabiH_SummarizeLBOPrototypeScan(records);
scan = struct();
scan.stage = 'StageRH4R';
scan.description = 'Photon LBO/OBB prototype diagnostics.';
scan.paramsBase = paramsBase;
scan.optsBase = optsBase;
scan.scanSpec = spec;
scan.records = records;
scan.summary = summary;
scan.outputDir = outDir;
scan.runtimeSeconds = toc(startAll);
end

function rec = local_empty_record()
rec = struct('index',NaN,'label','','status','pending','dFull',NaN,'dEff',NaN, ...
    'siteDimEff',NaN,'hoppingDim',NaN,'reductionFactor',NaN, ...
    'orthonormalError',NaN,'truncationHint',NaN,'commutatorError',NaN, ...
    'localSpectrumMaxError',NaN,'localSpectrumRMSError',NaN, ...
    'runtimeSeconds',NaN,'pointFile','','errorMessage','');
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
