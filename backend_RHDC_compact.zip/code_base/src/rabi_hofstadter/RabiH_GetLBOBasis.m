function basis = RabiH_GetLBOBasis(params, spec)
%RABIH_GETLBOBASIS Return or build a photon LBO basis.
%
% If params.lboBasis is present it is used directly.  Otherwise this helper
% constructs a snapshot/SVD photon isometry using dphFull and dphEff.  The
% construction is intentionally performed with useLBO=false to avoid
% recursion through the local Rabi Hamiltonian used in the snapshot density.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(spec), spec = struct(); end
if isfield(params,'lboBasis') && ~isempty(params.lboBasis)
    basis = params.lboBasis;
    return;
end
p = params;
p.useLBO = false;
if ~isfield(p,'dphFull') || isempty(p.dphFull)
    p.dphFull = RabiH_GetOpt(p,'dph',8);
end
if ~isfield(p,'dphEff') || isempty(p.dphEff)
    p.dphEff = min(6,p.dphFull);
end
bspec = spec;
bspec.dFull = RabiH_GetOpt(bspec,'dFull',p.dphFull);
bspec.dEff  = RabiH_GetOpt(bspec,'dEff',p.dphEff);
if ~isfield(bspec,'alphaList') || isempty(bspec.alphaList)
    bspec.alphaList = RabiH_GetOpt(p,'lboAlphaList',[0 0.4 0.8 1.2 1.6]);
end
basis = RabiH_PhotonBasis_FromSnapshots(p,bspec);
end
