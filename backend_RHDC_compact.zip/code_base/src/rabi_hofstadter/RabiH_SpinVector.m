function s = RabiH_SpinVector(spinState)
%RABIH_SPINVECTOR Spin-1/2 vector helper in basis |up>, |down>.

    if nargin < 1 || isempty(spinState)
        spinState = 'down';
    end
    if isnumeric(spinState)
        s = spinState(:);
        if numel(s) ~= 2
            error('RabiH_SpinVector:BadDim','Numeric spinState must have length 2.');
        end
    else
        switch lower(spinState)
            case {'up','up0','zplus'}
                s = [1;0];
            case {'down','down0','zminus'}
                s = [0;1];
            case {'xplus','plusx'}
                s = [1;1]/sqrt(2);
            case {'xminus','minusx'}
                s = [1;-1]/sqrt(2);
            case {'yplus','plusy'}
                s = [1;1i]/sqrt(2);
            case {'yminus','minusy'}
                s = [1;-1i]/sqrt(2);
            otherwise
                error('RabiH_SpinVector:UnknownState','Unknown spin state: %s.', spinState);
        end
    end
    ns = norm(s);
    if ns == 0 || ~isfinite(ns)
        error('RabiH_SpinVector:BadNorm','Spin vector norm is invalid.');
    end
    s = s/ns;
end
