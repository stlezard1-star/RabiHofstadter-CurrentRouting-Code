function RabiH_SC_PrintAnalyticBenchmarkReport(out)
%RabiH_SC_PrintAnalyticBenchmarkReport Print StageRH4AG summary.
fprintf('--- RabiH StageRH4AG analytic benchmark report ---\n');
fprintf('critical gc range       : [%.6g, %.6g]\n',out.summary.gcMin,out.summary.gcMax);
fprintf('max rhoSR mean-field    : %.6g\n',out.summary.maxRhoGL);
fprintf('max |chiSq| mean-field  : %.6e\n',out.summary.maxChiSqGL);
fprintf('max |chiTri| mean-field : %.6e\n',out.summary.maxChiTriGL);
fprintf('max |I13| theta-map     : %.6e\n',out.summary.maxAbsI13LT);
fprintf('max |I24| theta-map     : %.6e\n',out.summary.maxAbsI24LT);
fprintf('diag sign change        : %d\n',out.summary.hasDiagSignChange);
fprintf('triangular signal       : %d\n',out.summary.hasTriangularSignal);
fprintf('output directory        : %s\n',out.spec.outputDir);
end
