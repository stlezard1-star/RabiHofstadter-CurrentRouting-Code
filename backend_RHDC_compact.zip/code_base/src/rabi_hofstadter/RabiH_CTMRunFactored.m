function ctx = RabiH_CTMRunFactored(unitCell, opts)
%RABIH_CTMRUNFACTORED Non-blocked factored CTM context boundary.
%
% StageRH4D:
%   Constructs a safe factored local double-layer container and never calls
%   CTM_BlockUnitCell.
%
% StageRH4E:
%   Adds an optional exact-small-cell benchmark mode:
%       opts.factoredBackendMode = 'exactSmallCell'
%       opts.enableFactoredExactTorus = true
%   This mode is still not production CTM.  It is a non-blocked reference
%   contraction for small cells, guarded by RabiH_AssertFactoredExactSafe.
%
% Set opts.requireProductionFactoredCTM=true to force an error until the real
% multi-site CTM absorption/truncation kernel is implemented.

    if nargin < 2 || isempty(opts), opts = struct(); end
    if RabiH_GetOpt(opts,'requireProductionFactoredCTM',false)
        error('RabiH_CTMRunFactored:ProductionNotImplemented', ...
            ['The production multi-site CTM contraction kernel is not implemented yet. ' ...
             'Use the StageRH4E exact-small-cell backend only for validation.']);
    end

    risk = RabiH_BlockedCTMRiskEstimate(unitCell, opts);
    fcell = RabiH_FactoredCellConstruct(unitCell, opts);

    mode = lower(RabiH_GetOpt(opts,'factoredBackendMode','skeleton'));
    ctmBackend = lower(RabiH_GetOpt(opts,'ctmBackend',''));
    useExact = RabiH_GetOpt(opts,'enableFactoredExactTorus',false) || ...
               any(strcmp(mode,{'exact','exactsmallcell','exacttorus','smallcell'})) || ...
               any(strcmp(ctmBackend,{'factoredexact','exactfactored','exacttorus'}));

    ctx = struct();
    ctx.stage = 'StageRH4D';
    ctx.factoredCell = fcell;
    ctx.blockedCTMRisk = risk;
    ctx.hasBlockedTensor = false;
    ctx.env = [];
    ctx.hist = [];
    ctx.denOne = NaN;
    ctx.denH = NaN;
    ctx.denV = NaN;

    if useExact
        exactRisk = RabiH_AssertFactoredExactSafe(unitCell, opts);
        ctx.backend = 'factored_exact_torus';
        ctx.stage = 'StageRH4E';
        ctx.exactTorusCost = exactRisk;
        ctx.isProductionCTM = false;
        ctx.note = ['StageRH4E exact-small-cell non-blocked benchmark. ' ...
                    'This is useful for D=2 validation, not for production infinite-PEPS data.'];
        return;
    end

    ctx.backend = 'factored_skeleton';
    ctx.isProductionCTM = false;
    ctx.note = ['Factored CTM skeleton only: local double-layer tensors are available, ' ...
                'but multi-site CTM absorption/truncation is not yet implemented.'];
end
