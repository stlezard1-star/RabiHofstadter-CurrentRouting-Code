function spec = RabiH_Stage4U_DefaultAppendixPack()
%RABIH_STAGE4U_DEFAULTAPPENDIXPACK Defaults for final Appendix convergence pack.
%
% StageRH4U is an article-preparation layer.  It does not introduce a new
% optimizer or CTM backend.  Instead, it collects the StageRH4Q
% simple-update/resource overlay and the StageRH4T high-dph LBO benchmark
% into tables and plots that can be used directly in the manuscript Appendix.

spec = struct();
spec.stage = 'StageRH4U';
spec.name = 'StageRH4U_appendix_convergence_pack';
spec.description = ['Collect StageRH4Q resource/schedule overlay and StageRH4T ' ...
    'high-dph LBO benchmark into Appendix-ready summary tables and figures.'];
spec.outputDir = fullfile(pwd,'results_stage4U_appendix_convergence_pack');
spec.stage4QMatFile = fullfile(pwd,'results_stage4Q_accuracy_overlay_demo','stage4Q_accuracy_overlay.mat');
spec.stage4TMatFile = fullfile(pwd,'results_stage4T_high_dph_lbo_benchmark','stage4T_high_dph_lbo_benchmark.mat');
spec.runStage4QIfMissing = true;
spec.runStage4TIfMissing = true;
spec.writeCSV = true;
spec.makePlots = true;
spec.saveMAT = true;

% Article-level soft gates used only for reporting.  They should not be used
% as hard correctness tests because finite-D/SU errors remain separate from
% LBO projection errors.
spec.requirePhaseMatchQ = 0.999;
spec.requirePhaseMatchT = 0.999;
spec.warnRelRhoT = 3e-2;
spec.warnRelCurrentT = 3e-2;
spec.warnRelChiralityT = 3e-2;
spec.warnCurrentDivQ = 1e-3;
end
