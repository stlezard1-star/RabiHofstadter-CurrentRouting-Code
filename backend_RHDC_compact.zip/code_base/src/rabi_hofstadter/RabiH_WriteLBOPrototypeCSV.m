function csvFile = RabiH_WriteLBOPrototypeCSV(scan, csvFile)
%RABIH_WRITELBOPROTOTYPECSV Write StageRH4R LBO records to CSV.

if nargin < 2 || isempty(csvFile)
    outDir = scan.outputDir;
    if exist(outDir,'dir') ~= 7, mkdir(outDir); end
    csvFile = fullfile(outDir,'stage4R_lbo_prototype.csv');
end
fid = fopen(csvFile,'w');
if fid < 0, error('RabiH_WriteLBOPrototypeCSV:OpenFailed','Cannot open CSV.'); end
fprintf(fid,'index,label,status,dFull,dEff,siteDimEff,hoppingDim,reductionFactor,orthonormalError,truncationHint,commutatorError,localSpectrumMaxError,localSpectrumRMSError,runtimeSeconds,errorMessage\n');
for k = 1:numel(scan.records)
    r = scan.records(k);
    fprintf(fid,'%d,%s,%s,%g,%g,%g,%g,%.8g,%.16g,%.16g,%.16g,%.16g,%.16g,%.6g,%s\n', ...
        r.index, local_str(r.label), local_str(r.status), r.dFull, r.dEff, r.siteDimEff, r.hoppingDim, ...
        r.reductionFactor, r.orthonormalError, r.truncationHint, r.commutatorError, ...
        r.localSpectrumMaxError, r.localSpectrumRMSError, r.runtimeSeconds, local_str(r.errorMessage));
end
fclose(fid);
end

function s = local_str(x)
if isempty(x), s = ''; else, s = char(x); end
s = strrep(s,',',';');
s = strrep(s,sprintf('\n'),' ');
end
