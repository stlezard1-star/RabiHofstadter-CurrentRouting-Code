function RabiH_PrintBackendConsistencyReport(bench)
%RABIH_PRINTBACKENDCONSISTENCYREPORT Print compact StageRH4I backend table.

if nargin < 1 || isempty(bench)
    error('RabiH_PrintBackendConsistencyReport:MissingInput','bench is required.');
end

fprintf('--- RabiH StageRH4I backend consistency report ---\n');
if isfield(bench,'summary')
    fprintf('reference backend : %s\n', bench.summary.referenceLabel);
    fprintf('successful backends: %d / %d\n', bench.summary.numOk, bench.summary.numBackends);
    fprintf('max |dE|          : %.6e\n', bench.summary.maxAbsEnergyDelta);
    fprintf('max |d rhoSR|     : %.6e\n', bench.summary.maxAbsRhoSRDelta);
end
fprintf('%-24s %-10s %16s %16s %16s %10s\n', ...
    'label','ok','E/site','dE(ref)','rhoSR','time(s)');
for k = 1:numel(bench.entries)
    e = bench.entries(k);
    fprintf('%-24s %-10d %16.9g %16.6e %16.6e %10.3f\n', ...
        e.label, e.ok, e.energyPerSite, e.deltaEnergyVsReference, ...
        e.superradiantDensity, e.runtimeSeconds);
    if ~e.ok
        fprintf('    message: %s\n', e.message);
    end
end
end
