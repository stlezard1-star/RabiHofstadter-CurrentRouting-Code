function [Anew,Bnew,Cnew,info] = SU_ApplyThreeSiteEndGate_Path(A,B,C,pathKind,gate,Dmax,opts)
%SU_APPLYTHREESITEENDGATE_PATH Apply an end-to-end physical gate on a 3-site NN path.
%
%   [Anew,Bnew,Cnew,info] = SU_ApplyThreeSiteEndGate_Path(A,B,C,pathKind,gate,Dmax,opts)
%
%   This is a pragmatic long-range/diagonal update kernel used for StageRH4Y.
%   It contracts the three tensors on a nearest-neighbor path A--B--C,
%   applies a two-site physical gate to the end sites A and C, and splits the
%   result back into three PEPS tensors by two SVDs.  The diagonal correlation
%   is therefore routed through the chosen NN path rather than through a new
%   diagonal virtual bond.
%
%   Tensor convention: X(s,l,r,u,d).
%
%   Supported pathKind values:
%       'right_down' : A.r--B.l and B.d--C.u.  Represents A -> (x+1,y+1).
%       'right_up'   : A.r--B.l and B.u--C.d.  Represents A -> (x+1,y-1).
%
%   This is not a full variational plaquette optimization.  It is a genuine
%   diagonal two-site gate update within the existing PEPS graph, using a path
%   SVD truncation analogous to applying a short MPO on the path.

    if nargin < 7 || isempty(opts), opts = struct(); end
    svdCutoff = SU_GetOpt(opts,'svdCutoff',0.0);
    doNormalize = SU_GetOpt(opts,'normalize',true);

    A = reshape(A,PEPS_FullSize(A,5));
    B = reshape(B,PEPS_FullSize(B,5));
    C = reshape(C,PEPS_FullSize(C,5));
    szA = PEPS_FullSize(A,5); szB = PEPS_FullSize(B,5); szC = PEPS_FullSize(C,5);
    d = szA(1);
    if szB(1) ~= d || szC(1) ~= d
        error('SU_ApplyThreeSiteEndGate_Path:PhysicalDimMismatch','Physical dimensions of A,B,C must match.');
    end
    if ~isequal(size(gate),[d*d d*d])
        error('SU_ApplyThreeSiteEndGate_Path:GateSizeMismatch','Gate must have size d^2-by-d^2.');
    end
    kind = lower(strrep(pathKind,'-','_'));
    switch kind
        case {'right_down','rd','diagp','diagplus'}
            [theta, meta] = local_contract_right_down(A,B,C,szA,szB,szC);
            theta = local_apply_end_gate(theta,gate,d,[1 8]);
            [Anew,Bnew,Cnew,info] = local_split_right_down(theta,meta,Dmax,svdCutoff);
        case {'right_up','ru','diagm','diagminus'}
            [theta, meta] = local_contract_right_up(A,B,C,szA,szB,szC);
            theta = local_apply_end_gate(theta,gate,d,[1 8]);
            [Anew,Bnew,Cnew,info] = local_split_right_up(theta,meta,Dmax,svdCutoff);
        otherwise
            error('SU_ApplyThreeSiteEndGate_Path:UnknownPath','Unknown pathKind: %s.',pathKind);
    end
    if doNormalize
        Anew = iPEPS_NormalizeTensor(Anew);
        Bnew = iPEPS_NormalizeTensor(Bnew);
        Cnew = iPEPS_NormalizeTensor(Cnew);
    end
end

function [theta, meta] = local_contract_right_down(A,B,C,szA,szB,szC)
    % A.r == B.l, B.d == C.u.
    if szA(3) ~= szB(2)
        error('SU_ApplyThreeSiteEndGate_Path:BondMismatch','A.r and B.l dimensions do not match.');
    end
    if szB(5) ~= szC(4)
        error('SU_ApplyThreeSiteEndGate_Path:BondMismatch','B.d and C.u dimensions do not match.');
    end
    AB = PEPS_ContractPair_Fast(A,B,3,2,[],5,5);
    % AB order after reshape: [A.s,A.l,A.u,A.d,B.s,B.r,B.u,B.d]
    AB = reshape(AB,[szA(1),szA(2),szA(4),szA(5),szB(1),szB(3),szB(4),szB(5)]);
    K = szB(5);
    X = reshape(AB,[],K);
    Cp = permute(C,[4 1 2 3 5]); % [C.u,C.s,C.l,C.r,C.d]
    Y = reshape(Cp,K,[]);
    Z = X*Y;
    theta = reshape(Z,[szA(1),szA(2),szA(4),szA(5),szB(1),szB(3),szB(4),szC(1),szC(2),szC(3),szC(5)]);
    meta = struct('szA',szA,'szB',szB,'szC',szC);
end

function [theta, meta] = local_contract_right_up(A,B,C,szA,szB,szC)
    % A.r == B.l, B.u == C.d.
    if szA(3) ~= szB(2)
        error('SU_ApplyThreeSiteEndGate_Path:BondMismatch','A.r and B.l dimensions do not match.');
    end
    if szB(4) ~= szC(5)
        error('SU_ApplyThreeSiteEndGate_Path:BondMismatch','B.u and C.d dimensions do not match.');
    end
    AB = PEPS_ContractPair_Fast(A,B,3,2,[],5,5);
    % AB order after reshape: [A.s,A.l,A.u,A.d,B.s,B.r,B.u,B.d]
    AB = reshape(AB,[szA(1),szA(2),szA(4),szA(5),szB(1),szB(3),szB(4),szB(5)]);
    % Move B.u to last for contraction with C.d.
    ABp = permute(AB,[1 2 3 4 5 6 8 7]); % [A.s,A.l,A.u,A.d,B.s,B.r,B.d,B.u]
    K = szB(4);
    X = reshape(ABp,[],K);
    Cp = permute(C,[5 1 2 3 4]); % [C.d,C.s,C.l,C.r,C.u]
    Y = reshape(Cp,K,[]);
    Z = X*Y;
    theta = reshape(Z,[szA(1),szA(2),szA(4),szA(5),szB(1),szB(3),szB(5),szC(1),szC(2),szC(3),szC(4)]);
    meta = struct('szA',szA,'szB',szB,'szC',szC);
end

function theta = local_apply_end_gate(theta,gate,d,physPos)
    nd = 11;
    sz = size(theta);
    if numel(sz) < nd, sz = [sz ones(1,nd-numel(sz))]; end
    other = 1:nd; other(physPos) = [];
    perm = [physPos other];
    invperm(perm) = 1:nd;
    X = permute(reshape(theta,sz),perm);
    X = reshape(X,d*d,[]);
    X = gate*X;
    X = reshape(X,[d d sz(other)]);
    theta = permute(X,invperm);
end

function [Anew,Bnew,Cnew,info] = local_split_right_down(theta,meta,Dmax,svdCutoff)
    szA=meta.szA; szB=meta.szB; szC=meta.szC;
    leftA  = [szA(1),szA(2),szA(4),szA(5)];
    rest   = [szB(1),szB(3),szB(4),szC(1),szC(2),szC(3),szC(5)];
    M = reshape(theta,prod(leftA),prod(rest));
    [Amat,Rmat,lam1,inf1] = local_split_matrix(M,leftA,rest,Dmax,svdCutoff);
    D1 = numel(lam1);
    Anew = permute(Amat,[1 2 5 3 4]); % [s,l,r,u,d]
    R = reshape(Rmat,[D1,rest]);
    leftB = [D1,szB(1),szB(3),szB(4)]; % [B.l,B.s,B.r,B.u]
    rightC = [szC(1),szC(2),szC(3),szC(5)]; % [C.s,C.l,C.r,C.d]
    M2 = reshape(R,prod(leftB),prod(rightC));
    [Bmat,Cmat,lam2,inf2] = local_split_matrix(M2,leftB,rightC,Dmax,svdCutoff);
    D2 = numel(lam2);
    Bmat = reshape(Bmat,[leftB D2]);      % [B.l,B.s,B.r,B.u,B.d]
    Cmat = reshape(Cmat,[D2 rightC]);     % [C.u,C.s,C.l,C.r,C.d]
    Bnew = permute(Bmat,[2 1 3 4 5]);    % [s,l,r,u,d]
    Cnew = permute(Cmat,[2 3 4 1 5]);    % [s,l,r,u,d]
    info = local_info(inf1,inf2,lam1,lam2);
end

function [Anew,Bnew,Cnew,info] = local_split_right_up(theta,meta,Dmax,svdCutoff)
    szA=meta.szA; szB=meta.szB; szC=meta.szC;
    leftA  = [szA(1),szA(2),szA(4),szA(5)];
    rest   = [szB(1),szB(3),szB(5),szC(1),szC(2),szC(3),szC(4)];
    M = reshape(theta,prod(leftA),prod(rest));
    [Amat,Rmat,lam1,inf1] = local_split_matrix(M,leftA,rest,Dmax,svdCutoff);
    D1 = numel(lam1);
    Anew = permute(Amat,[1 2 5 3 4]); % [s,l,r,u,d]
    R = reshape(Rmat,[D1,rest]);
    leftB = [D1,szB(1),szB(3),szB(5)]; % [B.l,B.s,B.r,B.d]
    rightC = [szC(1),szC(2),szC(3),szC(4)]; % [C.s,C.l,C.r,C.u]
    M2 = reshape(R,prod(leftB),prod(rightC));
    [Bmat,Cmat,lam2,inf2] = local_split_matrix(M2,leftB,rightC,Dmax,svdCutoff);
    D2 = numel(lam2);
    Bmat = reshape(Bmat,[leftB D2]);      % [B.l,B.s,B.r,B.d,B.u]
    Cmat = reshape(Cmat,[D2 rightC]);     % [C.d,C.s,C.l,C.r,C.u]
    Bnew = permute(Bmat,[2 1 3 5 4]);    % [s,l,r,u,d]
    Cnew = permute(Cmat,[2 3 4 5 1]);    % [s,l,r,u,d]
    info = local_info(inf1,inf2,lam1,lam2);
end

function [Lfac,Rfac,lambda,info] = local_split_matrix(M,leftDims,rightDims,Dmax,svdCutoff)
    [U,S,V] = svd(M,'econ');
    sval = diag(S);
    if isempty(sval)
        error('SU_ApplyThreeSiteEndGate_Path:EmptySVD','SVD returned no singular values.');
    end
    keep = min(Dmax,numel(sval));
    if svdCutoff > 0
        keep2 = sum(sval > svdCutoff*max(sval));
        keep = min(keep,max(1,keep2));
    end
    svalKeep = sval(1:keep);
    U = U(:,1:keep); V = V(:,1:keep);
    sqrtS = sqrt(svalKeep(:));
    Lmat = bsxfun(@times,U,sqrtS.');
    Rmat = bsxfun(@times,sqrtS,V');
    Lfac = reshape(Lmat,[leftDims keep]);
    Rfac = reshape(Rmat,[keep rightDims]);
    nrm = norm(svalKeep);
    if nrm > 0, lambda=svalKeep(:)/nrm; else, lambda=svalKeep(:); end
    info = struct('singularValues',sval,'keptSingularValues',svalKeep,'keep',keep, ...
        'discardedWeight',sum(sval(keep+1:end).^2), ...
        'relDiscardedWeight',sum(sval(keep+1:end).^2)/max(sum(sval.^2),eps));
end

function info = local_info(inf1,inf2,lam1,lam2)
    info = struct();
    info.keep1 = inf1.keep; info.keep2 = inf2.keep;
    info.relDiscardedWeight1 = inf1.relDiscardedWeight;
    info.relDiscardedWeight2 = inf2.relDiscardedWeight;
    info.relDiscardedWeight = max(inf1.relDiscardedWeight,inf2.relDiscardedWeight);
    info.lambda1 = lam1; info.lambda2 = lam2;
    info.maxKeep = max([inf1.keep inf2.keep]);
end
