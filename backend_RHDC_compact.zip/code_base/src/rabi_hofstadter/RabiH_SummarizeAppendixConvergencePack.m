function summary = RabiH_SummarizeAppendixConvergencePack(pack)
%RABIH_SUMMARIZEAPPENDIXCONVERGENCEPACK Summarize StageRH4U pack quality.

summary = struct();
summary.stage = 'StageRH4U';

if isfield(pack,'scanQ') && isfield(pack.scanQ,'summary')
    q = pack.scanQ.summary;
else
    q = RabiH_SummarizeAccuracyOverlayScan(pack.scanQ.records);
end
if isfield(pack,'scanT') && isfield(pack.scanT,'summaryT')
    t = pack.scanT.summaryT;
elseif isfield(pack,'scanT') && isfield(pack.scanT,'records')
    t = RabiH_SummarizeHighDphLBOBenchmark(pack.scanT.records);
else
    t = struct();
end
summary.stage4Q = q;
summary.stage4T = t;

summary.stage4QPhaseMatch = local_get(q,'targetMatchFraction',NaN);
summary.stage4QMaxCurrentDivergence = local_get(q,'maxCurrentDivergence',NaN);
summary.stage4QMaxChiralityError = local_get(q,'maxChiralityDefinitionError',NaN);
summary.stage4QMaxBranchDE = local_get(q,'maxBranchDE',NaN);
summary.stage4QMaxBranchDRho = local_get(q,'maxBranchDRho',NaN);
summary.stage4QMaxBranchDCurrent = local_get(q,'maxBranchDCurrent',NaN);
summary.stage4QMaxBranchDChirality = local_get(q,'maxBranchDChirality',NaN);

summary.stage4TPhaseMatch = local_get(t,'phaseMatchFraction',NaN);
summary.stage4TPhaseErrors = local_get(t,'numPhaseError',NaN);
summary.stage4TMaxAbsDE = local_get(t,'maxAbsDE',NaN);
summary.stage4TMaxRelRhoSR = local_get(t,'maxRelRhoSR',NaN);
summary.stage4TMaxRelCurrent = local_get(t,'maxRelCurrent',NaN);
summary.stage4TMaxRelChirality = local_get(t,'maxRelChirality',NaN);
summary.stage4TMeanSpeedup = local_get(t,'meanSpeedup',NaN);
summary.stage4THopDimReduction = [local_get(t,'minHopDimReduction',NaN) local_get(t,'maxHopDimReduction',NaN)];
summary.stage4TLocalSpectrumError = [local_get(t,'minLocalSpectrumError',NaN) local_get(t,'maxLocalSpectrumError',NaN)];

spec = pack.spec;
qOK = summary.stage4QPhaseMatch >= RabiH_GetOpt(spec,'requirePhaseMatchQ',0.999);
tOK = summary.stage4TPhaseMatch >= RabiH_GetOpt(spec,'requirePhaseMatchT',0.999) && summary.stage4TPhaseErrors == 0;
rhoOK = summary.stage4TMaxRelRhoSR <= RabiH_GetOpt(spec,'warnRelRhoT',3e-2);
curOK = summary.stage4TMaxRelCurrent <= RabiH_GetOpt(spec,'warnRelCurrentT',3e-2);
chiOK = summary.stage4TMaxRelChirality <= RabiH_GetOpt(spec,'warnRelChiralityT',3e-2);
summary.readyForAppendix = qOK && tOK && rhoOK && curOK && chiOK;
summary.recommendation = local_recommendation(summary);
end

function v = local_get(s, field, defaultValue)
if isstruct(s) && isfield(s,field) && ~isempty(s.(field))
    v = s.(field);
else
    v = defaultValue;
end
end

function msg = local_recommendation(s)
if s.readyForAppendix
    msg = 'Appendix convergence/LBO evidence is internally consistent.';
else
    msg = 'Inspect StageRH4Q/4T outliers before using these tables as final Appendix evidence.';
end
end
