function RabiH_PrintAccuracyOverlayReport(scan)
%RABIH_PRINTACCURACYOVERLAYREPORT Print StageRH4Q accuracy overlay summary.

summary = scan.summary;
fprintf('--- RabiH StageRH4Q accuracy overlay report ---\n');
fprintf('records / ok / error       : %d / %d / %d\n', summary.numRecords, summary.numOK, summary.numError);
fprintf('energy range               : [%.12g, %.12g]\n', summary.energyRange(1), summary.energyRange(2));
fprintf('rhoSR range                : [%.12g, %.12g]\n', summary.rhoRange(1), summary.rhoRange(2));
fprintf('max |current|              : %.6e\n', summary.maxCurrent);
fprintf('max |chirality|            : %.6e\n', summary.maxChirality);
fprintf('max current divergence     : %.6e\n', summary.maxCurrentDivergence);
fprintf('max chirality err          : %.6e\n', summary.maxChiralityDefinitionError);
fprintf('target match fraction      : %.3f\n', summary.targetMatchFraction);
fprintf('max branch |dE|            : %.6e\n', summary.maxBranchDE);
fprintf('max branch |dRho|          : %.6e\n', summary.maxBranchDRho);
fprintf('max branch |dCurrent|      : %.6e\n', summary.maxBranchDCurrent);
fprintf('max branch |dChirality|    : %.6e\n', summary.maxBranchDChirality);
if isfield(scan,'csvFile') && ~isempty(scan.csvFile)
    fprintf('CSV                        : %s\n', scan.csvFile);
end
fprintf('branch              target      n   match phaseLabels          E-range                         rho-range                       |J|-range                       |chi|-range\n');
for k = 1:numel(summary.branchTable)
    b = summary.branchTable(k);
    fprintf('%-19s %-9s %3d  %.3f %-20s [% .6e,% .6e] [% .6e,% .6e] [% .6e,% .6e] [% .6e,% .6e]\n', ...
        local_trunc(b.branchName,19), local_trunc(b.targetPhase,9), b.numRecords, b.targetMatchFraction, ...
        local_trunc(b.phaseLabels,20), b.energyRange(1), b.energyRange(2), b.rhoRange(1), b.rhoRange(2), ...
        b.currentRange(1), b.currentRange(2), b.chiralityRange(1), b.chiralityRange(2));
end
end

function s = local_trunc(s,n)
if numel(s) > n, s = s(1:n); end
end
