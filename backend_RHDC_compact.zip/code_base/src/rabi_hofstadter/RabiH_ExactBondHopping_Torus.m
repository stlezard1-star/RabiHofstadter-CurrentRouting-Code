function [eBond, numerator, denominator] = RabiH_ExactBondHopping_Torus(unitCell, params, x, y, direction, Lx, Ly)
%RABIH_EXACTBONDHOPPING_TORUS Exact hopping energy on one oriented bond.
%   Supports NN right/down and NNN diagp/diagm bonds with periodic wrapping.

    if nargin < 7 || isempty(Ly), Ly = unitCell.Ly; end
    if nargin < 6 || isempty(Lx), Lx = unitCell.Lx; end
    spec = RabiH_BondSpec(x,y,direction,params,Lx,Ly);
    terms = RabiH_HoppingEnergyTerms(params, spec.phase, spec.tval);
    [eBond,numerator,denominator] = iPEPS_ExactProductOpTerms_Torus(unitCell,terms,x,y,spec.x2,spec.y2,Lx,Ly);
    if abs(imag(eBond)) < 1e-12*max(1,abs(real(eBond)))
        eBond = real(eBond);
    end
end
