function points = RabiH_ExpandConvergenceScanSpec(paramsBase, optsBase, scanSpec)
%RABIH_EXPANDCONVERGENCESCANSPEC Expand StageRH4K scan axes into point structs.

if nargin < 1 || isempty(paramsBase), paramsBase = struct(); end
if nargin < 2 || isempty(optsBase), optsBase = struct(); end
if nargin < 3 || isempty(scanSpec), scanSpec = struct(); end

DmaxList = local_get(scanSpec,'DmaxList',RabiH_GetOpt(optsBase,'Dmax',2));
chiMaxList = local_get(scanSpec,'chiMaxList',RabiH_GetOpt(optsBase,'chiMax',4));
dphList = local_get(scanSpec,'dphList',RabiH_GetOpt(paramsBase,'dph',3));
alphaSeedList = local_get(scanSpec,'alphaSeedList',RabiH_GetOpt(paramsBase,'alphaSeed',0));
alphaPatternList = local_get(scanSpec,'alphaPatternList',{RabiH_GetOpt(paramsBase,'alphaPattern','uniform')});
sharedBoundaryMixList = local_get(scanSpec,'sharedBoundaryMixList',RabiH_GetOpt(optsBase,'sharedBoundaryMix',0));
gRList = local_get(scanSpec,'gRList',RabiH_GetOpt(paramsBase,'gR',0.3));
tList = local_get(scanSpec,'tList',RabiH_GetOpt(paramsBase,'t',0.05));
PhiList = local_get(scanSpec,'PhiList',RabiH_GetOpt(paramsBase,'Phi',0));
sourceEtaList = local_get(scanSpec,'sourceEtaList',RabiH_GetOpt(paramsBase,'sourceEta',0));
sourcePhaseList = local_get(scanSpec,'sourcePhaseList',RabiH_GetOpt(paramsBase,'sourcePhase',0));
maxPoints = local_get(scanSpec,'maxPoints',Inf);

if ischar(alphaPatternList)
    alphaPatternList = {alphaPatternList};
end

points = repmat(local_empty_point(),1,0);
idx = 0;
for idph = 1:numel(dphList)
for iD = 1:numel(DmaxList)
for ichi = 1:numel(chiMaxList)
for ia = 1:numel(alphaSeedList)
for ipat = 1:numel(alphaPatternList)
for imix = 1:numel(sharedBoundaryMixList)
for ig = 1:numel(gRList)
for it = 1:numel(tList)
for iphi = 1:numel(PhiList)
for isrc = 1:numel(sourceEtaList)
for iphsrc = 1:numel(sourcePhaseList)
    if idx >= maxPoints
        return;
    end
    idx = idx + 1;
    p = local_empty_point();
    p.index = idx;
    p.dph = dphList(idph);
    p.Dmax = DmaxList(iD);
    p.chiMax = chiMaxList(ichi);
    p.alphaSeed = alphaSeedList(ia);
    p.alphaPattern = alphaPatternList{ipat};
    p.sharedBoundaryMix = sharedBoundaryMixList(imix);
    p.gR = gRList(ig);
    p.t = tList(it);
    p.Phi = PhiList(iphi);
    p.sourceEta = sourceEtaList(isrc);
    p.sourcePhase = sourcePhaseList(iphsrc);
    p.label = sprintf('p%04d_dph%d_D%d_chi%d_mix%.3g_src%.3g_alpha%.3g_%s', ...
        p.index, p.dph, p.Dmax, p.chiMax, p.sharedBoundaryMix, abs(p.sourceEta), p.alphaSeed, p.alphaPattern);
    points(end+1) = p; %#ok<AGROW>
end
end
end
end
end
end
end
end
end
end
end
end

function p = local_empty_point()
p = struct();
p.index = NaN;
p.dph = NaN;
p.Dmax = NaN;
p.chiMax = NaN;
p.alphaSeed = NaN;
p.alphaPattern = '';
p.sharedBoundaryMix = NaN;
p.gR = NaN;
p.t = NaN;
p.Phi = NaN;
p.sourceEta = 0;
p.sourcePhase = 0;
p.label = '';
end

function val = local_get(S, name, defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
