function RabiH_PrintNNNPatternFigureSetReport(figSet)
%RABIH_PRINTNNNPATTERNFIGURESETREPORT Print StageRH4AA figure-set summary.
fprintf('--- RabiH StageRH4AA NNN current-pattern figure-set report ---\n');
fprintf('target g, J1          : %.6g, %.6g\n',figSet.targetG,figSet.targetJ1);
fprintf('records / target recs  : %d / %d\n',figSet.numRecords,figSet.numTargetRecords);
fprintf('map figure             : %s\n',figSet.mapFigurePng);
fprintf('arrow figure           : %s\n',figSet.arrowFigurePng);
fprintf('selected CSV           : %s\n',figSet.selectedCsv);
if isfield(figSet,'selected')
    fprintf('selected records:\n');
    for k=1:numel(figSet.selected)
        r=figSet.selected(k).record;
        fprintf('  lambda=% .3f theta/pi=% .3f label=%s j13=% .3e j24=% .3e |chiSq|=%.3e |chiTri|=%.3e\n', ...
            r.lambda,r.thetaTri/pi,r.patternLabel,getnum(r,'j13'),getnum(r,'j24'),abs(getnum(r,'chiSquare')),getnum(r,'meanAbsTriangularChirality'));
    end
end
end
function v=getnum(r,name)
if isstruct(r) && isfield(r,name) && ~isempty(r.(name)), v=real(r.(name)); else, v=NaN; end
end
