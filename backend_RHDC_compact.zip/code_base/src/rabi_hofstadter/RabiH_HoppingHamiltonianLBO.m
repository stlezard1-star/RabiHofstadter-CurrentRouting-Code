function [Hhop, ops] = RabiH_HoppingHamiltonianLBO(params, basis, phase, tval)
%RABIH_HOPPINGHAMILTONIANLBO Two-site hopping Hamiltonian in LBO basis.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(basis), basis = RabiH_PhotonBasis_FromSnapshots(params, struct()); end
if nargin < 3 || isempty(phase), phase = 0; end
if nargin < 4 || isempty(tval), tval = RabiH_GetOpt(params,'t',0.05); end
ops = RabiH_SiteOpsLBO(params,basis);
a = ops.a; ad = ops.adag;
Hhop = -tval*(exp(1i*phase)*RabiH_TwoSiteOp(ad,a) + exp(-1i*phase)*RabiH_TwoSiteOp(a,ad));
Hhop = 0.5*(Hhop+Hhop');
end
