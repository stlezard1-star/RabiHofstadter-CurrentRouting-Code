function summary = RabiH_SummarizeBranchStabilityScan(records)
%RABIH_SUMMARIZEBRANCHSTABILITYSCAN Summarize StageRH4N branch diagnostics.

if nargin < 1 || isempty(records)
    summary = struct('numRecords',0,'numOK',0,'numError',0);
    return;
end
ok = arrayfun(@(r) strcmpi(r.status,'ok'), records);
summary = struct();
summary.numRecords = numel(records);
summary.numOK = sum(ok);
summary.numError = sum(~ok);
summary.allOK = all(ok);
summary.branches = unique({records.branchName},'stable');
summary.numBranches = numel(summary.branches);
summary.energyRange = local_range([records(ok).energyPerSite]);
summary.rhoSRRange = local_range([records(ok).superradiantDensity]);
summary.maxAbsCurrent = local_max([records(ok).meanAbsCurrent]);
summary.maxAbsChirality = local_max([records(ok).meanAbsChirality]);
summary.maxCurrentDivergence = local_max([records(ok).maxCurrentDivergence]);
summary.maxChiralityDefinitionError = local_max([records(ok).maxChiralityDefinitionError]);
summary.numTargetMatches = sum(arrayfun(@(r) local_bool_field(r,'matchesTarget'), records(ok)));
summary.targetMatchFraction = summary.numTargetMatches / max(1,summary.numOK);
summary.maxAbsEnergyDeltaWithinBranch = 0;
summary.maxAbsRhoDeltaWithinBranch = 0;
summary.maxAbsCurrentDeltaWithinBranch = 0;
summary.maxAbsChiralityDeltaWithinBranch = 0;
summary.branchTable = local_branch_table(records(ok), summary.branches);
for k = 1:numel(summary.branchTable)
    b = summary.branchTable(k);
    summary.maxAbsEnergyDeltaWithinBranch = max(summary.maxAbsEnergyDeltaWithinBranch, b.dEmax);
    summary.maxAbsRhoDeltaWithinBranch = max(summary.maxAbsRhoDeltaWithinBranch, b.dRhoMax);
    summary.maxAbsCurrentDeltaWithinBranch = max(summary.maxAbsCurrentDeltaWithinBranch, b.dCurrentMax);
    summary.maxAbsChiralityDeltaWithinBranch = max(summary.maxAbsChiralityDeltaWithinBranch, b.dChiralityMax);
end
summary.maxDivergenceOverCurrent = local_max_div_over_current(records(ok));
end

function table = local_branch_table(records, branches)
table = repmat(local_empty_branch(),1,numel(branches));
for ib = 1:numel(branches)
    name = branches{ib};
    mask = strcmp({records.branchName},name);
    rr = records(mask);
    b = local_empty_branch();
    b.branchName = name;
    if isempty(rr)
        table(ib) = b;
        continue;
    end
    b.numRecords = numel(rr);
    b.targetPhase = rr(1).targetPhase;
    b.phaseLabels = unique({rr.phaseLabel},'stable');
    b.numTargetMatches = sum(arrayfun(@(r) local_bool_field(r,'matchesTarget'), rr));
    E = [rr.energyPerSite];
    rho = [rr.superradiantDensity];
    cur = [rr.meanAbsCurrent];
    chi = [rr.meanAbsChirality];
    div = [rr.maxCurrentDivergence];
    b.energyRange = local_range(E);
    b.rhoSRRange = local_range(rho);
    b.currentRange = local_range(cur);
    b.chiralityRange = local_range(chi);
    b.maxCurrentDivergence = local_max(div);
    b.dEmax = max(abs(E - E(1)));
    b.dRhoMax = max(abs(rho - rho(1)));
    b.dCurrentMax = max(abs(cur - cur(1)));
    b.dChiralityMax = max(abs(chi - chi(1)));
    b.referenceEnergy = E(1);
    b.referenceRhoSR = rho(1);
    table(ib) = b;
end
end

function b = local_empty_branch()
b = struct();
b.branchName = '';
b.targetPhase = '';
b.numRecords = 0;
b.numTargetMatches = 0;
b.phaseLabels = {};
b.energyRange = [NaN NaN];
b.rhoSRRange = [NaN NaN];
b.currentRange = [NaN NaN];
b.chiralityRange = [NaN NaN];
b.maxCurrentDivergence = NaN;
b.dEmax = NaN;
b.dRhoMax = NaN;
b.dCurrentMax = NaN;
b.dChiralityMax = NaN;
b.referenceEnergy = NaN;
b.referenceRhoSR = NaN;
end

function m = local_max_div_over_current(records)
if isempty(records)
    m = NaN;
    return;
end
rat = NaN(1,numel(records));
for k = 1:numel(records)
    cur = max(abs([records(k).meanAbsCurrent records(k).maxAbsCurrent]));
    div = abs(records(k).maxCurrentDivergence);
    rat(k) = div / max(cur,1e-12);
end
m = local_max(rat);
end

function tf = local_bool_field(S,name)
tf = isstruct(S) && isfield(S,name) && ~isempty(S.(name)) && logical(S.(name));
end

function r = local_range(x)
x = x(~isnan(x));
if isempty(x)
    r = [NaN NaN];
else
    r = [min(x) max(x)];
end
end

function m = local_max(x)
x = x(~isnan(x));
if isempty(x), m = NaN; else, m = max(abs(x)); end
end
