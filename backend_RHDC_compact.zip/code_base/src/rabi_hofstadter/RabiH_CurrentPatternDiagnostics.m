function [pat, obs] = RabiH_CurrentPatternDiagnostics(obs, params)
%RABIH_CURRENTPATTERNDIAGNOSTICS Full NN/NNN current and loop-current diagnostics.
%
%   Adds square chirality, four triangular chiralities, diagonal currents,
%   total current divergence, and a coarse current-pattern label.

    if nargin < 2 || isempty(params), params = struct(); end
    if ~isfield(obs,'jRight') || ~isfield(obs,'jDown')
        error('RabiH_CurrentPatternDiagnostics:MissingNN','obs.jRight and obs.jDown are required.');
    end
    jR = obs.jRight;
    jD = obs.jDown;
    [Ly,Lx] = size(jR);
    if isfield(obs,'jDiagP'), jP = obs.jDiagP; else, jP = zeros(Ly,Lx); end
    if isfield(obs,'jDiagM'), jM = obs.jDiagM; else, jM = zeros(Ly,Lx); end

    chiSq = zeros(Ly,Lx);
    c123 = zeros(Ly,Lx); c134 = zeros(Ly,Lx); c124 = zeros(Ly,Lx); c234 = zeros(Ly,Lx);
    divTotal = zeros(Ly,Lx);
    for y = 1:Ly
        yp = mod(y,Ly)+1;
        ym = mod(y-2,Ly)+1;
        for x = 1:Lx
            xp = mod(x,Lx)+1;
            xm = mod(x-2,Lx)+1;
            I12 = jR(y,x);
            I23 = jD(y,xp);
            I34 = -jR(yp,x);
            I41 = -jD(y,x);
            I13 = jP(y,x);
            I24 = -jM(yp,x);    % 2 -> 4 is reverse of diagm 4 -> 2
            I42 = jM(yp,x);
            chiSq(y,x) = I12 + I23 + I34 + I41;
            c123(y,x) = I12 + I23 - I13;
            c134(y,x) = I13 + I34 + I41;
            c124(y,x) = I12 + I24 + I41;
            c234(y,x) = I23 + I34 + I42;
            divTotal(y,x) = jR(y,x) - jR(y,xm) + jD(y,x) - jD(ym,x) + ...
                            jP(y,x) - jP(ym,xm) + jM(y,x) - jM(yp,xm);
        end
    end

    pat = struct();
    pat.jRight = jR;
    pat.jDown = jD;
    pat.jDiagP = jP;
    pat.jDiagM = jM;
    pat.chiSquare = chiSq;
    pat.chiTri123 = c123;
    pat.chiTri134 = c134;
    pat.chiTri124 = c124;
    pat.chiTri234 = c234;
    pat.meanAbsNNCurrent = mean(abs([jR(:); jD(:)]));
    pat.meanAbsDiagCurrent = mean(abs([jP(:); jM(:)]));
    pat.meanAbsSquareChirality = mean(abs(chiSq(:)));
    pat.meanAbsTriangularChirality = mean(abs([c123(:); c134(:); c124(:); c234(:)]));
    pat.triangularImbalance = 0.5*mean(abs(c123(:)-c134(:)) + abs(c124(:)-c234(:)));
    pat.diagCurrentImbalance = mean(abs(jP(:)-jM(:)));
    pat.currentDivergenceTotal = divTotal;
    pat.maxCurrentDivergenceTotal = max(abs(divTotal(:)));
    pat.triangleIdentityErr = max([max(abs((c123(:)+c134(:))-chiSq(:))), max(abs((c124(:)+c234(:))-chiSq(:)))]);
    pat.label = local_classify(obs, pat, params);

    obs.jDiagP = jP;
    obs.jDiagM = jM;
    obs.plaquetteChirality = chiSq;
    obs.chiSquare = chiSq;
    obs.chiTri123 = c123;
    obs.chiTri134 = c134;
    obs.chiTri124 = c124;
    obs.chiTri234 = c234;
    obs.currentPattern = pat;
    obs.meanAbsNNCurrent = pat.meanAbsNNCurrent;
    obs.meanAbsDiagCurrent = pat.meanAbsDiagCurrent;
    obs.meanAbsSquareChirality = pat.meanAbsSquareChirality;
    obs.meanAbsTriangularChirality = pat.meanAbsTriangularChirality;
    obs.triangularImbalance = pat.triangularImbalance;
    obs.diagCurrentImbalance = pat.diagCurrentImbalance;
    obs.maxCurrentDivergenceTotal = pat.maxCurrentDivergenceTotal;
    obs.triangleIdentityErr = pat.triangleIdentityErr;
    obs.currentPatternLabel = pat.label;
end

function label = local_classify(obs, pat, params)
    rho = RabiH_GetOpt(obs,'superradiantDensity',0);
    rhoThr = RabiH_GetOpt(params,'rhoThreshold',1e-4);
    curThr = RabiH_GetOpt(params,'currentThreshold',1e-5);
    chiThr = RabiH_GetOpt(params,'chiralityThreshold',1e-4);
    if rho < rhoThr
        label = 'normal'; return;
    end
    sq = pat.meanAbsSquareChirality;
    tri = pat.meanAbsTriangularChirality;
    diag = pat.meanAbsDiagCurrent;
    imb = pat.triangularImbalance;
    if sq < chiThr && tri < chiThr && diag < curThr
        label = 'SR';
    elseif tri >= chiThr && sq < chiThr
        if imb > 10*chiThr
            label = 'imbalancedTriangularChiralSR';
        else
            label = 'triangularChiralSR';
        end
    elseif sq >= chiThr && tri < chiThr
        label = 'squareChiralSR';
    elseif sq >= chiThr && tri >= chiThr
        if imb > 10*chiThr
            label = 'imbalancedMixedChiralSR';
        else
            label = 'mixedChiralSR';
        end
    else
        label = 'currentSR';
    end
end
