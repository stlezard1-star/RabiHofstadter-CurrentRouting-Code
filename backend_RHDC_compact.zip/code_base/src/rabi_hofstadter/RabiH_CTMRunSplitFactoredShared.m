function ctx = RabiH_CTMRunSplitFactoredShared(unitCell, opts)
%RABIH_CTMRUNSPLITFACTOREDSHARED StageRH4J shared/cached periodic split CTM.
%
% This backend is the next accuracy/engineering step after StageRH4H.  It
% keeps the split ket/bra cell, lazily builds one local double-layer tensor
% per inequivalent site, caches all neighbour tensors, and evolves all local
% CTM environments in a shared global sweep.  Optional boundary sharing can
% softly align the edge tensors living on the same periodic bond.
%
% Scope of this v1 kernel:
%   - no 2x2 blocked tensor is allocated;
%   - local double layers are cached once per site;
%   - all CTM environments are updated in one global periodic sweep;
%   - sharedBoundaryMix controls optional edge-boundary averaging.
%
% With sharedBoundaryMix=0 this backend is intentionally numerically aligned
% with the StageRH4H periodic-neighbour backend while exposing the cached and
% shared-boundary infrastructure needed for larger-D profiling.

    if nargin < 2 || isempty(opts), opts = struct(); end

    scell = RabiH_SplitLayerCellConstruct(unitCell, opts);
    splitCost = RabiH_SplitFactoredCTMCostEstimate(unitCell, opts);
    if ~splitCost.isSafe
        error('RabiH_CTMRunSplitFactoredShared:UnsafeSplitCost', ...
            'Split/factored CTM guard refused this point: %s', splitCost.reason);
    end

    chiMax = RabiH_GetOpt(opts,'chiMax',16);
    maxIter = RabiH_GetOpt(opts,'sharedMaxIter',RabiH_GetOpt(opts,'maxIter',20));
    tol = RabiH_GetOpt(opts,'tol',1e-9);
    verbose = RabiH_GetOpt(opts,'verbose',false);
    sharedBoundaryMix = RabiH_GetOpt(opts,'sharedBoundaryMix',0.0);
    if sharedBoundaryMix < 0 || sharedBoundaryMix > 1
        error('RabiH_CTMRunSplitFactoredShared:InvalidMix', ...
            'sharedBoundaryMix must be in [0,1].');
    end

    envOpts = opts;
    envOpts.chiMax = chiMax;
    envOpts.maxIter = maxIter;
    envOpts.tol = tol;
    envOpts.skipNormHistory = RabiH_GetOpt(opts,'skipCTMNormHistory',true) || ...
                              RabiH_GetOpt(opts,'skipNormHistory',false) || ...
                              RabiH_GetOpt(opts,'skipIterNorm',false);

    Lx = scell.Lx;
    Ly = scell.Ly;
    Ecell = cell(Ly,Lx);
    envCell = cell(Ly,Lx);
    WCell = cell(Ly,Lx);
    denOne = zeros(Ly,Lx);
    denH = zeros(Ly,Lx);
    denV = zeros(Ly,Lx);
    localDoubleLayerElements = zeros(Ly,Lx);

    for y = 1:Ly
        for x = 1:Lx
            Ecell{y,x} = RabiH_SplitLayerLocalDoubleLayer(scell,x,y);
            localDoubleLayerElements(y,x) = numel(Ecell{y,x});
            envCell{y,x} = CTM_InitUniform(Ecell{y,x}, envOpts);
        end
    end

    neighbour = local_make_neighbour_cache(Lx,Ly);
    [envCell, globalHistory, shareInfo] = local_shared_periodic_iterate( ...
        Ecell, envCell, neighbour, envOpts, sharedBoundaryMix, verbose);

    for y = 1:Ly
        for x = 1:Lx
            WCell{y,x} = CTM_BuildOneSiteEnvironment(envCell{y,x});
            denOne(y,x) = CTM_EvaluateNorm_Fast(Ecell{y,x}, WCell{y,x});
            if abs(denOne(y,x)) < eps
                error('RabiH_CTMRunSplitFactoredShared:ZeroNorm', ...
                    'Encountered zero shared CTM one-site norm at site (%d,%d).', x, y);
            end
        end
    end

    for y = 1:Ly
        for x = 1:Lx
            xp = neighbour.rightX(y,x);
            yp = neighbour.downY(y,x);
            denH(y,x) = CTM_EvaluateHorizontalPair(Ecell{y,x}, Ecell{y,xp}, envCell{y,x});
            denV(y,x) = CTM_EvaluateVerticalPair(Ecell{y,x}, Ecell{yp,x}, envCell{y,x});
            if abs(denH(y,x)) < eps || abs(denV(y,x)) < eps
                error('RabiH_CTMRunSplitFactoredShared:ZeroPairNorm', ...
                    'Encountered zero shared CTM pair norm at site (%d,%d).', x, y);
            end
        end
    end

    ctx = struct();
    ctx.stage = 'StageRH4J';
    ctx.backend = 'split_factored_ctm_v1_shared_cached';
    ctx.description = ['StageRH4J shared/cached periodic split/factored CTM.  ' ...
        'No blocked unit-cell tensor is allocated.  Local double-layer tensors ' ...
        'are cached once and all local environments are evolved in global ' ...
        'periodic sweeps with optional shared-boundary mixing.'];
    ctx.splitCell = scell;
    ctx.cost = splitCost;
    ctx.hasBlockedTensor = false;
    ctx.hasLocalDoubleLayerCell = true;
    ctx.hasCachedLocalDoubleLayers = true;
    ctx.isProductionCTM = true;
    ctx.productionLevel = 'StageRH4J_v1_shared_cached_periodic_split_ctm';
    ctx.Ecell = Ecell;
    ctx.envCell = envCell;
    ctx.WCell = WCell;
    ctx.denOne = local_real_if_safe(denOne);
    ctx.denH = local_real_if_safe(denH);
    ctx.denV = local_real_if_safe(denV);
    ctx.globalHistory = globalHistory;
    ctx.shareInfo = shareInfo;
    ctx.neighbourCache = neighbour;
    ctx.localDoubleLayerElements = localDoubleLayerElements;
    ctx.maxLocalDoubleLayerElements = max(localDoubleLayerElements(:));
    ctx.chiMax = chiMax;
    ctx.maxIter = maxIter;
    ctx.tol = tol;
    ctx.sharedBoundaryMix = sharedBoundaryMix;
    ctx.absorptionPolicy = ['shared cached periodic sweep: all inequivalent CTM ' ...
        'environments are updated in lockstep using cached periodic-neighbour tensors'];
    ctx.warning = ['StageRH4J is a shared/cached engineering upgrade over StageRH4H.  ' ...
        'Use it for convergence scans and profiling.  Key article points still ' ...
        'need chi, D, dph, and seed-pattern convergence checks.'];

    if verbose
        fprintf('[StageRH4J] shared/cached split CTM built. max local DL elems=%g, chiMax=%d, mix=%.3g\n', ...
            ctx.maxLocalDoubleLayerElements, chiMax, sharedBoundaryMix);
    end
end

function neighbour = local_make_neighbour_cache(Lx,Ly)
    leftX = zeros(Ly,Lx); rightX = zeros(Ly,Lx);
    upY = zeros(Ly,Lx); downY = zeros(Ly,Lx);
    for y = 1:Ly
        for x = 1:Lx
            leftX(y,x)  = mod(x-2,Lx)+1;
            rightX(y,x) = mod(x,Lx)+1;
            upY(y,x)    = mod(y-2,Ly)+1;
            downY(y,x)  = mod(y,Ly)+1;
        end
    end
    neighbour = struct('leftX',leftX,'rightX',rightX,'upY',upY,'downY',downY);
end

function [envCell, history, shareInfo] = local_shared_periodic_iterate(Ecell, envCell, neighbour, opts, mix, verbose)
    maxIter = CTM_GetOpt(opts,'maxIter',20);
    tol = CTM_GetOpt(opts,'tol',1e-9);
    skipNormHistory = CTM_GetOpt(opts,'skipNormHistory',true) || ...
                      CTM_GetOpt(opts,'skipIterNorm',false) || ...
                      CTM_GetOpt(opts,'skipCTMNormHistory',false);
    [Ly,Lx] = size(Ecell);
    history = zeros(maxIter,3); % [maxEnvDiff, meanNormOrNaN, shareResidual]
    shareInfo = struct('numSharedEdges',0,'lastResidual',NaN,'mix',mix);

    for it = 1:maxIter
        oldCell = envCell;
        for y = 1:Ly
            for x = 1:Lx
                oldCell{y,x} = CTM_NormalizeEnv(oldCell{y,x});
            end
        end

        newCell = cell(Ly,Lx);
        for y = 1:Ly
            for x = 1:Lx
                env = envCell{y,x};
                env = local_one_cached_cycle(Ecell, env, neighbour, x, y, opts);
                newCell{y,x} = CTM_NormalizeEnv(env);
            end
        end

        [newCell, shareResidual, numShared] = local_share_boundary_edges(newCell, mix);
        envCell = newCell;
        diffVal = local_envcell_diff(envCell, oldCell);
        if skipNormHistory
            normVal = NaN;
        else
            normVals = zeros(Ly,Lx);
            for yy = 1:Ly
                for xx = 1:Lx
                    normVals(yy,xx) = CTM_EvaluateNorm(Ecell{yy,xx}, envCell{yy,xx});
                end
            end
            normVal = mean(normVals(:));
        end
        history(it,:) = [diffVal, normVal, shareResidual];
        shareInfo.numSharedEdges = numShared;
        shareInfo.lastResidual = shareResidual;

        for y = 1:Ly
            for x = 1:Lx
                envCell{y,x}.iter = it;
                envCell{y,x}.lastDiff = diffVal;
                envCell{y,x}.history = history(1:it,:);
            end
        end

        if verbose
            if skipNormHistory
                fprintf('[StageRH4J-CTM] iter %4d: diff = %.3e, norm = skipped, share = %.3e\n', ...
                    it, diffVal, shareResidual);
            else
                fprintf('[StageRH4J-CTM] iter %4d: diff = %.3e, mean norm = %.12e, share = %.3e\n', ...
                    it, diffVal, normVal, shareResidual);
            end
        end
        if diffVal < tol
            history = history(1:it,:);
            return;
        end
    end
    history = history(1:maxIter,:);
end

function env = local_one_cached_cycle(Ecell, env, neighbour, x, y, opts)
    xm = neighbour.leftX(y,x);
    xp = neighbour.rightX(y,x);
    ym = neighbour.upY(y,x);
    yp = neighbour.downY(y,x);
    [env,~] = CTM_MoveLeft(Ecell{y,xm}, env, opts);
    [env,~] = CTM_MoveRight(Ecell{y,xp}, env, opts);
    [env,~] = CTM_MoveUp(Ecell{ym,x}, env, opts);
    [env,~] = CTM_MoveDown(Ecell{yp,x}, env, opts);
    env = CTM_NormalizeEnv(env);
    CTM_CheckEnv(env);
end

function [envCell, residual, numShared] = local_share_boundary_edges(envCell, mix)
    [Ly,Lx] = size(envCell);
    residual = 0;
    numShared = 0;
    if mix <= 0
        return;
    end

    % Horizontal shared edges: right boundary of (x,y) and left boundary of (x+1,y).
    for y = 1:Ly
        for x = 1:Lx
            xp = mod(x,Lx)+1;
            [A,B,r,ok] = local_blend_pair(envCell{y,x}.T2, envCell{y,xp}.T4, mix);
            if ok
                envCell{y,x}.T2 = A;
                envCell{y,xp}.T4 = B;
                residual = max(residual,r);
                numShared = numShared + 1;
            end
        end
    end

    % Vertical shared edges: bottom boundary of (x,y) and top boundary of (x,y+1).
    for y = 1:Ly
        yp = mod(y,Ly)+1;
        for x = 1:Lx
            [A,B,r,ok] = local_blend_pair(envCell{y,x}.T3, envCell{yp,x}.T1, mix);
            if ok
                envCell{y,x}.T3 = A;
                envCell{yp,x}.T1 = B;
                residual = max(residual,r);
                numShared = numShared + 1;
            end
        end
    end

    for y = 1:Ly
        for x = 1:Lx
            envCell{y,x} = CTM_NormalizeEnv(envCell{y,x});
        end
    end
end

function [A2,B2,residual,ok] = local_blend_pair(A,B,mix)
    A2 = A; B2 = B; residual = NaN; ok = false;
    if ~isequal(size(A),size(B))
        return;
    end
    residual = PEPS_RelErr(A,B);
    if ~isfinite(residual), residual = 0; end
    avg = 0.5*(A+B);
    A2 = (1-mix)*A + mix*avg;
    B2 = (1-mix)*B + mix*avg;
    [A2,~] = CTM_FroNormalize(A2);
    [B2,~] = CTM_FroNormalize(B2);
    ok = true;
end

function diffVal = local_envcell_diff(cellA, cellB)
    [Ly,Lx] = size(cellA);
    diffVal = 0;
    for y = 1:Ly
        for x = 1:Lx
            d = CTM_EnvDiff(cellA{y,x}, cellB{y,x});
            if ~isfinite(d), d = 1; end
            diffVal = max(diffVal,d);
        end
    end
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
