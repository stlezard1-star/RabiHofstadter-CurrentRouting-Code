function RabiH_PrintCTMSummary(obs)
%RABIH_PRINTCTMSUMMARY Compact blocked-CTM observable printout.
    fprintf('--- RabiH StageRH2 blocked-CTM summary ---\n');
    fprintf('E/site=%.12g, rhoSR=%.3e, meanN=%.3e\n', real(obs.energyPerSite), real(obs.superradiantDensity), real(obs.meanPhotonNumber));
    fprintf('mean|J|=%.3e, mean|chi|=%.3e\n', real(obs.meanAbsCurrent), real(obs.meanAbsChirality));
end
