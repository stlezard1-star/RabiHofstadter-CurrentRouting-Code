function RabiH_WriteBackendConsistencyCSV(bench, filename)
%RABIH_WRITEBACKENDCONSISTENCYCSV Write StageRH4I backend comparison to CSV.

if nargin < 2 || isempty(filename)
    filename = fullfile(pwd,'rabih_stage4I_backend_consistency.csv');
end
outDir = fileparts(filename);
if ~isempty(outDir) && exist(outDir,'dir') ~= 7
    mkdir(outDir);
end

fid = fopen(filename,'w');
if fid < 0
    error('RabiH_WriteBackendConsistencyCSV:OpenFailed','Cannot open %s for writing.', filename);
end
cleanupObj = onCleanup(@() fclose(fid));

fprintf(fid,'label,backend,stage,ok,energyPerSite,deltaEnergyVsReference,superradiantDensity,deltaRhoSRVsReference,meanPhotonNumber,meanAbsCurrent,meanAbsChirality,runtimeSeconds,message\n');
for k = 1:numel(bench.entries)
    e = bench.entries(k);
    fprintf(fid,'%s,%s,%s,%d,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%s\n', ...
        local_csv(e.label), local_csv(e.backend), local_csv(e.stage), e.ok, ...
        e.energyPerSite, e.deltaEnergyVsReference, e.superradiantDensity, ...
        e.deltaRhoSRVsReference, e.meanPhotonNumber, e.meanAbsCurrent, ...
        e.meanAbsChirality, e.runtimeSeconds, local_csv(e.message));
end
end

function s = local_csv(x)
    if isempty(x)
        s = '';
    elseif isnumeric(x)
        s = num2str(x);
    else
        s = char(x);
    end
    s = strrep(s,'"','""');
    if any(s == ',') || any(s == '"') || any(s == sprintf('\n')) || any(s == sprintf('\r'))
        s = ['"' s '"'];
    end
end
