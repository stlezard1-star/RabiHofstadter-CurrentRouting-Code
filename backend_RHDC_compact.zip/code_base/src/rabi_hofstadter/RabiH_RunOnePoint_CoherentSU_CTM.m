function result = RabiH_RunOnePoint_CoherentSU_CTM(params, opts)
%RABIH_RUNONEPOINT_COHERENTSU_CTM One-point coherent-seed SU + CTM run.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
    if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
    if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
    if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

    uc = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
    [uc, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(uc, params, opts);
    obs = RabiH_CTMObservables_Blocked(uc, params, opts);

    result = struct();
    result.unitCell = uc;
    result.suInfo = suInfo;
    result.obs = obs;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanAbsCurrent = obs.meanAbsCurrent;
    result.alphaSeed = uc.alphaSeed;
end
