function RabiH_PlotCurrentPatternRecord_Refined(rec)
%RABIH_PLOTCURRENTPATTERNRECORD_REFINED Compact current-arrow plot.
coords = [0 0; 1 0; 1 1; 0 1];
plot([coords(:,1);coords(1,1)],[coords(:,2);coords(1,2)],'k-','LineWidth',1.2); hold on;
plot([0 1],[0 1],'k:','LineWidth',0.8); plot([1 0],[0 1],'k:','LineWidth',0.8);
axis equal off; xlim([-0.28 1.28]); ylim([-0.28 1.28]);
text(coords(:,1)-0.05,coords(:,2)-0.07,{'1','2','3','4'},'FontSize',9,'Interpreter','none');
I = [local_num(rec,'j12'),local_num(rec,'j23'),local_num(rec,'j34'),local_num(rec,'j41'),local_num(rec,'j13'),local_num(rec,'j24')];
maxI = max(abs(I(isfinite(I)))); if isempty(maxI) || maxI <= 0, maxI = 1; end
% NN boundary currents: blue/red according to sign after orienting arrow.
local_arrow(coords(1,:),coords(2,:),local_num(rec,'j12'),maxI,[0.0 0.35 0.85]);
local_arrow(coords(2,:),coords(3,:),local_num(rec,'j23'),maxI,[0.85 0.25 0.05]);
local_arrow(coords(3,:),coords(4,:),local_num(rec,'j34'),maxI,[0.0 0.35 0.85]);
local_arrow(coords(4,:),coords(1,:),local_num(rec,'j41'),maxI,[0.85 0.25 0.05]);
% Diagonal currents.
local_arrow(coords(1,:),coords(3,:),local_num(rec,'j13'),maxI,[0.92 0.65 0.00]);
local_arrow(coords(2,:),coords(4,:),local_num(rec,'j24'),maxI,[0.45 0.10 0.55]);
summary = sprintf('|chiSq|=%.3g, |chiTri|=%.3g\nj13=%.3g, j24=%.3g\n%s', ...
    abs(local_num(rec,'chiSquare')),local_num(rec,'meanAbsTriangularChirality'),local_num(rec,'j13'),local_num(rec,'j24'),local_str(rec,'patternLabelRefined'));
text(0.02,1.14,summary,'FontSize',7.5,'Interpreter','none','VerticalAlignment','bottom');
end
function local_arrow(p1,p2,I,maxI,colorVal)
if ~isfinite(I) || abs(I) < 1e-14, return; end
if I < 0, tmp = p1; p1 = p2; p2 = tmp; I = -I; end
mid = 0.5*(p1+p2); vec = p2-p1; L = norm(vec); if L == 0, return; end
vec = vec/L; scale = 0.30 + 0.45*min(1,abs(I)/maxI);
start = mid - 0.5*scale*vec; dv = scale*vec;
quiver(start(1),start(2),dv(1),dv(2),0,'LineWidth',1.2+1.5*min(1,abs(I)/maxI), ...
    'MaxHeadSize',0.50,'Color',colorVal);
end
function v = local_num(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = real(S.(name)); else, v = NaN; end
end
function s = local_str(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), s = S.(name); else, s = ''; end
end
