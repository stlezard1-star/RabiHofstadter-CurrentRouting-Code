function phase = RabiH_NNNPhase(x, y, direction, params)
%RABIH_NNNPHASE Peierls phase on diagonal NNN bonds.
%
%   direction = 'diagp' : (x,y) -> (x+1,y+1), diagonal 1->3
%   direction = 'diagm' : (x,y) -> (x+1,y-1), diagonal 4->2 in plaquette notation
%
%   nnnPhaseMode:
%       'lineIntegral'  default, uses straight-line integral in Landau gauge
%       'zero'          diagonal phase is zero except triangular imbalance
%       'manual'        use params.phaseDiagP / params.phaseDiagM
%
%   Extra triangular imbalance phases:
%       thetaTri applies to both diagonals unless theta13/theta24 are provided.
%       theta13 shifts diagp, theta24 shifts diagm.

    if nargin < 4 || isempty(params), params = struct(); end
    dir = lower(direction);
    mode = lower(RabiH_GetOpt(params,'nnnPhaseMode','lineIntegral'));
    switch mode
        case {'lineintegral','line','gauge','background'}
            switch dir
                case {'diagp','diagplus','13'}
                    base = RabiH_GaugePhase(x,y,'diagp',params);
                case {'diagm','diagminus','24'}
                    base = RabiH_GaugePhase(x,y,'diagm',params);
                otherwise
                    error('RabiH_NNNPhase:UnknownDirection','Unknown diagonal direction: %s.', direction);
            end
        case {'zero','none'}
            base = 0;
        case {'manual','custom'}
            switch dir
                case {'diagp','diagplus','13'}
                    base = RabiH_GetOpt(params,'phaseDiagP',0);
                case {'diagm','diagminus','24'}
                    base = RabiH_GetOpt(params,'phaseDiagM',0);
                otherwise
                    error('RabiH_NNNPhase:UnknownDirection','Unknown diagonal direction: %s.', direction);
            end
        otherwise
            error('RabiH_NNNPhase:UnknownMode','Unknown nnnPhaseMode: %s.', mode);
    end

    thetaTri = RabiH_GetOpt(params,'thetaTri',0);
    switch dir
        case {'diagp','diagplus','13'}
            theta = RabiH_GetOpt(params,'theta13',thetaTri);
        case {'diagm','diagminus','24'}
            theta = RabiH_GetOpt(params,'theta24',thetaTri);
        otherwise
            theta = 0;
    end
    phase = base + theta;
end
