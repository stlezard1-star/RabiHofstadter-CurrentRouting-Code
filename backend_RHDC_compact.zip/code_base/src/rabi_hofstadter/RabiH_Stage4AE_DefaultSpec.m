function spec = RabiH_Stage4AE_DefaultSpec()
%RabiH_Stage4AE_DefaultSpec  Citation/scope-audit defaults for StageRH4AE.
% This stage does not run numerics. It collects the manuscript-level audit
% items after adding NNN hopping and triangular-loop current patterns.

spec.stage = 'StageRH4AE';
spec.title = 'Citation and scope audit for NNN loop-current manuscript';
spec.outputDir = fullfile(pwd,'results_stage4AE_citation_audit');
spec.manuscriptVersion = 'v3_citation_audited';
spec.readyForManuscriptV3 = true;
spec.scopeItems = { ...
    'Do not claim chiral superradiance itself is new.', ...
    'Distinguish finite-loop Rabi/Dicke clusters from 2D thermodynamic loop-current texture.', ...
    'State that NNN hopping creates triangular subloops and redistributes square-loop chirality.', ...
    'Do not claim a new iPEPS algorithm; present split/factored CTM and LBO as numerical tools.', ...
    'Keep path-gate NNN update caveat visible; avoid critical-exponent claims.'};
end
