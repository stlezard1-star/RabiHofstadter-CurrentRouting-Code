function scan = RabiH_RunLBOPEPSBenchmark(paramsBase, optsBase, spec)
%RABIH_RUNLBOPEPSBENCHMARK Run StageRH4S full-vs-LBO one-point PEPS checks.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4S_DefaultLBOBenchmark();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec), spec = struct(); end

branches = local_get(spec,'branchList',RabiH_Stage4S_RepresentativeBranches());
dFullList = local_get(spec,'dFullList',8);
dEffList  = local_get(spec,'dEffList',6);
outDir = local_get(spec,'outputDir',RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4S_lbo_peps_benchmark')));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
stopOnError = local_get(spec,'stopOnError',false);
runFullRef = local_get(spec,'runFullReference',true);

records = repmat(local_empty_record(),1,0);
idx = 0;
startAll = tic;
for ib = 1:numel(branches)
for ifu = 1:numel(dFullList)
for ie = 1:numel(dEffList)
    dFull = dFullList(ifu); dEff = dEffList(ie);
    if dEff > dFull, continue; end
    idx = idx + 1;
    br = branches(ib);
    rec = local_empty_record();
    rec.index = idx;
    rec.branch = br.name;
    rec.targetPhase = br.target;
    rec.dFull = dFull;
    rec.dEff = dEff;
    rec.label = sprintf('s%04d_%s_dfull%d_deff%d',idx,br.name,dFull,dEff);
    t0 = tic;
    try
        paramsPoint = local_apply_branch(paramsBase, br);
        optsPoint = optsBase;
        optsPoint.alpha = br.alphaSeed;
        optsPoint.alphaPattern = br.alphaPattern;
        optsPoint.outputDir = outDir;

        % Build one reusable LBO basis in the full photon space.
        bspec = struct();
        bspec.dFull = dFull;
        bspec.dEff = dEff;
        bspec.alphaList = local_get(spec,'alphaList',[0 0.4 0.8 1.2 1.6]);
        bspec.includeFock = true;
        bspec.numFock = local_get(spec,'numFock',min(4,dFull));
        bspec.includeLocalRabi = true;
        bspec.numLocalStates = local_get(spec,'numLocalStates',6);
        basis = RabiH_PhotonBasis_FromSnapshots(local_setfield(paramsPoint,'dph',dFull), bspec);
        sdiag = RabiH_LBO_LocalSpectrumDiagnostic(local_setfield(paramsPoint,'dph',dFull), basis, local_get(spec,'nLevels',6));
        rec.lboOrthonormalError = basis.orthonormalError;
        rec.lboTruncationHint = basis.truncationHint;
        rec.localSpectrumMaxError = sdiag.maxAbsError;
        rec.localSpectrumRMSError = sdiag.rmsError;

        if runFullRef
            paramsFull = paramsPoint;
            paramsFull.useLBO = false;
            paramsFull.dph = dFull;
            optsFull = optsPoint;
            optsFull.outputDir = fullfile(outDir,'full_refs');
            ticFull = tic;
            fullResult = RabiH_RunOnePoint_AutoBackend(paramsFull, optsFull);
            rec.fullRuntimeSeconds = toc(ticFull);
            rec.fullEnergy = fullResult.energyPerSite;
            rec.fullRhoSR = fullResult.superradiantDensity;
            rec.fullMeanN = fullResult.meanPhotonNumber;
            rec.fullAbsCurrent = fullResult.meanAbsCurrent;
            rec.fullAbsChirality = fullResult.meanAbsChirality;
            rec.fullPhase = RabiH_ClassifyPhaseFromRecord(local_result_to_record(fullResult), local_get(spec,'phaseThresholds',struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5)));
        else
            fullResult = [];
        end

        paramsLBO = paramsPoint;
        paramsLBO.useLBO = true;
        paramsLBO.dphFull = dFull;
        paramsLBO.dphEff = dEff;
        paramsLBO.dph = dEff;
        paramsLBO.lboBasis = basis;
        optsLBO = optsPoint;
        optsLBO.outputDir = fullfile(outDir,'lbo_runs');
        ticLBO = tic;
        lboResult = RabiH_RunOnePoint_AutoBackend(paramsLBO, optsLBO);
        rec.lboRuntimeSeconds = toc(ticLBO);
        rec.lboEnergy = lboResult.energyPerSite;
        rec.lboRhoSR = lboResult.superradiantDensity;
        rec.lboMeanN = lboResult.meanPhotonNumber;
        rec.lboAbsCurrent = lboResult.meanAbsCurrent;
        rec.lboAbsChirality = lboResult.meanAbsChirality;
        rec.lboPhase = RabiH_ClassifyPhaseFromRecord(local_result_to_record(lboResult), local_get(spec,'phaseThresholds',struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5)));

        if runFullRef
            rec.dE = rec.lboEnergy - rec.fullEnergy;
            rec.absDE = abs(rec.dE);
            rec.dRhoSR = rec.lboRhoSR - rec.fullRhoSR;
            rec.relRhoSR = local_relerr(rec.lboRhoSR, rec.fullRhoSR);
            rec.dCurrent = rec.lboAbsCurrent - rec.fullAbsCurrent;
            rec.relCurrent = local_relerr(rec.lboAbsCurrent, rec.fullAbsCurrent);
            rec.dChirality = rec.lboAbsChirality - rec.fullAbsChirality;
            rec.relChirality = local_relerr(rec.lboAbsChirality, rec.fullAbsChirality);
            rec.phaseMatch = strcmpi(rec.fullPhase, rec.lboPhase);
        end
        rec.status = 'ok';
        rec.runtimeSeconds = toc(t0);
        rec.fullSiteDim = 2*dFull;
        rec.lboSiteDim = 2*dEff;
        rec.hopDimFull = (2*dFull)^2;
        rec.hopDimLBO = (2*dEff)^2;
        rec.siteDimReduction = rec.fullSiteDim/max(rec.lboSiteDim,1);
        rec.hopDimReduction = rec.hopDimFull/max(rec.hopDimLBO,1);
        pointFile = fullfile(outDir,sprintf('stage4S_lbo_peps_point_%04d.mat',idx));
        save(pointFile,'paramsPoint','optsPoint','paramsLBO','basis','sdiag','fullResult','lboResult','rec');
        rec.pointFile = pointFile;
    catch ME
        rec.status = 'error';
        rec.runtimeSeconds = toc(t0);
        rec.errorMessage = ME.message;
        if stopOnError
            records(end+1) = rec; %#ok<AGROW>
            rethrow(ME);
        end
    end
    records(end+1) = rec; %#ok<AGROW>
end
end
end

summary = RabiH_SummarizeLBOPEPSBenchmark(records);
scan = struct();
scan.stage = 'StageRH4S';
scan.description = 'Integrated photon-LBO PEPS benchmark: full cutoff versus projected photon basis.';
scan.paramsBase = paramsBase;
scan.optsBase = optsBase;
scan.scanSpec = spec;
scan.records = records;
scan.summary = summary;
scan.outputDir = outDir;
scan.runtimeSeconds = toc(startAll);
if local_get(spec,'writeCSV',true)
    scan.csvFile = RabiH_WriteLBOPEPSBenchmarkCSV(scan, fullfile(outDir,'stage4S_lbo_peps_benchmark.csv'));
end
end

function rec = local_empty_record()
rec = struct('index',NaN,'label','','status','pending','branch','','targetPhase','', ...
    'dFull',NaN,'dEff',NaN,'fullSiteDim',NaN,'lboSiteDim',NaN,'hopDimFull',NaN,'hopDimLBO',NaN, ...
    'siteDimReduction',NaN,'hopDimReduction',NaN, ...
    'fullEnergy',NaN,'lboEnergy',NaN,'dE',NaN,'absDE',NaN, ...
    'fullRhoSR',NaN,'lboRhoSR',NaN,'dRhoSR',NaN,'relRhoSR',NaN, ...
    'fullMeanN',NaN,'lboMeanN',NaN, ...
    'fullAbsCurrent',NaN,'lboAbsCurrent',NaN,'dCurrent',NaN,'relCurrent',NaN, ...
    'fullAbsChirality',NaN,'lboAbsChirality',NaN,'dChirality',NaN,'relChirality',NaN, ...
    'fullPhase','','lboPhase','','phaseMatch',false, ...
    'lboOrthonormalError',NaN,'lboTruncationHint',NaN,'localSpectrumMaxError',NaN,'localSpectrumRMSError',NaN, ...
    'fullRuntimeSeconds',NaN,'lboRuntimeSeconds',NaN,'runtimeSeconds',NaN,'pointFile','','errorMessage','');
end

function params = local_apply_branch(params, br)
params.gR = br.gR;
params.t = br.t;
params.tX = br.t;
params.tY = br.t;
params.Phi = br.Phi;
params.alphaSeed = br.alphaSeed;
params.alphaPattern = br.alphaPattern;
params.sourceEta = br.sourceEta;
end

function rec = local_result_to_record(result)
rec = struct();
rec.status = 'ok';
rec.superradiantDensity = result.superradiantDensity;
rec.meanAbsCurrent = result.meanAbsCurrent;
rec.meanAbsChirality = result.meanAbsChirality;
rec.energyPerSite = result.energyPerSite;
end

function e = local_relerr(a,b)
e = abs(a-b)/max(1e-12,abs(b));
end

function S = local_setfield(S,name,value)
S.(name) = value;
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
