function scan = RabiH_RunNNNProductionPatternScan(paramsBase, optsBase, spec)
%RABIH_RUNNNNPRODUCTIONPATTERNSCAN Run StageRH4Z NNN production current-pattern scan.
%
%   This is a wrapper around the explicit StageRH4Y path-gate update.  It
%   keeps the tested NNN path-update kernel, but adds StageRH4Z summary
%   diagnostics for negative/positive lambda, triangular-flux imbalance,
%   chirality sign changes, and current-pattern labels.

    if nargin < 1 || isempty(paramsBase)
        [paramsBase, optsBase, spec] = RabiH_Stage4Z_DefaultProductionScan('demo');
    elseif nargin < 2 || isempty(optsBase)
        optsBase = struct();
    end
    if nargin < 3 || isempty(spec), spec = struct(); end

    if ~isfield(optsBase,'outputDir') || isempty(optsBase.outputDir)
        optsBase.outputDir = fullfile(pwd,'results_stage4Z_nnn_production_pattern_demo');
    end
    if ~isfield(optsBase,'useNNNPathUpdate')
        optsBase.useNNNPathUpdate = true;
    end

    scan = RabiH_RunNNNPathCurrentPatternScan(paramsBase, optsBase, spec);
    scan.stage = 'StageRH4Z';
    scan.description = ['Explicit NNN path-gate scan with negative/positive J2, ', ...
        'triangular-flux imbalance, and full current-pattern diagnostics.'];
    scan.summaryZ = RabiH_SummarizeNNNProductionPatternScan(scan.bestRecords, scan.rawRecords);

    outDir = scan.outputDir;
    zBestCsv = fullfile(outDir,'stage4Z_best_nnn_production_pattern.csv');
    zRawCsv  = fullfile(outDir,'stage4Z_raw_nnn_production_pattern.csv');
    zSummaryCsv = fullfile(outDir,'stage4Z_nnn_production_summary.csv');
    RabiH_WriteNNNCurrentPatternCSV(scan.bestRecords, zBestCsv);
    RabiH_WriteNNNCurrentPatternCSV(scan.rawRecords, zRawCsv);
    RabiH_WriteNNNProductionSummaryCSV(scan.summaryZ, zSummaryCsv);
    scan.bestCsv = zBestCsv;
    scan.rawCsv = zRawCsv;
    scan.summaryCsv = zSummaryCsv;

    save(fullfile(outDir,'stage4Z_nnn_production_pattern_scan.mat'),'scan');
end
