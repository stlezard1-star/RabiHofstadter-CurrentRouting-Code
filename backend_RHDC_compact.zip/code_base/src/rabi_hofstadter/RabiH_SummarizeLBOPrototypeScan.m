function summary = RabiH_SummarizeLBOPrototypeScan(records)
%RABIH_SUMMARIZELBOPROTOTYPESCAN Summarize StageRH4R records.

okMask = arrayfun(@(r) strcmpi(r.status,'ok'), records);
ok = records(okMask);
summary = struct();
summary.numRecords = numel(records);
summary.numOK = sum(okMask);
summary.numError = summary.numRecords - summary.numOK;
if isempty(ok)
    summary.maxOrthonormalError = NaN;
    summary.maxLocalSpectrumError = NaN;
    summary.bestRecord = struct([]);
    return;
end
summary.maxOrthonormalError = max([ok.orthonormalError]);
summary.maxTruncationHint = max([ok.truncationHint]);
summary.maxCommutatorError = max([ok.commutatorError]);
summary.maxLocalSpectrumError = max([ok.localSpectrumMaxError]);
summary.minLocalSpectrumError = min([ok.localSpectrumMaxError]);
[~,idx] = min([ok.localSpectrumMaxError]);
summary.bestRecord = ok(idx);
end
