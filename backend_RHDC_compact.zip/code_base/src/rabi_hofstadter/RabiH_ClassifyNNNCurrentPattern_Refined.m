function [label, tags] = RabiH_ClassifyNNNCurrentPattern_Refined(rec, spec)
%RABIH_CLASSIFYNNNCURRENTPATTERN_REFINED Refined NNN loop-current classifier.
%
% The coarse Stage4W/Z label typically returns imbalancedMixedChiralSR for a
% broad set of current-carrying superradiant states.  This post-processing
% classifier separates the current texture into more useful categories:
% square-dominant, triangular-enhanced, diagonal-selected, and balanced mixed.
% It also returns tags for sign reversal and diagonal/triangular selection.

if nargin < 2 || isempty(spec), spec = struct(); end
rhoThr = local_get(spec,'rhoThreshold',1e-4);
chiThr = local_get(spec,'chiralityThreshold',1e-5);
curThr = local_get(spec,'currentThreshold',1e-6);
triEnhancedThr = local_get(spec,'triEnhancedRatio',0.70);
squareDominantThr = local_get(spec,'squareDominantRatio',0.55);
diagSelectedThr = local_get(spec,'diagSelectedRatio',0.60);

rho = local_num(rec,'superradiantDensity');
chiSq = abs(local_num(rec,'chiSquare'));
chiTri = local_num(rec,'meanAbsTriangularChirality');
j13 = local_num(rec,'j13');
j24 = local_num(rec,'j24');
idiag = local_num(rec,'meanAbsDiagCurrent');
lambda = local_num(rec,'lambda');

if ~isfinite(rho), rho = 0; end
if ~isfinite(chiSq), chiSq = 0; end
if ~isfinite(chiTri), chiTri = 0; end
if ~isfinite(idiag), idiag = 0; end

triRatio = chiTri / max(chiSq, eps);
diagSel = abs(j13-j24) / max(abs(j13)+abs(j24), eps);
diagMean = 0.5*(j13+j24);

isSR = rho >= rhoThr;
isChiral = (chiSq >= chiThr) || (chiTri >= chiThr) || (idiag >= curThr);
isTriEnhanced = isChiral && (triRatio >= triEnhancedThr);
isSquareDominant = isChiral && (triRatio <= squareDominantThr);
isDiagSelected = isChiral && (diagSel >= diagSelectedThr) && (abs(j13)+abs(j24) >= curThr);
isDiagSignReversed = isChiral && (lambda < -1e-12) && abs(diagMean) >= curThr && diagMean < 0;

if ~isSR
    label = 'normal';
elseif ~isChiral
    label = 'SR';
else
    if isTriEnhanced && isDiagSelected
        label = 'triEnhancedDiagSelectedChiralSR';
    elseif isTriEnhanced
        label = 'triangularEnhancedChiralSR';
    elseif isDiagSelected
        label = 'diagonalSelectedChiralSR';
    elseif isSquareDominant
        label = 'squareDominantChiralSR';
    else
        label = 'balancedMixedChiralSR';
    end
end

tags = struct();
tags.label = label;
tags.triRatio = triRatio;
tags.diagSelectionRatio = diagSel;
tags.diagMeanSigned = diagMean;
tags.j13Minusj24 = j13 - j24;
tags.isSR = isSR;
tags.isChiral = isChiral;
tags.isTriEnhanced = isTriEnhanced;
tags.isSquareDominant = isSquareDominant;
tags.isDiagSelected = isDiagSelected;
tags.isDiagSignReversed = isDiagSignReversed;
tags.isNegativeJ2 = lambda < -1e-12;

% Signed triangular-pair observables.  Use NaN-safe defaults if the older
% CSV/record lacks individual triangle loop currents.
chi123 = local_num(rec,'chiTri123');
chi134 = local_num(rec,'chiTri134');
chi124 = local_num(rec,'chiTri124');
chi234 = local_num(rec,'chiTri234');
tags.chiTriSigned13 = chi123 - chi134;
tags.chiTriSigned24 = chi124 - chi234;
tags.chiTriPairMeanSigned = 0.5*(tags.chiTriSigned13 + tags.chiTriSigned24);
end

function v = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = S.(name); else, v = defaultVal; end
end
function v = local_num(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = real(S.(name)); else, v = NaN; end
end
