function flux = RabiH_PlaquetteFlux(x, y, params)
%RABIH_PLAQUETTEFLUX Gauge-invariant square plaquette flux.
%   Oriented loop: (x,y)->(x+1,y)->(x+1,y+1)->(x,y+1)->(x,y).
    Ax1 = RabiH_GaugePhase(x,   y,   'right', params);
    Ay2 = RabiH_GaugePhase(x+1, y,   'down',  params);
    Ax3 = RabiH_GaugePhase(x,   y+1, 'right', params);
    Ay4 = RabiH_GaugePhase(x,   y,   'down',  params);
    flux = Ax1 + Ay2 - Ax3 - Ay4;
    flux = atan2(sin(flux), cos(flux));
end
