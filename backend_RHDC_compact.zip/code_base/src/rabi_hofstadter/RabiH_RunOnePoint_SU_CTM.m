function result = RabiH_RunOnePoint_SU_CTM(params, opts)
%RABIH_RUNONEPOINT_SU_CTM One-point site-boson SU + blocked CTM measurement.
%   Useful for profiling the core iPEPS algorithm layer before larger scans.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    initOpts = RabiH_GetOpt(opts,'initOpts',struct('state','down0'));
    uc = RabiH_InitProductUnitCell(Lx,Ly,params,initOpts);
    [uc, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(uc, params, opts);
    obs = RabiH_CTMObservables_Blocked(uc, params, opts);
    result = struct();
    result.unitCell = uc;
    result.suInfo = suInfo;
    result.obs = obs;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanAbsCurrent = obs.meanAbsCurrent;
end
