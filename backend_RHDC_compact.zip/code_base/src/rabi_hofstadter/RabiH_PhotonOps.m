function ops = RabiH_PhotonOps(dph)
%RABIH_PHOTONOPS Truncated single-mode boson operators.
%
%   ops = RabiH_PhotonOps(dph)
%
%   Basis ordering is |n>, n=0,...,dph-1.

    if nargin < 1 || isempty(dph)
        dph = 4;
    end
    if dph < 1 || round(dph) ~= dph
        error('RabiH_PhotonOps:InvalidDim','dph must be a positive integer.');
    end

    a = zeros(dph,dph);
    for n = 1:(dph-1)
        % a |n> = sqrt(n) |n-1>, with MATLAB index n+1 for |n>.
        a(n,n+1) = sqrt(n);
    end
    adag = a';
    N = adag*a;
    Q = a + adag;

    ops = struct();
    ops.dph = dph;
    ops.a = a;
    ops.adag = adag;
    ops.N = N;
    ops.Q = Q;
    ops.I = eye(dph);
end
