function fcell = RabiH_FactoredCellConstruct(unitCell, opts, opCell)
%RABIH_FACTOREDCELLCONSTRUCT Build a non-blocked double-layer unit-cell container.
%
%   fcell = RabiH_FactoredCellConstruct(unitCell, opts)
%   builds local double-layer tensors E{y,x} but deliberately does NOT call
%   CTM_BlockUnitCell and does NOT form a giant blocked tensor.
%
%   fcell = RabiH_FactoredCellConstruct(unitCell, opts, opCell)
%   uses the same operator-insertion convention as iPEPS_BuildDoubleLayerUnitCell.
%
% StageRH4D purpose:
%   This is the first safe data structure for a future genuine multi-site CTM
%   backend.  It is not yet the final CTM contraction algorithm; it only
%   guarantees that the high-D path can remain factored.

    if nargin < 2 || isempty(opts), opts = struct(); end
    if nargin < 3, opCell = []; end

    iPEPS_CheckUnitCell(unitCell);
    Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell, opCell);

    [Ly,Lx] = size(Ecell);
    localDims = zeros(Ly,Lx,4);
    localElems = zeros(Ly,Lx);
    maxLeg = 1;
    for y = 1:Ly
        for x = 1:Lx
            sz = PEPS_FullSize(Ecell{y,x},4);
            localDims(y,x,:) = sz;
            localElems(y,x) = prod(double(sz));
            maxLeg = max(maxLeg, max(double(sz)));
        end
    end

    risk = RabiH_BlockedCTMRiskEstimate(unitCell, opts);

    fcell = struct();
    fcell.type = 'RabiH_StageRH4D_factored_double_layer_cell';
    fcell.backend = 'factored_skeleton';
    fcell.Ecell = Ecell;
    fcell.Lx = Lx;
    fcell.Ly = Ly;
    fcell.d = unitCell.d;
    fcell.Dmax = local_max_virtual_dim(unitCell);
    fcell.localDims = localDims;
    fcell.localElements = localElems;
    fcell.maxLocalElements = max(localElems(:));
    fcell.totalLocalElements = sum(localElems(:));
    fcell.maxDoubleLayerLegDim = maxLeg;
    fcell.hasBlockedTensor = false;
    fcell.blockedTensorElementsEstimate = risk.blockedTensorElements;
    fcell.blockedTensorMBEstimate = risk.blockedTensorMB;
    fcell.estimatedNormIntermediateMB = risk.estimatedNormIntermediateMB;
    fcell.memoryRatioBlockedOverLocal = risk.blockedTensorElements / max(1,fcell.totalLocalElements);
    fcell.isProductionCTM = false;
    fcell.note = ['StageRH4D factored container only. It keeps local double-layer tensors ' ...
                  'and does not allocate a blocked unit-cell tensor.'];
end

function Dmax = local_max_virtual_dim(unitCell)
    Dmax = 1;
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            A = unitCell.A{y,x};
            sz = PEPS_FullSize(A,5);
            Dmax = max(Dmax, max(sz(2:5)));
        end
    end
end
