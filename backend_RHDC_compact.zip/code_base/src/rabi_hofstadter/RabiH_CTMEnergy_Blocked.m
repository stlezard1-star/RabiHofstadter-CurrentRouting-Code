function result = RabiH_CTMEnergy_Blocked(unitCell, params, opts)
%RABIH_CTMENERGY_BLOCKED Blocked-CTM NN Rabi-Hofstadter energy estimator.
%   Includes local Rabi terms and right/down photon hopping bonds.  This is
%   the site-boson analogue of the production energy layer; it is intentionally
%   blocked and dense for robustness before multi-site CTMRG optimization.

    if nargin < 3 || isempty(opts), opts = struct(); end
    ctx = RabiH_GetOpt(opts,'ctmContext',[]);
    if isempty(ctx)
        ctx = RabiH_CTMRunBlocked(unitCell, opts);
    end
    [Hloc,~] = RabiH_LocalHamiltonian(params);
    Lx = unitCell.Lx;
    Ly = unitCell.Ly;
    eLoc = zeros(Ly,Lx);
    eRight = zeros(Ly,Lx);
    eDown = zeros(Ly,Lx);

    for y = 1:Ly
        for x = 1:Lx
            Bop = CTM_BlockUnitCell_OneSiteOp(unitCell, Hloc, x, y);
            eLoc(y,x) = CTM_EvaluateNorm_Fast(Bop, ctx.W) / ctx.denOne;
        end
    end

    for y = 1:Ly
        for x = 1:Lx
            eRight(y,x) = local_bond_value(unitCell, params, ctx, x, y, 'right', 'energy');
            eDown(y,x)  = local_bond_value(unitCell, params, ctx, x, y, 'down',  'energy');
        end
    end

    totalEnergy = sum(eLoc(:)) + sum(eRight(:)) + sum(eDown(:));
    E = totalEnergy/(Lx*Ly);
    E = local_real_if_safe(E);
    result = struct();
    result.energyPerSite = E;
    result.localEnergy = local_real_if_safe(eLoc);
    result.hopRight = local_real_if_safe(eRight);
    result.hopDown = local_real_if_safe(eDown);
    result.totalEnergy = totalEnergy;
    result.ctx = ctx;
    result.env = ctx.env;
    result.hist = ctx.hist;
    result.denOne = ctx.denOne;
    result.denH = ctx.denH;
    result.denV = ctx.denV;
    result.description = 'StageRH2 blocked-CTM NN Rabi-Hofstadter energy estimator';
end

function val = local_bond_value(unitCell, params, ctx, x, y, direction, kind)
    Lx = unitCell.Lx; Ly = unitCell.Ly;
    dir = lower(direction);
    switch dir
        case {'right','x','horizontal'}
            x2 = mod(x,Lx)+1; y2 = y;
            phase = RabiH_GaugePhase(x,y,'right',params);
            tval = RabiH_GetOpt(params,'tX',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denH;
            isInternal = x < Lx;
        case {'down','y','vertical'}
            x2 = x; y2 = mod(y,Ly)+1;
            phase = RabiH_GaugePhase(x,y,'down',params);
            tval = RabiH_GetOpt(params,'tY',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denV;
            isInternal = y < Ly;
        otherwise
            error('RabiH_CTMEnergy_Blocked:UnknownDirection','Unknown direction.');
    end
    if strcmpi(kind,'current')
        terms = RabiH_CurrentTerms(params, phase, tval);
    else
        terms = RabiH_HoppingEnergyTerms(params, phase, tval);
    end
    if isInternal
        Bop = CTM_BlockUnitCell_ProductOpTerms(unitCell, terms, x,y,x2,y2);
        val = CTM_EvaluateNorm_Fast(Bop, ctx.W) / ctx.denOne;
    else
        num = 0;
        for k = 1:numel(terms)
            BA = CTM_BlockUnitCell_OneSiteOp(unitCell, terms(k).opA, x, y);
            BB = CTM_BlockUnitCell_OneSiteOp(unitCell, terms(k).opB, x2, y2);
            switch dir
                case {'right','x','horizontal'}
                    num = num + terms(k).coeff * CTM_EvaluateHorizontalPair(BA, BB, ctx.env);
                otherwise
                    num = num + terms(k).coeff * CTM_EvaluateVerticalPair(BA, BB, ctx.env);
            end
        end
        val = num / denPair;
    end
    val = local_real_if_safe(val);
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
