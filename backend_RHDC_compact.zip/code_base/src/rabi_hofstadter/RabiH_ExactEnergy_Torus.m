function [energyPerSite, details] = RabiH_ExactEnergy_Torus(unitCell, params, opts)
%RABIH_EXACTENERGY_TORUS Exact small-torus energy for Rabi-Hofstadter PEPS.
%   Includes one-site Rabi terms, NN right/down hopping, and optionally NNN
%   diagonal hopping when params.includeNNN=true or J2/t2/lambda is nonzero.

    if nargin < 3 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',unitCell.Lx);
    Ly = RabiH_GetOpt(opts,'Ly',unitCell.Ly);
    [J2,~,includeNNN] = RabiH_GetNNNHopping(params);

    [Hloc,~] = RabiH_LocalHamiltonian(params);
    eLoc = zeros(Ly,Lx);
    eRight = zeros(Ly,Lx);
    eDown = zeros(Ly,Lx);
    eDiagP = zeros(Ly,Lx);
    eDiagM = zeros(Ly,Lx);

    for yy = 1:Ly
        for xx = 1:Lx
            eLoc(yy,xx) = iPEPS_ExactOneSiteObservable_Torus(unitCell,Hloc,xx,yy,Lx,Ly);
        end
    end
    for yy = 1:Ly
        for xx = 1:Lx
            eRight(yy,xx) = RabiH_ExactBondHopping_Torus(unitCell,params,xx,yy,'right',Lx,Ly);
            eDown(yy,xx)  = RabiH_ExactBondHopping_Torus(unitCell,params,xx,yy,'down',Lx,Ly);
            if includeNNN && abs(J2) > 0
                eDiagP(yy,xx) = RabiH_ExactBondHopping_Torus(unitCell,params,xx,yy,'diagp',Lx,Ly);
                eDiagM(yy,xx) = RabiH_ExactBondHopping_Torus(unitCell,params,xx,yy,'diagm',Lx,Ly);
            end
        end
    end

    totalEnergy = sum(eLoc(:)) + sum(eRight(:)) + sum(eDown(:)) + sum(eDiagP(:)) + sum(eDiagM(:));
    energyPerSite = totalEnergy/(Lx*Ly);
    if abs(imag(energyPerSite)) < 1e-12*max(1,abs(real(energyPerSite)))
        energyPerSite = real(energyPerSite);
    end

    details = struct();
    details.Lx = Lx;
    details.Ly = Ly;
    details.energyPerSite = energyPerSite;
    details.totalEnergy = totalEnergy;
    details.local = eLoc;
    details.hopRight = eRight;
    details.hopDown = eDown;
    details.hopDiagP = eDiagP;
    details.hopDiagM = eDiagM;
    details.includeNNN = includeNNN;
    details.J2 = J2;
    details.note = 'Exact small-torus Rabi-Hofstadter energy with optional NNN diagonal hopping.';
end
