function summary = RabiH_CompareBackendBenchmarkEntries(entries)
%RABIH_COMPAREBACKENDBENCHMARKENTRIES Build diagnostic deltas for backend entries.
%
% The preferred reference is splitFactoredExact, then factoredExact, then the
% first successful backend.  The function intentionally does not impose a
% tight tolerance; tests decide what tolerance is appropriate for a stage.

if nargin < 1 || isempty(entries)
    entries = struct([]);
end

n = numel(entries);
refIdx = local_find_label(entries, {'splitFactoredExact','split_factored_exact','splitexact'});
if refIdx == 0
    refIdx = local_find_label(entries, {'factoredExact','factored_exact'});
end
if refIdx == 0
    for k = 1:n
        if isfield(entries(k),'ok') && entries(k).ok
            refIdx = k;
            break;
        end
    end
end

if refIdx > 0
    refE = entries(refIdx).energyPerSite;
    refRho = entries(refIdx).superradiantDensity;
else
    refE = NaN;
    refRho = NaN;
end

maxAbsEnergyDelta = 0;
maxAbsRhoDelta = 0;
numOk = 0;
for k = 1:n
    if isfield(entries(k),'ok') && entries(k).ok
        numOk = numOk + 1;
        entries(k).deltaEnergyVsReference = entries(k).energyPerSite - refE;
        entries(k).deltaRhoSRVsReference = entries(k).superradiantDensity - refRho;
        if isfinite(entries(k).deltaEnergyVsReference)
            maxAbsEnergyDelta = max(maxAbsEnergyDelta, abs(entries(k).deltaEnergyVsReference));
        end
        if isfinite(entries(k).deltaRhoSRVsReference)
            maxAbsRhoDelta = max(maxAbsRhoDelta, abs(entries(k).deltaRhoSRVsReference));
        end
    else
        entries(k).deltaEnergyVsReference = NaN;
        entries(k).deltaRhoSRVsReference = NaN;
    end
end

summary = struct();
summary.referenceIndex = refIdx;
if refIdx > 0
    summary.referenceLabel = entries(refIdx).label;
    summary.referenceBackend = entries(refIdx).backend;
else
    summary.referenceLabel = '';
    summary.referenceBackend = '';
end
summary.numBackends = n;
summary.numOk = numOk;
summary.maxAbsEnergyDelta = maxAbsEnergyDelta;
summary.maxAbsRhoSRDelta = maxAbsRhoDelta;
summary.entries = entries;
end

function idx = local_find_label(entries, labels)
    idx = 0;
    for k = 1:numel(entries)
        if ~isfield(entries(k),'label') || ~isfield(entries(k),'ok') || ~entries(k).ok
            continue;
        end
        lab = lower(entries(k).label);
        for j = 1:numel(labels)
            if strcmp(lab, lower(labels{j}))
                idx = k;
                return;
            end
        end
    end
end
