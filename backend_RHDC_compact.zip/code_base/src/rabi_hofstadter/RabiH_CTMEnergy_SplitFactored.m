function result = RabiH_CTMEnergy_SplitFactored(unitCell, params, opts)
%RABIH_CTMENERGY_SPLITFACTORED StageRH4G split/factored CTM energy estimator.
%
% This estimator uses the StageRH4G executable split/factored CTM v1 context.
% It measures local Rabi terms and right/down hopping bonds without ever
% forming a blocked 2x2 unit-cell tensor.

    if nargin < 3 || isempty(opts), opts = struct(); end
    ctx = RabiH_GetOpt(opts,'ctmContext',[]);
    if isempty(ctx)
        prodOpts = opts;
        prodOpts.splitBackendMode = 'production';
        ctx = RabiH_CTMRunSplitFactored(unitCell, prodOpts);
    end

    [Hloc,~] = RabiH_LocalHamiltonian(params);
    Lx = unitCell.Lx;
    Ly = unitCell.Ly;
    eLoc = zeros(Ly,Lx);
    eRight = zeros(Ly,Lx);
    eDown = zeros(Ly,Lx);

    for y = 1:Ly
        for x = 1:Lx
            Eop = RabiH_SplitLayerLocalDoubleLayer(ctx.splitCell,x,y,Hloc);
            eLoc(y,x) = CTM_EvaluateNorm_Fast(Eop, ctx.WCell{y,x}) / ctx.denOne(y,x);
        end
    end

    for y = 1:Ly
        for x = 1:Lx
            eRight(y,x) = local_bond_value(ctx, params, x, y, 'right', 'energy');
            eDown(y,x)  = local_bond_value(ctx, params, x, y, 'down',  'energy');
        end
    end

    totalEnergy = sum(eLoc(:)) + sum(eRight(:)) + sum(eDown(:));
    E = totalEnergy/(Lx*Ly);
    E = local_real_if_safe(E);

    result = struct();
    result.energyPerSite = E;
    result.localEnergy = local_real_if_safe(eLoc);
    result.hopRight = local_real_if_safe(eRight);
    result.hopDown = local_real_if_safe(eDown);
    result.totalEnergy = local_real_if_safe(totalEnergy);
    result.ctx = ctx;
    result.denOne = ctx.denOne;
    result.denH = ctx.denH;
    result.denV = ctx.denV;
    result.description = ['StageRH4G split/factored CTM v1 Rabi-Hofstadter ' ...
                          'energy estimator.  No blocked tensor is allocated.'];
end

function val = local_bond_value(ctx, params, x, y, direction, kind)
    Lx = ctx.splitCell.Lx;
    Ly = ctx.splitCell.Ly;
    dir = lower(direction);
    switch dir
        case {'right','x','horizontal'}
            x2 = mod(x,Lx)+1; y2 = y;
            phase = RabiH_GaugePhase(x,y,'right',params);
            tval = RabiH_GetOpt(params,'tX',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denH(y,x);
            pairFun = @CTM_EvaluateHorizontalPair;
        case {'down','y','vertical'}
            x2 = x; y2 = mod(y,Ly)+1;
            phase = RabiH_GaugePhase(x,y,'down',params);
            tval = RabiH_GetOpt(params,'tY',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denV(y,x);
            pairFun = @CTM_EvaluateVerticalPair;
        otherwise
            error('RabiH_CTMEnergy_SplitFactored:UnknownDirection','Unknown direction.');
    end

    if strcmpi(kind,'current')
        terms = RabiH_CurrentTerms(params, phase, tval);
    else
        terms = RabiH_HoppingEnergyTerms(params, phase, tval);
    end

    num = 0;
    for k = 1:numel(terms)
        EA = RabiH_SplitLayerLocalDoubleLayer(ctx.splitCell,x,y,terms(k).opA);
        EB = RabiH_SplitLayerLocalDoubleLayer(ctx.splitCell,x2,y2,terms(k).opB);
        num = num + terms(k).coeff * pairFun(EA, EB, ctx.envCell{y,x});
    end
    val = num / denPair;
    val = local_real_if_safe(val);
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
