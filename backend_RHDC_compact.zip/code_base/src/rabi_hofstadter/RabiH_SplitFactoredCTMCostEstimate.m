function est = RabiH_SplitFactoredCTMCostEstimate(unitCell, opts)
%RABIH_SPLITFACTOREDCTMCOSTESTIMATE Memory guard for split/factored CTM path.
%
% The estimate is intentionally conservative and diagnostic.  The production
% split/factored CTM will still need profiling once the absorption/truncation
% kernel is implemented.

    if nargin < 1
        unitCell = [];
    end
    if nargin < 2 || isempty(opts)
        opts = struct();
    end

    blocked = RabiH_BlockedCTMRiskEstimate(unitCell, opts);
    if isempty(unitCell)
        Lx = RabiH_GetOpt(opts,'Lx',2);
        Ly = RabiH_GetOpt(opts,'Ly',2);
        d = 2 * RabiH_GetOpt(opts,'dph',4);
        Dmax = RabiH_GetOpt(opts,'Dmax',2);
        maxKetElems = d * Dmax^4;
        totalKetElems = Lx * Ly * maxKetElems;
        maxLocalDoubleLayerElems = Dmax^8;
    else
        scell = RabiH_SplitLayerCellConstruct(unitCell, opts);
        Lx = scell.Lx;
        Ly = scell.Ly;
        d = scell.d;
        Dmax = scell.Dmax;
        maxKetElems = scell.maxKetElements;
        totalKetElems = scell.totalKetElements;
        maxLocalDoubleLayerElems = scell.maxDoubleLayerLegDim^4;
    end

    bytesPerElement = RabiH_GetOpt(opts,'splitBytesPerElement',16);
    chiMax = RabiH_GetOpt(opts,'chiMax',RabiH_GetOpt(opts,'chiCTM',16));
    q = max(1,Dmax^2);

    localKetMB = totalKetElems * bytesPerElement / 1024^2;
    localDLMb = maxLocalDoubleLayerElems * bytesPerElement / 1024^2;

    % A rough row/column workspace estimate for a future split/factored CTM:
    % boundary chi^2 plus one local double-layer leg q.  This is not the
    % final scaling law; it is a guard that prevents accidental giant blocks.
    rowWorkspaceElems = max([chiMax^2*q^2, chiMax*q^3, maxLocalDoubleLayerElems]);
    rowWorkspaceMB = rowWorkspaceElems * bytesPerElement / 1024^2;

    maxLocalDLMB = RabiH_GetOpt(opts,'maxSplitLocalDoubleLayerMB',512);
    maxWorkspaceMB = RabiH_GetOpt(opts,'maxSplitWorkspaceMB',8192);
    isSafe = (localDLMb <= maxLocalDLMB) && (rowWorkspaceMB <= maxWorkspaceMB);

    if localDLMb > maxLocalDLMB
        reason = sprintf('local double-layer %.3f MB exceeds maxSplitLocalDoubleLayerMB=%.3f MB', localDLMb, maxLocalDLMB);
    elseif rowWorkspaceMB > maxWorkspaceMB
        reason = sprintf('estimated split workspace %.3f MB exceeds maxSplitWorkspaceMB=%.3f MB', rowWorkspaceMB, maxWorkspaceMB);
    else
        reason = 'safe for StageRH4F split/factored CTM prototype path';
    end

    est = struct();
    est.stage = 'StageRH4F';
    est.backend = 'split_factored_ctm_prototype';
    est.Lx = Lx;
    est.Ly = Ly;
    est.d = d;
    est.Dmax = Dmax;
    est.doubleLayerLegDim = q;
    est.chiMax = chiMax;
    est.maxKetElements = maxKetElems;
    est.totalKetElements = totalKetElems;
    est.maxLocalDoubleLayerElements = maxLocalDoubleLayerElems;
    est.totalKetMB = localKetMB;
    est.maxLocalDoubleLayerMB = localDLMb;
    est.estimatedRowWorkspaceElements = rowWorkspaceElems;
    est.estimatedRowWorkspaceMB = rowWorkspaceMB;
    est.hasBlockedTensor = false;
    est.isSafe = isSafe;
    est.reason = reason;
    est.blockedRisk = blocked;
end
