function spec = RabiH_SC_DefaultAnalyticBenchmarkSpec()
%RabiH_SC_DefaultAnalyticBenchmarkSpec Defaults for StageRH4AG analytic maps.
spec = struct();
spec.outputDir = fullfile(pwd,'results_stage4AG_analytic_benchmark');
spec.J1 = 0.16;
spec.PhiList = linspace(0,pi,9);
spec.lambdaList = [-0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8];
spec.thetaTriList = [-pi/4 -pi/8 0 pi/8 pi/4];
spec.gList = [0.4 0.6 0.8 1.0 1.2 1.4 1.6];
spec.fixedPhiForNNN = pi/2;
spec.fixedGForTheta = 1.4;
spec.fixedThetaForCritical = 0;
spec.nStarts = 10;
spec.verbose = true;
end
