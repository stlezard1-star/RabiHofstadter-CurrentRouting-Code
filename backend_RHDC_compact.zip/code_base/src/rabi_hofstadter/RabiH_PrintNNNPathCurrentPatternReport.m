function RabiH_PrintNNNPathCurrentPatternReport(scan)
%RABIH_PRINTNNNPATHCURRENTPATTERNREPORT Print StageRH4Y report.
    fprintf('--- RabiH StageRH4Y explicit NNN path-update report ---\n');
    RabiH_PrintNNNCurrentPatternReport(scan);
end
