function obs = RabiH_ExactObservables_Torus(unitCell, params, opts)
%RABIH_EXACTOBSERVABLES_TORUS Exact small-torus observables.
%   Computes <a>, <n>, spin expectations, NN/NNN currents, square and
%   triangular loop-current diagnostics.
%
%   LBO/OBB compatibility:
%   This function must use RabiH_SiteOpsAuto(params), not RabiH_SiteOps(dph),
%   because in the LBO route the physical photon operators are projected as
%   W' a W and W' a^\dagger a W.

    if nargin < 3 || isempty(opts), opts = struct(); end

    Lx = RabiH_GetOpt(opts,'Lx',unitCell.Lx);
    Ly = RabiH_GetOpt(opts,'Ly',unitCell.Ly);

    % IMPORTANT:
    % Use automatic site operators so that LBO projected operators are used
    % when params.useLBO=true.
    ops = RabiH_SiteOpsAuto(params);

    % Optional dimension sanity check.
    try
        dsite = PEPS_FullSize(unitCell.A{1,1},1);
        if size(ops.I,1) ~= dsite
            dsite = PEPS_FullSize(unitCell.A{1,1},5);
        end
        if size(ops.I,1) ~= dsite
            warning('RabiH_ExactObservables_Torus:DimMismatch', ...
                'Operator dimension %d does not match local physical dimension %d.', ...
                size(ops.I,1), dsite);
        end
    catch
        % Do not fail if PEPS_FullSize conventions differ.
    end

    [J2,~,includeNNN] = RabiH_GetNNNHopping(params);

    alpha = zeros(Ly,Lx);
    nph = zeros(Ly,Lx);
    sx = zeros(Ly,Lx);
    sy = zeros(Ly,Lx);
    sz = zeros(Ly,Lx);

    for yy = 1:Ly
        for xx = 1:Lx
            alpha(yy,xx) = iPEPS_ExactOneSiteObservable_Torus(unitCell,ops.a,xx,yy,Lx,Ly);
            nph(yy,xx)   = iPEPS_ExactOneSiteObservable_Torus(unitCell,ops.N,xx,yy,Lx,Ly);
            sx(yy,xx)    = iPEPS_ExactOneSiteObservable_Torus(unitCell,ops.sx,xx,yy,Lx,Ly);
            sy(yy,xx)    = iPEPS_ExactOneSiteObservable_Torus(unitCell,ops.sy,xx,yy,Lx,Ly);
            sz(yy,xx)    = iPEPS_ExactOneSiteObservable_Torus(unitCell,ops.sz,xx,yy,Lx,Ly);
        end
    end

    jRight = zeros(Ly,Lx);
    jDown  = zeros(Ly,Lx);
    jDiagP = zeros(Ly,Lx);
    jDiagM = zeros(Ly,Lx);

    for yy = 1:Ly
        for xx = 1:Lx
            jRight(yy,xx) = RabiH_ExactBondCurrent_Torus(unitCell,params,xx,yy,'right',Lx,Ly);
            jDown(yy,xx)  = RabiH_ExactBondCurrent_Torus(unitCell,params,xx,yy,'down',Lx,Ly);

            if includeNNN && abs(J2) > 0
                jDiagP(yy,xx) = RabiH_ExactBondCurrent_Torus(unitCell,params,xx,yy,'diagp',Lx,Ly);
                jDiagM(yy,xx) = RabiH_ExactBondCurrent_Torus(unitCell,params,xx,yy,'diagm',Lx,Ly);
            end
        end
    end

    [E,details] = RabiH_ExactEnergy_Torus(unitCell,params,opts);

    obs = struct();
    obs.Lx = Lx;
    obs.Ly = Ly;
    obs.energyPerSite = E;
    obs.energyDetails = details;

    obs.alpha = local_real_if_safe(alpha);
    obs.photonNumber = local_real_if_safe(nph);
    obs.sx = local_real_if_safe(sx);
    obs.sy = local_real_if_safe(sy);
    obs.sz = local_real_if_safe(sz);

    obs.jRight = local_real_if_safe(jRight);
    obs.jDown  = local_real_if_safe(jDown);
    obs.jDiagP = local_real_if_safe(jDiagP);
    obs.jDiagM = local_real_if_safe(jDiagM);

    obs.superradiantDensity = mean(abs(alpha(:)).^2);
    obs.meanPhotonNumber = mean(real(nph(:)));

    obs.includeNNN = includeNNN;
    obs.J2 = J2;

    [pat,obs] = RabiH_CurrentPatternDiagnostics(obs, params);
    obs.currentPattern = pat;

    obs.meanAbsCurrent = mean(abs([jRight(:); jDown(:); jDiagP(:); jDiagM(:)]));
    obs.meanAbsChirality = obs.meanAbsSquareChirality;

    obs.note = 'Exact small-torus observable summary with full NN/NNN current-pattern diagnostics. LBO-compatible one-site observables.';
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end