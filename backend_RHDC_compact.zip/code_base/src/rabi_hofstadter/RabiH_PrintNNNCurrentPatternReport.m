function RabiH_PrintNNNCurrentPatternReport(scan)
%RABIH_PRINTNNNCURRENTPATTERNREPORT Print compact StageRH4W report.
S = scan.summary;
fprintf('--- RabiH StageRH4W NNN current-pattern report ---\n');
fprintf('best records / ok       : %d / %d\n', S.numBest, S.numBestOK);
fprintf('raw records / ok        : %d / %d\n', S.numRaw, S.numRawOK);
fprintf('energy range            : [%.12g, %.12g]\n', S.energyRange(1), S.energyRange(2));
fprintf('rhoSR range             : [%.12g, %.12g]\n', S.rhoSRRange(1), S.rhoSRRange(2));
fprintf('max |I_NN|              : %.6e\n', S.maxAbsNNCurrent);
fprintf('max |I_diag|            : %.6e\n', S.maxAbsDiagCurrent);
fprintf('max |chi_square|        : %.6e\n', S.maxAbsSquareChirality);
fprintf('max mean |chi_triangle| : %.6e\n', S.maxAbsTriangularChirality);
fprintf('max triangular imbalance: %.6e\n', S.maxTriangularImbalance);
fprintf('max total current div   : %.6e\n', S.maxCurrentDivergenceTotal);
fprintf('max triangle identity err: %.6e\n', S.maxTriangleIdentityErr);
fprintf('best CSV                : %s\n', scan.bestCsv);
if isfield(S,'perLambda') && ~isempty(S.perLambda)
    fprintf('per-lambda summary:\n');
    fprintf(' lambda    n   max|chiSq|   max|chiTri|   max|Idiag|   maxImb       labels\n');
    for k=1:numel(S.perLambda)
        p=S.perLambda(k);
        fprintf(' %6.3f %4d  %.3e   %.3e   %.3e   %.3e   %s\n', p.lambda,p.n,p.maxSquareChi,p.maxTriChi,p.maxDiagCurrent,p.maxImbalance,p.labels);
    end
end
fprintf('sample best records:\n');
fprintf('label                       pattern          g    J1 lambda Phi/pi  E/site       rhoSR      |I_diag| |chiSq| |chiTri|\n');
B = scan.bestRecords;
for k=1:min(12,numel(B))
    r=B(k);
    lab = r.label;
    if numel(lab) > 27, lab = lab(1:27); end
    fprintf('%-27s %-16s %4.2g %5.3g %5.2g %6.3f % .8g %.3e %.3e %.3e %.3e\n', lab, r.patternLabel, r.g, r.J1, r.lambda, r.Phi/pi, r.energyPerSite, r.superradiantDensity, r.meanAbsDiagCurrent, r.meanAbsSquareChirality, r.meanAbsTriangularChirality);
end
end
