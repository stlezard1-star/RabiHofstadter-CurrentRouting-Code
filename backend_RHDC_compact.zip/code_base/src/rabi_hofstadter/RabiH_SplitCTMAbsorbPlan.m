function plan = RabiH_SplitCTMAbsorbPlan(scell, direction, opts)
%RABIH_SPLITCTMABSORBPLAN Build a deterministic local absorption schedule.
%
%   plan = RabiH_SplitCTMAbsorbPlan(scell,'left',opts)
%
% StageRH4F uses this as the public interface for the future production
% split/factored CTMRG kernel.  The plan lists local sites in the order in
% which a row/column move should absorb them.  It does not form a blocked
% tensor.

    if nargin < 3 || isempty(opts), opts = struct(); end
    if nargin < 2 || isempty(direction), direction = 'left'; end
    direction = lower(direction);

    switch direction
        case {'left','right'}
            n = scell.Ly;
            x = RabiH_GetOpt(opts,'x',1);
            sites = zeros(n,2);
            for k = 1:n
                if strcmp(direction,'left')
                    y = k;
                else
                    y = scell.Ly - k + 1;
                end
                sites(k,:) = [mod(x-1,scell.Lx)+1, y];
            end
        case {'up','down'}
            n = scell.Lx;
            y = RabiH_GetOpt(opts,'y',1);
            sites = zeros(n,2);
            for k = 1:n
                if strcmp(direction,'up')
                    x = k;
                else
                    x = scell.Lx - k + 1;
                end
                sites(k,:) = [x, mod(y-1,scell.Ly)+1];
            end
        otherwise
            error('RabiH_SplitCTMAbsorbPlan:UnknownDirection', ...
                'Unknown direction: %s.', direction);
    end

    plan = struct();
    plan.stage = 'StageRH4F';
    plan.direction = direction;
    plan.sites = sites;
    plan.numLocalAbsorptions = size(sites,1);
    plan.hasBlockedTensor = false;
    plan.note = ['Prototype local absorption schedule.  The production ' ...
                 'kernel should execute these local contractions with QR/SVD ' ...
                 'truncation after each row/column move.'];
end
