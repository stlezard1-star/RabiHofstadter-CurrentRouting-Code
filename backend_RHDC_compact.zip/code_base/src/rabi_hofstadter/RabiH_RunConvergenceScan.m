function scanResult = RabiH_RunConvergenceScan(paramsBase, optsBase, scanSpec)
%RABIH_RUNCONVERGENCESCAN Run StageRH4K convergence diagnostics.
%
% Each point is evaluated with RabiH_RunOnePoint_AutoBackend.  The intended
% default backend is StageRH4J splitFactoredShared, but the routine keeps the
% backend configurable for cross-checks.

if nargin < 1 || isempty(paramsBase), paramsBase = struct(); end
if nargin < 2 || isempty(optsBase), optsBase = struct(); end
if nargin < 3 || isempty(scanSpec), scanSpec = struct(); end

points = RabiH_ExpandConvergenceScanSpec(paramsBase, optsBase, scanSpec);
stopOnError = local_get(scanSpec,'stopOnError',false);
outDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4K_convergence'));
saveEachPoint = RabiH_GetOpt(optsBase,'saveEachPoint',true);
if exist(outDir,'dir') ~= 7
    mkdir(outDir);
end

records = repmat(local_empty_record(),1,numel(points));
startAll = tic;
for k = 1:numel(points)
    point = points(k);
    params = paramsBase;
    opts = optsBase;

    params.dph = point.dph;
    params.gR = point.gR;
    params.t = point.t;
    params.tX = point.t;
    params.tY = point.t;
    params.Phi = point.Phi;
    params.sourceEta = point.sourceEta;
    params.sourcePhase = point.sourcePhase;
    params.alphaSeed = point.alphaSeed;
    params.alphaPattern = point.alphaPattern;

    opts.Dmax = point.Dmax;
    opts.chiMax = point.chiMax;
    opts.alpha = point.alphaSeed;
    opts.alphaPattern = point.alphaPattern;
    opts.sharedBoundaryMix = point.sharedBoundaryMix;
    opts.ctmBackend = local_get(scanSpec,'backend',RabiH_GetOpt(optsBase,'ctmBackend','splitFactoredShared'));
    opts.splitBackendMode = 'shared';

    rec = local_empty_record();
    rec.index = point.index;
    rec.label = point.label;
    rec.dph = point.dph;
    rec.Dmax = point.Dmax;
    rec.chiMax = point.chiMax;
    rec.alphaSeed = point.alphaSeed;
    rec.alphaPattern = point.alphaPattern;
    rec.sharedBoundaryMix = point.sharedBoundaryMix;
    rec.gR = point.gR;
    rec.t = point.t;
    rec.Phi = point.Phi;
    rec.sourceEta = point.sourceEta;
    rec.sourcePhase = point.sourcePhase;

    t0 = tic;
    try
        result = RabiH_RunOnePoint_AutoBackend(params, opts);
        obs = result.obs;
        diag = RabiH_CurrentChiralityDiagnostics(obs);
        rec.status = 'ok';
        rec.backend = result.backend;
        rec.stage = result.stage;
        rec.runtimeSeconds = toc(t0);
        rec.energyPerSite = local_real_scalar(result.energyPerSite);
        rec.superradiantDensity = local_real_scalar(result.superradiantDensity);
        rec.meanPhotonNumber = local_real_scalar(result.meanPhotonNumber);
        rec.meanAbsCurrent = local_real_scalar(result.meanAbsCurrent);
        rec.meanAbsChirality = local_real_scalar(result.meanAbsChirality);
        rec.maxCurrentDivergence = local_real_scalar(diag.maxCurrentDivergence);
        rec.meanAbsCurrentDivergence = local_real_scalar(diag.meanAbsCurrentDivergence);
        rec.maxChiralityDefinitionError = local_real_scalar(diag.maxChiralityDefinitionError);
        rec.netPlaquetteChirality = local_real_scalar(diag.netPlaquetteChirality);
        rec.maxAbsCurrent = local_real_scalar(diag.maxAbsCurrent);
        rec.maxAbsChirality = local_real_scalar(diag.maxAbsChirality);
        if isfield(result,'backendInfo')
            rec.backendSelected = result.backendInfo.selected;
            rec.blockedTensorMB = local_real_scalar(result.backendInfo.risk.blockedTensorMB);
            rec.blockedInterMB = local_real_scalar(result.backendInfo.risk.estimatedNormIntermediateMB);
        end
        if saveEachPoint
            pointFile = fullfile(outDir,sprintf('stage4K_point_%04d.mat',rec.index));
            save(pointFile,'result','diag','params','opts','point','rec');
            rec.pointFile = pointFile;
        end
    catch ME
        rec.status = 'error';
        rec.runtimeSeconds = toc(t0);
        rec.errorMessage = ME.message;
        if stopOnError
            records(k) = rec;
            rethrow(ME);
        end
    end
    records(k) = rec;
end

summary = RabiH_SummarizeConvergenceScan(records);
scanResult = struct();
scanResult.stage = 'StageRH4K';
scanResult.description = 'Convergence and current/chirality diagnostic scan.';
scanResult.paramsBase = paramsBase;
scanResult.optsBase = optsBase;
scanResult.scanSpec = scanSpec;
scanResult.points = points;
scanResult.records = records;
scanResult.summary = summary;
scanResult.runtimeSeconds = toc(startAll);
scanResult.outputDir = outDir;
end

function rec = local_empty_record()
rec = struct();
rec.index = NaN;
rec.label = '';
rec.status = 'pending';
rec.backend = '';
rec.backendSelected = '';
rec.stage = '';
rec.dph = NaN;
rec.Dmax = NaN;
rec.chiMax = NaN;
rec.alphaSeed = NaN;
rec.alphaPattern = '';
rec.sharedBoundaryMix = NaN;
rec.gR = NaN;
rec.t = NaN;
rec.Phi = NaN;
rec.sourceEta = 0;
rec.sourcePhase = 0;
rec.energyPerSite = NaN;
rec.superradiantDensity = NaN;
rec.meanPhotonNumber = NaN;
rec.meanAbsCurrent = NaN;
rec.meanAbsChirality = NaN;
rec.maxCurrentDivergence = NaN;
rec.meanAbsCurrentDivergence = NaN;
rec.maxChiralityDefinitionError = NaN;
rec.netPlaquetteChirality = NaN;
rec.maxAbsCurrent = NaN;
rec.maxAbsChirality = NaN;
rec.runtimeSeconds = NaN;
rec.blockedTensorMB = NaN;
rec.blockedInterMB = NaN;
rec.pointFile = '';
rec.errorMessage = '';
end

function val = local_real_scalar(x)
if isempty(x)
    val = NaN;
else
    val = real(x(1));
end
end

function val = local_get(S, name, defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
