function [params, opts, backendList] = RabiH_Stage4J_DefaultBenchmark()
%RABIH_STAGE4J_DEFAULTBENCHMARK Backend-comparison defaults including StageRH4J.

[params, opts, ~] = RabiH_Stage4I_DefaultBenchmark();
opts.sharedBoundaryMix = 0.0;
opts.sharedMaxIter = opts.maxIter;
backendList = {'factoredExact','splitFactoredExact','splitFactored','splitFactoredPeriodic','splitFactoredShared'};
end
