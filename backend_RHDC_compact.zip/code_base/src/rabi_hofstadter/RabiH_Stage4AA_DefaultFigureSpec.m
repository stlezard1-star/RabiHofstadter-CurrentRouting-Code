function spec = RabiH_Stage4AA_DefaultFigureSpec(mode)
%RABIH_STAGE4AA_DEFAULTFIGURESPEC Default StageRH4AA NNN current-pattern figure spec.
if nargin < 1 || isempty(mode), mode='demo'; end
spec = struct();
spec.mode = mode;
spec.targetG = 1.4;
spec.targetJ1 = 0.16;
spec.outputDir = fullfile(pwd,'results_stage4AA_nnn_pattern_figures');
spec.mapFields = {'meanAbsDiagCurrent','meanAbsSquareChirality','meanAbsTriangularChirality','triangularImbalance','j13','j24'};
spec.mapTitles = {'|I_{diag}|','|\chi_{sq}|','mean |\chi_{tri}|','triangular imbalance','I_{13}','I_{24}'};
spec.arrowCases = [ ...
    -0.6, -0.25; ...
    -0.6,  0.00; ...
     0.6,  0.00; ...
     0.6,  0.25];
spec.makeVisible = false;
end
