function unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, G)
%RABIH_APPLYLOCALGATE_UNITCELL Apply the same one-site gate to every site.
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            unitCell.A{y,x} = RabiH_ApplyOneSiteGate(unitCell.A{y,x}, G);
        end
    end
    unitCell = iPEPS_NormalizeUnitCell(unitCell);
end
