function J2 = RabiH_SC_GetJ2(params)
%RabiH_SC_GetJ2  Return diagonal hopping amplitude J2.
if isfield(params,'J2') && ~isempty(params.J2)
    J2 = params.J2;
else
    J1 = 0;
    if isfield(params,'J1') && ~isempty(params.J1), J1 = params.J1; end
    lam = 0;
    if isfield(params,'lambda') && ~isempty(params.lambda), lam = params.lambda; end
    J2 = lam * J1;
end
end
