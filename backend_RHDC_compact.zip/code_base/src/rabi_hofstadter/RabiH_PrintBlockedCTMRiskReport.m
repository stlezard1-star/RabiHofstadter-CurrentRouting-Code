function risk = RabiH_PrintBlockedCTMRiskReport(params, opts)
%RABIH_PRINTBLOCKEDCTMRISKREPORT Print blocked-CTM memory-risk estimate.
%   risk = RabiH_PrintBlockedCTMRiskReport(params, opts)
%
% params is currently optional and reserved for future reporting.

    if nargin < 1 || isempty(params), params = struct(); end %#ok<NASGU>
    if nargin < 2 || isempty(opts), opts = struct(); end

    risk = RabiH_BlockedCTMRiskEstimate([], opts);
    fprintf('--- RabiH blocked-CTM risk report ---\n');
    fprintf('unit cell                  : %d x %d\n', risk.Lx, risk.Ly);
    fprintf('virtual Dmax estimate       : %d\n', risk.Dmax);
    fprintf('double-layer leg dimension  : %g\n', risk.doubleLeg);
    fprintf('blocked leg dimensions      : [%g %g %g %g]\n', risk.blockedLegDims);
    fprintf('blocked tensor elements     : %.6g\n', risk.blockedTensorElements);
    fprintf('blocked tensor memory       : %.3f MB\n', risk.blockedTensorMB);
    fprintf('estimated norm intermediate : %.3f MB\n', risk.estimatedNormIntermediateMB);
    fprintf('threshold elements          : %.6g\n', risk.maxBlockedTensorElements);
    fprintf('threshold tensor memory     : %.3f MB\n', risk.maxBlockedTensorMB);
    fprintf('threshold intermediate      : %.3f MB\n', risk.maxBlockedNormIntermediateMB);
    fprintf('risk level                  : %s\n', risk.level);
    fprintf('isSafe                      : %d\n', risk.isSafe);
    fprintf('recommendation              : %s\n', risk.recommendation);
end
