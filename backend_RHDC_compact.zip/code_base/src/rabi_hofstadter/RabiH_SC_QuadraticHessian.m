function [H, info] = RabiH_SC_QuadraticHessian(params)
%RabiH_SC_QuadraticHessian Quadratic normal-state Hessian for coherent amplitudes.
%   alpha_i = x_i + i y_i, z=[x1..x4,y1..y4]. The quadratic energy is
%   E^(2)=0.5*z.'*H*z.  This is the analytic normal-state Hessian of the
%   coherent-state Rabi-Hofstadter functional on one 2x2 plaquette.

omega = local_get(params,'omega',1.0);
Delta = local_get(params,'Delta',1.0);
g = local_get(params,'g',1.0);
J1 = local_get(params,'J1',0.16);
J2 = RabiH_SC_GetJ2(params);
ph = RabiH_SC_FluxPhases(params);

H = zeros(8,8);
% Local quadratic terms from
% omega|alpha|^2 - (g^2/Delta)(alpha+alpha*)^2.
cx = omega - 4*g^2/Delta;
cy = omega;
for i=1:4
    H(i,i) = H(i,i) + 2*cx;
    H(4+i,4+i) = H(4+i,4+i) + 2*cy;
end

% Directed bonds follow the same convention as RabiH_SC_Observables.
H = local_add_bond(H,1,2,J1,ph.A12);
H = local_add_bond(H,2,3,J1,ph.A23);
H = local_add_bond(H,3,4,J1,ph.A34);
H = local_add_bond(H,4,1,J1,ph.A41);
H = local_add_bond(H,1,3,J2,ph.B13);
H = local_add_bond(H,2,4,J2,ph.B24);

H = 0.5*(H+H.');
ev = eig(H);
info = struct();
info.minEig = min(real(ev));
info.eigvals = real(ev(:));
info.params = params;
info.flux = ph;
end

function H = local_add_bond(H,i,j,J,phi)
if abs(J) < 1e-15
    return;
end
c = cos(phi); s = sin(phi);
xi=i; xj=j; yi=4+i; yj=4+j;
% E_ij = -2J c (x_i x_j + y_i y_j) + 2J s (x_i y_j - y_i x_j)
H = local_add_cross(H,xi,xj,-2*J*c);
H = local_add_cross(H,yi,yj,-2*J*c);
H = local_add_cross(H,xi,yj, 2*J*s);
H = local_add_cross(H,yi,xj,-2*J*s);
end

function H = local_add_cross(H,a,b,C)
H(a,b)=H(a,b)+C;
H(b,a)=H(b,a)+C;
end

function v = local_get(s,name,defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
