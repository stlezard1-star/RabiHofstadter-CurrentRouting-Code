function summary = RabiH_SummarizeNNNCurrentPatternScan(bestRecords, rawRecords)
%RABIH_SUMMARIZENNNCURRENTPATTERNSCAN Summary for StageRH4W NNN current scan.
if nargin < 1, bestRecords = struct([]); end
if nargin < 2, rawRecords = bestRecords; end
ok = strcmp({bestRecords.status},'ok');
B = bestRecords(ok);
summary = struct();
summary.numBest = numel(bestRecords);
summary.numBestOK = numel(B);
summary.numRaw = numel(rawRecords);
summary.numRawOK = sum(strcmp({rawRecords.status},'ok'));
if isempty(B)
    summary.energyRange = [NaN NaN]; summary.rhoSRRange=[NaN NaN];
    summary.maxAbsNNCurrent=NaN; summary.maxAbsDiagCurrent=NaN;
    summary.maxAbsSquareChirality=NaN; summary.maxAbsTriangularChirality=NaN;
    summary.maxTriangularImbalance=NaN; summary.maxCurrentDivergenceTotal=NaN;
    summary.maxFluxIdentityErr=NaN; summary.patternCounts=struct(); summary.perLambda=[];
    return;
end
summary.energyRange = [min([B.energyPerSite]) max([B.energyPerSite])];
summary.rhoSRRange = [min([B.superradiantDensity]) max([B.superradiantDensity])];
summary.maxAbsNNCurrent = max([B.meanAbsNNCurrent]);
summary.maxAbsDiagCurrent = max([B.meanAbsDiagCurrent]);
summary.maxAbsSquareChirality = max([B.meanAbsSquareChirality]);
summary.maxAbsTriangularChirality = max([B.meanAbsTriangularChirality]);
summary.maxTriangularImbalance = max([B.triangularImbalance]);
summary.maxDiagCurrentImbalance = max([B.diagCurrentImbalance]);
summary.maxCurrentDivergenceTotal = max([B.maxCurrentDivergenceTotal]);
summary.maxTriangleIdentityErr = max([B.triangleIdentityErr]);
summary.maxFluxIdentityErr = max([B.fluxIdentityErr]);
labels = {B.patternLabel};
uniqueLabels = unique(labels);
pc = struct();
for k=1:numel(uniqueLabels)
    nm = matlab.lang.makeValidName(uniqueLabels{k});
    pc.(nm) = sum(strcmp(labels,uniqueLabels{k}));
end
summary.patternCounts = pc;
lamVals = unique([B.lambda]);
per = repmat(struct('lambda',NaN,'n',0,'maxTriChi',NaN,'maxSquareChi',NaN,'maxDiagCurrent',NaN,'maxImbalance',NaN,'labels',''),1,numel(lamVals));
for k=1:numel(lamVals)
    idx = abs([B.lambda]-lamVals(k)) < 1e-12;
    R = B(idx);
    per(k).lambda = lamVals(k);
    per(k).n = numel(R);
    per(k).maxTriChi = max([R.meanAbsTriangularChirality]);
    per(k).maxSquareChi = max([R.meanAbsSquareChirality]);
    per(k).maxDiagCurrent = max([R.meanAbsDiagCurrent]);
    per(k).maxImbalance = max([R.triangularImbalance]);
    per(k).labels = strjoin(unique({R.patternLabel}), '|');
end
summary.perLambda = per;
end
