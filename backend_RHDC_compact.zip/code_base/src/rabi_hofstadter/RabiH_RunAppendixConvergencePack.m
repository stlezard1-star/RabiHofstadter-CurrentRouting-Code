function pack = RabiH_RunAppendixConvergencePack(spec)
%RABIH_RUNAPPENDIXCONVERGENCEPACK Build StageRH4U Appendix convergence pack.
%
% This routine loads or generates the two supporting scans:
%   StageRH4Q: simple-update/resource overlay
%   StageRH4T: high-dph full-Fock versus LBO benchmark
% and then writes compact Appendix-ready CSV tables and figures.

if nargin < 1 || isempty(spec), spec = RabiH_Stage4U_DefaultAppendixPack(); end
if ~isfield(spec,'outputDir') || isempty(spec.outputDir)
    spec.outputDir = fullfile(pwd,'results_stage4U_appendix_convergence_pack');
end
if exist(spec.outputDir,'dir') ~= 7, mkdir(spec.outputDir); end

[scanQ, sourceQ] = local_get_stage4Q(spec);
[scanT, sourceT] = local_get_stage4T(spec);

pack = struct();
pack.stage = 'StageRH4U';
pack.description = 'Appendix convergence pack assembled from StageRH4Q and StageRH4T.';
pack.spec = spec;
pack.scanQ = scanQ;
pack.scanT = scanT;
pack.sourceQ = sourceQ;
pack.sourceT = sourceT;
pack.outputDir = spec.outputDir;
pack.summaryU = RabiH_SummarizeAppendixConvergencePack(pack);

if RabiH_GetOpt(spec,'writeCSV',true)
    pack.csvFiles = RabiH_WriteAppendixConvergenceCSVs(pack, spec.outputDir);
else
    pack.csvFiles = struct();
end
if RabiH_GetOpt(spec,'makePlots',true)
    pack.figureFiles = RabiH_PlotAppendixConvergencePack(pack, spec.outputDir);
else
    pack.figureFiles = struct();
end
if RabiH_GetOpt(spec,'saveMAT',true)
    pack.matFile = fullfile(spec.outputDir,'stage4U_appendix_convergence_pack.mat');
    save(pack.matFile,'pack');
end
end

function [scanQ, src] = local_get_stage4Q(spec)
scanQ = [];
src = '';
if isfield(spec,'stage4QMatFile') && exist(spec.stage4QMatFile,'file') == 2
    tmp = load(spec.stage4QMatFile);
    if isfield(tmp,'scan')
        scanQ = tmp.scan;
        src = spec.stage4QMatFile;
        return;
    end
end
if RabiH_GetOpt(spec,'runStage4QIfMissing',true)
    scanQ = run_rabih_stage4Q_overlay_demo();
    src = 'generated:run_rabih_stage4Q_overlay_demo';
else
    error('RabiH_RunAppendixConvergencePack:MissingStage4Q','StageRH4Q scan not found.');
end
end

function [scanT, src] = local_get_stage4T(spec)
scanT = [];
src = '';
if isfield(spec,'stage4TMatFile') && exist(spec.stage4TMatFile,'file') == 2
    tmp = load(spec.stage4TMatFile);
    if isfield(tmp,'scan')
        scanT = tmp.scan;
        src = spec.stage4TMatFile;
        return;
    end
end
if RabiH_GetOpt(spec,'runStage4TIfMissing',true)
    scanT = run_rabih_stage4T_highdph_demo();
    src = 'generated:run_rabih_stage4T_highdph_demo';
else
    error('RabiH_RunAppendixConvergencePack:MissingStage4T','StageRH4T scan not found.');
end
end
