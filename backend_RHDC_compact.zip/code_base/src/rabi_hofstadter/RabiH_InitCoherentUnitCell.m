function unitCell = RabiH_InitCoherentUnitCell(Lx, Ly, params, opts)
%RABIH_INITCOHERENTUNITCELL D=1 coherent-photon site-boson product PEPS.
%
% In the ordinary route the photon seed is represented in the truncated Fock
% basis.  In the StageRH4S LBO route, the full coherent state is projected
% into the optimized photon basis W before forming the PEPS physical vector.

    if nargin < 3 || isempty(params), params = struct(); end
    if nargin < 4 || isempty(opts), opts = struct(); end
    alpha0 = RabiH_GetOpt(opts,'alpha',RabiH_GetOpt(params,'alphaSeed',0));
    pattern = RabiH_GetOpt(opts,'pattern',RabiH_GetOpt(params,'alphaPattern','uniform'));
    spinState = RabiH_GetOpt(opts,'spinState',RabiH_GetOpt(params,'spinSeed','down'));

    alphaCell = RabiH_AlphaPattern(Lx,Ly,pattern,alpha0,params);
    pat = cell(Ly,Lx);

    if RabiH_IsLBOEnabled(params)
        basis = RabiH_GetLBOBasis(params);
        dsite = 2*basis.dEff;
        for yy = 1:Ly
            for xx = 1:Lx
                pat{yy,xx} = RabiH_SiteState_CoherentSpinLBO(params,basis,alphaCell(yy,xx),spinState);
            end
        end
        unitCell = iPEPS_InitProductUnitCell(pat, struct('d',dsite,'normalize',true));
        unitCell.stage = 'RabiH_StageRH4S_LBO_coherent_seed';
        unitCell.model = 'RabiHofstadter_LBO';
        unitCell.dph = basis.dEff;
        unitCell.dphFull = basis.dFull;
        unitCell.lboBasis = basis;
    else
        dph = RabiH_GetOpt(params,'dph',4);
        for yy = 1:Ly
            for xx = 1:Lx
                pat{yy,xx} = RabiH_SiteState_CoherentSpin(dph, alphaCell(yy,xx), spinState);
            end
        end
        unitCell = iPEPS_InitProductUnitCell(pat, struct('d',2*dph,'normalize',true));
        unitCell.stage = 'RabiH_StageRH3_coherent_seed';
        unitCell.model = 'RabiHofstadter';
        unitCell.dph = dph;
    end
    unitCell.alphaSeed = alphaCell;
    unitCell.spinSeed = spinState;
end
