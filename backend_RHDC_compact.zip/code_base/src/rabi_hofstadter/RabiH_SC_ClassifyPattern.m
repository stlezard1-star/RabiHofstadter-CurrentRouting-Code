function [label, code, tags] = RabiH_SC_ClassifyPattern(obs, thresholds)
%RabiH_SC_ClassifyPattern  Semiclassical current-pattern taxonomy.
if nargin < 2 || isempty(thresholds)
    thresholds = struct();
end
rhoThr = local_get(thresholds,'rhoThr',1e-5);
chiThr = local_get(thresholds,'chiThr',1e-5);
triEnhancedThr = local_get(thresholds,'triEnhancedThr',0.75);
squareDomThr = local_get(thresholds,'squareDominantThr',0.55);
diagSelThr = local_get(thresholds,'diagSelectionThr',0.60);

tags = struct();
tags.isSR = obs.rhoSR > rhoThr;
tags.isChiral = (abs(obs.chiSquare) > chiThr) || (obs.meanAbsTriangularChirality > chiThr);
tags.isTriEnhanced = obs.triRatio > triEnhancedThr;
tags.isSquareDominant = obs.triRatio < squareDomThr;
tags.isDiagSelected = obs.diagSelectionRatio > diagSelThr;

if ~tags.isSR
    label = 'normal'; code = 0; return;
end
if ~tags.isChiral
    label = 'SR'; code = 1; return;
end
if tags.isTriEnhanced && tags.isDiagSelected
    label = 'triEnhancedDiagSelectedChiralSR'; code = 5; return;
end
if tags.isTriEnhanced
    label = 'triangularEnhancedChiralSR'; code = 4; return;
end
if tags.isDiagSelected
    label = 'diagonalSelectedChiralSR'; code = 3; return;
end
if tags.isSquareDominant
    label = 'squareDominantChiralSR'; code = 2; return;
end
label = 'balancedMixedChiralSR'; code = 6;
end

function v = local_get(s, name, defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
