function RabiH_SC_WriteCSV(filename, records)
%RabiH_SC_WriteCSV  Write semiclassical scan records to CSV.
[fid,msg] = fopen(filename,'w');
if fid < 0, error('Cannot open CSV file: %s', msg); end
headers = {'index','scanKind','status','g','J1','lambda','PhiOverPi','thetaOverPi', ...
    'energyPerSite','rhoSR','I12','I23','I34','I41','I13','I24', ...
    'absINN','absIDiag','chiSquare','absChiSquare','chi123','chi134','chi124','chi234', ...
    'meanAbsChiTri','triangularImbalance','diagSelectionRatio','triRatio','I13MinusI24', ...
    'chiTriSigned13','chiTriSigned24','maxCurrentDivergence','maxTriangleIdentityErr','patternLabel','patternCode','runtimeSeconds','message'};
fprintf(fid,'%s\n', strjoin(headers,','));
for k = 1:numel(records)
    r = records(k);
    vals = {r.index, r.scanKind, r.status, r.g, r.J1, r.lambda, r.PhiSquare/pi, r.thetaTri/pi, ...
        r.energyPerSite, r.rhoSR, r.I12, r.I23, r.I34, r.I41, r.I13, r.I24, ...
        r.absINN, r.absIDiag, r.chiSquare, r.absChiSquare, r.chi123, r.chi134, r.chi124, r.chi234, ...
        r.meanAbsChiTri, r.triangularImbalance, r.diagSelectionRatio, r.triRatio, r.I13MinusI24, ...
        r.chiTriSigned13, r.chiTriSigned24, r.maxCurrentDivergence, r.maxTriangleIdentityErr, r.patternLabel, r.patternCode, r.runtimeSeconds, r.message};
    fprintf(fid,'%s\n', local_csv_line(vals));
end
fclose(fid);
end

function line = local_csv_line(vals)
parts = cell(1,numel(vals));
for i=1:numel(vals)
    v = vals{i};
    if isnumeric(v)
        if isempty(v)
            parts{i} = '';
        else
            parts{i} = sprintf('%.12g', v);
        end
    else
        s = char(v);
        s = strrep(s,'"','""');
        parts{i} = ['"' s '"'];
    end
end
line = strjoin(parts,',');
end
