function out = RabiH_SC_RunDefaultDemo(outputDir)
%RabiH_SC_RunDefaultDemo  Run StageRH4AF semiclassical demo and build figures.
if nargin < 1 || isempty(outputDir)
    outputDir = fullfile(pwd,'results_stage4AF_semiclassical');
end
params = RabiH_SC_DefaultParams();
spec = RabiH_SC_DefaultScanSpec('all');
spec.outputDir = outputDir;
opts = spec.minimize;

fprintf('[StageRH4AF] Running semiclassical coherent-state scans...\n');
scan = RabiH_SC_RunScan(params, opts, spec);
RabiH_SC_PrintReport(scan);

if ~exist(outputDir,'dir'), mkdir(outputDir); end
RabiH_SC_WriteCSV(fullfile(outputDir,'stage4AF_semiclassical_scan.csv'), scan.records);
save(fullfile(outputDir,'stage4AF_semiclassical_scan.mat'),'scan','params','spec','opts');

fprintf('[StageRH4AF] Building semiclassical figure set...\n');
figSet = RabiH_SC_BuildFigureSet(scan, scan, spec);
save(fullfile(outputDir,'stage4AF_semiclassical_figure_set.mat'),'figSet','scan','params','spec','opts');

out = struct();
out.scan = scan;
out.figSet = figSet;
out.outputDir = outputDir;
end
