function basis = RabiH_PhotonBasis_FromSnapshots(params, spec)
%RABIH_PHOTONBASIS_FROMSNAPSHOTS Build an optimized photon basis by SVD.
%
% The basis is an isometry W(fullPhotonDim, effectivePhotonDim).  The column
% space is spanned by coherent-state snapshots, low Fock states, and optional
% photon reduced-density eigenvectors from local Rabi eigenstates.  This is a
% lightweight LBO/OBB prototype; it does not yet change the main PEPS tensor
% class unless explicitly used through the projected-operator functions.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(spec), spec = struct(); end

dFull = local_get(spec,'dFull',RabiH_GetOpt(params,'dphFull',max(RabiH_GetOpt(params,'dph',6),8)));
dEff = local_get(spec,'dEff',RabiH_GetOpt(params,'dphEff',min(6,dFull)));
if dEff > dFull
    error('RabiH_PhotonBasis_FromSnapshots:InvalidDim','dEff cannot exceed dFull.');
end
alphaList = local_get(spec,'alphaList',[0 0.4 0.8 1.2]);
includeFock = local_get(spec,'includeFock',true);
numFock = min(local_get(spec,'numFock',min(dEff,dFull)),dFull);
includeLocalRabi = local_get(spec,'includeLocalRabi',true);
numLocalStates = local_get(spec,'numLocalStates',min(4,2*dFull));

S = [];
weights = [];
for k = 1:numel(alphaList)
    c = RabiH_CoherentVector(dFull, alphaList(k));
    S(:,end+1) = c; %#ok<AGROW>
    weights(end+1) = 1; %#ok<AGROW>
end
if includeFock
    for n = 1:numFock
        e = zeros(dFull,1); e(n) = 1;
        S(:,end+1) = e; %#ok<AGROW>
        weights(end+1) = 0.35; %#ok<AGROW>
    end
end
if includeLocalRabi
    rho = local_rabi_photon_density(params,dFull,numLocalStates);
    [V,D] = eig(0.5*(rho+rho'));
    [evals,idx] = sort(real(diag(D)),'descend');
    keep = idx(1:min(numel(idx),dEff));
    for k = 1:numel(keep)
        if evals(k) > 1e-14
            S(:,end+1) = V(:,keep(k)); %#ok<AGROW>
            weights(end+1) = sqrt(max(evals(k),0)); %#ok<AGROW>
        end
    end
end
if isempty(S)
    S = eye(dFull,dEff);
    weights = ones(1,dEff);
end
S = S * diag(weights);
[U,~,~] = svd(S,'econ');
W = U(:,1:dEff);

basis = struct();
basis.type = 'photon_lbo_svd_snapshots';
basis.W = W;
basis.dFull = dFull;
basis.dEff = dEff;
basis.alphaList = alphaList;
basis.includeFock = includeFock;
basis.numFock = numFock;
basis.includeLocalRabi = includeLocalRabi;
basis.numLocalStates = numLocalStates;
basis.orthonormalError = norm(W'*W-eye(dEff),'fro');
basis.truncationHint = local_projection_residual(S,W);
basis.created = datestr(now,'yyyy-mm-dd HH:MM:SS');
end

function rho = local_rabi_photon_density(params,dFull,numStates)
p = params;
p.dph = dFull;
p.useLBO = false;
if isfield(p,'lboBasis'), p = rmfield(p,'lboBasis'); end
H = RabiH_LocalHamiltonian(p);
[V,D] = eig(0.5*(H+H'));
[~,idx] = sort(real(diag(D)),'ascend');
numStates = min(numStates,numel(idx));
rho = zeros(dFull,dFull);
for m = 1:numStates
    psi = V(:,idx(m));
    psi = reshape(psi,[2,dFull]).'; % rows photon, cols spin
    rho = rho + psi*psi';
end
rho = rho / max(numStates,1);
rho = rho / trace(rho);
end

function r = local_projection_residual(S,W)
if isempty(S)
    r = 0;
else
    r = norm(S-W*(W'*S),'fro') / max(norm(S,'fro'),eps);
end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
