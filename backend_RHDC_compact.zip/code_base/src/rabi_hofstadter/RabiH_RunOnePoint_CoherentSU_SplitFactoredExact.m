function result = RabiH_RunOnePoint_CoherentSU_SplitFactoredExact(params, opts)
%RABIH_RUNONEPOINT_COHERENTSU_SPLITFACTOREDEXACT Small-cell SU + split benchmark.
%
% This StageRH4F runner is for regression/validation.  It uses the same
% coherent-seed SU path as the blocked runner, then measures the final state
% through the split/factored exact-small-cell backend.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
    if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
    if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
    if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

    uc = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
    [uc, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(uc, params, opts);

    splitOpts = opts;
    splitOpts.enableSplitExactTorus = true;
    splitOpts.splitBackendMode = 'exactSmallCell';
    splitOpts.exactLx = RabiH_GetOpt(opts,'exactLx',Lx);
    splitOpts.exactLy = RabiH_GetOpt(opts,'exactLy',Ly);
    obs = RabiH_CTMObservables_SplitFactored(uc, params, splitOpts);

    result = struct();
    result.unitCell = uc;
    result.suInfo = suInfo;
    result.obs = obs;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanPhotonNumber = obs.meanPhotonNumber;
    result.meanAbsCurrent = obs.meanAbsCurrent;
    if isfield(obs,'meanAbsChirality'), result.meanAbsChirality = obs.meanAbsChirality; end
    result.alphaSeed = uc.alphaSeed;
    result.backend = 'split_factored_exact_torus';
    result.pipelineStage = 'RabiH_v0_4_0_StageRH4F_split_factored_exact_one_point';
end
