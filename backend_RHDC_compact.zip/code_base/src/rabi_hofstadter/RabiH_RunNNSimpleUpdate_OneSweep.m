function [unitCell, info] = RabiH_RunNNSimpleUpdate_OneSweep(unitCell, params, opts)
%RABIH_RUNNNSIMPLEUPDATE_ONESWEEP One NN Rabi-Hofstadter simple-update sweep.
%
%   Scope of StageRH0:
%       local Rabi gate + nearest-neighbor photon hopping gates on right/down
%       bonds with Landau-gauge Peierls phases.
%
%   Diagonal/cross hopping requires a long-range/plaquette update kernel and
%   is intentionally not applied here.

    if nargin < 3 || isempty(opts), opts = struct(); end
    tau  = RabiH_GetOpt(params,'tau',0.01);
    Dmax = RabiH_GetOpt(opts,'Dmax',unitCell.D);
    nSweeps = RabiH_GetOpt(opts,'nSweeps',1);
    tX = RabiH_GetNNHopping(params,'right');
    tY = RabiH_GetNNHopping(params,'down');

    Lx = unitCell.Lx;
    Ly = unitCell.Ly;
    info = struct();
    info.nSweeps = nSweeps;
    info.relDiscardedWeight = [];
    info.keep = [];
    info.note = 'StageRH0 NN site-boson simple update; diagonal hopping not applied.';

    [Gloc,~] = RabiH_LocalGate(params, tau/2);

    for sw = 1:nSweeps
        unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, Gloc);
        bcnt = 0;
        dw = zeros(1,2*Lx*Ly);
        kp = zeros(1,2*Lx*Ly);

        for y = 1:Ly
            for x = 1:Lx
                xp = mod(x,Lx)+1;
                ph = RabiH_GaugePhase(x,y,'right',params);
                G = RabiH_HoppingGate(params, ph, tX, tau);
                [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x}, unitCell.A{y,xp}, 'right', G, Dmax, opts);
                unitCell.A{y,x} = Anew;
                unitCell.A{y,xp} = Bnew;
                bcnt = bcnt + 1;
                dw(bcnt) = sinfo.relDiscardedWeight;
                kp(bcnt) = sinfo.keep;
            end
        end

        for y = 1:Ly
            yp = mod(y,Ly)+1;
            for x = 1:Lx
                ph = RabiH_GaugePhase(x,y,'down',params);
                G = RabiH_HoppingGate(params, ph, tY, tau);
                [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x}, unitCell.A{yp,x}, 'down', G, Dmax, opts);
                unitCell.A{y,x} = Anew;
                unitCell.A{yp,x} = Bnew;
                bcnt = bcnt + 1;
                dw(bcnt) = sinfo.relDiscardedWeight;
                kp(bcnt) = sinfo.keep;
            end
        end

        unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, Gloc);
        unitCell = iPEPS_NormalizeUnitCell(unitCell);
        info.relDiscardedWeight = [info.relDiscardedWeight; dw]; %#ok<AGROW>
        info.keep = [info.keep; kp]; %#ok<AGROW>
    end
    unitCell.stage = 'RabiH_Stage0_NN_simple_update';
    unitCell.D = local_maxD(unitCell);
end

function D = local_maxD(unitCell)
    D = 1;
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            sz = PEPS_FullSize(unitCell.A{y,x},5);
            D = max(D, max(sz(2:5)));
        end
    end
end
