function figSet = RabiH_BuildNNNPatternFigureSet(scan, spec)
%RABIH_BUILDNNNPATTERNFIGURESET Build StageRH4AA NNN current-pattern map/arrow figures.
if nargin < 1 || isempty(scan)
    scan = local_load_or_run_stage4Z();
end
if nargin < 2 || isempty(spec), spec = RabiH_Stage4AA_DefaultFigureSpec(); end
outDir = getfield_default(spec,'outputDir',fullfile(pwd,'results_stage4AA_nnn_pattern_figures'));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
makeVisible = getfield_default(spec,'makeVisible',false);
vis = 'off'; if makeVisible, vis='on'; end

R = scan.bestRecords;
ok = strcmp({R.status},'ok');
R = R(ok);
if isempty(R), error('RabiH_BuildNNNPatternFigureSet:NoRecords','No ok best records found.'); end

targetG = getfield_default(spec,'targetG',R(1).g);
targetJ1 = getfield_default(spec,'targetJ1',R(1).J1);
% choose nearest available target pair
pairs = [[R.g]' [R.J1]'];
[~,ipair] = min((pairs(:,1)-targetG).^2 + (pairs(:,2)-targetJ1).^2);
targetG = R(ipair).g; targetJ1 = R(ipair).J1;
S = R(abs([R.g]-targetG)<1e-12 & abs([R.J1]-targetJ1)<1e-12);
if isempty(S), S=R; end

fields = getfield_default(spec,'mapFields',{'meanAbsDiagCurrent','meanAbsSquareChirality','meanAbsTriangularChirality','triangularImbalance','j13','j24'});
titles = getfield_default(spec,'mapTitles',fields);
fig1 = figure('Visible',vis,'Color','w','Position',[100 100 1100 650]);
for k=1:numel(fields)
    subplot(2,ceil(numel(fields)/2),k);
    [M,lamVals,thetaVals] = local_matrix(S, fields{k});
    imagesc(thetaVals/pi, lamVals, M); set(gca,'YDir','normal'); colorbar;
    xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none');
    title(titles{k},'Interpreter','none');
end
local_suptitle(fig1, sprintf('Stage4AA NNN current maps: g=%.3g, J1=%.3g',targetG,targetJ1));
figMapPng = fullfile(outDir,'Fig_stage4AA_NNN_current_maps.png');
figMapFig = fullfile(outDir,'Fig_stage4AA_NNN_current_maps.fig');
saveas(fig1,figMapPng); savefig_compat(fig1,figMapFig); close(fig1);

cases = getfield_default(spec,'arrowCases',[-0.6 -0.25; -0.6 0; 0.6 0; 0.6 0.25]);
fig2 = figure('Visible',vis,'Color','w','Position',[100 100 1000 850]);
sel = repmat(local_empty_pick(),1,size(cases,1));
for k=1:size(cases,1)
    rec = local_pick_record(S,cases(k,1),cases(k,2));
    sel(k).lambda = rec.lambda; sel(k).thetaTri = rec.thetaTri; sel(k).label = rec.patternLabel; sel(k).record = rec;
    subplot(2,ceil(size(cases,1)/2),k);
    RabiH_PlotCurrentPatternRecord(rec);
    title(sprintf('lambda=%.2g, thetaTri/pi=%.2g',rec.lambda,rec.thetaTri/pi),'Interpreter','none');
end
local_suptitle(fig2, sprintf('Representative NNN current patterns: g=%.3g, J1=%.3g',targetG,targetJ1));
figArrowPng = fullfile(outDir,'Fig_stage4AA_NNN_current_arrows.png');
figArrowFig = fullfile(outDir,'Fig_stage4AA_NNN_current_arrows.fig');
saveas(fig2,figArrowPng); savefig_compat(fig2,figArrowFig); close(fig2);

summaryCsv = fullfile(outDir,'stage4AA_selected_current_patterns.csv');
local_write_selected_csv(sel,summaryCsv);

figSet = struct();
figSet.stage = 'StageRH4AA';
figSet.targetG = targetG; figSet.targetJ1 = targetJ1;
figSet.outputDir = outDir;
figSet.mapFigurePng = figMapPng; figSet.mapFigureFig = figMapFig;
figSet.arrowFigurePng = figArrowPng; figSet.arrowFigureFig = figArrowFig;
figSet.selectedCsv = summaryCsv; figSet.selected = sel;
figSet.numRecords = numel(R); figSet.numTargetRecords = numel(S);
save(fullfile(outDir,'stage4AA_nnn_pattern_figure_set.mat'),'figSet','scan','spec');
end

function scan = local_load_or_run_stage4Z()
matFile = fullfile(pwd,'results_stage4Z_nnn_production_pattern_demo','stage4Z_nnn_production_pattern_scan.mat');
if exist(matFile,'file') == 2
    tmp = load(matFile,'scan'); scan = tmp.scan; return;
end
scan = run_rabih_stage4Z_nnn_production_demo();
end
function [M,lamVals,thetaVals] = local_matrix(R, field)
lamVals = unique([R.lambda]); thetaVals = unique([R.thetaTri]);
M = NaN(numel(lamVals),numel(thetaVals));
for i=1:numel(lamVals)
    for j=1:numel(thetaVals)
        idx=find(abs([R.lambda]-lamVals(i))<1e-12 & abs([R.thetaTri]-thetaVals(j))<1e-12,1,'first');
        if ~isempty(idx), M(i,j)=getnum(R(idx),field); end
    end
end
end
function rec = local_pick_record(R, lam, thetaOverPi)
if isempty(R), error('No records.'); end
theta = thetaOverPi*pi;
score = ([R.lambda]-lam).^2 + (([R.thetaTri]-theta)/pi).^2;
[~,idx]=min(score); rec=R(idx);
end
function e=local_empty_pick()
e=struct('lambda',NaN,'thetaTri',NaN,'label','','record',struct());
end
function local_write_selected_csv(sel,filename)
fid=fopen(filename,'w'); if fid<0, error('Cannot open %s',filename); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'lambda,thetaOverPi,patternLabel,g,J1,E,rhoSR,j12,j23,j34,j41,j13,j24,chiSquare,chiTriMeanAbs,triImbalance\n');
for k=1:numel(sel)
    r=sel(k).record;
    fprintf(fid,'%.16g,%.16g,%s,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g\n', ...
        r.lambda,r.thetaTri/pi,r.patternLabel,r.g,r.J1,r.energyPerSite,r.superradiantDensity, ...
        getnum(r,'j12'),getnum(r,'j23'),getnum(r,'j34'),getnum(r,'j41'),getnum(r,'j13'),getnum(r,'j24'), ...
        r.chiSquare,r.meanAbsTriangularChirality,r.triangularImbalance);
end
end
function v=getnum(r,name)
if isstruct(r) && isfield(r,name) && ~isempty(r.(name)), v=real(r.(name)); else, v=NaN; end
end
function val=getfield_default(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), val=S.(name); else, val=defaultVal; end
end

function local_suptitle(fig, str)
%LOCAL_SUPTITLE MATLAB-version-compatible replacement for sgtitle.
% MATLAB R2018a and older may not provide sgtitle.  Use a plain-text
% annotation instead to avoid TeX/LaTeX parser warnings in old releases.
if nargin < 1 || isempty(fig), fig = gcf; end
if nargin < 2, str = ''; end
try
    if exist('sgtitle','file') == 2 || exist('sgtitle','builtin') == 5
        sgtitle(str,'Interpreter','none');
        return;
    end
catch
end
try
    annotation(fig,'textbox',[0 0.955 1 0.04], ...
        'String',str,'EdgeColor','none','HorizontalAlignment','center', ...
        'VerticalAlignment','middle','FontWeight','bold','Interpreter','none');
catch
    try
        annotation('textbox',[0 0.955 1 0.04], ...
            'String',str,'EdgeColor','none','HorizontalAlignment','center', ...
            'VerticalAlignment','middle','FontWeight','bold','Interpreter','none');
    catch
        % Last-resort fallback: put a title on an invisible axes.
        ax = axes('Parent',fig,'Position',[0 0 1 1],'Visible','off'); %#ok<LAXES>
        text(ax,0.5,0.985,str,'Units','normalized','HorizontalAlignment','center', ...
            'VerticalAlignment','top','FontWeight','bold','Interpreter','none');
    end
end
end

function savefig_compat(fig,filename)
try
    savefig(fig,filename);
catch
    saveas(fig,filename);
end
end
