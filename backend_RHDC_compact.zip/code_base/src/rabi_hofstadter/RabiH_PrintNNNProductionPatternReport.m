function RabiH_PrintNNNProductionPatternReport(scan)
%RABIH_PRINTNNNPRODUCTIONPATTERNREPORT Print StageRH4Z report.

    if isfield(scan,'summaryZ')
        S = scan.summaryZ;
    else
        S = RabiH_SummarizeNNNProductionPatternScan(scan.bestRecords, scan.rawRecords);
    end
    fprintf('--- RabiH StageRH4Z NNN production current-pattern report ---\n');
    fprintf('best records / ok       : %d / %d\n', S.numBest, S.numBestOK);
    fprintf('raw records / ok        : %d / %d\n', S.numRaw, S.numRawOK);
    fprintf('energy range            : [%.12g, %.12g]\n', S.energyRange(1), S.energyRange(2));
    fprintf('rhoSR range             : [%.12g, %.12g]\n', S.rhoSRRange(1), S.rhoSRRange(2));
    fprintf('lambda range            : [%.3g, %.3g]\n', S.lambdaRange(1), S.lambdaRange(2));
    fprintf('thetaTri/pi range       : [%.3g, %.3g]\n', S.thetaTriRange(1)/pi, S.thetaTriRange(2)/pi);
    fprintf('max |I_NN|              : %.6e\n', S.maxAbsNNCurrent);
    fprintf('max |I_diag|            : %.6e\n', S.maxAbsDiagCurrent);
    fprintf('max |chi_square|        : %.6e\n', S.maxAbsSquareChirality);
    fprintf('max mean |chi_triangle| : %.6e\n', S.maxAbsTriangularChirality);
    fprintf('max triangular imbalance: %.6e\n', S.maxTriangularImbalance);
    fprintf('max total current div   : %.6e\n', S.maxCurrentDivergenceTotal);
    fprintf('max triangle identity err: %.6e\n', S.maxTriangleIdentityErr);
    fprintf('diag-current sign reversal : %d\n', S.hasDiagCurrentSignReversal);
    fprintf('square-chi sign reversal   : %d\n', S.hasSquareChiralitySignReversal);
    fprintf('triangle-chi sign reversal : %d\n', S.hasTriangularChiralitySignReversal);
    fprintf('ready for NNN main text    : %d\n', S.readyForNNNMainText);
    fprintf('recommendation             : %s\n', S.recommendation);
    if isfield(scan,'bestCsv'), fprintf('best CSV                   : %s\n', scan.bestCsv); end
    if isfield(scan,'summaryCsv'), fprintf('summary CSV                : %s\n', scan.summaryCsv); end

    if isfield(S,'perLambda') && ~isempty(S.perLambda)
        fprintf('per-lambda summary:\n');
        fprintf(' lambda    n   max|chiSq|   max|chiTri|   max|Idiag|   maxImb       labels\n');
        for k=1:numel(S.perLambda)
            p=S.perLambda(k);
            fprintf(' %7.3f %4d  %.3e   %.3e   %.3e   %.3e   %s\n', p.lambda,p.n,p.maxSquareChi,p.maxTriChi,p.maxDiagCurrent,p.maxImbalance,p.labels);
        end
    end
    if isfield(S,'perTheta') && ~isempty(S.perTheta)
        fprintf('per-theta summary:\n');
        fprintf(' theta/pi  n   max|chiSq|   max|chiTri|   max|Idiag|   maxImb       labels\n');
        for k=1:numel(S.perTheta)
            p=S.perTheta(k);
            fprintf(' %7.3f %4d  %.3e   %.3e   %.3e   %.3e   %s\n', p.thetaOverPi,p.n,p.maxSquareChi,p.maxTriChi,p.maxDiagCurrent,p.maxImbalance,p.labels);
        end
    end
    fprintf('sample best records:\n');
    fprintf('label                       pattern          g    J1 lambda theta/pi E/site       rhoSR      j13      j24      |chiSq| |chiTri|\n');
    B = scan.bestRecords;
    for k=1:min(12,numel(B))
        r=B(k); lab = r.label; if numel(lab)>27, lab=lab(1:27); end
        fprintf('%-27s %-16s %4.2g %5.3g %6.2g %7.3f % .8g %.3e % .2e % .2e %.3e %.3e\n', ...
            lab, r.patternLabel, r.g, r.J1, r.lambda, r.thetaTri/pi, r.energyPerSite, r.superradiantDensity, r.j13, r.j24, r.meanAbsSquareChirality, r.meanAbsTriangularChirality);
    end
end
