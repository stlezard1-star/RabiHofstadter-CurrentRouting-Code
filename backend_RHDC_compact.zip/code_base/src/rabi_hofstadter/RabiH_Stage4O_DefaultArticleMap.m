function [params, opts, spec] = RabiH_Stage4O_DefaultArticleMap()
%RABIH_STAGE4O_DEFAULTARTICLEMAP Defaults for refined article-map scans.
%
% StageRH4O converts the StageRH4M/4N diagnostics into a first map-producing
% data pipeline around the visible SR/chiralSR window.  It is still a
% preliminary-article map layer rather than the final production sweep: it
% keeps a modest grid, seed competition, and diagnostic flags so that the
% resulting CSV/figures can be inspected before larger scans.

[params, opts, spec] = RabiH_Stage4M_DefaultStressScan();

params.dph = 5;
params.gR = 1.0;
params.t = 0.12;
params.tX = params.t;
params.tY = params.t;
params.Phi = pi/2;
params.sourceEta = 0;
params.sourcePhase = 0;
params.alphaSeed = 0.8;
params.alphaPattern = 'uniform';

opts.Dmax = 2;
opts.chiMax = 6;
opts.maxIter = 5;
opts.sharedMaxIter = 5;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.sharedBoundaryMix = 0.0;
opts.outputDir = fullfile(pwd,'results_stage4O_article_map');
opts.saveEachPoint = true;

spec.name = 'StageRH4O_refined_article_map';
spec.description = ['Refined first article-map scan around the SR/chiralSR ' ...
    'window located by StageRH4M and stabilized by StageRH4N.  The grid ' ...
    'keeps seed competition and writes best-seed map tables plus simple figures.'];
spec.backend = 'splitFactoredShared';
spec.DmaxList = 2;
spec.chiMaxList = 6;
spec.dphList = 5;
spec.sharedBoundaryMixList = 0;
spec.sourceEtaList = 0;
spec.sourcePhaseList = 0;

% Refined physical window: include the normal/SR boundary near gR~0.6--0.8,
% the robust SR region gR>=1, and flux values symmetric around Phi=pi/2.
spec.gRList = [0.60 0.75 0.90 1.05 1.20 1.35 1.50];
spec.tList = [0.08 0.12 0.16];
spec.PhiList = [0 pi/8 pi/4 3*pi/8 pi/2 5*pi/8 3*pi/4 7*pi/8 pi];

% Stage4M found uniform alpha=0.8 to be dominant in the visible SR/chiralSR
% branch.  We still include alpha=0 and a larger alpha to catch normal/SR
% branch switches and avoid hard-coding the broken-symmetry solution.
spec.alphaSeedList = [0 0.4 0.8 1.2];
spec.alphaPatternList = {'uniform','vortex2x2'};
spec.groupByFields = {'dph','Dmax','chiMax','sharedBoundaryMix','gR','t','Phi','sourceEta','sourcePhase'};
spec.bestSeedCriterion = 'minEnergy';
spec.phaseThresholds = struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5);
spec.maxPoints = Inf;
spec.stopOnError = false;
spec.tag = datestr(now,'yyyymmdd_HHMMSS');

% Map/report options used by Stage4O wrappers.
spec.reportTopChiral = 12;
spec.makePlots = true;
end
