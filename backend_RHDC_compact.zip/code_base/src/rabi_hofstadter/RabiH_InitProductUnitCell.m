function unitCell = RabiH_InitProductUnitCell(Lx, Ly, params, opts)
%RABIH_INITPRODUCTUNITCELL D=1 site-boson product iPEPS unit cell.
%
%   Default local state is |spin down> \otimes |0_photon> in the convention
%   p = spin + 2*n. The returned unitCell is a standard site PEPS unit cell,
%   not a decorated-bond unit cell.

    if nargin < 3 || isempty(params), params = struct(); end
    if nargin < 4 || isempty(opts), opts = struct(); end
    dph = RabiH_GetOpt(params,'dph',4);
    d = 2*dph;
    state = RabiH_GetOpt(opts,'state','down0');

    v = zeros(d,1);
    if ischar(state)
        switch lower(state)
            case {'down0','vacdown'}
                p = 2; % spin down, n=0
                v(p) = 1;
            case {'up0','vacup'}
                p = 1; % spin up, n=0
                v(p) = 1;
            otherwise
                error('RabiH_InitProductUnitCell:UnknownState','Unknown state: %s.', state);
        end
    else
        v = state(:);
        if numel(v) ~= d
            error('RabiH_InitProductUnitCell:StateDimMismatch','State vector length must be 2*dph.');
        end
        nv = norm(v);
        if nv == 0
            error('RabiH_InitProductUnitCell:ZeroState','State vector is zero.');
        end
        v = v/nv;
    end

    pat = cell(Ly,Lx);
    for yy = 1:Ly
        for xx = 1:Lx
            pat{yy,xx} = v;
        end
    end
    unitCell = iPEPS_InitProductUnitCell(pat, struct('d',d,'normalize',true));
    unitCell.stage = 'RabiH_Stage0_site_boson_product';
    unitCell.model = 'RabiHofstadter';
    unitCell.dph = dph;
end
