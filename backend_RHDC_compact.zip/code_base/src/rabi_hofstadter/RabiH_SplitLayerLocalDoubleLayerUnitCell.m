function Ecell = RabiH_SplitLayerLocalDoubleLayerUnitCell(scell, opCell)
%RABIH_SPLITLAYERLOCALDOUBLELAYERUNITCELL Build local double layers lazily per site.
%
% This helper is for guarded benchmarks and local-kernel tests.  It does not
% block the unit cell into a giant rank-4 tensor.

    if nargin < 2, opCell = []; end
    Ecell = cell(scell.Ly, scell.Lx);
    for y = 1:scell.Ly
        for x = 1:scell.Lx
            op = [];
            if ~isempty(opCell)
                op = iPEPS_GetCellTensor(opCell,x,y);
            end
            Ecell{y,x} = RabiH_SplitLayerLocalDoubleLayer(scell,x,y,op);
        end
    end
end
