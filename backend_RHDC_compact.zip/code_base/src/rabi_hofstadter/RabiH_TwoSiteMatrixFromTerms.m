function M = RabiH_TwoSiteMatrixFromTerms(terms)
%RABIH_TWOSITEMATRIXFROMTERMS Convert product-op terms to dense two-site matrix.
%   Uses the same combined physical-index convention as RabiH_TwoSiteOp.

    if isempty(terms)
        M = [];
        return;
    end
    d = size(terms(1).opA,1);
    M = zeros(d*d,d*d);
    for k = 1:numel(terms)
        M = M + terms(k).coeff * RabiH_TwoSiteOp(terms(k).opA, terms(k).opB);
    end
    M = 0.5*(M + M');
end
