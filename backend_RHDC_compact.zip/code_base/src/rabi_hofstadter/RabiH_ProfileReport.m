function report = RabiH_ProfileReport(filename, topN)
%RABIH_PROFILEREPORT Export MATLAB profiler hotspots to a text file.
%
%   report = RabiH_ProfileReport(filename, topN)
%
% Call after profile off.  The function sorts by TotalTime and also reports
% SelfTime.  This is the preferred way to pass profiler hotspots between
% development iterations.

if nargin < 1 || isempty(filename)
    filename = fullfile(pwd,'rabih_profile_report.txt');
end
if nargin < 2 || isempty(topN)
    topN = 30;
end
p = profile('info');
ft = p.FunctionTable;

n = numel(ft);
rows = repmat(struct('FunctionName','','TotalTime',0,'SelfTime',0,'NumCalls',0), n, 1);
for k = 1:n
    rows(k).FunctionName = ft(k).FunctionName;
    rows(k).TotalTime = ft(k).TotalTime;
    if isfield(ft,'SelfTime')
        rows(k).SelfTime = ft(k).SelfTime;
    else
        rows(k).SelfTime = NaN;
    end
    rows(k).NumCalls = ft(k).NumCalls;
end
[~,ord] = sort([rows.TotalTime],'descend');
rows = rows(ord);

fid = fopen(filename,'w');
if fid < 0
    error('RabiH_ProfileReport:OpenFailed','Cannot open file for writing: %s.', filename);
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'RabiH MATLAB profiler report\n');
fprintf(fid,'Generated: %s\n', datestr(now));
fprintf(fid,'Top %d functions sorted by TotalTime\n\n', min(topN,n));
fprintf(fid,'%-5s %-12s %-12s %-10s %s\n', '#', 'TotalTime', 'SelfTime', 'Calls', 'FunctionName');
fprintf(fid,'%s\n', repmat('-',1,100));
for k = 1:min(topN,n)
    fprintf(fid,'%-5d %-12.6g %-12.6g %-10d %s\n', k, rows(k).TotalTime, rows(k).SelfTime, rows(k).NumCalls, rows(k).FunctionName);
end

report = struct();
report.filename = filename;
report.rows = rows;
report.topN = topN;
end
