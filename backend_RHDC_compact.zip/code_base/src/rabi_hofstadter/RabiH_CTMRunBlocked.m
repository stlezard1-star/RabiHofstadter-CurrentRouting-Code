function ctx = RabiH_CTMRunBlocked(unitCell, opts)
%RABIH_CTMRUNBLOCKED Build double layer, block unit cell, and run CTMRG.
%   StageRH4B version adds a pre-flight blocked-CTM memory guard and supports
%   skipping expensive CTM diagnostic norm history.

    if nargin < 2 || isempty(opts), opts = struct(); end

    risk = RabiH_CheckBlockedCTMRisk(unitCell, opts);

    Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell);
    Bnorm = CTM_BlockUnitCell(Ecell);
    env = CTM_InitUniform(Bnorm, opts);

    iterOpts = opts;
    if isfield(opts,'skipCTMNormHistory')
        iterOpts.skipNormHistory = opts.skipCTMNormHistory;
    elseif strcmpi(risk.level,'medium') || strcmpi(risk.level,'high')
        iterOpts.skipNormHistory = true;
    end

    [env,hist] = CTM_Iterate(Bnorm, env, iterOpts);
    W = CTM_BuildOneSiteEnvironment(env);
    den1 = CTM_EvaluateNorm_Fast(Bnorm, W);
    denH = CTM_EvaluateHorizontalPair(Bnorm, Bnorm, env);
    denV = CTM_EvaluateVerticalPair(Bnorm, Bnorm, env);

    ctx = struct();
    ctx.Ecell = Ecell;
    ctx.Bnorm = Bnorm;
    ctx.env = env;
    ctx.hist = hist;
    ctx.W = W;
    ctx.denOne = den1;
    ctx.denH = denH;
    ctx.denV = denV;
    ctx.blockedCTMRisk = risk;
end
