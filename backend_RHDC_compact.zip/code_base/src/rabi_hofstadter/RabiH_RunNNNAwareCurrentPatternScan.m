function scan = RabiH_RunNNNAwareCurrentPatternScan(paramsBase, optsBase, spec)
%RABIH_RUNNNNAWARECURRENTPATTERNSCAN Run StageRH4X NNN-aware current-pattern scan.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4W_DefaultNNNScan();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec), spec = struct(); end

outDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4W_nnn_current_pattern'));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
optsBase.outputDir = outDir;

points = local_expand_points(paramsBase, optsBase, spec);
records = repmat(local_empty_record(),1,numel(points));
stopOnError = local_get(spec,'stopOnError',false);
saveEach = RabiH_GetOpt(optsBase,'saveEachPoint',true);
startAll = tic;
for k = 1:numel(points)
    point = points(k);
    params = paramsBase;
    opts = optsBase;
    params.dph = point.dph;
    params.gR = point.g;
    params.g = point.g;
    params.J1 = point.J1;
    params.t = point.J1;
    params.tX = point.J1;
    params.tY = point.J1;
    params.lambda = point.lambda;
    params.lambda2 = point.lambda;
    params.J2 = point.lambda * point.J1;
    params.t2 = params.J2;
    params.includeNNN = true;
    params.Phi = point.Phi;
    params.thetaTri = point.thetaTri;
    params.nnnPhaseMode = local_get(spec,'nnnPhaseMode',RabiH_GetOpt(paramsBase,'nnnPhaseMode','lineIntegral'));
    params.alphaSeed = point.alphaSeed;
    params.alphaPattern = point.alphaPattern;

    opts.Dmax = point.Dmax;
    opts.chiMax = point.chiMax;
    opts.alpha = point.alphaSeed;
    opts.alphaPattern = point.alphaPattern;
    opts.ctmBackend = local_get(spec,'backend',RabiH_GetOpt(optsBase,'ctmBackend','splitFactoredExact'));
    opts.enableSplitExactTorus = true;
    opts.splitBackendMode = 'exactSmallCell';
    opts.exactLx = RabiH_GetOpt(optsBase,'exactLx',RabiH_GetOpt(optsBase,'Lx',2));
    opts.exactLy = RabiH_GetOpt(optsBase,'exactLy',RabiH_GetOpt(optsBase,'Ly',2));

    rec = local_empty_record();
    rec.index = point.index; rec.label = point.label;
    rec.dph = point.dph; rec.Dmax = point.Dmax; rec.chiMax = point.chiMax;
    rec.g = point.g; rec.gR = point.g; rec.J1 = point.J1; rec.lambda = point.lambda; rec.J2 = params.J2;
    rec.Phi = point.Phi; rec.thetaTri = point.thetaTri;
    rec.alphaSeed = point.alphaSeed; rec.alphaPattern = point.alphaPattern;
    t0 = tic;
    try
        if RabiH_GetOpt(opts,'useNNNMeanFieldUpdate',true)
            result = RabiH_RunOnePoint_CoherentNNNMF_SplitFactoredExact(params, opts);
        else
            result = RabiH_RunOnePoint_AutoBackend(params, opts);
        end
        obs = result.obs;
        rec.status = 'ok';
        rec.runtimeSeconds = toc(t0);
        rec.backend = result.backend;
        rec.energyPerSite = local_scalar(local_getfield(result,'energyPerSite',obs.energyPerSite));
        rec.superradiantDensity = local_scalar(local_getfield(result,'superradiantDensity',obs.superradiantDensity));
        % Some validation backends, especially splitFactoredExact, keep
        % meanPhotonNumber only inside result.obs.  Accessing
        % result.meanPhotonNumber directly caused all Stage4W scan points
        % to be marked as errors even though the observable evaluation
        % succeeded.  Use the observable as the canonical source and allow
        % result-level fields as a convenience.
        rec.meanPhotonNumber = local_scalar(local_getfield(result,'meanPhotonNumber',obs.meanPhotonNumber));
        rec.meanAbsNNCurrent = local_scalar(obs.meanAbsNNCurrent);
        rec.meanAbsDiagCurrent = local_scalar(obs.meanAbsDiagCurrent);
        rec.meanAbsSquareChirality = local_scalar(obs.meanAbsSquareChirality);
        rec.meanAbsTriangularChirality = local_scalar(obs.meanAbsTriangularChirality);
        rec.triangularImbalance = local_scalar(obs.triangularImbalance);
        rec.diagCurrentImbalance = local_scalar(obs.diagCurrentImbalance);
        rec.maxCurrentDivergenceTotal = local_scalar(obs.maxCurrentDivergenceTotal);
        rec.triangleIdentityErr = local_scalar(obs.triangleIdentityErr);
        rec.patternLabel = obs.currentPatternLabel;
        rec.j12 = local_scalar(obs.jRight(1,1));
        rec.j23 = local_scalar(obs.jDown(1,mod(1,obs.Lx)+1));
        rec.j13 = local_scalar(obs.jDiagP(1,1));
        rec.j24 = local_scalar(-obs.jDiagM(mod(1,obs.Ly)+1,1));
        rec.chiSquare = local_scalar(obs.chiSquare(1,1));
        rec.chiTri123 = local_scalar(obs.chiTri123(1,1));
        rec.chiTri134 = local_scalar(obs.chiTri134(1,1));
        rec.chiTri124 = local_scalar(obs.chiTri124(1,1));
        rec.chiTri234 = local_scalar(obs.chiTri234(1,1));
        fl = RabiH_LoopFluxDiagnostics(params,1,1);
        rec.PhiSquare = local_scalar(fl.PhiSquare);
        rec.PhiTri123 = local_scalar(fl.PhiTri123);
        rec.PhiTri134 = local_scalar(fl.PhiTri134);
        rec.PhiTri124 = local_scalar(fl.PhiTri124);
        rec.PhiTri234 = local_scalar(fl.PhiTri234);
        rec.fluxIdentityErr = max(fl.identityErr13, fl.identityErr24);
        if saveEach
            pointFile = fullfile(outDir,sprintf('stage4X_point_%04d.mat',rec.index));
            save(pointFile,'result','obs','params','opts','point','rec');
            rec.pointFile = pointFile;
        end
    catch ME
        rec.status = 'error';
        rec.runtimeSeconds = toc(t0);
        rec.errorMessage = ME.message;
        if stopOnError
            records(k) = rec;
            rethrow(ME);
        end
    end
    records(k) = rec;
end

best = local_select_best(records);
summary = RabiH_SummarizeNNNCurrentPatternScan(best, records);
rawCsv = fullfile(outDir,'stage4X_raw_nnnmf_current_pattern.csv');
bestCsv = fullfile(outDir,'stage4X_best_nnnmf_current_pattern.csv');
RabiH_WriteNNNCurrentPatternCSV(records, rawCsv);
RabiH_WriteNNNCurrentPatternCSV(best, bestCsv);

scan = struct();
scan.stage = 'StageRH4X';
scan.description = 'NNN-aware mean-field SU plus full square/triangular current-pattern diagnostics.';
scan.paramsBase = paramsBase; scan.optsBase = optsBase; scan.spec = spec;
scan.points = points; scan.rawRecords = records; scan.bestRecords = best; scan.summary = summary;
scan.rawCsv = rawCsv; scan.bestCsv = bestCsv; scan.outputDir = outDir;
scan.runtimeSeconds = toc(startAll);
save(fullfile(outDir,'stage4X_nnnmf_current_pattern_scan.mat'),'scan');
end

function points = local_expand_points(paramsBase, optsBase, spec)
    gList = local_get(spec,'gList',RabiH_GetOpt(paramsBase,'gR',1.0));
    J1List = local_get(spec,'J1List',RabiH_GetNNHopping(paramsBase,'generic'));
    lambdaList = local_get(spec,'lambdaList',RabiH_GetOpt(paramsBase,'lambda',0));
    PhiList = local_get(spec,'PhiList',RabiH_GetOpt(paramsBase,'Phi',pi/2));
    thetaTriList = local_get(spec,'thetaTriList',RabiH_GetOpt(paramsBase,'thetaTri',0));
    alphaSeedList = local_get(spec,'alphaSeedList',RabiH_GetOpt(paramsBase,'alphaSeed',0.8));
    alphaPatternList = local_get(spec,'alphaPatternList',{RabiH_GetOpt(paramsBase,'alphaPattern','uniform')});
    if ischar(alphaPatternList), alphaPatternList={alphaPatternList}; end
    dphList = local_get(spec,'dphList',RabiH_GetOpt(paramsBase,'dph',4));
    DmaxList = local_get(spec,'DmaxList',RabiH_GetOpt(optsBase,'Dmax',2));
    chiMaxList = local_get(spec,'chiMaxList',RabiH_GetOpt(optsBase,'chiMax',6));
    maxPoints = local_get(spec,'maxPoints',Inf);
    % MATLAB R2018 can fail when assigning a populated struct into an
    % empty struct array or when field order differs.  We therefore build
    % every point from one template and preallocate the output.
    pointTemplate = struct('index',NaN,'dph',NaN,'Dmax',NaN,'chiMax',NaN, ...
        'g',NaN,'J1',NaN,'lambda',NaN,'Phi',NaN,'thetaTri',NaN, ...
        'alphaSeed',NaN,'alphaPattern','','label','');
    totalPoints = numel(dphList)*numel(DmaxList)*numel(chiMaxList)*numel(gList)*numel(J1List)*numel(lambdaList)*numel(PhiList)*numel(thetaTriList)*numel(alphaSeedList)*numel(alphaPatternList);
    if isfinite(maxPoints)
        totalPoints = min(totalPoints, maxPoints);
    end
    if totalPoints <= 0
        points = repmat(pointTemplate,1,0);
        return;
    end
    points = repmat(pointTemplate,1,totalPoints);
    idx=0;
    for id=1:numel(dphList)
    for iD=1:numel(DmaxList)
    for ic=1:numel(chiMaxList)
    for ig=1:numel(gList)
    for ij=1:numel(J1List)
    for il=1:numel(lambdaList)
    for ip=1:numel(PhiList)
    for it=1:numel(thetaTriList)
    for ia=1:numel(alphaSeedList)
    for iap=1:numel(alphaPatternList)
        if idx >= maxPoints, return; end
        idx=idx+1;
        p=pointTemplate; p.index=idx; p.dph=dphList(id); p.Dmax=DmaxList(iD); p.chiMax=chiMaxList(ic);
        p.g=gList(ig); p.J1=J1List(ij); p.lambda=lambdaList(il); p.Phi=PhiList(ip); p.thetaTri=thetaTriList(it);
        p.alphaSeed=alphaSeedList(ia); p.alphaPattern=alphaPatternList{iap};
        p.label=sprintf('w%04d_g%.3g_J1%.3g_lam%.3g_phi%.3g_theta%.3g_a%.3g_%s',idx,p.g,p.J1,p.lambda,p.Phi/pi,p.thetaTri/pi,p.alphaSeed,p.alphaPattern);
        points(idx)=p;
    end
    end
    end
    end
    end
    end
    end
    end
    end
    end
    if idx < numel(points)
        points = points(1:idx);
    end
end

function best = local_select_best(records)
    ok = strcmp({records.status},'ok');
    recs = records(ok);
    keys = cell(1,numel(recs));
    for k=1:numel(recs)
        keys{k}=sprintf('d%d_D%d_chi%d_g%.16g_J1%.16g_lam%.16g_phi%.16g_theta%.16g',recs(k).dph,recs(k).Dmax,recs(k).chiMax,recs(k).g,recs(k).J1,recs(k).lambda,recs(k).Phi,recs(k).thetaTri);
    end
    [ukeys,~,ic]=unique(keys);
    best = repmat(local_empty_record(),1,numel(ukeys));
    for u=1:numel(ukeys)
        idx=find(ic==u);
        E=[recs(idx).energyPerSite];
        [~,m]=min(E);
        best(u)=recs(idx(m));
    end
end

function rec = local_empty_record()
rec=struct('index',NaN,'label','','status','pending','backend','','dph',NaN,'Dmax',NaN,'chiMax',NaN, ...
    'g',NaN,'gR',NaN,'J1',NaN,'lambda',NaN,'J2',NaN,'Phi',NaN,'thetaTri',NaN,'alphaSeed',NaN,'alphaPattern','', ...
    'energyPerSite',NaN,'superradiantDensity',NaN,'meanPhotonNumber',NaN, ...
    'meanAbsNNCurrent',NaN,'meanAbsDiagCurrent',NaN,'meanAbsSquareChirality',NaN,'meanAbsTriangularChirality',NaN, ...
    'triangularImbalance',NaN,'diagCurrentImbalance',NaN,'maxCurrentDivergenceTotal',NaN,'triangleIdentityErr',NaN, ...
    'patternLabel','','j12',NaN,'j23',NaN,'j13',NaN,'j24',NaN, ...
    'chiSquare',NaN,'chiTri123',NaN,'chiTri134',NaN,'chiTri124',NaN,'chiTri234',NaN, ...
    'PhiSquare',NaN,'PhiTri123',NaN,'PhiTri134',NaN,'PhiTri124',NaN,'PhiTri234',NaN,'fluxIdentityErr',NaN, ...
    'runtimeSeconds',NaN,'pointFile','','errorMessage','');
end

function val=local_getfield(S,name,defaultVal)
    if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
        val = S.(name);
    else
        val = defaultVal;
    end
end
function val=local_scalar(x)
    if isempty(x), val=NaN; else, val=real(x(1)); end
end
function val=local_get(S,name,defaultVal)
    if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), val=S.(name); else, val=defaultVal; end
end
