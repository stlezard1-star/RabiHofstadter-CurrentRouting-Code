function figSet = RabiH_BuildNNNRefinedPatternFigureSet(scan, spec)
%RABIH_BUILDNNNREFINEDPATTERNFIGURESET Build refined NNN current maps and arrows.
if nargin < 1 || isempty(scan), scan = local_load_or_run_stage4Z(); end
if nargin < 2 || isempty(spec), spec = RabiH_Stage4AB_DefaultRefinedFigureSpec(); end
outDir = local_get(spec,'outputDir',fullfile(pwd,'results_stage4AB_refined_nnn_patterns'));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
makeVisible = local_get(spec,'makeVisible',false); vis = 'off'; if makeVisible, vis = 'on'; end

R = scan.bestRecords;
if isfield(R,'status'), ok = strcmp({R.status},'ok'); R = R(ok); end
if isempty(R), error('RabiH_BuildNNNRefinedPatternFigureSet:NoRecords','No ok best records found.'); end
R = RabiH_RefineNNNPatternRecords(R, spec);

[targetG,targetJ1,S] = local_select_target_records(R,spec);

figUnsigned = local_make_map_figure(S, spec, 'unsigned', vis, targetG, targetJ1);
figUnsignedPng = fullfile(outDir,'Fig_stage4AB_NNN_unsigned_maps.png');
figUnsignedFig = fullfile(outDir,'Fig_stage4AB_NNN_unsigned_maps.fig');
saveas(figUnsigned,figUnsignedPng); local_savefig(figUnsigned,figUnsignedFig); close(figUnsigned);

figSigned = local_make_map_figure(S, spec, 'signed', vis, targetG, targetJ1);
figSignedPng = fullfile(outDir,'Fig_stage4AB_NNN_signed_maps.png');
figSignedFig = fullfile(outDir,'Fig_stage4AB_NNN_signed_maps.fig');
saveas(figSigned,figSignedPng); local_savefig(figSigned,figSignedFig); close(figSigned);

[figArrow, selected] = local_make_arrow_figure(S, spec, vis, targetG, targetJ1);
figArrowPng = fullfile(outDir,'Fig_stage4AB_NNN_refined_arrows.png');
figArrowFig = fullfile(outDir,'Fig_stage4AB_NNN_refined_arrows.fig');
saveas(figArrow,figArrowPng); local_savefig(figArrow,figArrowFig); close(figArrow);

summaryCsv = fullfile(outDir,'stage4AB_refined_current_patterns.csv');
local_write_refined_csv(S,summaryCsv);
selectedCsv = fullfile(outDir,'stage4AB_selected_refined_patterns.csv');
local_write_refined_csv([selected.record],selectedCsv);

figSet = struct();
figSet.stage = 'StageRH4AB';
figSet.targetG = targetG; figSet.targetJ1 = targetJ1;
figSet.outputDir = outDir;
figSet.unsignedFigurePng = figUnsignedPng; figSet.unsignedFigureFig = figUnsignedFig;
figSet.signedFigurePng = figSignedPng; figSet.signedFigureFig = figSignedFig;
figSet.arrowFigurePng = figArrowPng; figSet.arrowFigureFig = figArrowFig;
figSet.summaryCsv = summaryCsv; figSet.selectedCsv = selectedCsv;
figSet.records = S; figSet.selected = selected;
figSet.numRecords = numel(R); figSet.numTargetRecords = numel(S);
figSet.labels = unique({S.patternLabelRefined});
save(fullfile(outDir,'stage4AB_refined_nnn_pattern_figure_set.mat'),'figSet','scan','spec');
end

function scan = local_load_or_run_stage4Z()
matFile = fullfile(pwd,'results_stage4Z_nnn_production_pattern_demo','stage4Z_nnn_production_pattern_scan.mat');
if exist(matFile,'file') == 2
    tmp = load(matFile,'scan'); scan = tmp.scan; return;
end
scan = run_rabih_stage4Z_nnn_production_demo();
end

function [targetG,targetJ1,S] = local_select_target_records(R,spec)
targetG = local_get(spec,'targetG',R(1).g);
targetJ1 = local_get(spec,'targetJ1',R(1).J1);
pairs = [[R.g]' [R.J1]'];
[~,ipair] = min((pairs(:,1)-targetG).^2 + (pairs(:,2)-targetJ1).^2);
targetG = R(ipair).g; targetJ1 = R(ipair).J1;
S = R(abs([R.g]-targetG)<1e-12 & abs([R.J1]-targetJ1)<1e-12);
if isempty(S), S = R; end
end

function fig = local_make_map_figure(S, spec, mode, vis, targetG, targetJ1)
if strcmp(mode,'signed')
    fields = local_get(spec,'signedFields',{'j13','j24','j13Minusj24','chiTriSigned13'});
    titles = local_get(spec,'signedTitles',fields);
    mainTitle = sprintf('Stage4AB signed NNN-current maps: g=%.3g, J1=%.3g',targetG,targetJ1);
else
    fields = local_get(spec,'unsignedFields',{'meanAbsDiagCurrent','meanAbsSquareChirality','meanAbsTriangularChirality','triangularImbalance'});
    titles = local_get(spec,'unsignedTitles',fields);
    mainTitle = sprintf('Stage4AB unsigned NNN-current maps: g=%.3g, J1=%.3g',targetG,targetJ1);
end
fig = figure('Visible',vis,'Color','w','Position',[100 100 1100 650]);
for k = 1:numel(fields)
    subplot(2,ceil(numel(fields)/2),k);
    [M,lamVals,thetaVals] = local_matrix(S,fields{k});
    imagesc(thetaVals/pi,lamVals,M); set(gca,'YDir','normal'); colorbar;
    xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none');
    title(titles{k},'Interpreter','none');
    if strcmp(mode,'signed')
        m = max(abs(M(:))); if isfinite(m) && m > 0, caxis([-m m]); end
    end
end
local_suptitle(fig,mainTitle);
end

function [fig, selected] = local_make_arrow_figure(S, spec, vis, targetG, targetJ1)
cases = local_get(spec,'arrowCases',[-0.6 -0.25; -0.6 0; 0.6 0; 0.6 0.25]);
fig = figure('Visible',vis,'Color','w','Position',[100 100 1050 850]);
selected = repmat(struct('lambda',NaN,'thetaTri',NaN,'record',struct()),1,size(cases,1));
for k = 1:size(cases,1)
    rec = local_pick_record(S,cases(k,1),cases(k,2));
    selected(k).lambda = rec.lambda; selected(k).thetaTri = rec.thetaTri; selected(k).record = rec;
    subplot(2,ceil(size(cases,1)/2),k);
    RabiH_PlotCurrentPatternRecord_Refined(rec);
    title(sprintf('lambda=%.2g, thetaTri/pi=%.2g',rec.lambda,rec.thetaTri/pi),'Interpreter','none');
end
local_suptitle(fig,sprintf('Refined representative NNN current patterns: g=%.3g, J1=%.3g',targetG,targetJ1));
end

function [M,lamVals,thetaVals] = local_matrix(R, field)
lamVals = unique([R.lambda]); thetaVals = unique([R.thetaTri]);
M = NaN(numel(lamVals),numel(thetaVals));
for i = 1:numel(lamVals)
    for j = 1:numel(thetaVals)
        idx = find(abs([R.lambda]-lamVals(i))<1e-12 & abs([R.thetaTri]-thetaVals(j))<1e-12,1,'first');
        if ~isempty(idx), M(i,j) = local_num(R(idx),field); end
    end
end
end

function rec = local_pick_record(R, lam, thetaOverPi)
theta = thetaOverPi*pi;
score = ([R.lambda]-lam).^2 + (([R.thetaTri]-theta)/pi).^2;
[~,idx] = min(score); rec = R(idx);
end

function local_write_refined_csv(R, filename)
fid = fopen(filename,'w'); if fid < 0, error('Cannot open %s',filename); end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'g,J1,lambda,thetaOverPi,patternLabel,patternLabelRefined,E,rhoSR,j13,j24,j13Minusj24,chiSquare,chiTriMeanAbs,chiTriSigned13,chiTriSigned24,triRatio,diagSelectionRatio,isTriEnhanced,isDiagSelected,isDiagSignReversed\n');
for k = 1:numel(R)
    fprintf(fid,'%.16g,%.16g,%.16g,%.16g,%s,%s,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%d,%d,%d\n', ...
        local_num(R(k),'g'),local_num(R(k),'J1'),local_num(R(k),'lambda'),local_num(R(k),'thetaTri')/pi, ...
        local_str(R(k),'patternLabel'),local_str(R(k),'patternLabelRefined'),local_num(R(k),'energyPerSite'),local_num(R(k),'superradiantDensity'), ...
        local_num(R(k),'j13'),local_num(R(k),'j24'),local_num(R(k),'j13Minusj24'),local_num(R(k),'chiSquare'),local_num(R(k),'meanAbsTriangularChirality'), ...
        local_num(R(k),'chiTriSigned13'),local_num(R(k),'chiTriSigned24'),local_num(R(k),'triRatio'),local_num(R(k),'diagSelectionRatio'), ...
        round(local_num(R(k),'isTriEnhanced')),round(local_num(R(k),'isDiagSelected')),round(local_num(R(k),'isDiagSignReversed')));
end
end

function v = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = S.(name); else, v = defaultVal; end
end
function v = local_num(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = real(S.(name)); else, v = NaN; end
end
function s = local_str(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), s = S.(name); else, s = ''; end
end
function local_savefig(fig,filename)
try, savefig(fig,filename); catch, saveas(fig,filename); end
end
function local_suptitle(fig, str)
try
    if exist('sgtitle','file') == 2 || exist('sgtitle','builtin') == 5
        sgtitle(str,'Interpreter','none'); return;
    end
catch
end
try
    annotation(fig,'textbox',[0 0.955 1 0.04],'String',str,'EdgeColor','none', ...
        'HorizontalAlignment','center','VerticalAlignment','middle','FontWeight','bold','Interpreter','none');
catch
    ax = axes('Parent',fig,'Position',[0 0 1 1],'Visible','off'); %#ok<LAXES>
    text(ax,0.5,0.985,str,'Units','normalized','HorizontalAlignment','center','VerticalAlignment','top','FontWeight','bold','Interpreter','none');
end
end
