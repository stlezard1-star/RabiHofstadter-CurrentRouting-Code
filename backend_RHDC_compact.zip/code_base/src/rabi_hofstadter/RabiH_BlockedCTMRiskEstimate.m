function risk = RabiH_BlockedCTMRiskEstimate(unitCell, opts)
%RABIH_BLOCKEDCTMRISKESTIMATE Estimate memory risk for blocked 2x2 CTM.
%
%   risk = RabiH_BlockedCTMRiskEstimate(unitCell, opts)
%
% This is a conservative pre-flight estimator for the current blocked CTM
% backend.  It does not build the blocked tensor.  It estimates the boundary
% leg dimensions after grouping a Lx-by-Ly unit cell into a one-site tensor.
%
% For a site PEPS with virtual dimension D, each double-layer virtual leg is
% D^2.  Blocking Lx sites horizontally and Ly sites vertically gives
%   left/right blocked legs  ~ (D^2)^Ly,
%   up/down blocked legs     ~ (D^2)^Lx.
%
% The blocked tensor element count is the product of the four blocked legs.
%
% Compatibility: if the first argument is a params-style struct rather than a
% unitCell struct with field A, its fields are merged into opts and the cost is
% estimated from opts.Lx/opts.Ly/opts.Dmax.

    if nargin < 1, unitCell = []; end
    if nargin < 2 || isempty(opts), opts = struct(); end

    [unitCell, opts] = local_normalize_unitcell_or_params(unitCell, opts);

    if ~isempty(unitCell)
        Lx = local_get_unitcell_dim(unitCell,'Lx',2);
        Ly = local_get_unitcell_dim(unitCell,'Ly',1);
        Dmax = local_max_virtual_dim(unitCell, Lx, Ly);
    else
        Lx = local_get(opts,'Lx',2);
        Ly = local_get(opts,'Ly',2);
        Dmax = local_get(opts,'Dmax',local_get(opts,'D',2));
    end

    doubleLeg = double(Dmax)^2;
    legL = doubleLeg^Ly;
    legR = legL;
    legU = doubleLeg^Lx;
    legD = legU;
    elems = legL * legR * legU * legD;

    isComplex = local_get(opts,'assumeComplex',true);
    bytesPerElem = 8;
    if isComplex
        bytesPerElem = 16;
    end

    blockedBytes = elems * bytesPerElem;

    % A rough warning estimate for dangerous ncon/tcontract intermediates.
    % The exact peak depends on contraction order, CTM chi, and observable
    % layer.  This deliberately errs on the safe side.
    chiMax = local_get(opts,'chiMax',local_get(opts,'chi',0));
    if isempty(chiMax) || chiMax <= 0
        chiMax = 0;
    end
    worstNormMatrixElements = max(1,chiMax)^2 * elems;
    worstNormMatrixBytes = worstNormMatrixElements * bytesPerElem;

    risk = struct();
    risk.Lx = Lx;
    risk.Ly = Ly;
    risk.Dmax = Dmax;
    risk.doubleLeg = doubleLeg;
    risk.blockedLegDims = [legL legR legU legD];
    risk.blockedTensorElements = elems;
    risk.blockedTensorBytes = blockedBytes;
    risk.blockedTensorMB = blockedBytes / 1024^2;
    risk.estimatedNormIntermediateElements = worstNormMatrixElements;
    risk.estimatedNormIntermediateBytes = worstNormMatrixBytes;
    risk.estimatedNormIntermediateMB = worstNormMatrixBytes / 1024^2;

    maxElem = local_get(opts,'maxBlockedTensorElements',2.0e7);
    maxMB   = local_get(opts,'maxBlockedTensorMB',1024);
    maxInterMB = local_get(opts,'maxBlockedNormIntermediateMB',8192);

    risk.maxBlockedTensorElements = maxElem;
    risk.maxBlockedTensorMB = maxMB;
    risk.maxBlockedNormIntermediateMB = maxInterMB;

    risk.exceedsElementLimit = elems > maxElem;
    risk.exceedsMemoryLimit = risk.blockedTensorMB > maxMB;
    risk.exceedsIntermediateLimit = risk.estimatedNormIntermediateMB > maxInterMB;
    risk.isSafe = ~(risk.exceedsElementLimit || risk.exceedsMemoryLimit || risk.exceedsIntermediateLimit);

    if risk.isSafe
        risk.level = 'low';
        risk.recommendation = 'blocked CTM is allowed by the current guard thresholds';
    elseif risk.exceedsElementLimit || risk.exceedsMemoryLimit
        risk.level = 'high';
        risk.recommendation = 'blocked tensor is too large; use a genuine multi-site/factored CTM backend';
    else
        risk.level = 'medium';
        risk.recommendation = 'blocked tensor may fit, but norm/pair contractions are risky; skip diagnostics or use multi-site CTM';
    end
end

function [unitCell, opts] = local_normalize_unitcell_or_params(unitCell, opts)
    if isempty(unitCell)
        return;
    end
    if isstruct(unitCell) && isfield(unitCell,'A')
        if ~isfield(unitCell,'Ly') || isempty(unitCell.Ly)
            unitCell.Ly = size(unitCell.A,1);
        end
        if ~isfield(unitCell,'Lx') || isempty(unitCell.Lx)
            unitCell.Lx = size(unitCell.A,2);
        end
        return;
    end
    if isstruct(unitCell)
        params = unitCell;
        f = fieldnames(params);
        for k = 1:numel(f)
            name = f{k};
            if ~isfield(opts,name) || isempty(opts.(name))
                opts.(name) = params.(name);
            end
        end
        unitCell = [];
        return;
    end
    error('RabiH_BlockedCTMRiskEstimate:BadInput', ...
        'First argument must be empty, a unitCell struct, or a params struct.');
end

function dim = local_get_unitcell_dim(unitCell, name, defaultVal)
    if isfield(unitCell,name) && ~isempty(unitCell.(name))
        dim = unitCell.(name);
    elseif isfield(unitCell,'A') && iscell(unitCell.A)
        if strcmp(name,'Ly')
            dim = size(unitCell.A,1);
        elseif strcmp(name,'Lx')
            dim = size(unitCell.A,2);
        else
            dim = defaultVal;
        end
    else
        dim = defaultVal;
    end
end

function Dmax = local_max_virtual_dim(unitCell, Lx, Ly)
    Dmax = 1;
    for y = 1:Ly
        for x = 1:Lx
            A = unitCell.A{y,x};
            sz = size(A);
            sz = [sz ones(1,5-numel(sz))];
            Dmax = max(Dmax, max(sz(2:5)));
        end
    end
end

function v = local_get(s, name, defaultVal)
    if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
        v = s.(name);
    else
        v = defaultVal;
    end
end
