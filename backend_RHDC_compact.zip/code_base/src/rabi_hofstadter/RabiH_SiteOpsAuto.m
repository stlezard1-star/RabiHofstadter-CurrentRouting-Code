function ops = RabiH_SiteOpsAuto(params)
%RABIH_SITEOPSAUTO Site operators in either full Fock or LBO photon basis.
if nargin < 1 || isempty(params), params = struct(); end
if RabiH_IsLBOEnabled(params)
    basis = RabiH_GetLBOBasis(params);
    ops = RabiH_SiteOpsLBO(params,basis);
else
    dph = RabiH_GetOpt(params,'dph',4);
    ops = RabiH_SiteOps(dph);
    ops.type = 'site_ops_full_fock';
end
end
