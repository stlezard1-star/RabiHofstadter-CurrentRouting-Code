function RabiH_WriteNNNProductionSummaryCSV(S, filename)
%RABIH_WRITENNNPRODUCTIONSUMMARYCSV Write compact StageRH4Z summary CSV.

    fid = fopen(filename,'w');
    if fid < 0, error('Could not open %s for writing.', filename); end
    cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

    fprintf(fid,'section,key,value\n');
    local_kv(fid,'global','numBest',S.numBest);
    local_kv(fid,'global','numBestOK',S.numBestOK);
    local_kv(fid,'global','numRaw',S.numRaw);
    local_kv(fid,'global','numRawOK',S.numRawOK);
    local_kv(fid,'global','energyMin',S.energyRange(1));
    local_kv(fid,'global','energyMax',S.energyRange(2));
    local_kv(fid,'global','rhoSRMin',S.rhoSRRange(1));
    local_kv(fid,'global','rhoSRMax',S.rhoSRRange(2));
    local_kv(fid,'global','lambdaMin',S.lambdaRange(1));
    local_kv(fid,'global','lambdaMax',S.lambdaRange(2));
    local_kv(fid,'global','thetaTriMin',S.thetaTriRange(1));
    local_kv(fid,'global','thetaTriMax',S.thetaTriRange(2));
    local_kv(fid,'global','maxAbsNNCurrent',S.maxAbsNNCurrent);
    local_kv(fid,'global','maxAbsDiagCurrent',S.maxAbsDiagCurrent);
    local_kv(fid,'global','maxAbsSquareChirality',S.maxAbsSquareChirality);
    local_kv(fid,'global','maxAbsTriangularChirality',S.maxAbsTriangularChirality);
    local_kv(fid,'global','maxTriangularImbalance',S.maxTriangularImbalance);
    local_kv(fid,'global','maxCurrentDivergenceTotal',S.maxCurrentDivergenceTotal);
    local_kv(fid,'global','maxTriangleIdentityErr',S.maxTriangleIdentityErr);
    local_kv(fid,'global','hasDiagCurrentSignReversal',double(S.hasDiagCurrentSignReversal));
    local_kv(fid,'global','hasSquareChiralitySignReversal',double(S.hasSquareChiralitySignReversal));
    local_kv(fid,'global','hasTriangularChiralitySignReversal',double(S.hasTriangularChiralitySignReversal));
    local_kv(fid,'global','readyForNNNMainText',double(S.readyForNNNMainText));
    fprintf(fid,'global,recommendation,"%s"\n',strrep(S.recommendation,'"','""'));

    fprintf(fid,'\nperLambda,lambda,n,maxSquareChi,maxTriChi,maxDiagCurrent,maxImbalance,labels\n');
    if isfield(S,'perLambda')
        for k=1:numel(S.perLambda)
            p=S.perLambda(k);
            fprintf(fid,'perLambda,%.16g,%d,%.16g,%.16g,%.16g,%.16g,"%s"\n',p.lambda,p.n,p.maxSquareChi,p.maxTriChi,p.maxDiagCurrent,p.maxImbalance,strrep(p.labels,'"','""'));
        end
    end
    fprintf(fid,'\nperTheta,thetaTri,thetaOverPi,n,maxSquareChi,maxTriChi,maxDiagCurrent,maxImbalance,labels\n');
    if isfield(S,'perTheta')
        for k=1:numel(S.perTheta)
            p=S.perTheta(k);
            fprintf(fid,'perTheta,%.16g,%.16g,%d,%.16g,%.16g,%.16g,%.16g,"%s"\n',p.thetaTri,p.thetaOverPi,p.n,p.maxSquareChi,p.maxTriChi,p.maxDiagCurrent,p.maxImbalance,strrep(p.labels,'"','""'));
        end
    end
    fprintf(fid,'\nperLambdaTheta,lambda,thetaTri,thetaOverPi,n,maxSquareChi,maxTriChi,maxDiagCurrent,maxImbalance,meanSignedDiagP,meanSignedDiagM,meanSignedSquareChi,labels\n');
    if isfield(S,'perLambdaTheta')
        for k=1:numel(S.perLambdaTheta)
            p=S.perLambdaTheta(k);
            fprintf(fid,'perLambdaTheta,%.16g,%.16g,%.16g,%d,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,"%s"\n', ...
                p.lambda,p.thetaTri,p.thetaOverPi,p.n,p.maxSquareChi,p.maxTriChi,p.maxDiagCurrent,p.maxImbalance,p.meanSignedDiagP,p.meanSignedDiagM,p.meanSignedSquareChi,strrep(p.labels,'"','""'));
        end
    end
end

function local_kv(fid,section,key,val)
    fprintf(fid,'%s,%s,%.16g\n',section,key,val);
end
