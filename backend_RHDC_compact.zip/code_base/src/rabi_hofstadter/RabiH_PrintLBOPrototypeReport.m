function RabiH_PrintLBOPrototypeReport(scan)
%RABIH_PRINTLBOPROTOTYPEREPORT Print StageRH4R LBO report.

s = scan.summary;
fprintf('--- RabiH StageRH4R photon-LBO prototype report ---\n');
fprintf('records / ok / error       : %d / %d / %d\n', s.numRecords, s.numOK, s.numError);
fprintf('max orthonormal error      : %.6e\n', s.maxOrthonormalError);
fprintf('max projection residual    : %.6e\n', s.maxTruncationHint);
fprintf('max commutator error       : %.6e\n', s.maxCommutatorError);
fprintf('local spectrum error range : [%.6e, %.6e]\n', s.minLocalSpectrumError, s.maxLocalSpectrumError);
if isfield(s,'bestRecord') && ~isempty(s.bestRecord)
    b = s.bestRecord;
    fprintf('best local spectrum point  : dFull=%d, dEff=%d, maxErr=%.6e, rmsErr=%.6e\n', ...
        b.dFull, b.dEff, b.localSpectrumMaxError, b.localSpectrumRMSError);
end
if isfield(scan,'csvFile') && ~isempty(scan.csvFile)
    fprintf('CSV                        : %s\n', scan.csvFile);
end
fprintf('label                 ok dFull dEff siteDim  hopDim   maxSpecErr   rmsSpecErr   orthoErr   truncHint\n');
for k = 1:numel(scan.records)
    r = scan.records(k);
    fprintf('%-20s %d %5g %4g %7g %7g %12.4e %12.4e %10.2e %10.2e\n', ...
        local_trunc(r.label,20), strcmpi(r.status,'ok'), r.dFull, r.dEff, r.siteDimEff, r.hoppingDim, ...
        r.localSpectrumMaxError, r.localSpectrumRMSError, r.orthonormalError, r.truncationHint);
end
end

function s = local_trunc(s,n)
if numel(s) > n, s = s(1:n); end
end
