function RabiH_PrintFigureSetReport(figSet)
%RABIH_PRINTFIGURESETREPORT Print StageRH4P figure-set v1 summary.
if isfield(figSet,'summary'), s = figSet.summary; else, s = figSet; end
fprintf('--- RabiH StageRH4P article figure-set v1 report ---\n');
fprintf('map records          : %d\n', s.numMapRecords);
fprintf('flux-cut records     : %d\n', s.numFluxCutRecords);
fprintf('representatives      : %d\n', s.numRepresentativeRecords);
fprintf('phase counts         : normal=%d, SR=%d, currentSR=%d, chiralSR=%d\n', ...
    s.countNormal, s.countSR, s.countCurrentSR, s.countChiralSR);
fprintf('energy range         : [%.12g, %.12g]\n', s.energyRange(1), s.energyRange(2));
fprintf('rhoSR range          : [%.12g, %.12g]\n', s.rhoSRRange(1), s.rhoSRRange(2));
fprintf('max |current|        : %.6e\n', s.maxAbsCurrent);
fprintf('max |chirality|      : %.6e\n', s.maxAbsChirality);
fprintf('max current div      : %.6e\n', s.maxCurrentDivergence);
fprintf('max chirality err    : %.6e\n', s.maxChiralityDefinitionError);
fprintf('quality gates        : chiralCount=%d, div=%d, chiDef=%d\n', ...
    s.passChiralCount, s.passCurrentDivergence, s.passChiralityDefinition);
if isfield(figSet,'csvPaths') && isfield(figSet.csvPaths,'summary')
    fprintf('summary CSV          : %s\n', figSet.csvPaths.summary);
end
if isfield(figSet,'figurePaths') && isfield(figSet.figurePaths,'mapPanel')
    fprintf('figure map PNG       : %s\n', figSet.figurePaths.mapPanel);
end
if isfield(s,'warnings') && ~isempty(s.warnings)
    fprintf('warnings             :\n');
    for k = 1:numel(s.warnings), fprintf('  - %s\n', s.warnings{k}); end
end
end
