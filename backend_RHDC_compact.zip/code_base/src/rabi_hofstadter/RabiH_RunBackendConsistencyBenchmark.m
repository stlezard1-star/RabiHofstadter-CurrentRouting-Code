function bench = RabiH_RunBackendConsistencyBenchmark(params, opts, backendList)
%RABIH_RUNBACKENDCONSISTENCYBENCHMARK Compare CTM backends on one SU state.
%
%   bench = RabiH_RunBackendConsistencyBenchmark(params, opts, backendList)
%
% This routine runs the coherent-seed NN simple update once, then evaluates
% the same final unit cell using several observable backends.  This avoids
% confusing backend differences with stochastic/roundoff differences from
% repeating the variational optimization.
%
% Supported backend labels:
%   factoredExact          StageRH4E guarded exact-small-cell reference
%   splitFactoredExact     StageRH4F guarded split exact-small-cell reference
%   splitFactored          StageRH4G executable site-wise split/factored CTM
%   splitFactoredPeriodic  StageRH4H periodic-neighbor split/factored CTM
%   splitFactoredShared    StageRH4J shared/cached periodic split/factored CTM

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(opts), opts = struct(); end
if nargin < 3 || isempty(backendList)
    backendList = {'factoredExact','splitFactoredExact','splitFactored','splitFactoredPeriodic'};
end

Lx = RabiH_GetOpt(opts,'Lx',2);
Ly = RabiH_GetOpt(opts,'Ly',2);
seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

startAll = tic;
unitCell0 = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
[unitCell, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(unitCell0, params, opts);

entries = repmat(local_empty_entry(),1,numel(backendList));
for k = 1:numel(backendList)
    label = backendList{k};
    t0 = tic;
    try
        [obs, backendName, stageName] = local_measure_backend(unitCell, params, opts, label);
        entries(k).label = label;
        entries(k).backend = backendName;
        entries(k).stage = stageName;
        entries(k).ok = true;
        entries(k).message = 'ok';
        entries(k).runtimeSeconds = toc(t0);
        entries(k).energyPerSite = local_real_scalar(obs.energyPerSite);
        entries(k).superradiantDensity = local_real_scalar(obs.superradiantDensity);
        entries(k).meanPhotonNumber = local_get_real_field(obs,'meanPhotonNumber',NaN);
        entries(k).meanAbsCurrent = local_get_real_field(obs,'meanAbsCurrent',NaN);
        entries(k).meanAbsChirality = local_get_real_field(obs,'meanAbsChirality',NaN);
        entries(k).obs = obs;
    catch ME
        entries(k).label = label;
        entries(k).backend = '';
        entries(k).stage = '';
        entries(k).ok = false;
        entries(k).message = ME.message;
        entries(k).runtimeSeconds = toc(t0);
    end
end

summary = RabiH_CompareBackendBenchmarkEntries(entries);
entries = summary.entries;

bench = struct();
bench.stage = 'StageRH4I';
bench.description = ['Backend consistency benchmark.  The same SU-optimized ' ...
    'unit cell is measured by exact-small-cell and executable split/factored CTM backends.'];
bench.params = params;
bench.opts = opts;
bench.backendList = backendList;
bench.unitCell = unitCell;
bench.suInfo = suInfo;
bench.entries = entries;
bench.summary = summary;
bench.runtimeSeconds = toc(startAll);
end

function [obs, backendName, stageName] = local_measure_backend(unitCell, params, opts, label)
    labelLower = lower(label);
    switch labelLower
        case {'factoredexact','factored_exact','stage4e'}
            bopts = opts;
            bopts.ctmBackend = 'factoredExact';
            bopts.enableFactoredExactTorus = true;
            bopts.factoredBackendMode = 'exactSmallCell';
            bopts.exactLx = RabiH_GetOpt(opts,'exactLx',RabiH_GetOpt(opts,'Lx',unitCell.Lx));
            bopts.exactLy = RabiH_GetOpt(opts,'exactLy',RabiH_GetOpt(opts,'Ly',unitCell.Ly));
            obs = RabiH_CTMObservables_Factored(unitCell, params, bopts);
            backendName = obs.backend;
            stageName = 'StageRH4E';
        case {'splitfactoredexact','split_exact','splitfactored_exact','stage4f'}
            bopts = opts;
            bopts.ctmBackend = 'splitFactoredExact';
            bopts.enableSplitExactTorus = true;
            bopts.splitBackendMode = 'exactSmallCell';
            bopts.exactLx = RabiH_GetOpt(opts,'exactLx',RabiH_GetOpt(opts,'Lx',unitCell.Lx));
            bopts.exactLy = RabiH_GetOpt(opts,'exactLy',RabiH_GetOpt(opts,'Ly',unitCell.Ly));
            obs = RabiH_CTMObservables_SplitFactored(unitCell, params, bopts);
            backendName = obs.backend;
            stageName = 'StageRH4F';
        case {'splitfactored','split_factored','stage4g'}
            bopts = opts;
            bopts.ctmBackend = 'splitFactored';
            bopts.splitBackendMode = 'production';
            obs = RabiH_CTMObservables_SplitFactoredProduction(unitCell, params, bopts);
            backendName = obs.backend;
            stageName = 'StageRH4G';
        case {'splitfactoredperiodic','split_periodic','periodic','stage4h'}
            bopts = opts;
            bopts.ctmBackend = 'splitFactoredPeriodic';
            bopts.splitBackendMode = 'periodic';
            obs = RabiH_CTMObservables_SplitFactoredPeriodic(unitCell, params, bopts);
            backendName = obs.backend;
            stageName = 'StageRH4H';
        case {'splitfactoredshared','split_shared','shared','cached','stage4j'}
            bopts = opts;
            bopts.ctmBackend = 'splitFactoredShared';
            bopts.splitBackendMode = 'shared';
            obs = RabiH_CTMObservables_SplitFactoredShared(unitCell, params, bopts);
            backendName = obs.backend;
            stageName = 'StageRH4J';
        otherwise
            error('RabiH_RunBackendConsistencyBenchmark:UnknownBackend', ...
                'Unknown backend label: %s.', label);
    end
end

function entry = local_empty_entry()
    entry = struct();
    entry.label = '';
    entry.backend = '';
    entry.stage = '';
    entry.ok = false;
    entry.message = '';
    entry.runtimeSeconds = NaN;
    entry.energyPerSite = NaN;
    entry.superradiantDensity = NaN;
    entry.meanPhotonNumber = NaN;
    entry.meanAbsCurrent = NaN;
    entry.meanAbsChirality = NaN;
    entry.deltaEnergyVsReference = NaN;
    entry.deltaRhoSRVsReference = NaN;
    entry.obs = [];
end

function val = local_get_real_field(S, name, defaultVal)
    if isfield(S,name)
        val = local_real_scalar(S.(name));
    else
        val = defaultVal;
    end
end

function val = local_real_scalar(x)
    if isempty(x)
        val = NaN;
    else
        val = real(x(1));
    end
end
