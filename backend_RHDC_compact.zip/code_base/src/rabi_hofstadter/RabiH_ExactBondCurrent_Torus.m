function [jBond, numerator, denominator] = RabiH_ExactBondCurrent_Torus(unitCell, params, x, y, direction, Lx, Ly)
%RABIH_EXACTBONDCURRENT_TORUS Exact oriented photon current on one bond.
%   Supports NN bonds right/down and NNN diagonal bonds diagp/diagm.

    if nargin < 7 || isempty(Ly), Ly = unitCell.Ly; end
    if nargin < 6 || isempty(Lx), Lx = unitCell.Lx; end
    spec = RabiH_BondSpec(x,y,direction,params,Lx,Ly);
    terms = RabiH_CurrentTerms(params, spec.phase, spec.tval);
    [jBond,numerator,denominator] = iPEPS_ExactProductOpTerms_Torus(unitCell,terms,x,y,spec.x2,spec.y2,Lx,Ly);
    if abs(imag(jBond)) < 1e-12*max(1,abs(real(jBond)))
        jBond = real(jBond);
    end
end
