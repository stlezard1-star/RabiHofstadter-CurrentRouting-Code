function [params, opts, spec] = RabiH_Stage4P_DefaultFigureSet()
%RABIH_STAGE4P_DEFAULTFIGURESET Defaults for StageRH4P article figure set v1.
%
% StageRH4P freezes the first figure-data pipeline after StageRH4O maps.
% It does not introduce a new CTM backend.  It reads/creates a refined
% article map, extracts map/cut/representative tables, and produces MATLAB
% 2018-compatible PNG/FIG outputs for manuscript inspection.

[params, opts, mapSpec] = RabiH_Stage4O_DefaultArticleMap();
opts.outputDir = fullfile(pwd,'results_stage4P_figure_set_v1');
opts.saveEachPoint = true;

spec = struct();
spec.stage = 'StageRH4P';
spec.name = 'StageRH4P_figure_set_v1';
spec.description = ['Article figure-set v1 based on StageRH4O refined maps: ' ...
    'phase/order-parameter maps, flux cuts, and representative branch table.'];
spec.mapSpec = mapSpec;
spec.outputDir = opts.outputDir;
spec.reuseStage4OIfAvailable = true;
spec.stage4OResultDir = fullfile(pwd,'results_stage4O_article_map_demo');
spec.stage4OMatFile = fullfile(spec.stage4OResultDir,'stage4O_article_map.mat');
spec.makePlots = true;
spec.writeCSVs = true;

% Figure panels/cuts.  The extractor uses nearest available grid values, so
% these values remain safe if the Stage4O grid is adjusted later.
spec.figureTList = [0.08 0.12 0.16];
spec.figureCutGList = [0.75 1.05 1.35 1.50];
spec.figureCutTList = [0.08 0.16];
spec.representativePoints = local_default_representatives();

% Plot controls.
spec.plotVisible = 'off';
spec.pngResolution = 250;
spec.phaseCodeLabels = {'normal','SR','currentSR','chiralSR'};
spec.phaseCodeValues = [0 1 2 3];

% Quality gates copied from the current Stage4O diagnostic level.
spec.minChiralCount = 10;
spec.maxCurrentDivergenceWarn = 1e-3;
spec.maxChiralityDefinitionErrorWarn = 1e-10;
end

function reps = local_default_representatives()
empty = struct('name','','gR',NaN,'t',NaN,'Phi',NaN);
reps = repmat(empty,1,5);
reps(1) = struct('name','normal_weak','gR',0.60,'t',0.08,'Phi',0);
reps(2) = struct('name','sr_lowflux','gR',1.00,'t',0.08,'Phi',0);
reps(3) = struct('name','chiral_midflux','gR',1.00,'t',0.08,'Phi',pi/2);
reps(4) = struct('name','chiral_stronghop','gR',1.40,'t',0.16,'Phi',pi/2);
reps(5) = struct('name','strong_sr_edgeflux','gR',1.40,'t',0.16,'Phi',pi);
end
