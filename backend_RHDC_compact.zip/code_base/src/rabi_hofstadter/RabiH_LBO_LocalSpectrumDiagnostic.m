function diag = RabiH_LBO_LocalSpectrumDiagnostic(params, basis, nLevels)
%RABIH_LBO_LOCALSPECTRUMDIAGNOSTIC Compare full and LBO local spectra.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(basis), basis = RabiH_PhotonBasis_FromSnapshots(params, struct()); end
if nargin < 3 || isempty(nLevels), nLevels = min(6,2*basis.dEff); end
pFull = params;
pFull.dph = basis.dFull;
Hfull = RabiH_LocalHamiltonian(pFull);
Hlbo = RabiH_LocalHamiltonianLBO(params,basis);
ef = sort(real(eig(0.5*(Hfull+Hfull'))),'ascend');
ee = sort(real(eig(0.5*(Hlbo+Hlbo'))),'ascend');
nLevels = min([nLevels,numel(ef),numel(ee)]);
err = ee(1:nLevels)-ef(1:nLevels);
diag = struct();
diag.dFull = basis.dFull;
diag.dEff = basis.dEff;
diag.nLevels = nLevels;
diag.fullLevels = ef(1:nLevels).';
diag.lboLevels = ee(1:nLevels).';
diag.levelErrors = err.';
diag.maxAbsError = max(abs(err));
diag.rmsError = sqrt(mean(abs(err).^2));
diag.orthonormalError = basis.orthonormalError;
diag.truncationHint = basis.truncationHint;
end
