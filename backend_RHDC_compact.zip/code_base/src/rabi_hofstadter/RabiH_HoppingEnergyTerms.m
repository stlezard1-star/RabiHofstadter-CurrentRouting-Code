function terms = RabiH_HoppingEnergyTerms(params, phase, tval)
%RABIH_HOPPINGENERGYTERMS Product-operator terms for one photon hopping bond.
%
% Compatible with either full Fock or projected LBO photon operators.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(phase), phase = 0; end
    if nargin < 3 || isempty(tval)
        tval = RabiH_GetNNHopping(params,'generic');
    end

    ops = RabiH_SiteOpsAuto(params);

    terms = struct('coeff',{},'opA',{},'opB',{});
    terms(1).coeff = -tval * exp(1i*phase);
    terms(1).opA   = ops.adag;
    terms(1).opB   = ops.a;
    terms(2).coeff = -tval * exp(-1i*phase);
    terms(2).opA   = ops.a;
    terms(2).opB   = ops.adag;
end
