function selection = RabiH_SelectCoherentSeed_CTM(params, opts)
%RABIH_SELECTCOHERENTSEED_CTM Small coherent-seed line search using CTM energy.
%
%   This is not meant to be a final variational solver. It is a cheap seed
%   selector before the main iPEPS update, useful in superradiant regimes.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    alphaList = RabiH_GetOpt(opts,'alphaList',[0]);
    patternList = RabiH_GetOpt(opts,'patternList',{'uniform'});
    spinState = RabiH_GetOpt(opts,'spinState',RabiH_GetOpt(params,'spinSeed','down'));
    ctmOpts = RabiH_GetOpt(opts,'ctmOpts',opts);

    if ischar(patternList), patternList = {patternList}; end
    rows = struct('alpha',{},'pattern',{},'energyPerSite',{},'rhoSR',{},'meanN',{});
    bestE = Inf;
    bestIdx = 0;
    bestUC = [];
    bestObs = [];
    idx = 0;
    for ia = 1:numel(alphaList)
        for ip = 1:numel(patternList)
            seedOpts = struct('alpha',alphaList(ia),'pattern',patternList{ip},'spinState',spinState);
            uc = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
            obs = RabiH_CTMObservables_Blocked(uc,params,ctmOpts);
            idx = idx + 1;
            rows(idx).alpha = alphaList(ia); %#ok<AGROW>
            rows(idx).pattern = patternList{ip}; %#ok<AGROW>
            rows(idx).energyPerSite = obs.energyPerSite; %#ok<AGROW>
            rows(idx).rhoSR = obs.superradiantDensity; %#ok<AGROW>
            rows(idx).meanN = obs.meanPhotonNumber; %#ok<AGROW>
            if real(obs.energyPerSite) < bestE
                bestE = real(obs.energyPerSite);
                bestIdx = idx;
                bestUC = uc;
                bestObs = obs;
            end
        end
    end
    selection = struct();
    selection.rows = rows;
    selection.bestIndex = bestIdx;
    selection.bestUnitCell = bestUC;
    selection.bestObs = bestObs;
    selection.bestEnergyPerSite = bestObs.energyPerSite;
    selection.bestAlpha = rows(bestIdx).alpha;
    selection.bestPattern = rows(bestIdx).pattern;
    selection.note = 'StageRH3 coherent-seed CTM line search.';
end
