function v = RabiH_SiteState_CoherentSpinLBO(params, basis, alpha, spinState)
%RABIH_SITESTATE_COHERENTSPINLBO Project a full coherent photon seed to LBO basis.
if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(basis), basis = RabiH_GetLBOBasis(params); end
if nargin < 3 || isempty(alpha), alpha = RabiH_GetOpt(params,'alphaSeed',0); end
if nargin < 4 || isempty(spinState), spinState = RabiH_GetOpt(params,'spinSeed','down'); end
cFull = RabiH_CoherentVector(basis.dFull, alpha);
cEff = basis.W' * cFull;
if norm(cEff) < 1e-14
    error('RabiH_SiteState_CoherentSpinLBO:ZeroProjection','Projected coherent seed has near-zero norm.');
end
cEff = cEff / norm(cEff);
s = RabiH_SpinVector(spinState);
v = kron(cEff, s);
v = v/norm(v);
end
