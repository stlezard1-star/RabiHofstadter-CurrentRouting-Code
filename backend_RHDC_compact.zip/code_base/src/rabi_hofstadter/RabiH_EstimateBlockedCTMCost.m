function cost = RabiH_EstimateBlockedCTMCost(unitCell)
%RABIH_ESTIMATEBLOCKEDCTMCOST Estimate blocked-CTM tensor sizes.
%   cost = RabiH_EstimateBlockedCTMCost(unitCell)
%
%   The blocked 2x2 CTM backend groups all boundary legs of a unit cell.
%   For site-boson PEPS this can become large quickly.  This helper reports
%   the expected blocked central tensor dimensions without constructing it.

    if ~isstruct(unitCell) || ~isfield(unitCell,'A')
        error('RabiH_EstimateBlockedCTMCost:InvalidUnitCell','unitCell must contain field A.');
    end
    Lx = unitCell.Lx; Ly = unitCell.Ly;
    leftDims = zeros(1,Ly);
    rightDims = zeros(1,Ly);
    for y = 1:Ly
        Tleft = unitCell.A{y,1};
        Tright = unitCell.A{y,Lx};
        szL = PEPS_FullSize(Tleft,5);
        szR = PEPS_FullSize(Tright,5);
        leftDims(y) = szL(2)^2;   % left virtual double-layer leg
        rightDims(y) = szR(3)^2;  % right virtual double-layer leg
    end
    upDims = zeros(1,Lx);
    downDims = zeros(1,Lx);
    for x = 1:Lx
        Tup = unitCell.A{1,x};
        Tdown = unitCell.A{Ly,x};
        szU = PEPS_FullSize(Tup,5);
        szD = PEPS_FullSize(Tdown,5);
        upDims(x) = szU(4)^2;
        downDims(x) = szD(5)^2;
    end

    blockDims = [prod(leftDims), prod(rightDims), prod(upDims), prod(downDims)];
    nElem = prod(blockDims);
    cost = struct();
    cost.Lx = Lx;
    cost.Ly = Ly;
    cost.blockDims = blockDims;
    cost.blockElements = nElem;
    cost.blockMemoryMB_real = nElem * 8 / 1024^2;
    cost.blockMemoryMB_complex = nElem * 16 / 1024^2;
    cost.leftDims = leftDims;
    cost.rightDims = rightDims;
    cost.upDims = upDims;
    cost.downDims = downDims;
end
