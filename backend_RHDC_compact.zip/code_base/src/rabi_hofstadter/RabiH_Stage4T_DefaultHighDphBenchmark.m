function [params, opts, spec] = RabiH_Stage4T_DefaultHighDphBenchmark()
%RABIH_STAGE4T_DEFAULTHIGHDPHBENCHMARK Defaults for high-dph LBO article benchmark.
%
% StageRH4T extends StageRH4S from representative low/moderate cutoffs to
% article-facing high-cutoff checks.  It compares full Fock calculations
% against LBO-projected calculations on the SR/chiralSR branches used in the
% main figures and Appendix convergence discussion.

[params, opts, specS] = RabiH_Stage4S_DefaultLBOBenchmark();

opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.Dmax = 2;
opts.chiMax = 6;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;
opts.Lx = 2;
opts.Ly = 2;
opts.cacheGates = true;
opts.outputDir = fullfile(pwd,'results_stage4T_high_dph_lbo_benchmark');

spec = specS;
spec.stage = 'StageRH4T';
spec.name = 'StageRH4T_high_dph_LBO_article_benchmark';
spec.description = ['High-cutoff full-Fock versus LBO-projected benchmark for ' ...
    'article representative SR/chiralSR branches.  This stage is intended for ' ...
    'Appendix cutoff/LBO convergence evidence rather than broad phase-map scans.'];
spec.branchList = local_stage4T_branches();
spec.dFullList = [10 12 14];
spec.dEffList = [6 8];
spec.alphaList = [0 0.4 0.8 1.2 1.6 2.0];
spec.numFock = 5;
spec.numLocalStates = 8;
spec.nLevels = 8;
spec.runFullReference = true;
spec.outputDir = opts.outputDir;
spec.writeCSV = true;
spec.stopOnError = false;

% Soft quality gates.  These are diagnostics, not hard test assertions for
% the full article run because finite-D/SU errors remain larger than LBO errors.
spec.maxAbsDEWarn = 2e-2;
spec.maxRelRhoWarn = 2e-2;
spec.maxRelCurrentWarn = 2e-2;
spec.maxRelChiralityWarn = 2e-2;
spec.phaseThresholds = struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5);
end

function branches = local_stage4T_branches()
qreps = RabiH_Stage4Q_RepresentativePoints();
keep = {'sr_uniform','chiral_midflux','chiral_stronghop','max_chiral_stage4O'};
branches = repmat(struct('name','','target','','gR',NaN,'t',NaN,'Phi',NaN, ...
    'alphaSeed',NaN,'alphaPattern','uniform','sourceEta',0),1,0);
for k = 1:numel(qreps)
    if any(strcmp(qreps(k).name,keep))
        b = struct();
        b.name = qreps(k).name;
        b.target = qreps(k).targetPhase;
        b.gR = qreps(k).gR;
        b.t = qreps(k).t;
        b.Phi = qreps(k).Phi;
        b.alphaSeed = qreps(k).alphaSeed;
        b.alphaPattern = qreps(k).alphaPattern;
        b.sourceEta = 0;
        branches(end+1) = b; %#ok<AGROW>
    end
end
end
