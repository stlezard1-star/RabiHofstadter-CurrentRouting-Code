function figSet = RabiH_BuildNNNMainTextFigureSet(source, spec)
%RABIH_BUILDNNNMAINTEXTFIGURESET Assemble manuscript-style NNN figures.
% SOURCE can be empty, a Stage4AB figSet with .records, or a Stage4Z scan
% with .bestRecords. The function writes compact strength maps, signed maps,
% refined arrow plots, selected-record CSVs, and a LaTeX caption/results snippet.

if nargin < 1, source = []; end
if nargin < 2 || isempty(spec), spec = RabiH_Stage4AC_DefaultMainTextSpec(); end
outDir = local_get(spec,'outputDir',fullfile(pwd,'results_stage4AC_maintext_nnn_figures'));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
makeVisible = local_get(spec,'makeVisible',false); vis = 'off'; if makeVisible, vis = 'on'; end

R = local_records_from_source(source, spec);
if isempty(R), error('RabiH_BuildNNNMainTextFigureSet:NoRecords','No refined records found.'); end
[targetG,targetJ1,S] = local_select_target_records(R,spec);

% Ensure all records have refined classifier fields.
S = RabiH_RefineNNNPatternRecords(S, spec);

figStrength = local_make_map_figure(S, spec, 'strength', vis, targetG, targetJ1);
strengthPng = fullfile(outDir,[local_get(spec,'strengthFigureName','Fig_stage4AC_NNN_strength_maps_maintext') '.png']);
strengthFig = fullfile(outDir,[local_get(spec,'strengthFigureName','Fig_stage4AC_NNN_strength_maps_maintext') '.fig']);
strengthPdf = fullfile(outDir,[local_get(spec,'strengthFigureName','Fig_stage4AC_NNN_strength_maps_maintext') '.pdf']);
local_save_all(figStrength,strengthPng,strengthFig,strengthPdf); close(figStrength);

figSigned = local_make_map_figure(S, spec, 'signed', vis, targetG, targetJ1);
signedPng = fullfile(outDir,[local_get(spec,'signedFigureName','Fig_stage4AC_NNN_signed_maps_maintext') '.png']);
signedFig = fullfile(outDir,[local_get(spec,'signedFigureName','Fig_stage4AC_NNN_signed_maps_maintext') '.fig']);
signedPdf = fullfile(outDir,[local_get(spec,'signedFigureName','Fig_stage4AC_NNN_signed_maps_maintext') '.pdf']);
local_save_all(figSigned,signedPng,signedFig,signedPdf); close(figSigned);

[figArrow, selected] = local_make_arrow_figure(S, spec, vis, targetG, targetJ1);
arrowPng = fullfile(outDir,[local_get(spec,'arrowFigureName','Fig_stage4AC_NNN_arrow_patterns_maintext') '.png']);
arrowFig = fullfile(outDir,[local_get(spec,'arrowFigureName','Fig_stage4AC_NNN_arrow_patterns_maintext') '.fig']);
arrowPdf = fullfile(outDir,[local_get(spec,'arrowFigureName','Fig_stage4AC_NNN_arrow_patterns_maintext') '.pdf']);
local_save_all(figArrow,arrowPng,arrowFig,arrowPdf); close(figArrow);

refinedCsv = fullfile(outDir,local_get(spec,'refinedCsvName','stage4AC_maintext_refined_records.csv'));
local_write_refined_csv(S, refinedCsv);
selectedCsv = fullfile(outDir,local_get(spec,'selectedCsvName','stage4AC_selected_maintext_patterns.csv'));
local_write_refined_csv([selected.record], selectedCsv);

snippetFile = fullfile(outDir,local_get(spec,'snippetName','RabiH_NNN_Results_and_Captions_Stage4AC.tex'));
local_write_latex_snippet(snippetFile, targetG, targetJ1, S, selected);

figSet = struct();
figSet.stage = 'StageRH4AC';
figSet.targetG = targetG;
figSet.targetJ1 = targetJ1;
figSet.outputDir = outDir;
figSet.strengthFigurePng = strengthPng; figSet.strengthFigureFig = strengthFig; figSet.strengthFigurePdf = strengthPdf;
figSet.signedFigurePng = signedPng; figSet.signedFigureFig = signedFig; figSet.signedFigurePdf = signedPdf;
figSet.arrowFigurePng = arrowPng; figSet.arrowFigureFig = arrowFig; figSet.arrowFigurePdf = arrowPdf;
figSet.refinedCsv = refinedCsv;
figSet.selectedCsv = selectedCsv;
figSet.snippetFile = snippetFile;
figSet.records = S;
figSet.selected = selected;
figSet.numTargetRecords = numel(S);
figSet.labels = unique({S.patternLabelRefined});
figSet.triRatioRange = [min([S.triRatio]) max([S.triRatio])];
figSet.diagSelectionRange = [min([S.diagSelectionRatio]) max([S.diagSelectionRatio])];
save(fullfile(outDir,'stage4AC_maintext_nnn_figure_set.mat'),'figSet','spec','source');
end

function R = local_records_from_source(source, spec)
if isempty(source)
    matAC = fullfile(pwd,'results_stage4AB_refined_nnn_patterns','stage4AB_refined_nnn_pattern_figure_set.mat');
    if exist(matAC,'file') == 2
        tmp = load(matAC,'figSet');
        if isfield(tmp,'figSet') && isfield(tmp.figSet,'records')
            R = tmp.figSet.records; return;
        end
    end
    matZ = fullfile(pwd,'results_stage4Z_nnn_production_pattern_demo','stage4Z_nnn_production_pattern_scan.mat');
    if exist(matZ,'file') == 2
        tmp = load(matZ,'scan');
        R = RabiH_RefineNNNPatternRecords(tmp.scan.bestRecords,spec); return;
    end
    ab = run_rabih_stage4AB_refined_figures_demo();
    R = ab.records; return;
end
if isstruct(source) && isfield(source,'records')
    R = source.records; return;
end
if isstruct(source) && isfield(source,'bestRecords')
    R = RabiH_RefineNNNPatternRecords(source.bestRecords,spec); return;
end
error('RabiH_BuildNNNMainTextFigureSet:BadSource','Unsupported source object.');
end

function [targetG,targetJ1,S] = local_select_target_records(R,spec)
if isfield(R,'status')
    try
        ok = strcmp({R.status},'ok'); R = R(ok);
    catch
    end
end
targetG = local_get(spec,'targetG',local_num(R(1),'g'));
targetJ1 = local_get(spec,'targetJ1',local_num(R(1),'J1'));
pairs = [[R.g]' [R.J1]'];
[~,ipair] = min((pairs(:,1)-targetG).^2 + (pairs(:,2)-targetJ1).^2);
targetG = R(ipair).g; targetJ1 = R(ipair).J1;
S = R(abs([R.g]-targetG)<1e-12 & abs([R.J1]-targetJ1)<1e-12);
if isempty(S), S = R; end
end

function fig = local_make_map_figure(S, spec, mode, vis, targetG, targetJ1)
if strcmp(mode,'signed')
    fields = local_get(spec,'signedFields',{'j13','j24','j13Minusj24','chiTriSigned13'});
    titles = local_get(spec,'signedTitles',fields);
    mainTitle = sprintf('Signed NNN-current diagnostics at g=%.3g, J1=%.3g',targetG,targetJ1);
else
    fields = local_get(spec,'strengthFields',{'meanAbsDiagCurrent','meanAbsSquareChirality','meanAbsTriangularChirality','triangularImbalance'});
    titles = local_get(spec,'strengthTitles',fields);
    mainTitle = sprintf('NNN current-pattern strengths at g=%.3g, J1=%.3g',targetG,targetJ1);
end
fig = figure('Visible',vis,'Color','w','Position',[100 100 980 700]);
for k = 1:numel(fields)
    subplot(2,2,k);
    [M,lamVals,thetaVals] = local_matrix(S,fields{k});
    imagesc(thetaVals/pi,lamVals,M); set(gca,'YDir','normal'); colorbar;
    xlabel('thetaTri/pi','Interpreter','none'); ylabel('lambda = J2/J1','Interpreter','none');
    title(sprintf('(%c) %s',char('a'+k-1),titles{k}),'Interpreter','none','FontWeight','normal');
    if strcmp(mode,'signed')
        m = max(abs(M(:))); if isfinite(m) && m > 0, caxis([-m m]); end
    end
end
local_suptitle(fig,mainTitle);
end

function [fig, selected] = local_make_arrow_figure(S, spec, vis, targetG, targetJ1)
cases = local_get(spec,'arrowCases',[-0.6 -0.25; -0.6 0; 0.6 0; 0.6 0.25]);
fig = figure('Visible',vis,'Color','w','Position',[100 100 1180 900]);
local_suptitle(fig,sprintf('Representative NNN current patterns at g=%.3g, J1=%.3g',targetG,targetJ1));
% Manual axes positions leave room for captions under each panel.
pos = [0.08 0.55 0.38 0.34; 0.56 0.55 0.38 0.34; 0.08 0.10 0.38 0.34; 0.56 0.10 0.38 0.34];
selected = repmat(struct('lambda',NaN,'thetaTri',NaN,'record',struct()),1,size(cases,1));
for k = 1:size(cases,1)
    rec = local_pick_record(S,cases(k,1),cases(k,2));
    selected(k).lambda = rec.lambda; selected(k).thetaTri = rec.thetaTri; selected(k).record = rec;
    ax = axes('Parent',fig,'Position',pos(k,:)); %#ok<LAXES>
    local_plot_arrow_record(ax,rec,k);
end
% Compact legend / sign convention.
axLeg = axes('Parent',fig,'Position',[0.36 0.015 0.28 0.05],'Visible','off'); %#ok<LAXES>
text(axLeg,0,0.65,'Edge currents: blue/red; diagonal currents: orange/purple; arrow length ~ |I_{ij}|','Interpreter','none','FontSize',8);
text(axLeg,0,0.15,'Positive bond orientation: 1->2, 2->3, 3->4, 4->1, 1->3, 2->4','Interpreter','none','FontSize',8);
end

function local_plot_arrow_record(ax,rec,k)
axes(ax); %#ok<LAXES>
coords = [0 0; 1 0; 1 1; 0 1];
plot([coords(:,1);coords(1,1)],[coords(:,2);coords(1,2)],'k-','LineWidth',1.2); hold on;
plot([0 1],[0 1],'k:','LineWidth',0.8); plot([1 0],[0 1],'k:','LineWidth',0.8);
axis equal off; xlim([-0.30 1.30]); ylim([-0.36 1.32]);
text(coords(:,1)-0.055,coords(:,2)-0.075,{'1','2','3','4'},'FontSize',9,'Interpreter','none');
I = [local_num(rec,'j12'),local_num(rec,'j23'),local_num(rec,'j34'),local_num(rec,'j41'),local_num(rec,'j13'),local_num(rec,'j24')];
maxI = max(abs(I(isfinite(I)))); if isempty(maxI) || maxI <= 0, maxI = 1; end
local_arrow(coords(1,:),coords(2,:),local_num(rec,'j12'),maxI,[0.0 0.35 0.85]);
local_arrow(coords(2,:),coords(3,:),local_num(rec,'j23'),maxI,[0.85 0.25 0.05]);
local_arrow(coords(3,:),coords(4,:),local_num(rec,'j34'),maxI,[0.0 0.35 0.85]);
local_arrow(coords(4,:),coords(1,:),local_num(rec,'j41'),maxI,[0.85 0.25 0.05]);
local_arrow(coords(1,:),coords(3,:),local_num(rec,'j13'),maxI,[0.92 0.65 0.00]);
local_arrow(coords(2,:),coords(4,:),local_num(rec,'j24'),maxI,[0.45 0.10 0.55]);
% Use separated text regions to avoid overlap.
text(0.00,1.24,sprintf('(%c) lambda=%.2g, thetaTri/pi=%.2g',char('a'+k-1),local_num(rec,'lambda'),local_num(rec,'thetaTri')/pi), ...
    'FontSize',9,'FontWeight','bold','Interpreter','none','VerticalAlignment','bottom');
summary1 = sprintf('%s',local_str(rec,'patternLabelRefined'));
summary2 = sprintf('|chiSq|=%.3g, mean|chiTri|=%.3g, j13=%.3g, j24=%.3g', ...
    abs(local_num(rec,'chiSquare')),local_num(rec,'meanAbsTriangularChirality'),local_num(rec,'j13'),local_num(rec,'j24'));
text(0.00,-0.20,summary1,'FontSize',8,'Interpreter','none','VerticalAlignment','top');
text(0.00,-0.30,summary2,'FontSize',7.5,'Interpreter','none','VerticalAlignment','top');
end

function local_arrow(p1,p2,I,maxI,colorVal)
if ~isfinite(I) || abs(I) < 1e-14, return; end
if I < 0, tmp = p1; p1 = p2; p2 = tmp; I = -I; end
mid = 0.5*(p1+p2); vec = p2-p1; L = norm(vec); if L == 0, return; end
vec = vec/L; scale = 0.30 + 0.47*min(1,abs(I)/maxI);
start = mid - 0.5*scale*vec; dv = scale*vec;
quiver(start(1),start(2),dv(1),dv(2),0,'LineWidth',1.1+1.9*min(1,abs(I)/maxI), ...
    'MaxHeadSize',0.48,'Color',colorVal);
end

function [M,lamVals,thetaVals] = local_matrix(R, field)
lamVals = unique([R.lambda]); thetaVals = unique([R.thetaTri]);
M = NaN(numel(lamVals),numel(thetaVals));
for i = 1:numel(lamVals)
    for j = 1:numel(thetaVals)
        idx = find(abs([R.lambda]-lamVals(i))<1e-12 & abs([R.thetaTri]-thetaVals(j))<1e-12,1,'first');
        if ~isempty(idx), M(i,j) = local_num(R(idx),field); end
    end
end
end

function rec = local_pick_record(R, lam, thetaOverPi)
theta = thetaOverPi*pi;
score = ([R.lambda]-lam).^2 + (([R.thetaTri]-theta)/pi).^2;
[~,idx] = min(score); rec = R(idx);
end

function local_write_refined_csv(R, filename)
fid = fopen(filename,'w'); if fid < 0, error('Cannot open %s',filename); end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'g,J1,lambda,thetaOverPi,patternLabel,patternLabelRefined,E,rhoSR,j12,j23,j34,j41,j13,j24,j13Minusj24,chiSquare,chiTriMeanAbs,chiTriSigned13,chiTriSigned24,triRatio,diagSelectionRatio,isTriEnhanced,isDiagSelected,isDiagSignReversed\n');
for k = 1:numel(R)
    fprintf(fid,'%.16g,%.16g,%.16g,%.16g,%s,%s,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%d,%d,%d\n', ...
        local_num(R(k),'g'),local_num(R(k),'J1'),local_num(R(k),'lambda'),local_num(R(k),'thetaTri')/pi, ...
        local_str(R(k),'patternLabel'),local_str(R(k),'patternLabelRefined'),local_num(R(k),'energyPerSite'),local_num(R(k),'superradiantDensity'), ...
        local_num(R(k),'j12'),local_num(R(k),'j23'),local_num(R(k),'j34'),local_num(R(k),'j41'), ...
        local_num(R(k),'j13'),local_num(R(k),'j24'),local_num(R(k),'j13Minusj24'),local_num(R(k),'chiSquare'),local_num(R(k),'meanAbsTriangularChirality'), ...
        local_num(R(k),'chiTriSigned13'),local_num(R(k),'chiTriSigned24'),local_num(R(k),'triRatio'),local_num(R(k),'diagSelectionRatio'), ...
        round(local_num(R(k),'isTriEnhanced')),round(local_num(R(k),'isDiagSelected')),round(local_num(R(k),'isDiagSignReversed')));
end
end

function local_write_latex_snippet(filename, targetG, targetJ1, R, selected)
fid = fopen(filename,'w'); if fid < 0, error('Cannot open %s',filename); end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
labels = unique({R.patternLabelRefined});
triMax = max([R.meanAbsTriangularChirality]);
triMin = min([R.meanAbsTriangularChirality]);
diagMax = max(abs([R.j13]-[R.j24]));
fprintf(fid,'%% Auto-generated by StageRH4AC. Edit before submission.\n');
fprintf(fid,'\\paragraph{NNN-induced current-pattern redistribution.}\n');
fprintf(fid,['For the representative parameter set $g=%.3g$ and $J_1=%.3g$, the refined current-pattern analysis resolves the NNN-induced loop currents into square-boundary, diagonal, and triangular contributions. ', ...
    'The square-loop chirality remains finite across the sampled $J_2/J_1$ and triangular-flux imbalance window, while the diagonal and triangular components are strongly redistributed. ', ...
    'In particular, negative $J_2$ enhances the mean triangular-loop chirality, whereas positive $J_2$ produces a more square-dominant chiral-superradiant pattern. ', ...
    'The triangular-flux imbalance selectively amplifies one diagonal channel, as seen from the signed diagnostic $I_{13}-I_{24}$.\n\n'],targetG,targetJ1);
fprintf(fid,'%% Refined labels found: '); for k=1:numel(labels), fprintf(fid,'%s ',labels{k}); end; fprintf(fid,'\n');
fprintf(fid,'%% mean|chi_tri| range: [%.6g, %.6g], max |I13-I24| = %.6g\n\n',triMin,triMax,diagMax);
fprintf(fid,'\\begin{figure}[t]\n\\centering\n');
fprintf(fid,'\\includegraphics[width=0.92\\linewidth]{Fig_stage4AC_NNN_strength_maps_maintext.pdf}\n');
fprintf(fid,'\\caption{NNN-current strength diagnostics at $g=%.3g$ and $J_1=%.3g$. The panels show the magnitude of diagonal currents, square-loop chirality, mean triangular-loop chirality, and triangular-current imbalance as functions of $\\lambda=J_2/J_1$ and $\\theta_\\triangle/\\pi$.}\n',targetG,targetJ1);
fprintf(fid,'\\label{fig:nnn_strength_maps}\n\\end{figure}\n\n');
fprintf(fid,'\\begin{figure}[t]\n\\centering\n');
fprintf(fid,'\\includegraphics[width=0.92\\linewidth]{Fig_stage4AC_NNN_signed_maps_maintext.pdf}\n');
fprintf(fid,'\\caption{Signed NNN-current diagnostics. The maps of $I_{13}$, $I_{24}$, $I_{13}-I_{24}$, and $\\chi_{123}-\\chi_{134}$ reveal diagonal-current sign reversal and triangular-current redistribution controlled by $J_2$ and triangular-flux imbalance.}\n');
fprintf(fid,'\\label{fig:nnn_signed_maps}\n\\end{figure}\n\n');
fprintf(fid,'\\begin{figure}[t]\n\\centering\n');
fprintf(fid,'\\includegraphics[width=0.92\\linewidth]{Fig_stage4AC_NNN_arrow_patterns_maintext.pdf}\n');
fprintf(fid,'\\caption{Representative current patterns selected from the refined classifier. The four panels illustrate triangular-enhanced, square-dominant, diagonal-selected, and mixed current-carrying superradiant patterns.}\n');
fprintf(fid,'\\label{fig:nnn_current_patterns}\n\\end{figure}\n');
% Also list selected labels as comments for the user.
fprintf(fid,'\n%% Selected records:\n');
for k = 1:numel(selected)
    rec = selected(k).record;
    fprintf(fid,'%% lambda=%.6g theta/pi=%.6g label=%s j13=%.6g j24=%.6g\n',local_num(rec,'lambda'),local_num(rec,'thetaTri')/pi,local_str(rec,'patternLabelRefined'),local_num(rec,'j13'),local_num(rec,'j24'));
end
end

function local_save_all(fig,pngFile,figFile,pdfFile)
saveas(fig,pngFile); local_savefig(fig,figFile);
try, print(fig,pdfFile,'-dpdf','-bestfit'); catch, try, saveas(fig,pdfFile); catch, end, end
end
function local_savefig(fig,filename)
try, savefig(fig,filename); catch, saveas(fig,filename); end
end
function v = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = S.(name); else, v = defaultVal; end
end
function v = local_num(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), v = real(S.(name)); else, v = NaN; end
end
function s = local_str(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), s = S.(name); else, s = ''; end
end
function local_suptitle(fig, str)
try
    if exist('sgtitle','file') == 2 || exist('sgtitle','builtin') == 5
        sgtitle(str,'Interpreter','none'); return;
    end
catch
end
try
    annotation(fig,'textbox',[0 0.955 1 0.04],'String',str,'EdgeColor','none', ...
        'HorizontalAlignment','center','VerticalAlignment','middle','FontWeight','bold','Interpreter','none');
catch
    ax = axes('Parent',fig,'Position',[0 0 1 1],'Visible','off'); %#ok<LAXES>
    text(ax,0.5,0.985,str,'Units','normalized','HorizontalAlignment','center','VerticalAlignment','top','FontWeight','bold','Interpreter','none');
end
end
