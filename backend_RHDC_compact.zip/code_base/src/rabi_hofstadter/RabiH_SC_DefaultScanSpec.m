function spec = RabiH_SC_DefaultScanSpec(kind)
%RabiH_SC_DefaultScanSpec  Default scans for StageRH4AF semiclassical figures.
if nargin < 1 || isempty(kind)
    kind = 'all';
end

spec = struct();
spec.kind = kind;
spec.outputDir = fullfile(pwd,'results_stage4AF_semiclassical');
spec.overwrite = true;

% Baseline NN-only scan in (g,Phi)
spec.baseline.gList = linspace(0.3,1.6,14);
spec.baseline.PhiList = linspace(0,pi,13);
spec.baseline.J1 = 0.16;
spec.baseline.lambda = 0.0;
spec.baseline.thetaTri = 0.0;

% NNN/triangular-flux scan in (lambda,thetaTri)
spec.nnn.g = 1.4;
spec.nnn.J1 = 0.16;
spec.nnn.PhiSquare = pi/2;
spec.nnn.lambdaList = [-0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6 0.8];
spec.nnn.thetaTriList = [-pi/4 -pi/8 0 pi/8 pi/4];

% Minimization options
spec.minimize.nStarts = 40;
spec.minimize.randomStarts = 12;
spec.minimize.amplitudes = [0 0.05 0.2 0.6 1.0 1.4 1.8];
spec.minimize.maxIter = 5000;
spec.minimize.maxFunEvals = 20000;
spec.minimize.tolX = 1e-8;
spec.minimize.tolFun = 1e-10;
spec.minimize.randomSeed = 1234;

% Figure options
spec.figure.targetG = spec.nnn.g;
spec.figure.targetJ1 = spec.nnn.J1;
spec.figure.selectedCases = [ ...
    -0.6, -0.25; ...
    -0.6,  0.00; ...
     0.6,  0.00; ...
     0.6,  0.25];
spec.figure.formats = {'png','fig','pdf'};
end
