function cost = RabiH_AssertBlockedCTMSafe(unitCell, opts)
%RABIH_ASSERTBLOCKEDCTMSAFE Guard against accidental oversized blocked CTM.
%   cost = RabiH_AssertBlockedCTMSafe(unitCell, opts)
%
%   opts.maxBlockedTensorElements default Inf
%   opts.maxBlockedTensorMB       default Inf  (complex-double estimate)
%
%   This helper deliberately checks before CTM_BlockUnitCell allocates the
%   blocked tensor.  It avoids MATLAB becoming unresponsive from a huge
%   accidental blocked tensor allocation.

    if nargin < 2 || isempty(opts), opts = struct(); end
    cost = RabiH_EstimateBlockedCTMCost(unitCell);
    maxElem = RabiH_GetOpt(opts,'maxBlockedTensorElements',Inf);
    maxMB = RabiH_GetOpt(opts,'maxBlockedTensorMB',Inf);
    if cost.blockElements > maxElem || cost.blockMemoryMB_complex > maxMB
        error('RabiH_AssertBlockedCTMSafe:BlockedTensorTooLarge', ...
            ['Blocked 2x2 CTM tensor is too large: dims=[%s], elements=%.4g, complex memory=%.2f MB. ' ...
             'Use smaller D/dph/chi for blocked baseline, or switch to the future multi-site CTM backend.'], ...
            num2str(cost.blockDims), cost.blockElements, cost.blockMemoryMB_complex);
    end
end
