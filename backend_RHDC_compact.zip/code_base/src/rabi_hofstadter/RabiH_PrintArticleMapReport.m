function RabiH_PrintArticleMapReport(articleMap)
%RABIH_PRINTARTICLEMAPREPORT Print StageRH4O article-map summary.

if isfield(articleMap,'summary')
    summary = articleMap.summary;
else
    summary = articleMap;
end
fprintf('--- RabiH StageRH4O refined article-map report ---\n');
fprintf('records / ok         : %d / %d\n', summary.numRecords, summary.numOK);
fprintf('energy range         : [%.12g, %.12g]\n', summary.energyRange(1), summary.energyRange(2));
fprintf('rhoSR range          : [%.12g, %.12g]\n', summary.rhoSRRange(1), summary.rhoSRRange(2));
fprintf('max |current|        : %.6e\n', summary.maxAbsCurrent);
fprintf('max |chirality|      : %.6e\n', summary.maxAbsChirality);
fprintf('max current div      : %.6e\n', summary.maxCurrentDivergence);
fprintf('max chirality err    : %.6e\n', summary.maxChiralityDefinitionError);
pc = summary.phaseCounts;
fprintf('phase counts         : normal=%d, SR=%d, currentSR=%d, chiralSR=%d, error=%d, other=%d\n', ...
    pc.normal, pc.SR, pc.currentSR, pc.chiralSR, pc.error, pc.other);
if isfield(articleMap,'bestCsv')
    fprintf('best-seed CSV        : %s\n', articleMap.bestCsv);
end
if isfield(articleMap,'summaryCsv')
    fprintf('summary CSV          : %s\n', articleMap.summaryCsv);
end

if isfield(summary,'bestChiralRecord') && isfield(summary.bestChiralRecord,'gR')
    r = summary.bestChiralRecord;
    fprintf('max-chiral point     : gR=%.4g, t=%.4g, Phi/pi=%.4g, rho=%.4e, |J|=%.4e, |chi|=%.4e\n', ...
        r.gR, r.t, r.Phi/pi, r.superradiantDensity, r.meanAbsCurrent, r.meanAbsChirality);
end
if isfield(summary,'perT') && ~isempty(summary.perT)
    fprintf('per-t summary        :\n');
    fprintf('   t        n  normal  SR currentSR chiralSR   maxRho      max|J|     max|chi|\n');
    for k = 1:numel(summary.perT)
        s = summary.perT(k);
        fprintf('%7.4g %4d %7d %3d %9d %8d %10.3e %10.3e %10.3e\n', ...
            s.t, s.numRecords, s.numNormal, s.numSR, s.numCurrentSR, s.numChiralSR, ...
            s.maxRhoSR, s.maxAbsCurrent, s.maxAbsChirality);
    end
end
if isfield(summary,'warnings') && ~isempty(summary.warnings)
    fprintf('warnings             :\n');
    for k = 1:numel(summary.warnings)
        fprintf('  - %s\n', summary.warnings{k});
    end
end
end
