function [Hhop, ops] = RabiH_HoppingHamiltonian(params, phase, tval)
%RABIH_HOPPINGHAMILTONIAN Two-site photon hopping Hamiltonian.
%
% Uses full Fock photon operators by default.  With params.useLBO=true it
% uses projected photon operators in the optimized photon basis.

    if nargin < 1 || isempty(params)
        params = struct();
    end
    if nargin < 2 || isempty(phase)
        phase = 0;
    end
    if nargin < 3 || isempty(tval)
        tval = RabiH_GetNNHopping(params,'generic');
    end

    if RabiH_IsLBOEnabled(params)
        basis = RabiH_GetLBOBasis(params);
        [Hhop, ops] = RabiH_HoppingHamiltonianLBO(params,basis,phase,tval);
        return;
    end

    dph = RabiH_GetOpt(params,'dph',4);
    ops = RabiH_SiteOps(dph);
    a = ops.a;
    ad = ops.adag;

    hop12 = RabiH_TwoSiteOp(ad, a);  % a_1^dag a_2
    hop21 = RabiH_TwoSiteOp(a, ad);  % a_2^dag a_1
    Hhop = -tval*(exp(1i*phase)*hop12 + exp(-1i*phase)*hop21);
    Hhop = 0.5*(Hhop + Hhop');
end
