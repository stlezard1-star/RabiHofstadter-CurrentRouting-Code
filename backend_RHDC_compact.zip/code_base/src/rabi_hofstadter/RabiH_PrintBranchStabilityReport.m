function RabiH_PrintBranchStabilityReport(scan)
%RABIH_PRINTBRANCHSTABILITYREPORT Print StageRH4N report.

if isfield(scan,'summary')
    s = scan.summary;
    records = scan.records;
else
    records = scan;
    s = RabiH_SummarizeBranchStabilityScan(records);
end
fprintf('--- RabiH StageRH4N branch stability report ---\n');
fprintf('records / ok / error       : %d / %d / %d\n', s.numRecords, s.numOK, s.numError);
fprintf('branches                   : %d\n', s.numBranches);
fprintf('energy range               : [%.12g, %.12g]\n', s.energyRange(1), s.energyRange(2));
fprintf('rhoSR range                : [%.12g, %.12g]\n', s.rhoSRRange(1), s.rhoSRRange(2));
fprintf('max |current|              : %.6e\n', s.maxAbsCurrent);
fprintf('max |chirality|            : %.6e\n', s.maxAbsChirality);
fprintf('max current divergence     : %.6e\n', s.maxCurrentDivergence);
fprintf('max chirality err          : %.6e\n', s.maxChiralityDefinitionError);
fprintf('target match fraction      : %.3f\n', s.targetMatchFraction);
fprintf('max branch |dE|            : %.6e\n', s.maxAbsEnergyDeltaWithinBranch);
fprintf('max branch |dRho|          : %.6e\n', s.maxAbsRhoDeltaWithinBranch);
fprintf('max branch |dCurrent|      : %.6e\n', s.maxAbsCurrentDeltaWithinBranch);
fprintf('max branch |dChirality|    : %.6e\n', s.maxAbsChiralityDeltaWithinBranch);
if isfield(scan,'csvFile')
    fprintf('CSV                        : %s\n', scan.csvFile);
end
fprintf('branch              target      n match phaseLabels          E-range                         rho-range                       |J|-range                       |chi|-range\n');
for k = 1:numel(s.branchTable)
    b = s.branchTable(k);
    fprintf('%-19s %-10s %2d %5d %-20s [% .6e,% .6e] [% .6e,% .6e] [% .6e,% .6e] [% .6e,% .6e]\n', ...
        local_trunc(b.branchName,19), local_trunc(b.targetPhase,10), b.numRecords, b.numTargetMatches, ...
        local_trunc(local_join_labels(b.phaseLabels),20), b.energyRange(1), b.energyRange(2), ...
        b.rhoSRRange(1), b.rhoSRRange(2), b.currentRange(1), b.currentRange(2), ...
        b.chiralityRange(1), b.chiralityRange(2));
end
fprintf('sample records:\n');
fprintf('branch              phase       D chi dph  mix       eta      gR      t  Phi/pi       E/site        rhoSR        |J|       |chi|      divJ\n');
for k = 1:min(numel(records),30)
    r = records(k);
    fprintf('%-19s %-9s %2d %3d %3d %5.2g %9.1e %6.3g %6.3g %7.3f %14.8g %11.4e %9.2e %9.2e %9.2e\n', ...
        local_trunc(r.branchName,19), local_trunc(r.phaseLabel,9), r.Dmax, r.chiMax, r.dph, ...
        r.sharedBoundaryMix, r.sourceEta, r.gR, r.t, r.Phi/pi, r.energyPerSite, ...
        r.superradiantDensity, r.meanAbsCurrent, r.meanAbsChirality, r.maxCurrentDivergence);
end
end

function txt = local_join_labels(labels)
if isempty(labels)
    txt = '';
elseif ischar(labels)
    txt = labels;
else
    txt = strjoin(labels,'|');
end
end

function s = local_trunc(s,n)
if isempty(s), s = ''; end
if numel(s) > n, s = s(1:n); end
end
