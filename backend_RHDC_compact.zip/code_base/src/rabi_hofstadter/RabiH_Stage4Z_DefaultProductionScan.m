function [params, opts, spec] = RabiH_Stage4Z_DefaultProductionScan(mode)
%RABIH_STAGE4Z_DEFAULTPRODUCTIONSCAN Default StageRH4Z NNN current-pattern scan.
%
%   StageRH4Z is a production-oriented diagnostic scan for explicit NNN
%   path-gate updates.  It extends StageRH4Y by including negative and
%   positive J2/J1, triangular-flux imbalance thetaTri, and near-boundary
%   Rabi couplings.
%
%   mode = 'demo'       : moderate scan suitable for interactive testing.
%   mode = 'production' : larger scan for article map generation.
%   mode = 'tiny'       : small smoke-test scan.

    if nargin < 1 || isempty(mode), mode = 'demo'; end

    [params, opts, spec] = RabiH_Stage4Y_DefaultNNNPathScan();
    params.includeNNN = true;
    params.nnnPhaseMode = 'lineIntegral';
    params.thetaTri = 0;
    params.dph = 5;

    opts.outputDir = fullfile(pwd,'results_stage4Z_nnn_production_pattern_demo');
    opts.useNNNPathUpdate = true;
    opts.tauList = [0.04 0.02 0.01];
    opts.nSweeps = 1;
    opts.Dmax = 2;
    opts.chiMax = 6;

    spec.backend = 'splitFactoredExact';
    spec.stopOnError = false;
    spec.nnnPhaseMode = 'lineIntegral';
    spec.dphList = params.dph;
    spec.DmaxList = opts.Dmax;
    spec.chiMaxList = opts.chiMax;

    switch lower(mode)
        case 'tiny'
            spec.gList = [0.8 1.0];
            spec.J1List = 0.08;
            spec.lambdaList = [-0.4 0 0.4];
            spec.PhiList = pi/2;
            spec.thetaTriList = [0 pi/8];
            spec.alphaSeedList = 0.8;
            spec.alphaPatternList = {'uniform'};
            opts.outputDir = fullfile(pwd,'results_stage4Z_tiny_test');
        case 'production'
            spec.gList = [0.6 0.8 1.0 1.2 1.4];
            spec.J1List = [0.06 0.08 0.12 0.16];
            spec.lambdaList = [-0.8 -0.4 0 0.4 0.8 1.2];
            spec.PhiList = [pi/4 pi/2 3*pi/4];
            spec.thetaTriList = [-pi/4 -pi/8 0 pi/8 pi/4];
            spec.alphaSeedList = [0.4 0.8];
            spec.alphaPatternList = {'uniform','vortex2x2'};
            opts.outputDir = fullfile(pwd,'results_stage4Z_nnn_production_pattern_full');
        otherwise % demo
            spec.gList = [0.8 1.0 1.2 1.4];
            spec.J1List = [0.08 0.16];
            spec.lambdaList = [-0.6 -0.3 0 0.3 0.6];
            spec.PhiList = pi/2;
            spec.thetaTriList = [-pi/4 0 pi/4];
            spec.alphaSeedList = [0.4 0.8];
            spec.alphaPatternList = {'uniform'};
    end
end
