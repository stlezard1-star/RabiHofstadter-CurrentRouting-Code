function obs = RabiH_SC_Observables(alpha, params)
%RabiH_SC_Observables  Currents and loop chiralities from coherent amplitudes.
alpha = alpha(:).';
if numel(alpha) ~= 4
    error('alpha must contain four complex amplitudes.');
end
J1 = local_get(params,'J1',0.16);
J2 = RabiH_SC_GetJ2(params);
ph = RabiH_SC_FluxPhases(params);

a = alpha;
obs = struct();
obs.alpha = a;
obs.rhoSR = mean(abs(a).^2);
obs.meanPhotonNumber = obs.rhoSR;
obs.energy = RabiH_SC_EnergyAlpha(a, params);
obs.energyPerSite = obs.energy / 4;

% Directed bond currents.
obs.I12 = 2*J1*imag(exp(1i*ph.A12)*conj(a(1))*a(2));
obs.I23 = 2*J1*imag(exp(1i*ph.A23)*conj(a(2))*a(3));
obs.I34 = 2*J1*imag(exp(1i*ph.A34)*conj(a(3))*a(4));
obs.I41 = 2*J1*imag(exp(1i*ph.A41)*conj(a(4))*a(1));
obs.I13 = 2*J2*imag(exp(1i*ph.B13)*conj(a(1))*a(3));
obs.I24 = 2*J2*imag(exp(1i*ph.B24)*conj(a(2))*a(4));
obs.I31 = -obs.I13;
obs.I42 = -obs.I24;

% Loop chiralities.
obs.chiSquare = obs.I12 + obs.I23 + obs.I34 + obs.I41;
obs.chi123 = obs.I12 + obs.I23 - obs.I13;
obs.chi134 = obs.I13 + obs.I34 + obs.I41;
obs.chi124 = obs.I12 + obs.I24 + obs.I41;
obs.chi234 = obs.I23 + obs.I34 - obs.I24;

obs.meanAbsNNCurrent = mean(abs([obs.I12 obs.I23 obs.I34 obs.I41]));
obs.meanAbsDiagCurrent = mean(abs([obs.I13 obs.I24]));
obs.meanAbsSquareChirality = abs(obs.chiSquare);
obs.meanAbsTriangularChirality = mean(abs([obs.chi123 obs.chi134 obs.chi124 obs.chi234]));
obs.triangularImbalance = 0.5*(abs(obs.chi123-obs.chi134)+abs(obs.chi124-obs.chi234));
obs.diagCurrentImbalance = abs(obs.I13-obs.I24);
obs.triRatio = obs.meanAbsTriangularChirality / (abs(obs.chiSquare)+1e-14);
obs.diagSelectionRatio = abs(obs.I13-obs.I24) / (abs(obs.I13)+abs(obs.I24)+1e-14);
obs.I13MinusI24 = obs.I13 - obs.I24;
obs.chiTriSigned13 = obs.chi123 - obs.chi134;
obs.chiTriSigned24 = obs.chi124 - obs.chi234;

% Net outgoing bond-current imbalance. In the full Rabi model this is not a
% conservation error because local Rabi coupling creates/annihilates photons.
div1 = obs.I12 + obs.I13 - obs.I41;
div2 = obs.I23 + obs.I24 - obs.I12;
div3 = obs.I34 - obs.I23 - obs.I13;
div4 = obs.I41 - obs.I34 - obs.I24;
obs.currentDivergence = [div1 div2 div3 div4];
obs.maxCurrentDivergence = max(abs(obs.currentDivergence));

obs.triangleIdentityErr13 = abs((obs.chi123 + obs.chi134) - obs.chiSquare);
obs.triangleIdentityErr24 = abs((obs.chi124 + obs.chi234) - obs.chiSquare);
obs.maxTriangleIdentityErr = max(obs.triangleIdentityErr13, obs.triangleIdentityErr24);
obs.flux = ph;

[obs.patternLabel, obs.patternCode, tags] = RabiH_SC_ClassifyPattern(obs);
obs.patternTags = tags;
end

function v = local_get(s, name, defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
