function RabiH_SC_PrintReport(scan)
summary = scan.summary;
fprintf('--- RabiH StageRH4AF semiclassical coherent-state report ---\n');
fprintf('records / ok / error       : %d / %d / %d\n', summary.numRecords, summary.numOK, summary.numError);
fprintf('energy range               : [%.12g, %.12g]\n', summary.energyRange(1), summary.energyRange(2));
fprintf('rhoSR range                : [%.12g, %.12g]\n', summary.rhoRange(1), summary.rhoRange(2));
fprintf('max |chi_square|           : %.6e\n', summary.maxAbsChiSquare);
fprintf('max mean |chi_triangle|    : %.6e\n', summary.maxAbsChiTri);
fprintf('max |I_diag|               : %.6e\n', summary.maxAbsIDiag);
fprintf('max triangular imbalance   : %.6e\n', summary.maxTriImbalance);
fprintf('max current imbalance      : %.6e\n', summary.maxCurrentDivergence);
fprintf('max triangle identity err  : %.6e\n', summary.maxTriangleIdentityErr);
fprintf('labels                     : %s\n', summary.labels);
end
