function RabiH_PrintNNNRefinedPatternFigureSetReport(figSet)
%RABIH_PRINTNNNREFINEDPATTERNFIGURESETREPORT Print StageRH4AB summary.
fprintf('--- RabiH StageRH4AB refined NNN current-pattern report ---\n');
fprintf('target g, J1            : %.6g, %.6g\n',figSet.targetG,figSet.targetJ1);
fprintf('records / target recs    : %d / %d\n',figSet.numRecords,figSet.numTargetRecords);
fprintf('unsigned map figure      : %s\n',figSet.unsignedFigurePng);
fprintf('signed map figure        : %s\n',figSet.signedFigurePng);
fprintf('refined arrow figure     : %s\n',figSet.arrowFigurePng);
fprintf('summary CSV              : %s\n',figSet.summaryCsv);
fprintf('labels                   : ');
for k=1:numel(figSet.labels), fprintf('%s ',figSet.labels{k}); end
fprintf('\nselected records:\n');
for k=1:numel(figSet.selected)
    r = figSet.selected(k).record;
    fprintf('  lambda=% .3f theta/pi=% .3f refined=%s j13=% .3e j24=% .3e triRatio=%.3f diagSel=%.3f\n', ...
        r.lambda,r.thetaTri/pi,r.patternLabelRefined,r.j13,r.j24,r.triRatio,r.diagSelectionRatio);
end
end
