function [params, opts, spec] = RabiH_Stage4S_DefaultLBOBenchmark()
%RABIH_STAGE4S_DEFAULTLBOBENCHMARK Defaults for full-vs-LBO PEPS benchmark.
%
% StageRH4S integrates the StageRH4R photon basis into selected high-cutoff
% one-point PEPS runs.  It compares full Fock dph=dFull against projected
% photon basis dEff at the same physical branch and CTM/SU settings.

[params, opts, ~] = RabiH_Stage4Q_DefaultOverlay();
params.omega = RabiH_GetOpt(params,'omega',1.0);
params.Delta = RabiH_GetOpt(params,'Delta',1.0);
params.gR = 1.0;
params.t = 0.08;
params.Phi = pi/2;
params.alphaSeed = 0.8;
params.alphaPattern = 'uniform';
params.sourceEta = 0;

opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.Dmax = 2;
opts.chiMax = 6;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.Lx = 2;
opts.Ly = 2;
opts.cacheGates = true;
opts.outputDir = fullfile(pwd,'results_stage4S_lbo_peps_benchmark');

spec = struct();
spec.stage = 'StageRH4S';
spec.name = 'StageRH4S_LBO_integrated_PEPS_benchmark';
spec.description = ['Full-cutoff versus LBO-projected one-point PEPS benchmark. ' ...
    'This stage tests whether the photon LBO can replace large dph in selected branches.'];
spec.branchList = RabiH_Stage4S_RepresentativeBranches();
spec.dFullList = [8 10 12];
spec.dEffList = [6];
spec.alphaList = [0 0.4 0.8 1.2 1.6];
spec.numFock = 4;
spec.numLocalStates = 6;
spec.nLevels = 6;
spec.runFullReference = true;
spec.maxAbsDEWarn = 5e-2;
spec.maxRelRhoWarn = 0.15;
spec.maxRelCurrentWarn = 0.15;
spec.maxRelChiralityWarn = 0.15;
spec.outputDir = opts.outputDir;
spec.writeCSV = true;
spec.stopOnError = false;
end
