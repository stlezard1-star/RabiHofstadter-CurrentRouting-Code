function result = RabiH_RunOnePoint_CoherentSU_FactoredExact(params, opts)
%RABIH_RUNONEPOINT_COHERENTSU_FACTOREDEXACT Small-cell SU + factored exact benchmark.
%
% This StageRH4E runner is for validation and regression tests only.  It
% runs the same coherent-seed simple-update path as the blocked runner, then
% measures the final state with the non-blocked exact-torus reference backend.
% The exact-torus guard rejects unsafe cases such as D=3 on a 2x2 cell.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
    if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
    if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
    if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

    uc = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
    [uc, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(uc, params, opts);

    factoredOpts = opts;
    factoredOpts.enableFactoredExactTorus = true;
    factoredOpts.factoredBackendMode = 'exactSmallCell';
    factoredOpts.exactLx = RabiH_GetOpt(opts,'exactLx',Lx);
    factoredOpts.exactLy = RabiH_GetOpt(opts,'exactLy',Ly);
    obs = RabiH_CTMObservables_Factored(uc, params, factoredOpts);

    result = struct();
    result.unitCell = uc;
    result.suInfo = suInfo;
    result.obs = obs;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanAbsCurrent = obs.meanAbsCurrent;
    result.alphaSeed = uc.alphaSeed;
    result.backend = 'factored_exact_torus';
    result.pipelineStage = 'RabiH_v0_3_1_StageRH4E_factored_exact_one_point';
end
