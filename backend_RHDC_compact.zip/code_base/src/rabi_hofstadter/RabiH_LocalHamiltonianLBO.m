function [Hloc, ops] = RabiH_LocalHamiltonianLBO(params, basis)
%RABIH_LOCALHAMILTONIANLBO One-site Rabi Hamiltonian in projected photon basis.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(basis), basis = RabiH_PhotonBasis_FromSnapshots(params, struct()); end
omega = RabiH_GetOpt(params,'omega',1.0);
Delta = RabiH_GetOpt(params,'Delta',1.0);
gR = RabiH_GetOpt(params,'gR',0.2);
ops = RabiH_SiteOpsLBO(params,basis);
Hloc = omega*ops.N + 0.5*Delta*ops.sz + gR*(ops.Q*ops.sx);
eta = RabiH_GetOpt(params,'sourceEta',0);
if isreal(eta)
    eta = eta * exp(1i*RabiH_GetOpt(params,'sourcePhase',0));
end
if abs(eta) > 0
    Hloc = Hloc - (conj(eta)*ops.a + eta*ops.adag);
end
Hloc = 0.5*(Hloc+Hloc');
end
