function RabiH_WriteNNNCurrentPatternCSV(records, filename)
%RABIH_WRITENNNCURRENTPATTERNCSV Write NNN current-pattern records.
% Robust CSV writer used by StageRH4W--4AA.  It tolerates records produced
% by older scans where some of the directed edge-current fields were not
% yet present.
if nargin < 2 || isempty(filename), filename='stage4W_current_pattern.csv'; end
fid=fopen(filename,'w');
if fid<0, error('RabiH_WriteNNNCurrentPatternCSV:OpenFailed','Cannot open %s.',filename); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
headers={'index','status','label','patternLabel','dph','Dmax','chiMax','g','J1','lambda','J2','Phi','thetaTri','alphaSeed','alphaPattern','energyPerSite','rhoSR','meanPhotonNumber','INN','Idiag','chiSquareAbs','chiTriAbs','triImbalance','diagImbalance','divTotal','triIdentityErr','j12','j23','j34','j41','j13','j31','j24','j42','chiSquare','chiTri123','chiTri134','chiTri124','chiTri234','PhiSquare','PhiTri123','PhiTri134','PhiTri124','PhiTri234','runtime','errorMessage'};
fprintf(fid,'%s\n',strjoin(headers,','));
for k=1:numel(records)
    r=records(k);
    row={ ...
        getv(r,'index'), getv(r,'status'), getv(r,'label'), getv(r,'patternLabel'), ...
        getv(r,'dph'), getv(r,'Dmax'), getv(r,'chiMax'), getv(r,'g'), getv(r,'J1'), getv(r,'lambda'), getv(r,'J2'), getv(r,'Phi'), getv(r,'thetaTri'), getv(r,'alphaSeed'), getv(r,'alphaPattern'), ...
        getv(r,'energyPerSite'), getv(r,'superradiantDensity'), getv(r,'meanPhotonNumber'), ...
        getv(r,'meanAbsNNCurrent'), getv(r,'meanAbsDiagCurrent'), getv(r,'meanAbsSquareChirality'), getv(r,'meanAbsTriangularChirality'), ...
        getv(r,'triangularImbalance'), getv(r,'diagCurrentImbalance'), getv(r,'maxCurrentDivergenceTotal'), getv(r,'triangleIdentityErr'), ...
        getv(r,'j12'), getv(r,'j23'), getv(r,'j34'), getv(r,'j41'), getv(r,'j13'), getv(r,'j31'), getv(r,'j24'), getv(r,'j42'), ...
        getv(r,'chiSquare'), getv(r,'chiTri123'), getv(r,'chiTri134'), getv(r,'chiTri124'), getv(r,'chiTri234'), ...
        getv(r,'PhiSquare'), getv(r,'PhiTri123'), getv(r,'PhiTri134'), getv(r,'PhiTri124'), getv(r,'PhiTri234'), ...
        getv(r,'runtimeSeconds'), getv(r,'errorMessage')};
    strs=cellfun(@fmt,row,'UniformOutput',false);
    fprintf(fid,'%s\n',strjoin(strs,','));
end
end
function v=getv(r,name)
if isstruct(r) && isfield(r,name) && ~isempty(r.(name)), v=r.(name); else, v=NaN; end
end
function s=fmt(v)
if ischar(v)
    s=strrep(v,',',';');
elseif isstring(v)
    s=strrep(char(v),',',';');
elseif isempty(v)
    s='';
elseif isnumeric(v) || islogical(v)
    if numel(v)~=1, v=v(1); end
    if isfinite(v)
        s=sprintf('%.16g',real(v));
    else
        s='NaN';
    end
else
    s=strrep(char(v),',',';');
end
end
