function gateCache = RabiH_PrecomputeNNGates(params, tau, Lx, Ly)
%RABIH_PRECOMPUTENNGATES Precompute local and NN hopping gates for one tau.
%   This is a speed-oriented helper for site-boson Rabi-Hofstadter SU.
%   It avoids rebuilding expm gates inside the bond loops.

    if nargin < 3 || isempty(Lx), Lx = RabiH_GetOpt(params,'Lx',2); end
    if nargin < 4 || isempty(Ly), Ly = RabiH_GetOpt(params,'Ly',2); end
    tX = RabiH_GetNNHopping(params,'right');
    tY = RabiH_GetNNHopping(params,'down');

    gateCache = struct();
    gateCache.tau = tau;
    gateCache.Lx = Lx;
    gateCache.Ly = Ly;
    gateCache.tX = tX;
    gateCache.tY = tY;
    [gateCache.GlocHalf, gateCache.Hloc] = RabiH_LocalGate(params, tau/2);

    gateCache.Gx = cell(Ly,Lx);
    gateCache.Gy = cell(Ly,Lx);
    gateCache.phaseX = zeros(Ly,Lx);
    gateCache.phaseY = zeros(Ly,Lx);
    for y = 1:Ly
        for x = 1:Lx
            phx = RabiH_GaugePhase(x,y,'right',params);
            phy = RabiH_GaugePhase(x,y,'down',params);
            gateCache.phaseX(y,x) = phx;
            gateCache.phaseY(y,x) = phy;
            gateCache.Gx{y,x} = RabiH_HoppingGate(params, phx, tX, tau);
            gateCache.Gy{y,x} = RabiH_HoppingGate(params, phy, tY, tau);
        end
    end
end
