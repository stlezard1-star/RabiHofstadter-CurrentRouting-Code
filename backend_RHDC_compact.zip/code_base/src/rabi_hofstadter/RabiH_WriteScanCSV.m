function RabiH_WriteScanCSV(records, filename)
%RABIH_WRITESCANCSV Write scan record struct array to a compact CSV file.

if nargin < 2 || isempty(filename)
    filename = 'scan_summary.csv';
end
fid = fopen(filename,'w');
if fid < 0
    error('RabiH_WriteScanCSV:OpenFailed','Cannot open file for writing: %s.', filename);
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'index,gR,t,Phi,alphaSeed,status,energyPerSite,superradiantDensity,meanPhotonNumber,meanAbsCurrent,meanAbsChirality,runtimeSeconds,blockedTensorMB,blockedInterMB,errorMessage\n');
for k = 1:numel(records)
    msg = local_csv_escape(records(k).errorMessage);
    fprintf(fid,'%d,%.16g,%.16g,%.16g,%.16g,%s,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%s\n', ...
        records(k).index, records(k).gR, records(k).t, records(k).Phi, records(k).alphaSeed, ...
        local_csv_escape(records(k).status), records(k).energyPerSite, records(k).superradiantDensity, ...
        records(k).meanPhotonNumber, records(k).meanAbsCurrent, records(k).meanAbsChirality, ...
        records(k).runtimeSeconds, records(k).blockedTensorMB, records(k).blockedInterMB, msg);
end
end

function s = local_csv_escape(x)
if isempty(x)
    s = '""';
    return;
end
if ~ischar(x)
    x = char(x);
end
x = strrep(x, '"', '""');
x = strrep(x, sprintf('\n'), ' ');
x = strrep(x, sprintf('\r'), ' ');
s = ['"' x '"'];
end
