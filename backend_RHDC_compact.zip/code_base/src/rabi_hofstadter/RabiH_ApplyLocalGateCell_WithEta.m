function unitCell = RabiH_ApplyLocalGateCell_WithEta(unitCell, params, tau, etaCell)
%RABIH_APPLYLOCALGATECELL_WITHETA Apply site-dependent local gates.
    if nargin < 4 || isempty(etaCell)
        etaCell = zeros(unitCell.Ly,unitCell.Lx);
    end
    baseEta = RabiH_GetOpt(params,'sourceEta',0);
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            psite = params;
            psite.sourceEta = baseEta + etaCell(y,x);
            [G,~] = RabiH_LocalGate(psite, tau);
            unitCell.A{y,x} = RabiH_ApplyOneSiteGate(unitCell.A{y,x}, G);
        end
    end
end
