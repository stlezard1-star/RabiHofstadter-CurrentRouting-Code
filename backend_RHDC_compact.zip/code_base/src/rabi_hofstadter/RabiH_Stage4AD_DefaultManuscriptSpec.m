function spec = RabiH_Stage4AD_DefaultManuscriptSpec()
%RABIH_STAGE4AD_DEFAULTMANUSCRIPTSPEC Defaults for manuscript update packaging.
% StageRH4AD does not run new physics. It packages the NNN-current-pattern
% manuscript text and figures produced after Stage4AC.

spec = struct();
spec.outputDir = fullfile(pwd,'results_stage4AD_manuscript_update');
spec.sourceDir = fullfile(fileparts(fileparts(mfilename('fullpath'))),'manuscript','Stage4AD');
spec.texName = 'RabiH_manuscript_NNN_draft_v2.tex';
spec.pdfName = 'RabiH_manuscript_NNN_draft_v2.pdf';
spec.bibName = 'references_v2.bib';
spec.readmeName = 'README_Stage4AD_manuscript_update.txt';
end
