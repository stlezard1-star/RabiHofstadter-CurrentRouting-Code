function [params, opts, scanSpec] = RabiH_Stage4L_DefaultPrelimScan()
%RABIH_STAGE4L_DEFAULTPRELIMSCAN Defaults for preliminary article scans.
%
% StageRH4L is not a new CTM backend.  It uses the StageRH4J
% splitFactoredShared backend and runs a parameter scan with multiple
% coherent seeds.  The best seed is selected by the lowest measured energy
% within each physical parameter group.
%
% The default grid is intentionally moderate.  Use the demo wrappers for a
% smaller first run, then enlarge scanSpec for production figures.

[params, opts, scanSpec] = RabiH_Stage4K_DefaultConvergence();

params.dph = 4;
params.gR = 0.30;
params.t = 0.06;
params.tX = params.t;
params.tY = params.t;
params.Phi = pi;
params.alphaSeed = 0.10;
params.alphaPattern = 'vortex2x2';
params.spinSeed = 'down';

opts.Dmax = 2;
opts.chiMax = 6;
opts.maxIter = 4;
opts.sharedMaxIter = 4;
opts.tauList = [0.03 0.015];
opts.nSweeps = 1;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.sharedBoundaryMix = 0.0;
opts.outputDir = fullfile(pwd,'results_stage4L_prelim_scan');
opts.saveEachPoint = true;

scanSpec.name = 'StageRH4L_preliminary_article_scan';
scanSpec.description = ['Preliminary Rabi-Hofstadter article scan using the ' ...
    'StageRH4J shared/cached split CTM backend.  The scan keeps multiple ' ...
    'coherent seed patterns and selects the best seed by lowest energy for ' ...
    'each physical parameter point.'];
scanSpec.backend = 'splitFactoredShared';
scanSpec.DmaxList = 2;
scanSpec.chiMaxList = 6;
scanSpec.dphList = 4;
scanSpec.alphaSeedList = [0.00 0.05 0.10 0.20];
scanSpec.alphaPatternList = {'uniform','checkerboard','vortex2x2','landau'};
scanSpec.sharedBoundaryMixList = 0.0;
scanSpec.gRList = [0.15 0.30 0.45 0.60];
scanSpec.tList = [0.04 0.08];
scanSpec.PhiList = [0 pi/2 pi];
scanSpec.groupByFields = {'dph','Dmax','chiMax','sharedBoundaryMix','gR','t','Phi'};
scanSpec.bestSeedCriterion = 'minEnergy';
scanSpec.phaseThresholds = struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5);
scanSpec.maxPoints = Inf;
scanSpec.stopOnError = false;
scanSpec.tag = datestr(now,'yyyymmdd_HHMMSS');
end
