function [unitCell, info] = RabiH_RunNNNMeanFieldSU_Schedule(unitCell, params, opts)
%RABIH_RUNNNNMEANFIELDSU_SCHEDULE NN simple update plus NNN mean-field source.
%
%   This StageRH4X update keeps the robust NN two-site simple-update kernel
%   and incorporates diagonal NNN hopping through a site-dependent coherent
%   mean-field source computed from the seed/current alpha pattern.  It is a
%   low-cost intermediate step before a true plaquette/long-range NNN PEPS
%   update.
%
%   New opts/params fields:
%       useNNNMeanFieldUpdate  default true
%       nnnMFAlphaCell         optional Ly-by-Lx complex alpha cell
%       nnnMFUseSeedAlpha      default true

    if nargin < 3 || isempty(opts), opts = struct(); end
    tauList = RabiH_GetOpt(opts,'tauList',RabiH_GetOpt(params,'tauList',[0.04 0.02 0.01]));
    nSweeps = RabiH_GetOpt(opts,'nSweeps',1);
    Dmax = RabiH_GetOpt(opts,'Dmax',unitCell.D);
    cacheGates = RabiH_GetOpt(opts,'cacheGates',true);
    checkAfter = RabiH_GetOpt(opts,'checkAfter',true);

    Lx = unitCell.Lx; Ly = unitCell.Ly;
    alphaCell = RabiH_GetOpt(opts,'nnnMFAlphaCell',[]);
    if isempty(alphaCell)
        alphaCell = RabiH_GetOpt(params,'nnnMFAlphaCell',[]);
    end
    if isempty(alphaCell)
        if isfield(unitCell,'alphaSeed') && RabiH_GetOpt(opts,'nnnMFUseSeedAlpha',true)
            alphaCell = unitCell.alphaSeed;
        else
            alpha0 = RabiH_GetOpt(opts,'alpha',RabiH_GetOpt(params,'alphaSeed',0));
            pat = RabiH_GetOpt(opts,'alphaPattern',RabiH_GetOpt(params,'alphaPattern','uniform'));
            alphaCell = RabiH_AlphaPattern(Lx,Ly,pat,alpha0,params);
        end
    end
    [etaCell, mfInfo] = RabiH_NNNMeanFieldSourceCell(params,Lx,Ly,alphaCell);

    info = struct();
    info.tauList = tauList; info.nSweeps = nSweeps; info.Dmax = Dmax;
    info.alphaCell = alphaCell; info.etaCell = etaCell; info.meanFieldInfo = mfInfo;
    info.relDiscardedWeight = []; info.keep = [];
    info.step = struct('tau',{},'sweep',{},'meanDiscarded',{},'maxKeep',{});
    info.note = 'StageRH4X NN simple update with NNN mean-field local source.';

    gateCaches = cell(1,numel(tauList));
    if cacheGates
        for kt = 1:numel(tauList)
            gateCaches{kt} = RabiH_PrecomputeNNGates(params,tauList(kt),Lx,Ly);
        end
    end

    stepPtr = 0;
    for kt = 1:numel(tauList)
        tau = tauList(kt);
        if cacheGates
            gates = gateCaches{kt};
        else
            gates = RabiH_PrecomputeNNGates(params,tau,Lx,Ly);
        end
        for sw = 1:nSweeps
            unitCell = RabiH_ApplyLocalGateCell_WithEta(unitCell, params, tau/2, etaCell);
            bcnt = 0; dw = zeros(1,2*Lx*Ly); kp = zeros(1,2*Lx*Ly);
            for y = 1:Ly
                for x = 1:Lx
                    xp = mod(x,Lx)+1;
                    [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x},unitCell.A{y,xp},'right',gates.Gx{y,x},Dmax,opts);
                    unitCell.A{y,x}=Anew; unitCell.A{y,xp}=Bnew;
                    bcnt=bcnt+1; dw(bcnt)=local_getfield(sinfo,'relDiscardedWeight',NaN); kp(bcnt)=local_getfield(sinfo,'keep',NaN);
                end
            end
            for y = 1:Ly
                yp = mod(y,Ly)+1;
                for x = 1:Lx
                    [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x},unitCell.A{yp,x},'down',gates.Gy{y,x},Dmax,opts);
                    unitCell.A{y,x}=Anew; unitCell.A{yp,x}=Bnew;
                    bcnt=bcnt+1; dw(bcnt)=local_getfield(sinfo,'relDiscardedWeight',NaN); kp(bcnt)=local_getfield(sinfo,'keep',NaN);
                end
            end
            unitCell = RabiH_ApplyLocalGateCell_WithEta(unitCell, params, tau/2, etaCell);
            unitCell = iPEPS_NormalizeUnitCell(unitCell);
            info.relDiscardedWeight = [info.relDiscardedWeight; dw]; %#ok<AGROW>
            info.keep = [info.keep; kp]; %#ok<AGROW>
            stepPtr = stepPtr+1;
            info.step(stepPtr).tau = tau;
            info.step(stepPtr).sweep = sw;
            info.step(stepPtr).meanDiscarded = mean(dw(isfinite(dw)));
            info.step(stepPtr).maxKeep = max(kp(isfinite(kp)));
        end
    end
    unitCell.stage = 'RabiH_StageRH4X_NNN_mean_field_SU_schedule';
    unitCell.D = local_maxD(unitCell);
    unitCell.nnnMFAlphaCell = alphaCell;
    unitCell.nnnMFSourceEta = etaCell;
    if checkAfter, iPEPS_CheckUnitCell(unitCell); end
end

function val = local_getfield(s, name, defaultVal)
    if isstruct(s) && isfield(s,name) && ~isempty(s.(name)), val=s.(name); else, val=defaultVal; end
end
function D = local_maxD(unitCell)
    D = 1;
    for y=1:unitCell.Ly
        for x=1:unitCell.Lx
            sz = PEPS_FullSize(unitCell.A{y,x},5);
            D = max(D,max(sz(2:5)));
        end
    end
end
