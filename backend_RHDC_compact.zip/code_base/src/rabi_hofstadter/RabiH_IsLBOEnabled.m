function tf = RabiH_IsLBOEnabled(params)
%RABIH_ISLBOENABLED True when projected photon/LBO operators should be used.
if nargin < 1 || isempty(params)
    tf = false;
    return;
end
tf = isstruct(params) && isfield(params,'useLBO') && ~isempty(params.useLBO) && logical(params.useLBO);
end
