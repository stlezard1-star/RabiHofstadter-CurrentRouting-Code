function obs = RabiH_CTMObservables_SplitFactored(unitCell, params, opts)
%RABIH_CTMOBSERVABLES_SPLITFACTORED Split/factored observable interface.
%
% StageRH4F currently supports product cells and guarded exact-small-cell
% benchmarks.  For D>1 production data, the future split/factored CTMRG
% absorption/truncation kernel is still required.

    if nargin < 3 || isempty(opts), opts = struct(); end

    mode = lower(RabiH_GetOpt(opts,'splitBackendMode',RabiH_GetOpt(opts,'factoredBackendMode','auto')));
    ctmBackend = lower(RabiH_GetOpt(opts,'ctmBackend',''));
    isProduct = local_is_product_unitcell_split(unitCell);
    useProduction = any(strcmp(mode,{'production','ctm','ctmrg','splitctm','splitctmrg'})) || ...
                    any(strcmp(ctmBackend,{'splitfactored','splitfactoredctm','splitctm','splitmultisite'}));
    if useProduction
        obs = RabiH_CTMObservables_SplitFactoredProduction(unitCell, params, opts);
        return;
    end

    useExact = isProduct || ...
               RabiH_GetOpt(opts,'enableSplitExactTorus',false) || ...
               RabiH_GetOpt(opts,'enableFactoredExactTorus',false) || ...
               any(strcmp(mode,{'exact','exactsmallcell','exacttorus','smallcell'})) || ...
               any(strcmp(ctmBackend,{'splitfactoredexact','splitexact','factoredexact','exacttorus'}));

    ctxOpts = opts;
    if useExact
        ctxOpts.enableSplitExactTorus = true;
        ctxOpts.splitBackendMode = 'exactSmallCell';
    end
    ctx = RabiH_CTMRunSplitFactored(unitCell, ctxOpts);

    if useExact
        exactOpts = opts;
        exactOpts.Lx = RabiH_GetOpt(opts,'exactLx',RabiH_GetOpt(opts,'Lx',unitCell.Lx));
        exactOpts.Ly = RabiH_GetOpt(opts,'exactLy',RabiH_GetOpt(opts,'Ly',unitCell.Ly));
        obs = RabiH_ExactObservables_Torus(unitCell, params, exactOpts);
        obs.ctx = ctx;
        obs.backend = 'split_factored_exact_torus';
        if isProduct
            obs.backend = 'split_factored_product_exact';
        end
        obs.description = ['StageRH4F split/factored observable interface using ' ...
                           'guarded exact finite-torus contraction.  No blocked tensor is allocated.'];
        return;
    end

    error('RabiH_CTMObservables_SplitFactored:ProductionNotImplemented', ...
        ['Split/factored observables for D>1 require either ' ...
         'opts.enableSplitExactTorus=true for a small-cell benchmark, or the ' ...
         'future production split/factored CTMRG absorption backend.']);
end

function tf = local_is_product_unitcell_split(unitCell)
    tf = true;
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            sz = PEPS_FullSize(unitCell.A{y,x},5);
            if any(sz(2:5) ~= 1)
                tf = false;
                return;
            end
        end
    end
end
