function summary = RabiH_SummarizeSuperradianceStressScan(best)
%RABIH_SUMMARIZESUPERRADIANCESTRESSSCAN Summarize StageRH4M best records.

if isfield(best,'records')
    records = best.records;
else
    records = best;
end
summary = struct();
summary.numBestRecords = numel(records);
if isempty(records)
    summary.numNonzeroAlphaBest = 0;
    summary.numSRBest = 0;
    summary.maxRhoSR = NaN;
    summary.maxAbsCurrent = NaN;
    summary.maxAbsChirality = NaN;
    summary.maxCurrentDivergence = NaN;
    summary.bestAlphaList = [];
    summary.phaseLabels = {};
    return;
end
alpha = arrayfun(@(r) local_field(r,'alphaSeed',NaN), records);
rho = arrayfun(@(r) local_field(r,'superradiantDensity',NaN), records);
cur = arrayfun(@(r) local_field(r,'meanAbsCurrent',NaN), records);
chi = arrayfun(@(r) local_field(r,'meanAbsChirality',NaN), records);
div = arrayfun(@(r) local_field(r,'maxCurrentDivergence',NaN), records);
labels = cell(1,numel(records));
for k = 1:numel(records)
    labels{k} = local_field(records(k),'phaseLabel','');
end
summary.numNonzeroAlphaBest = sum(abs(alpha) > 1e-12);
summary.nonzeroAlphaFraction = summary.numNonzeroAlphaBest / max(1,numel(records));
summary.numSRBest = sum(rho > 1e-4);
summary.SRFraction = summary.numSRBest / max(1,numel(records));
summary.maxRhoSR = max(rho);
summary.minRhoSR = min(rho);
summary.maxAbsCurrent = max(abs(cur));
summary.maxAbsChirality = max(abs(chi));
summary.maxCurrentDivergence = max(abs(div));
summary.bestAlphaList = unique(alpha,'stable');
summary.phaseLabels = unique(labels,'stable');

% crude warning flags for diagnosis
summary.allBestAlphaZero = (summary.numNonzeroAlphaBest == 0);
summary.noVisibleSR = (summary.numSRBest == 0);
end

function v = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end
