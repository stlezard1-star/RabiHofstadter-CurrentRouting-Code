function spec = RabiH_BondSpec(x, y, direction, params, Lx, Ly)
%RABIH_BONDSPEC Target site, Peierls phase, and hopping amplitude for a bond.
%   Supports NN directions right/down and NNN directions diagp/diagm.

    if nargin < 4 || isempty(params), params = struct(); end
    if nargin < 5 || isempty(Lx), Lx = RabiH_GetOpt(params,'Lx',2); end
    if nargin < 6 || isempty(Ly), Ly = RabiH_GetOpt(params,'Ly',2); end
    wrapx = @(z) mod(z-1,Lx)+1;
    wrapy = @(z) mod(z-1,Ly)+1;
    dir = lower(direction);
    spec = struct();
    spec.x1 = x; spec.y1 = y; spec.direction = dir;
    switch dir
        case {'right','x','horizontal'}
            spec.x2 = wrapx(x+1); spec.y2 = y;
            spec.phase = RabiH_GaugePhase(x,y,'right',params);
            spec.tval = RabiH_GetNNHopping(params,'right');
            spec.kind = 'NN';
        case {'down','y','vertical'}
            spec.x2 = x; spec.y2 = wrapy(y+1);
            spec.phase = RabiH_GaugePhase(x,y,'down',params);
            spec.tval = RabiH_GetNNHopping(params,'down');
            spec.kind = 'NN';
        case {'diagp','diagplus','13'}
            spec.x2 = wrapx(x+1); spec.y2 = wrapy(y+1);
            spec.phase = RabiH_NNNPhase(x,y,'diagp',params);
            spec.tval = RabiH_GetNNNHopping(params);
            spec.kind = 'NNN';
        case {'diagm','diagminus','24'}
            spec.x2 = wrapx(x+1); spec.y2 = wrapy(y-1);
            spec.phase = RabiH_NNNPhase(x,y,'diagm',params);
            spec.tval = RabiH_GetNNNHopping(params);
            spec.kind = 'NNN';
        otherwise
            error('RabiH_BondSpec:UnknownDirection','Unknown bond direction: %s.', direction);
    end
end
