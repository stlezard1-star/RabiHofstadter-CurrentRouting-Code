function reps = RabiH_Stage4N_RepresentativePoints()
%RABIH_STAGE4N_REPRESENTATIVEPOINTS Representative branches from StageRH4M.
%
% These points are based on the first visible SR/chiralSR stress scan:
%   normal        : gR=0.6, t=0.08, Phi=0,    alpha=0
%   flux-normal   : gR=0.6, t=0.16, Phi=pi/2, alpha=0
%   SR            : gR=1.0, t=0.08, Phi=0,    alpha=0.8
%   chiralSR      : gR=1.0, t=0.08, Phi=pi/2, alpha=0.8
%   strong chiral : gR=1.4, t=0.16, Phi=pi/2, alpha=0.8
%
% The labels are diagnostic labels, not final phase assignments.

reps = repmat(local_empty_rep(),1,5);
reps(1) = local_rep('normal_weak',       'normal',   0.60, 0.08, 0,    0.00, 'uniform');
reps(2) = local_rep('normal_flux_edge',  'normal',   0.60, 0.16, pi/2, 0.00, 'uniform');
reps(3) = local_rep('sr_uniform',        'SR',       1.00, 0.08, 0,    0.80, 'uniform');
reps(4) = local_rep('chiral_midflux',    'chiralSR', 1.00, 0.08, pi/2, 0.80, 'uniform');
reps(5) = local_rep('chiral_stronghop',  'chiralSR', 1.40, 0.16, pi/2, 0.80, 'uniform');
end

function r = local_rep(name,target,gR,t,Phi,alpha,pattern)
r = local_empty_rep();
r.name = name;
r.targetPhase = target;
r.gR = gR;
r.t = t;
r.Phi = Phi;
r.alphaSeed = alpha;
r.alphaPattern = pattern;
end

function r = local_empty_rep()
r = struct('name','','targetPhase','','gR',NaN,'t',NaN,'Phi',NaN, ...
    'alphaSeed',NaN,'alphaPattern','uniform');
end
