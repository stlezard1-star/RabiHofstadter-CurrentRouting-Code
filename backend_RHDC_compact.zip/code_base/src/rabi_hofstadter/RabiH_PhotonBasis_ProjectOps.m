function phEff = RabiH_PhotonBasis_ProjectOps(basis)
%RABIH_PHOTONBASIS_PROJECTOPS Project photon operators into LBO basis.

W = basis.W;
dFull = size(W,1);
dEff = size(W,2);
ph = RabiH_PhotonOps(dFull);
phEff = struct();
phEff.type = 'projected_photon_ops';
phEff.dFull = dFull;
phEff.dEff = dEff;
phEff.W = W;
phEff.I = eye(dEff);
phEff.a = W' * ph.a * W;
phEff.adag = W' * ph.adag * W;
phEff.N = W' * ph.N * W;
phEff.Q = W' * ph.Q * W;
phEff.projectorError = norm(W'*W-eye(dEff),'fro');
phEff.commutatorError = norm(phEff.a*phEff.adag - phEff.adag*phEff.a - eye(dEff),'fro');
phEff.full = ph;
end
