function summary = RabiH_SummarizeArticleMap(records, spec)
%RABIH_SUMMARIZEARTICLEMAP Summarize StageRH4O best-seed map records.

if nargin < 1 || isempty(records), records = []; end
if nargin < 2 || isempty(spec), spec = struct(); end
summary = struct();
summary.numRecords = numel(records);
summary.numOK = 0;
summary.phaseCounts = struct('normal',0,'SR',0,'currentSR',0,'chiralSR',0,'error',0,'other',0);
summary.phaseLabels = {};
summary.energyRange = [NaN NaN];
summary.rhoSRRange = [NaN NaN];
summary.maxAbsCurrent = NaN;
summary.maxAbsChirality = NaN;
summary.maxCurrentDivergence = NaN;
summary.maxChiralityDefinitionError = NaN;
summary.bestChiralRecord = struct();
summary.bestCurrentRecord = struct();
summary.chiralRecords = [];
summary.perT = [];
summary.warnings = {};

if isempty(records)
    summary.warnings = {'empty records'};
    return;
end

statusOK = arrayfun(@(r) isfield(r,'status') && strcmpi(r.status,'ok'), records);
okRecords = records(statusOK);
summary.numOK = numel(okRecords);
if isempty(okRecords)
    summary.warnings = {'no ok records'};
    return;
end

labels = cell(1,numel(okRecords));
for k = 1:numel(okRecords)
    if isfield(okRecords(k),'phaseLabel') && ~isempty(okRecords(k).phaseLabel)
        labels{k} = okRecords(k).phaseLabel;
    else
        labels{k} = RabiH_ClassifyPhaseFromRecord(okRecords(k), local_get(spec,'phaseThresholds',struct()));
    end
    switch labels{k}
        case 'normal'
            summary.phaseCounts.normal = summary.phaseCounts.normal + 1;
        case 'SR'
            summary.phaseCounts.SR = summary.phaseCounts.SR + 1;
        case 'currentSR'
            summary.phaseCounts.currentSR = summary.phaseCounts.currentSR + 1;
        case 'chiralSR'
            summary.phaseCounts.chiralSR = summary.phaseCounts.chiralSR + 1;
        case 'error'
            summary.phaseCounts.error = summary.phaseCounts.error + 1;
        otherwise
            summary.phaseCounts.other = summary.phaseCounts.other + 1;
    end
end
summary.phaseLabels = unique(labels,'stable');

E = arrayfun(@(r) local_field(r,'energyPerSite',NaN), okRecords);
rho = arrayfun(@(r) local_field(r,'superradiantDensity',NaN), okRecords);
cur = arrayfun(@(r) local_field(r,'meanAbsCurrent',NaN), okRecords);
chi = arrayfun(@(r) local_field(r,'meanAbsChirality',NaN), okRecords);
divJ = arrayfun(@(r) local_field(r,'maxCurrentDivergence',NaN), okRecords);
chiErr = arrayfun(@(r) local_field(r,'maxChiralityDefinitionError',NaN), okRecords);
summary.energyRange = [min(E) max(E)];
summary.rhoSRRange = [min(rho) max(rho)];
summary.maxAbsCurrent = max(abs(cur));
summary.maxAbsChirality = max(abs(chi));
summary.maxCurrentDivergence = max(abs(divJ));
summary.maxChiralityDefinitionError = max(abs(chiErr));

[~,iChi] = max(abs(chi));
[~,iCur] = max(abs(cur));
summary.bestChiralRecord = okRecords(iChi);
summary.bestCurrentRecord = okRecords(iCur);

chiralMask = strcmp(labels,'chiralSR');
summary.chiralRecords = okRecords(chiralMask);

% Per-t summary for map captions and quick inspection.
tVals = unique(arrayfun(@(r) local_field(r,'t',NaN), okRecords));
perT = repmat(local_empty_tsummary(),1,0);
for it = 1:numel(tVals)
    tv = tVals(it);
    mask = abs(arrayfun(@(r) local_field(r,'t',NaN), okRecords)-tv) < 1e-12;
    sub = okRecords(mask);
    lab = labels(mask);
    ts = local_empty_tsummary();
    ts.t = tv;
    ts.numRecords = numel(sub);
    ts.numNormal = sum(strcmp(lab,'normal'));
    ts.numSR = sum(strcmp(lab,'SR'));
    ts.numCurrentSR = sum(strcmp(lab,'currentSR'));
    ts.numChiralSR = sum(strcmp(lab,'chiralSR'));
    ts.maxRhoSR = max(arrayfun(@(r) local_field(r,'superradiantDensity',NaN), sub));
    ts.maxAbsCurrent = max(abs(arrayfun(@(r) local_field(r,'meanAbsCurrent',NaN), sub)));
    ts.maxAbsChirality = max(abs(arrayfun(@(r) local_field(r,'meanAbsChirality',NaN), sub)));
    perT(end+1) = ts; %#ok<AGROW>
end
summary.perT = perT;

if summary.phaseCounts.chiralSR == 0
    summary.warnings{end+1} = 'no chiralSR records in best-seed map';
end
if summary.phaseCounts.normal == 0
    summary.warnings{end+1} = 'no normal records in best-seed map; map may not contain transition boundary';
end
if summary.maxCurrentDivergence > local_get(spec,'currentDivergenceWarn',1e-3)
    summary.warnings{end+1} = sprintf('large current divergence %.3e', summary.maxCurrentDivergence);
end
end

function ts = local_empty_tsummary()
ts = struct('t',NaN,'numRecords',0,'numNormal',0,'numSR',0,'numCurrentSR',0, ...
    'numChiralSR',0,'maxRhoSR',NaN,'maxAbsCurrent',NaN,'maxAbsChirality',NaN);
end

function v = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
