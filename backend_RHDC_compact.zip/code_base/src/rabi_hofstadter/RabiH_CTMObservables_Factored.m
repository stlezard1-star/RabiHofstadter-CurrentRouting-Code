function obs = RabiH_CTMObservables_Factored(unitCell, params, opts)
%RABIH_CTMOBSERVABLES_FACTORED Factored-backend observable interface.
%
% StageRH4D:
%   D=1 product/coherent-product cells use exact finite-torus contraction as
%   a no-blocked reference path.  D>1 otherwise throws a clear error.
%
% StageRH4E:
%   Adds an explicit guarded exact-small-cell benchmark backend for D=2:
%       opts.enableFactoredExactTorus = true
%       opts.factoredBackendMode = 'exactSmallCell'
%   This backend deliberately avoids CTM_BlockUnitCell and is used to validate
%   the factored observable path before implementing the production multi-site
%   CTM absorption kernel.

    if nargin < 3 || isempty(opts), opts = struct(); end

    mode = lower(RabiH_GetOpt(opts,'factoredBackendMode','auto'));
    ctmBackend = lower(RabiH_GetOpt(opts,'ctmBackend',''));
    isProduct = local_is_product_unitcell(unitCell);
    useExact = isProduct || ...
               RabiH_GetOpt(opts,'enableFactoredExactTorus',false) || ...
               any(strcmp(mode,{'exact','exactsmallcell','exacttorus','smallcell'})) || ...
               any(strcmp(ctmBackend,{'factoredexact','exactfactored','exacttorus'}));

    ctxOpts = opts;
    if useExact
        ctxOpts.enableFactoredExactTorus = true;
        ctxOpts.factoredBackendMode = 'exactSmallCell';
    end
    ctx = RabiH_CTMRunFactored(unitCell, ctxOpts);

    if useExact
        exactOpts = opts;
        exactOpts.Lx = RabiH_GetOpt(opts,'exactLx',RabiH_GetOpt(opts,'Lx',unitCell.Lx));
        exactOpts.Ly = RabiH_GetOpt(opts,'exactLy',RabiH_GetOpt(opts,'Ly',unitCell.Ly));
        obs = RabiH_ExactObservables_Torus(unitCell, params, exactOpts);
        obs.ctx = ctx;
        obs.backend = 'factored_exact_torus';
        if isProduct
            obs.backend = 'factored_product_exact';
        end
        obs.description = ['StageRH4E factored observable interface using guarded exact ' ...
                           'finite-torus contraction. No blocked tensor is allocated.'];
        return;
    end

    error('RabiH_CTMObservables_Factored:ProductionNotImplemented', ...
        ['Factored observables for D>1 require either opts.enableFactoredExactTorus=true ' ...
         'for a small-cell benchmark, or the future genuine multi-site/factored CTM ' ...
         'absorption backend for production data.']);
end

function tf = local_is_product_unitcell(unitCell)
    tf = true;
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            sz = PEPS_FullSize(unitCell.A{y,x},5);
            if any(sz(2:5) ~= 1)
                tf = false;
                return;
            end
        end
    end
end
