function points = RabiH_ExpandBranchStabilitySpec(spec, optsBase, paramsBase)
%RABIH_EXPANDBRANCHSTABILITYSPEC Expand StageRH4N representative scan.

if nargin < 1 || isempty(spec), spec = struct(); end
if nargin < 2 || isempty(optsBase), optsBase = struct(); end
if nargin < 3 || isempty(paramsBase), paramsBase = struct(); end

reps = local_get(spec,'representativePoints',RabiH_Stage4N_RepresentativePoints());
DmaxList = local_get(spec,'DmaxList',RabiH_GetOpt(optsBase,'Dmax',2));
chiMaxList = local_get(spec,'chiMaxList',RabiH_GetOpt(optsBase,'chiMax',6));
dphList = local_get(spec,'dphList',RabiH_GetOpt(paramsBase,'dph',5));
sharedBoundaryMixList = local_get(spec,'sharedBoundaryMixList',RabiH_GetOpt(optsBase,'sharedBoundaryMix',0));
sourceEtaList = local_get(spec,'sourceEtaList',RabiH_GetOpt(paramsBase,'sourceEta',0));
sourcePhaseList = local_get(spec,'sourcePhaseList',RabiH_GetOpt(paramsBase,'sourcePhase',0));
maxRecords = local_get(spec,'maxRecords',Inf);

points = repmat(local_empty_point(),1,0);
idx = 0;
for ir = 1:numel(reps)
for idph = 1:numel(dphList)
for iD = 1:numel(DmaxList)
for ichi = 1:numel(chiMaxList)
for imix = 1:numel(sharedBoundaryMixList)
for isrc = 1:numel(sourceEtaList)
for iphsrc = 1:numel(sourcePhaseList)
    if idx >= maxRecords
        return;
    end
    idx = idx + 1;
    p = local_empty_point();
    p.index = idx;
    p.branchName = reps(ir).name;
    p.targetPhase = reps(ir).targetPhase;
    p.gR = reps(ir).gR;
    p.t = reps(ir).t;
    p.Phi = reps(ir).Phi;
    p.alphaSeed = reps(ir).alphaSeed;
    p.alphaPattern = reps(ir).alphaPattern;
    p.dph = dphList(idph);
    p.Dmax = DmaxList(iD);
    p.chiMax = chiMaxList(ichi);
    p.sharedBoundaryMix = sharedBoundaryMixList(imix);
    p.sourceEta = sourceEtaList(isrc);
    p.sourcePhase = sourcePhaseList(iphsrc);
    p.label = sprintf('n%04d_%s_dph%d_D%d_chi%d_mix%.3g_src%.3g', ...
        p.index, p.branchName, p.dph, p.Dmax, p.chiMax, ...
        p.sharedBoundaryMix, abs(p.sourceEta));
    points(end+1) = p; %#ok<AGROW>
end
end
end
end
end
end
end
end

function p = local_empty_point()
p = struct();
p.index = NaN;
p.label = '';
p.branchName = '';
p.targetPhase = '';
p.dph = NaN;
p.Dmax = NaN;
p.chiMax = NaN;
p.sharedBoundaryMix = NaN;
p.gR = NaN;
p.t = NaN;
p.Phi = NaN;
p.alphaSeed = NaN;
p.alphaPattern = '';
p.sourceEta = 0;
p.sourcePhase = 0;
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
