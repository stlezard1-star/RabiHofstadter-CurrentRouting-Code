function ops = RabiH_SiteOps(dph)
%RABIH_SITEOPS Spin-1/2 plus truncated photon-mode site operators.
%
%   Site physical basis convention:
%       p = s + 2*n,  s=1,2 and n=0,...,dph-1.
%   Equivalently, local Hilbert space is photon \otimes spin, so spin is
%   the fastest index. This convention is compatible with dense PEPS site
%   physical leg p=1,...,2*dph.

    ph = RabiH_PhotonOps(dph);

    sx = [0 1; 1 0];
    sy = [0 -1i; 1i 0];
    sz = [1 0; 0 -1];
    sp = [0 1; 0 0];
    sm = [0 0; 1 0];
    Is = eye(2);

    ops = struct();
    ops.dph = dph;
    ops.d = 2*dph;
    ops.I = eye(2*dph);

    % photon operators act as photon op \otimes spin identity
    ops.a = kron(ph.a, Is);
    ops.adag = kron(ph.adag, Is);
    ops.N = kron(ph.N, Is);
    ops.Q = kron(ph.Q, Is);

    % spin operators act as photon identity \otimes spin op
    ops.sx = kron(ph.I, sx);
    ops.sy = kron(ph.I, sy);
    ops.sz = kron(ph.I, sz);
    ops.sp = kron(ph.I, sp);
    ops.sm = kron(ph.I, sm);
    ops.Is = kron(ph.I, Is);

    ops.photon = ph;
    ops.spin.sx = sx;
    ops.spin.sy = sy;
    ops.spin.sz = sz;
    ops.spin.sp = sp;
    ops.spin.sm = sm;
    ops.spin.I = Is;
end
