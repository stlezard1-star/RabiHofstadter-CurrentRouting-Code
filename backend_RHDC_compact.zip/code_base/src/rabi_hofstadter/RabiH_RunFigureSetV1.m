function figSet = RabiH_RunFigureSetV1(articleMapOrFile, opts, spec)
%RABIH_RUNFIGURESETV1 Build StageRH4P figure-set v1.
%
% Usage:
%   figSet = RabiH_RunFigureSetV1();
%   figSet = RabiH_RunFigureSetV1(articleMap);
%   figSet = RabiH_RunFigureSetV1('/path/to/stage4O_article_map.mat');

if nargin < 2 || isempty(opts), opts = struct(); end
if nargin < 3 || isempty(spec)
    [~, defaultOpts, spec] = RabiH_Stage4P_DefaultFigureSet();
    opts = local_merge(defaultOpts, opts);
end
outDir = local_get(opts,'outputDir',local_get(spec,'outputDir',fullfile(pwd,'results_stage4P_figure_set_v1')));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end

if nargin < 1 || isempty(articleMapOrFile)
    articleMap = local_load_or_run_stage4O(spec);
elseif ischar(articleMapOrFile)
    S = load(articleMapOrFile);
    if isfield(S,'articleMap'), articleMap = S.articleMap; else, error('RabiH_RunFigureSetV1:BadMat','MAT file lacks articleMap.'); end
elseif isstruct(articleMapOrFile)
    articleMap = articleMapOrFile;
else
    error('RabiH_RunFigureSetV1:BadInput','Unsupported articleMap input.');
end

figSet = RabiH_ExtractFigureSetTables(articleMap, spec);
figSet.outputDir = outDir;
figSet.stage = 'StageRH4P';
figSet.articleMap = articleMap;

if local_get(spec,'writeCSVs',true)
    figSet.csvPaths = RabiH_WriteFigureSetCSVs(figSet, outDir);
else
    figSet.csvPaths = struct();
end
if local_get(spec,'makePlots',true)
    figSet.figurePaths = RabiH_PlotFigureSetV1(figSet, outDir, spec);
else
    figSet.figurePaths = struct();
end

save(fullfile(outDir,'stage4P_figure_set_v1.mat'),'figSet');
end

function articleMap = local_load_or_run_stage4O(spec)
matFile = local_get(spec,'stage4OMatFile','');
if local_get(spec,'reuseStage4OIfAvailable',true) && ~isempty(matFile) && exist(matFile,'file') == 2
    S = load(matFile);
    if isfield(S,'articleMap')
        articleMap = S.articleMap;
        return;
    end
end
% Fall back to a fresh Stage4O scan.  This can be moderately expensive but
% keeps the figure pipeline reproducible from a clean checkout.
articleMap = run_rabih_stage4O_article_map_demo();
end

function A = local_merge(A,B)
if ~isstruct(B), return; end
names = fieldnames(B);
for k = 1:numel(names), A.(names{k}) = B.(names{k}); end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), val = S.(name); else, val = defaultVal; end
end
