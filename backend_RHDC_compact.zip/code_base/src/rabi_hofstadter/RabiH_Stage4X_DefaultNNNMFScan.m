function [params, opts, spec] = RabiH_Stage4X_DefaultNNNMFScan()
%RABIH_STAGE4X_DEFAULTNNNMFSCAN Default NNN-aware mean-field scan.
    params = RabiH_DefaultArticleParams();
    params.dph = 5;
    params.omega = 1; params.Delta = 1;
    params.Phi = pi/2;
    params.includeNNN = true;
    params.nnnPhaseMode = 'lineIntegral';
    params.thetaTri = 0;

    opts = struct();
    opts.Lx = 2; opts.Ly = 2;
    opts.Dmax = 2; opts.chiMax = 6;
    opts.ctmBackend = 'splitFactoredExact';
    opts.enableSplitExactTorus = true;
    opts.splitBackendMode = 'exactSmallCell';
    opts.exactLx = 2; opts.exactLy = 2;
    opts.cacheGates = true;
    opts.tauList = [0.05 0.025 0.0125];
    opts.nSweeps = 2;
    opts.useNNNMeanFieldUpdate = true;
    opts.outputDir = fullfile(pwd,'results_stage4X_nnnmf_current_pattern_demo');

    spec = struct();
    spec.gList = [1.0 1.4];
    spec.J1List = [0.08 0.16];
    spec.lambdaList = [0 0.2 0.4 0.6];
    spec.PhiList = pi/2;
    spec.thetaTriList = 0;
    spec.alphaSeedList = [0.4 0.8];
    spec.alphaPatternList = {'uniform','vortex2x2'};
    spec.dphList = params.dph;
    spec.DmaxList = opts.Dmax;
    spec.chiMaxList = opts.chiMax;
    spec.backend = 'splitFactoredExact';
    spec.stopOnError = false;
end
