function scan = RabiH_SC_RunScan(paramsBase, opts, scanSpec)
%RabiH_SC_RunScan  Run a grid of semiclassical minimizations.
if nargin < 1 || isempty(paramsBase), paramsBase = RabiH_SC_DefaultParams(); end
if nargin < 2 || isempty(opts), opts = struct(); end
if nargin < 3 || isempty(scanSpec), scanSpec = struct(); end

points = local_expand_points(paramsBase, scanSpec);
recTemplate = local_record_template();
records = repmat(recTemplate, 1, numel(points));

t0 = tic;
for k = 1:numel(points)
    p = points(k);
    rec = recTemplate;
    rec.index = k;
    rec.g = p.g;
    rec.J1 = p.J1;
    rec.lambda = p.lambda;
    rec.J2 = p.J2;
    rec.PhiSquare = p.PhiSquare;
    rec.thetaTri = p.thetaTri;
    rec.scanKind = p.scanKind;
    try
        params = paramsBase;
        params.g = p.g;
        params.J1 = p.J1;
        params.lambda = p.lambda;
        params.J2 = p.J2;
        params.PhiSquare = p.PhiSquare;
        params.thetaTri = p.thetaTri;
        tk = tic;
        r = RabiH_SC_MinimizeOnePoint(params, opts);
        rec.runtimeSeconds = toc(tk);
        rec.status = 'ok';
        rec.message = '';
        rec.energyPerSite = r.energyPerSite;
        rec.rhoSR = r.obs.rhoSR;
        rec.meanPhotonNumber = r.obs.meanPhotonNumber;
        rec.I12 = r.obs.I12; rec.I23 = r.obs.I23; rec.I34 = r.obs.I34; rec.I41 = r.obs.I41;
        rec.I13 = r.obs.I13; rec.I24 = r.obs.I24;
        rec.absINN = r.obs.meanAbsNNCurrent;
        rec.absIDiag = r.obs.meanAbsDiagCurrent;
        rec.chiSquare = r.obs.chiSquare;
        rec.absChiSquare = abs(r.obs.chiSquare);
        rec.chi123 = r.obs.chi123; rec.chi134 = r.obs.chi134;
        rec.chi124 = r.obs.chi124; rec.chi234 = r.obs.chi234;
        rec.meanAbsChiTri = r.obs.meanAbsTriangularChirality;
        rec.triangularImbalance = r.obs.triangularImbalance;
        rec.diagSelectionRatio = r.obs.diagSelectionRatio;
        rec.triRatio = r.obs.triRatio;
        rec.I13MinusI24 = r.obs.I13MinusI24;
        rec.chiTriSigned13 = r.obs.chiTriSigned13;
        rec.chiTriSigned24 = r.obs.chiTriSigned24;
        rec.maxCurrentDivergence = r.obs.maxCurrentDivergence;
        rec.maxTriangleIdentityErr = r.obs.maxTriangleIdentityErr;
        rec.patternLabel = r.obs.patternLabel;
        rec.patternCode = r.obs.patternCode;
    catch ME
        rec.status = 'error';
        rec.message = ME.message;
    end
    records(k) = rec;
end

scan = struct();
scan.records = records;
scan.points = points;
scan.paramsBase = paramsBase;
scan.scanSpec = scanSpec;
scan.opts = opts;
scan.runtimeSeconds = toc(t0);
scan.summary = RabiH_SC_SummarizeScan(scan);
end

function points = local_expand_points(paramsBase, scanSpec)
kind = 'all';
if isfield(scanSpec,'kind') && ~isempty(scanSpec.kind), kind = scanSpec.kind; end
pt = struct('g',[],'J1',[],'lambda',[],'J2',[],'PhiSquare',[],'thetaTri',[],'scanKind','');
rows = {};
if strcmpi(kind,'baseline') || strcmpi(kind,'all')
    if isfield(scanSpec,'baseline'), b = scanSpec.baseline; else, b = struct(); end
    gList = local_get(b,'gList',linspace(0.3,1.6,14));
    PhiList = local_get(b,'PhiList',linspace(0,pi,13));
    J1 = local_get(b,'J1',local_get(paramsBase,'J1',0.16));
    lam = local_get(b,'lambda',0.0);
    theta = local_get(b,'thetaTri',0.0);
    for g = gList(:).'
        for Phi = PhiList(:).'
            p = pt; p.g=g; p.J1=J1; p.lambda=lam; p.J2=[]; p.PhiSquare=Phi; p.thetaTri=theta; p.scanKind='baseline';
            rows{end+1,1}=p; %#ok<AGROW>
        end
    end
end
if strcmpi(kind,'nnn') || strcmpi(kind,'all')
    if isfield(scanSpec,'nnn'), n = scanSpec.nnn; else, n = struct(); end
    g = local_get(n,'g',local_get(paramsBase,'g',1.4));
    J1 = local_get(n,'J1',local_get(paramsBase,'J1',0.16));
    Phi = local_get(n,'PhiSquare',local_get(paramsBase,'PhiSquare',pi/2));
    lambdaList = local_get(n,'lambdaList',[-0.8 -0.4 0 0.4 0.8]);
    thetaList = local_get(n,'thetaTriList',[-pi/4 0 pi/4]);
    for lam = lambdaList(:).'
        for theta = thetaList(:).'
            p = pt; p.g=g; p.J1=J1; p.lambda=lam; p.J2=[]; p.PhiSquare=Phi; p.thetaTri=theta; p.scanKind='nnn';
            rows{end+1,1}=p; %#ok<AGROW>
        end
    end
end
points = repmat(pt,1,numel(rows));
for k=1:numel(rows), points(k)=rows{k}; end
end

function rec = local_record_template()
rec = struct('index',NaN,'scanKind','','status','','message','', ...
    'g',NaN,'J1',NaN,'lambda',NaN,'J2',NaN,'PhiSquare',NaN,'thetaTri',NaN, ...
    'energyPerSite',NaN,'rhoSR',NaN,'meanPhotonNumber',NaN, ...
    'I12',NaN,'I23',NaN,'I34',NaN,'I41',NaN,'I13',NaN,'I24',NaN, ...
    'absINN',NaN,'absIDiag',NaN,'chiSquare',NaN,'absChiSquare',NaN, ...
    'chi123',NaN,'chi134',NaN,'chi124',NaN,'chi234',NaN, ...
    'meanAbsChiTri',NaN,'triangularImbalance',NaN,'diagSelectionRatio',NaN, ...
    'triRatio',NaN,'I13MinusI24',NaN,'chiTriSigned13',NaN,'chiTriSigned24',NaN, ...
    'maxCurrentDivergence',NaN,'maxTriangleIdentityErr',NaN, ...
    'patternLabel','','patternCode',NaN,'runtimeSeconds',NaN);
end

function v = local_get(s, name, defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
