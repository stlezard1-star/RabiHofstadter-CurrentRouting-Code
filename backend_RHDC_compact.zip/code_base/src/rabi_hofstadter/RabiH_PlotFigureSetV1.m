function figPaths = RabiH_PlotFigureSetV1(figSet, outDir, spec)
%RABIH_PLOTFIGURESETV1 Create StageRH4P manuscript-inspection figures.
%
% MATLAB 2018 compatible.  Uses saveas/print and standard subplot.
if nargin < 2 || isempty(outDir), outDir = pwd; end
if nargin < 3 || isempty(spec), spec = struct(); end
if exist(outDir,'dir') ~= 7, mkdir(outDir); end

figPaths = struct();
figPaths.mapPanel = fullfile(outDir,'Fig2_stage4P_maps_v1.png');
figPaths.mapPanelFig = fullfile(outDir,'Fig2_stage4P_maps_v1.fig');
figPaths.fluxCuts = fullfile(outDir,'Fig3_stage4P_flux_cuts_v1.png');
figPaths.fluxCutsFig = fullfile(outDir,'Fig3_stage4P_flux_cuts_v1.fig');
figPaths.representatives = fullfile(outDir,'Fig4_stage4P_representatives_v1.png');
figPaths.representativesFig = fullfile(outDir,'Fig4_stage4P_representatives_v1.fig');

vis = local_get(spec,'plotVisible','off');
res = local_get(spec,'pngResolution',250);

local_plot_maps(figSet.map.records, figPaths, vis, res, spec);
local_plot_flux_cuts(figSet.fluxCuts.records, figPaths, vis, res);
local_plot_representatives(figSet.representatives.records, figPaths, vis, res);
end

function local_plot_maps(records, paths, vis, res, spec)
tVals = local_get(spec,'figureTList',unique(local_arr(records,'t')));
if numel(tVals) > 3, tVals = tVals(1:3); end
fig = figure('Visible',vis,'Position',[100 100 1200 900]);
plotIndex = 1;
for it = 1:numel(tVals)
    tsel = local_nearest(unique(local_arr(records,'t')), tVals(it));
    sub = records(abs(local_arr(records,'t')-tsel)<1e-12);
    [gVals,phiVals,rhoZ,jZ,chiZ] = local_grid(sub);
    subplot(numel(tVals),3,plotIndex); plotIndex = plotIndex + 1;
    imagesc(phiVals/pi,gVals,rhoZ); set(gca,'YDir','normal');
    xlabel('\Phi/\pi'); ylabel('g_R'); title(sprintf('\rho_{SR}, t=%.3g',tsel)); colorbar;
    subplot(numel(tVals),3,plotIndex); plotIndex = plotIndex + 1;
    imagesc(phiVals/pi,gVals,jZ); set(gca,'YDir','normal');
    xlabel('\Phi/\pi'); ylabel('g_R'); title(sprintf('|J|, t=%.3g',tsel)); colorbar;
    subplot(numel(tVals),3,plotIndex); plotIndex = plotIndex + 1;
    imagesc(phiVals/pi,gVals,chiZ); set(gca,'YDir','normal');
    xlabel('\Phi/\pi'); ylabel('g_R'); title(sprintf('|\chi|, t=%.3g',tsel)); colorbar;
end
saveas(fig,paths.mapPanelFig);
print(fig,paths.mapPanel,'-dpng',sprintf('-r%d',res));
close(fig);
end

function local_plot_flux_cuts(rows, paths, vis, res)
if isempty(rows), return; end
fig = figure('Visible',vis,'Position',[100 100 1100 700]);
[gVals,~,~] = unique(local_arr(rows,'cutG'));
if isempty(gVals), gVals = unique(local_arr(rows,'gR')); end
for ig = 1:numel(gVals)
    g = gVals(ig);
    mask = abs(local_arr(rows,'cutG')-g)<1e-12 | abs(local_arr(rows,'gR')-g)<1e-12;
    sub = rows(mask);
    if isempty(sub), continue; end
    phi = local_arr(sub,'Phi')/pi;
    [phi,ord] = sort(phi); sub = sub(ord);
    subplot(3,1,1); hold on; plot(phi,local_arr(sub,'superradiantDensity'),'-o','DisplayName',sprintf('g=%.3g',g));
    ylabel('\rho_{SR}');
    subplot(3,1,2); hold on; plot(phi,local_arr(sub,'meanAbsCurrent'),'-o','DisplayName',sprintf('g=%.3g',g));
    ylabel('|J|');
    subplot(3,1,3); hold on; plot(phi,local_arr(sub,'meanAbsChirality'),'-o','DisplayName',sprintf('g=%.3g',g));
    ylabel('|\chi|'); xlabel('\Phi/\pi');
end
for k = 1:3
    subplot(3,1,k); grid on; legend('show','Location','best');
end
saveas(fig,paths.fluxCutsFig);
print(fig,paths.fluxCuts,'-dpng',sprintf('-r%d',res));
close(fig);
end

function local_plot_representatives(rows, paths, vis, res)
if isempty(rows), return; end
fig = figure('Visible',vis,'Position',[100 100 1000 650]);
labels = cell(1,numel(rows));
for k = 1:numel(rows)
    labels{k} = local_str(rows(k),'repName');
    if isempty(labels{k}), labels{k} = sprintf('rep%d',k); end
end
x = 1:numel(rows);
subplot(3,1,1); bar(x,local_arr(rows,'superradiantDensity')); ylabel('\rho_{SR}'); set(gca,'XTick',x,'XTickLabel',labels); xtickangle(25);
subplot(3,1,2); bar(x,local_arr(rows,'meanAbsCurrent')); ylabel('|J|'); set(gca,'XTick',x,'XTickLabel',labels); xtickangle(25);
subplot(3,1,3); bar(x,local_arr(rows,'meanAbsChirality')); ylabel('|\chi|'); set(gca,'XTick',x,'XTickLabel',labels); xtickangle(25);
saveas(fig,paths.representativesFig);
print(fig,paths.representatives,'-dpng',sprintf('-r%d',res));
close(fig);
end

function [gVals,phiVals,rhoZ,jZ,chiZ] = local_grid(records)
gVals = unique(local_arr(records,'gR'));
phiVals = unique(local_arr(records,'Phi'));
rhoZ = NaN(numel(gVals),numel(phiVals));
jZ = rhoZ; chiZ = rhoZ;
for ig = 1:numel(gVals)
    for ip = 1:numel(phiVals)
        mask = abs(local_arr(records,'gR')-gVals(ig))<1e-12 & abs(local_arr(records,'Phi')-phiVals(ip))<1e-12;
        if any(mask)
            idx = find(mask,1,'first');
            rhoZ(ig,ip) = local_field(records(idx),'superradiantDensity',NaN);
            jZ(ig,ip) = local_field(records(idx),'meanAbsCurrent',NaN);
            chiZ(ig,ip) = local_field(records(idx),'meanAbsChirality',NaN);
        end
    end
end
end

function vals = local_arr(records,name)
vals = NaN(1,numel(records));
for k = 1:numel(records), vals(k) = local_field(records(k),name,NaN); end
end

function val = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), val = S.(name); else, val = defaultVal; end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), val = S.(name); else, val = defaultVal; end
end

function x = local_nearest(vals,target)
if isempty(vals), x = NaN; return; end
[~,i] = min(abs(vals-target)); x = vals(i);
end

function s = local_str(S,name)
if isfield(S,name) && ~isempty(S.(name)), s = char(S.(name)); else, s = ''; end
end
