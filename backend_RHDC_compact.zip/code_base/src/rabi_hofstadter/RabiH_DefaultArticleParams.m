function [params, opts, scan] = RabiH_DefaultArticleParams()
%RABIH_DEFAULTARTICLEPARAMS Conservative default parameters for article-pipeline tests.
%
%   [params, opts, scan] = RabiH_DefaultArticleParams()
%
% The defaults are intentionally safe for the current blocked-CTM backend.
% They are meant for smoke tests and first scans, not final production data.
% Use Dmax=2 here. Dmax>=3 for a 2x2 unit cell requires the future factored
% multi-site CTM backend.

params = struct();
params.dph = 4;
params.omega = 1.0;
params.Delta = 1.0;
params.gR = 0.35;
params.t = 0.08;
params.tX = 0.08;
params.tY = 0.08;
params.Phi = pi;
params.alphaSeed = 0.2;
params.alphaPattern = 'vortex2x2';
params.spinSeed = 'down';

opts = struct();
opts.Lx = 2;
opts.Ly = 2;
opts.Dmax = 2;
opts.chiMax = 6;
opts.maxIter = 8;
opts.tol = 1e-8;
opts.tauList = [0.04 0.02 0.01];
opts.nSweeps = 1;
opts.svdCutoff = 1e-12;
opts.cacheGates = true;
opts.checkAfter = true;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.spinState = params.spinSeed;
opts.ctmBackend = 'auto';
opts.enableBlockedCTMGuard = true;
opts.skipCTMNormHistory = true;
opts.maxBlockedTensorElements = 2.0e7;
opts.maxBlockedTensorMB = 1024;
opts.maxBlockedNormIntermediateMB = 8192;
opts.outputDir = fullfile(pwd,'results_rabih_article_demo');
opts.saveEachPoint = true;
opts.verbose = false;

scan = struct();
scan.gRList = [0.20 0.35 0.50];
scan.tList = [0.05 0.08];
scan.PhiList = [0 pi/2 pi];
scan.alphaList = [0.0 0.2];
scan.paramsBase = params;
scan.optsBase = opts;
scan.tag = datestr(now,'yyyymmdd_HHMMSS');
end
