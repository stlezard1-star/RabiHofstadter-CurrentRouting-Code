function G = RabiH_DiagonalHoppingGate(params, x, y, direction, tau)
%RABIH_DIAGONALHOPPINGGATE Physical two-site gate for an NNN diagonal bond.
%   StageRH4Y helper.  Written for MATLAB R2018 compatibility: do not use
%   chained function-output indexing and do not assume a particular dimension
%   field name in the site-operator struct.  The local physical dimension is
%   inferred from the photon annihilation matrix whenever needed.

    if nargin < 5 || isempty(tau)
        tau = RabiH_GetOpt(params,'tau',0.01);
    end

    [J2,~,includeNNN] = RabiH_GetNNNHopping(params);

    if ~includeNNN || abs(J2) == 0
        d = local_site_dim(params);
        G = eye(d*d);
        return;
    end

    ph = RabiH_NNNPhase(x,y,direction,params);
    G = RabiH_HoppingGate(params, ph, J2, tau);
end

function d = local_site_dim(params)
    ops = RabiH_SiteOpsAuto(params);
    if isfield(ops,'d') && ~isempty(ops.d)
        d = ops.d;
    elseif isfield(ops,'dim') && ~isempty(ops.dim)
        d = ops.dim;
    elseif isfield(ops,'physDim') && ~isempty(ops.physDim)
        d = ops.physDim;
    elseif isfield(ops,'I') && ~isempty(ops.I)
        d = size(ops.I,1);
    elseif isfield(ops,'a') && ~isempty(ops.a)
        d = size(ops.a,1);
    else
        error('RabiH_DiagonalHoppingGate:CannotInferDim', ...
            'Could not infer local physical dimension from site operators.');
    end
end
