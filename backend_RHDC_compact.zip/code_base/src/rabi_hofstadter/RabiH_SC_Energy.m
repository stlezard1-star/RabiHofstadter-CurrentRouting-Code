function E = RabiH_SC_Energy(x, params)
%RabiH_SC_Energy  Coherent-state energy for 2x2 Rabi-Hofstadter plaquette.
%
% x is an 8-vector: [Re alpha_1..Re alpha_4, Im alpha_1..Im alpha_4].

if numel(x) ~= 8
    error('RabiH_SC_Energy expects an 8-vector.');
end
x = x(:).';
alpha = x(1:4) + 1i*x(5:8);
E = RabiH_SC_EnergyAlpha(alpha, params);
end
