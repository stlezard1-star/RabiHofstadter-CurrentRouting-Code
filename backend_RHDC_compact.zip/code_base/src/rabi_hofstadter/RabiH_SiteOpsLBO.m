function ops = RabiH_SiteOpsLBO(params, basis)
%RABIH_SITEOPSLBO Site operators using projected photon LBO basis.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(basis)
    basis = RabiH_PhotonBasis_FromSnapshots(params, struct());
end
ph = RabiH_PhotonBasis_ProjectOps(basis);

sx = [0 1; 1 0];
sy = [0 -1i; 1i 0];
sz = [1 0; 0 -1];
sp = [0 1; 0 0];
sm = [0 0; 1 0];
Is = eye(2);

ops = struct();
ops.type = 'site_ops_lbo';
ops.basis = basis;
ops.dph = basis.dEff;
ops.dphFull = basis.dFull;
ops.d = 2*basis.dEff;
ops.I = eye(ops.d);
ops.a = kron(ph.a, Is);
ops.adag = kron(ph.adag, Is);
ops.N = kron(ph.N, Is);
ops.Q = kron(ph.Q, Is);
ops.sx = kron(ph.I, sx);
ops.sy = kron(ph.I, sy);
ops.sz = kron(ph.I, sz);
ops.sp = kron(ph.I, sp);
ops.sm = kron(ph.I, sm);
ops.Is = kron(ph.I, Is);
ops.photon = ph;
ops.spin.sx = sx;
ops.spin.sy = sy;
ops.spin.sz = sz;
ops.spin.sp = sp;
ops.spin.sm = sm;
ops.spin.I = Is;
end
