function O12 = RabiH_TwoSiteOp(O1, O2)
%RABIH_TWOSITEOP Two-site operator in PEPS physical ordering.
%
%   SU_ApplyTwoSiteGate uses combined index p1 + (p2-1)*d, so the dense
%   two-site matrix is kron(O2,O1).
    O12 = kron(O2, O1);
end
