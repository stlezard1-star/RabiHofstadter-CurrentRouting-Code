function summary = RabiH_SummarizeHighDphLBOBenchmark(records)
%RABIH_SUMMARIZEHIGHDPHLBOBENCHMARK Extra grouping summary for StageRH4T.
summary = struct();
summary.numRecords = numel(records);
ok = arrayfun(@(r) strcmpi(r.status,'ok'), records);
summary.numOK = sum(ok);
summary.numError = sum(~ok);
if ~any(ok)
    summary.phaseMatchFraction = NaN;
    summary.numPhaseError = NaN;
    summary.maxAbsDE = NaN;
    summary.maxRelRhoSR = NaN;
    summary.maxRelCurrent = NaN;
    summary.maxRelChirality = NaN;
    summary.meanSpeedup = NaN;
    summary.branchSummary = repmat(local_empty_branch_summary(),1,0);
    return;
end
rr = records(ok);
phaseError = arrayfun(@(r) strcmpi(r.fullPhase,'error') || strcmpi(r.lboPhase,'error') || isempty(r.fullPhase) || isempty(r.lboPhase), rr);
summary.numPhaseError = sum(phaseError);
if all(phaseError)
    summary.phaseMatchFraction = 0;
else
    summary.phaseMatchFraction = mean([rr(~phaseError).phaseMatch]);
end
summary.phaseMatchFractionRaw = mean([rr.phaseMatch]);
summary.maxAbsDE = max([rr.absDE]);
summary.maxRelRhoSR = max([rr.relRhoSR]);
summary.maxRelCurrent = max([rr.relCurrent]);
summary.maxRelChirality = max([rr.relChirality]);
summary.minLocalSpectrumError = min([rr.localSpectrumMaxError]);
summary.maxLocalSpectrumError = max([rr.localSpectrumMaxError]);
summary.minHopDimReduction = min([rr.hopDimReduction]);
summary.maxHopDimReduction = max([rr.hopDimReduction]);
summary.meanSpeedup = mean([rr.fullRuntimeSeconds]./max([rr.lboRuntimeSeconds],eps));
summary.maxDFull = max([rr.dFull]);
summary.maxDEff = max([rr.dEff]);
summary.branchSummary = local_branch_summary(rr);
end

function out = local_branch_summary(rr)
branches = unique({rr.branch});
out = repmat(local_empty_branch_summary(),1,0);
for ib = 1:numel(branches)
    br = branches{ib};
    mask = strcmp({rr.branch},br);
    sub = rr(mask);
    s = local_empty_branch_summary();
    s.branch = br;
    s.n = numel(sub);
    s.maxAbsDE = max([sub.absDE]);
    s.maxRelRhoSR = max([sub.relRhoSR]);
    s.maxRelCurrent = max([sub.relCurrent]);
    s.maxRelChirality = max([sub.relChirality]);
    s.minFullChi = min([sub.fullAbsChirality]);
    s.maxFullChi = max([sub.fullAbsChirality]);
    s.minLBOChi = min([sub.lboAbsChirality]);
    s.maxLBOChi = max([sub.lboAbsChirality]);
    phaseError = arrayfun(@(r) strcmpi(r.fullPhase,'error') || strcmpi(r.lboPhase,'error') || isempty(r.fullPhase) || isempty(r.lboPhase), sub);
    s.phaseErrors = sum(phaseError);
    if all(phaseError)
        s.phaseMatchFraction = 0;
    else
        s.phaseMatchFraction = mean([sub(~phaseError).phaseMatch]);
    end
    s.meanSpeedup = mean([sub.fullRuntimeSeconds]./max([sub.lboRuntimeSeconds],eps));
    out(end+1) = s; %#ok<AGROW>
end
end

function s = local_empty_branch_summary()
s = struct('branch','','n',0,'maxAbsDE',NaN,'maxRelRhoSR',NaN,'maxRelCurrent',NaN, ...
    'maxRelChirality',NaN,'minFullChi',NaN,'maxFullChi',NaN,'minLBOChi',NaN,'maxLBOChi',NaN, ...
    'phaseErrors',NaN,'phaseMatchFraction',NaN,'meanSpeedup',NaN);
end
