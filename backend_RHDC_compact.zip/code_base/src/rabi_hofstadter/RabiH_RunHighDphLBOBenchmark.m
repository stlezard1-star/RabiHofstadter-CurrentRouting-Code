function scan = RabiH_RunHighDphLBOBenchmark(paramsBase, optsBase, spec)
%RABIH_RUNHIGHDPHLBOBENCHMARK Run StageRH4T high-cutoff LBO benchmark.
%
% This is a thin article-facing wrapper around the StageRH4S full-vs-LBO
% engine.  It adds StageRH4T metadata and a high-cutoff summary layer while
% reusing the tested full/LBO one-point PEPS comparison pipeline.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4T_DefaultHighDphBenchmark();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec), spec = struct(); end
if ~isfield(spec,'stage') || isempty(spec.stage), spec.stage = 'StageRH4T'; end
if ~isfield(spec,'outputDir') || isempty(spec.outputDir)
    spec.outputDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4T_high_dph_lbo_benchmark'));
end
optsBase.outputDir = spec.outputDir;

scan = RabiH_RunLBOPEPSBenchmark(paramsBase, optsBase, spec);
scan.stage = 'StageRH4T';
scan.description = 'High-dph full-Fock versus LBO-projected article benchmark.';
scan.summaryT = RabiH_SummarizeHighDphLBOBenchmark(scan.records);
if isfield(scan,'csvFile') && ~isempty(scan.csvFile)
    % Keep Stage4S-generated CSV name for compatibility, then add a Stage4T alias.
    stage4TCSV = fullfile(scan.outputDir,'stage4T_high_dph_lbo_benchmark.csv');
    RabiH_WriteLBOPEPSBenchmarkCSV(scan, stage4TCSV);
    scan.csvFileStage4T = stage4TCSV;
end
matFile = fullfile(scan.outputDir,'stage4T_high_dph_lbo_benchmark.mat');
save(matFile,'scan');
scan.matFile = matFile;
end
