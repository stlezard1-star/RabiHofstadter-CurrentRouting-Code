function obs = RabiH_CTMObservables_SplitFactoredPeriodic(unitCell, params, opts)
%RABIH_CTMOBSERVABLES_SPLITFACTOREDPERIODIC StageRH4H observables.
%
% Reuses the StageRH4G split/factored observable evaluator with a StageRH4H
% periodic-neighbor CTM context.  The central measurement contractions are
% unchanged; only the CTM context construction is upgraded from site-wise to
% periodic-neighbor absorption.

    if nargin < 3 || isempty(opts), opts = struct(); end
    ctx = RabiH_GetOpt(opts,'ctmContext',[]);
    if isempty(ctx)
        ctx = RabiH_CTMRunSplitFactoredPeriodic(unitCell, opts);
    end

    obsOpts = opts;
    obsOpts.ctmContext = ctx;
    obs = RabiH_CTMObservables_SplitFactoredProduction(unitCell, params, obsOpts);
    obs.backend = ctx.backend;
    obs.stage = ctx.stage;
    obs.description = ['StageRH4H periodic-neighbor split/factored CTM observable summary.  ' ...
                       'No blocked tensor is allocated; CTM environments are built by ' ...
                       'absorbing periodic-neighbor tensors.'];
end
