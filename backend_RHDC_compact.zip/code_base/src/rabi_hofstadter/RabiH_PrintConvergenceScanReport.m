function RabiH_PrintConvergenceScanReport(scanResult)
%RABIH_PRINTCONVERGENCESCANREPORT Print StageRH4K convergence summary.

s = scanResult.summary;
fprintf('--- RabiH StageRH4K convergence diagnostic report ---\n');
fprintf('records            : %d\n', s.numRecords);
fprintf('ok / error         : %d / %d\n', s.numOK, s.numError);
fprintf('energy range       : [%.12g, %.12g]\n', s.energyRange(1), s.energyRange(2));
fprintf('rhoSR range        : [%.12g, %.12g]\n', s.rhoSRRange(1), s.rhoSRRange(2));
fprintf('max |dE| vs first  : %.6e\n', s.maxAbsEnergyDeltaVsFirstOK);
fprintf('max |dRho| vs first: %.6e\n', s.maxAbsRhoDeltaVsFirstOK);
fprintf('max current div    : %.6e\n', s.maxCurrentDivergence);
fprintf('max chirality err  : %.6e\n', s.maxChiralityDefinitionError);
fprintf('label                              ok   dph   D  chi    mix          E/site          rhoSR       divJ      time(s)\n');
for k = 1:numel(scanResult.records)
    r = scanResult.records(k);
    ok = strcmpi(r.status,'ok');
    fprintf('%-32s %3d %5g %3g %4g %6.3g %16.9g %12.4e %9.2e %9.3f\n', ...
        local_trunc(r.label,32), ok, r.dph, r.Dmax, r.chiMax, r.sharedBoundaryMix, ...
        r.energyPerSite, r.superradiantDensity, r.maxCurrentDivergence, r.runtimeSeconds);
end
end

function s = local_trunc(s,n)
if numel(s) > n
    s = s(1:n);
end
end
