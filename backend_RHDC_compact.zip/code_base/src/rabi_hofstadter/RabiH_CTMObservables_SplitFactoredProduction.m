function obs = RabiH_CTMObservables_SplitFactoredProduction(unitCell, params, opts)
%RABIH_CTMOBSERVABLES_SPLITFACTOREDPRODUCTION StageRH4G observables.
%
% Measures the same basic quantities as RabiH_CTMObservables_Blocked but via
% the StageRH4G split/factored CTM v1 backend.  No blocked unit-cell tensor is
% constructed.

    if nargin < 3 || isempty(opts), opts = struct(); end
    ctx = RabiH_GetOpt(opts,'ctmContext',[]);
    if isempty(ctx)
        prodOpts = opts;
        prodOpts.splitBackendMode = 'production';
        ctx = RabiH_CTMRunSplitFactored(unitCell, prodOpts);
    end

    ops = RabiH_SiteOpsAuto(params);
    Lx = unitCell.Lx;
    Ly = unitCell.Ly;

    alpha = zeros(Ly,Lx);
    nph = zeros(Ly,Lx);
    sx = zeros(Ly,Lx);
    sy = zeros(Ly,Lx);
    sz = zeros(Ly,Lx);

    for y = 1:Ly
        for x = 1:Lx
            alpha(y,x) = local_onesite(ctx, ops.a,  x,y);
            nph(y,x)   = local_onesite(ctx, ops.N,  x,y);
            sx(y,x)    = local_onesite(ctx, ops.sx, x,y);
            sy(y,x)    = local_onesite(ctx, ops.sy, x,y);
            sz(y,x)    = local_onesite(ctx, ops.sz, x,y);
        end
    end

    jRight = zeros(Ly,Lx);
    jDown = zeros(Ly,Lx);
    for y = 1:Ly
        for x = 1:Lx
            jRight(y,x) = local_current(ctx, params, x,y,'right');
            jDown(y,x)  = local_current(ctx, params, x,y,'down');
        end
    end

    chirality = zeros(Ly,Lx);
    for y = 1:Ly
        yp = mod(y,Ly)+1;
        for x = 1:Lx
            xp = mod(x,Lx)+1;
            chirality(y,x) = jRight(y,x) + jDown(y,xp) - jRight(yp,x) - jDown(y,x);
        end
    end

    energy = RabiH_CTMEnergy_SplitFactored(unitCell, params, local_setfield(opts,'ctmContext',ctx));

    obs = struct();
    obs.energyPerSite = energy.energyPerSite;
    obs.energyDetails = energy;
    obs.alpha = alpha;
    obs.photonNumber = local_real_if_safe(nph);
    obs.sx = local_real_if_safe(sx);
    obs.sy = local_real_if_safe(sy);
    obs.sz = local_real_if_safe(sz);
    obs.jRight = local_real_if_safe(jRight);
    obs.jDown = local_real_if_safe(jDown);
    obs.plaquetteChirality = local_real_if_safe(chirality);
    obs.superradiantDensity = mean(abs(alpha(:)).^2);
    obs.meanPhotonNumber = mean(real(nph(:)));
    obs.meanAbsCurrent = mean(abs([jRight(:); jDown(:)]));
    obs.meanAbsChirality = mean(abs(chirality(:)));
    obs.ctx = ctx;
    obs.backend = 'split_factored_ctm_v1_sitewise';
    obs.description = ['StageRH4G split/factored CTM v1 observable summary.  ' ...
                       'This backend is memory-safe and non-blocked, but should ' ...
                       'be treated as pre-production until the periodic split-CTMRG kernel is added.'];
end

function val = local_onesite(ctx, op, x, y)
    Eop = RabiH_SplitLayerLocalDoubleLayer(ctx.splitCell,x,y,op);
    val = CTM_EvaluateNorm_Fast(Eop, ctx.WCell{y,x}) / ctx.denOne(y,x);
    val = local_real_if_safe(val);
end

function val = local_current(ctx, params, x, y, direction)
    Lx = ctx.splitCell.Lx;
    Ly = ctx.splitCell.Ly;
    switch lower(direction)
        case {'right','x','horizontal'}
            x2 = mod(x,Lx)+1; y2 = y;
            phase = RabiH_GaugePhase(x,y,'right',params);
            tval = RabiH_GetOpt(params,'tX',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denH(y,x);
            pairFun = @CTM_EvaluateHorizontalPair;
        case {'down','y','vertical'}
            x2 = x; y2 = mod(y,Ly)+1;
            phase = RabiH_GaugePhase(x,y,'down',params);
            tval = RabiH_GetOpt(params,'tY',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denV(y,x);
            pairFun = @CTM_EvaluateVerticalPair;
        otherwise
            error('RabiH_CTMObservables_SplitFactoredProduction:UnknownDirection','Unknown direction.');
    end
    terms = RabiH_CurrentTerms(params, phase, tval);
    num = 0;
    for k = 1:numel(terms)
        EA = RabiH_SplitLayerLocalDoubleLayer(ctx.splitCell,x,y,terms(k).opA);
        EB = RabiH_SplitLayerLocalDoubleLayer(ctx.splitCell,x2,y2,terms(k).opB);
        num = num + terms(k).coeff * pairFun(EA, EB, ctx.envCell{y,x});
    end
    val = num / denPair;
    val = local_real_if_safe(val);
end

function S = local_setfield(S, name, value)
    S.(name) = value;
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
