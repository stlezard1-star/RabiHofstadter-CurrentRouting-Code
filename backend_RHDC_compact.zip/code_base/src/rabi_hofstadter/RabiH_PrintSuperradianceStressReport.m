function RabiH_PrintSuperradianceStressReport(stress)
%RABIH_PRINTSUPERRADIANCESTRESSREPORT Print StageRH4M stress-scan summary.

if isfield(stress,'summary')
    s = stress.summary;
    best = stress.best;
else
    best = stress;
    s = RabiH_SummarizeSuperradianceStressScan(best);
end
records = best.records;

fprintf('--- RabiH StageRH4M superradiance stress report ---\n');
fprintf('best physical points      : %d\n', s.numBestRecords);
fprintf('best nonzero-alpha count  : %d / %d\n', s.numNonzeroAlphaBest, s.numBestRecords);
fprintf('SR-labelled count         : %d / %d\n', s.numSRBest, s.numBestRecords);
fprintf('rhoSR range               : [%.12g, %.12g]\n', s.minRhoSR, s.maxRhoSR);
fprintf('max |current|             : %.6e\n', s.maxAbsCurrent);
fprintf('max |chirality|           : %.6e\n', s.maxAbsChirality);
fprintf('max current divergence    : %.6e\n', s.maxCurrentDivergence);
if isfield(stress,'bestCsv')
    fprintf('best-seed CSV             : %s\n', stress.bestCsv);
end
if s.allBestAlphaZero
    fprintf('diagnosis                 : all best seeds still alpha=0; enlarge gR/t, add sourceEta, or improve SU schedule.\n');
elseif s.noVisibleSR
    fprintf('diagnosis                 : nonzero-alpha branches appear but rhoSR is below threshold; inspect energy gaps and sourceEta.\n');
else
    fprintf('diagnosis                 : visible SR branch detected; proceed to convergence and eta->0 checks.\n');
end

fprintf('label       gR       t      Phi/pi sourceEta    E/site          rhoSR       |J|       |chi|     seed pattern\n');
for k = 1:numel(records)
    r = records(k);
    fprintf('%-9s %6.3g %6.3g %8.3f %8.2e %16.9g %11.4e %9.2e %9.2e %6.3g %s\n', ...
        local_trunc(local_field(r,'phaseLabel',''),9), r.gR, r.t, r.Phi/pi, ...
        local_field(r,'sourceEta',0), r.energyPerSite, r.superradiantDensity, ...
        r.meanAbsCurrent, r.meanAbsChirality, r.alphaSeed, r.alphaPattern);
end
end

function s = local_trunc(s,n)
if numel(s) > n, s = s(1:n); end
end

function v = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end
