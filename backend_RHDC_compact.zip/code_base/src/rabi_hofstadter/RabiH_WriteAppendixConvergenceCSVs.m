function csvFiles = RabiH_WriteAppendixConvergenceCSVs(pack, outDir)
%RABIH_WRITEAPPENDIXCONVERGENCECSVS Write StageRH4U Appendix CSV tables.
if nargin < 2 || isempty(outDir), outDir = pack.outputDir; end
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
csvFiles = struct();
csvFiles.summary = fullfile(outDir,'stage4U_appendix_summary.csv');
csvFiles.accuracyBranches = fullfile(outDir,'stage4U_accuracy_overlay_branches.csv');
csvFiles.lboBranches = fullfile(outDir,'stage4U_highdph_lbo_branches.csv');
local_write_summary(pack, csvFiles.summary);
local_write_q_branches(pack, csvFiles.accuracyBranches);
local_write_t_branches(pack, csvFiles.lboBranches);
end

function local_write_summary(pack, fileName)
s = pack.summaryU;
fid = fopen(fileName,'w');
if fid < 0, error('RabiH_WriteAppendixConvergenceCSVs:OpenFailed','Cannot open summary CSV.'); end
fprintf(fid,'metric,value\n');
local_kv(fid,'stage4Q_phase_match',s.stage4QPhaseMatch);
local_kv(fid,'stage4Q_max_current_divergence',s.stage4QMaxCurrentDivergence);
local_kv(fid,'stage4Q_max_chirality_error',s.stage4QMaxChiralityError);
local_kv(fid,'stage4Q_max_branch_dE',s.stage4QMaxBranchDE);
local_kv(fid,'stage4Q_max_branch_dRho',s.stage4QMaxBranchDRho);
local_kv(fid,'stage4Q_max_branch_dCurrent',s.stage4QMaxBranchDCurrent);
local_kv(fid,'stage4Q_max_branch_dChirality',s.stage4QMaxBranchDChirality);
local_kv(fid,'stage4T_phase_match',s.stage4TPhaseMatch);
local_kv(fid,'stage4T_phase_label_errors',s.stage4TPhaseErrors);
local_kv(fid,'stage4T_max_abs_dE',s.stage4TMaxAbsDE);
local_kv(fid,'stage4T_max_rel_dRhoSR',s.stage4TMaxRelRhoSR);
local_kv(fid,'stage4T_max_rel_dCurrent',s.stage4TMaxRelCurrent);
local_kv(fid,'stage4T_max_rel_dChirality',s.stage4TMaxRelChirality);
local_kv(fid,'stage4T_mean_speedup',s.stage4TMeanSpeedup);
local_kv(fid,'stage4T_min_hop_dim_reduction',s.stage4THopDimReduction(1));
local_kv(fid,'stage4T_max_hop_dim_reduction',s.stage4THopDimReduction(2));
local_kv(fid,'ready_for_appendix',double(s.readyForAppendix));
fprintf(fid,'recommendation,%s\n',local_csv_str(s.recommendation));
fclose(fid);
end

function local_write_q_branches(pack, fileName)
fid = fopen(fileName,'w');
if fid < 0, error('RabiH_WriteAppendixConvergenceCSVs:OpenFailed','Cannot open Q branch CSV.'); end
fprintf(fid,'branch,targetPhase,n,phaseLabels,match,Emin,Emax,rhoMin,rhoMax,Jmin,Jmax,chiMin,chiMax\n');
q = pack.summaryU.stage4Q;
if isfield(q,'branchTable')
    bt = q.branchTable;
else
    bt = repmat(struct(),1,0);
end
for k = 1:numel(bt)
    b = bt(k);
    fprintf(fid,'%s,%s,%d,%s,%.12g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g\n', ...
        local_csv_str(b.branchName), local_csv_str(b.targetPhase), b.numRecords, local_csv_str(b.phaseLabels), ...
        b.targetMatchFraction, b.energyRange(1), b.energyRange(2), b.rhoRange(1), b.rhoRange(2), ...
        b.currentRange(1), b.currentRange(2), b.chiralityRange(1), b.chiralityRange(2));
end
fclose(fid);
end

function local_write_t_branches(pack, fileName)
fid = fopen(fileName,'w');
if fid < 0, error('RabiH_WriteAppendixConvergenceCSVs:OpenFailed','Cannot open T branch CSV.'); end
fprintf(fid,'branch,n,phaseMatch,phaseErrors,maxAbsDE,maxRelRho,maxRelCurrent,maxRelChirality,minFullChi,maxFullChi,minLBOChi,maxLBOChi,meanSpeedup\n');
t = pack.summaryU.stage4T;
if isfield(t,'branchSummary')
    bt = t.branchSummary;
else
    bt = repmat(struct(),1,0);
end
for k = 1:numel(bt)
    b = bt(k);
    fprintf(fid,'%s,%d,%.12g,%d,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.12g\n', ...
        local_csv_str(b.branch), b.n, b.phaseMatchFraction, b.phaseErrors, b.maxAbsDE, ...
        b.maxRelRhoSR, b.maxRelCurrent, b.maxRelChirality, b.minFullChi, b.maxFullChi, ...
        b.minLBOChi, b.maxLBOChi, b.meanSpeedup);
end
fclose(fid);
end

function local_kv(fid, key, value)
fprintf(fid,'%s,%.16g\n', key, value);
end

function s = local_csv_str(x)
if isempty(x), s = ''; else, s = char(x); end
s = strrep(s,',',';');
s = strrep(s,sprintf('\n'),' ');
end
