function spec = RabiH_Stage4AC_DefaultMainTextSpec()
%RABIH_STAGE4AC_DEFAULTMAINTEXTSPEC Defaults for main-text NNN figure assembly.
% StageRH4AC takes refined Stage4AB current-pattern records and assembles
% compact figures that are closer to manuscript panels.

spec = struct();
spec.outputDir = fullfile(pwd,'results_stage4AC_maintext_nnn_figures');
spec.makeVisible = false;
spec.targetG = 1.4;
spec.targetJ1 = 0.16;
spec.arrowCases = [-0.6 -0.25; -0.6 0; 0.6 0; 0.6 0.25];

% Map panels. Keep these compact for main-text use.
spec.strengthFields = {'meanAbsDiagCurrent','meanAbsSquareChirality','meanAbsTriangularChirality','triangularImbalance'};
spec.strengthTitles = {'|I_{diag}|','|chi_{sq}|','mean |chi_{tri}|','triangular imbalance'};
spec.signedFields = {'j13','j24','j13Minusj24','chiTriSigned13'};
spec.signedTitles = {'I_{13}','I_{24}','I_{13}-I_{24}','chi_{123}-chi_{134}'};

% Figure file prefixes.
spec.strengthFigureName = 'Fig_stage4AC_NNN_strength_maps_maintext';
spec.signedFigureName = 'Fig_stage4AC_NNN_signed_maps_maintext';
spec.arrowFigureName = 'Fig_stage4AC_NNN_arrow_patterns_maintext';
spec.selectedCsvName = 'stage4AC_selected_maintext_patterns.csv';
spec.refinedCsvName = 'stage4AC_maintext_refined_records.csv';
spec.snippetName = 'RabiH_NNN_Results_and_Captions_Stage4AC.tex';
end
