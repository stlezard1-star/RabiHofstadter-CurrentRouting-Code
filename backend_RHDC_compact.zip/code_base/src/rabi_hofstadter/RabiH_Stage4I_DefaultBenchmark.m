function [params, opts, backendList] = RabiH_Stage4I_DefaultBenchmark()
%RABIH_STAGE4I_DEFAULTBENCHMARK Conservative backend-comparison defaults.
%
% StageRH4I is not a new physics backend.  It is a diagnostic layer that
% compares the guarded exact-small-cell references against the executable
% split/factored CTM approximations on the same SU-optimized unit cell.

params = struct();
params.dph = 3;
params.omega = 1.0;
params.Delta = 1.0;
params.gR = 0.25;
params.t = 0.04;
params.tX = 0.04;
params.tY = 0.04;
params.Phi = pi;
params.alphaSeed = 0.10;
params.alphaPattern = 'vortex2x2';
params.spinSeed = 'down';

opts = struct();
opts.Lx = 2;
opts.Ly = 2;
opts.Dmax = 2;
opts.chiMax = 4;
opts.maxIter = 2;
opts.tol = 1e-8;
opts.tauList = 0.02;
opts.nSweeps = 1;
opts.svdCutoff = 1e-12;
opts.cacheGates = true;
opts.checkAfter = true;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.spinState = params.spinSeed;
opts.skipCTMNormHistory = true;
opts.enableBlockedCTMGuard = true;
opts.maxBlockedTensorElements = 2.0e7;
opts.maxBlockedTensorMB = 1024;
opts.maxBlockedNormIntermediateMB = 8192;
opts.maxExactTorusElements = 1.0e6;
opts.maxSplitLocalDoubleLayerMB = 512;
opts.maxSplitWorkspaceMB = 8192;
opts.verbose = false;

backendList = {'factoredExact','splitFactoredExact','splitFactored','splitFactoredPeriodic'};
end
