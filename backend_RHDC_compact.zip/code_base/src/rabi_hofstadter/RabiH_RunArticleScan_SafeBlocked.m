function scanResult = RabiH_RunArticleScan_SafeBlocked(scan, opts)
%RABIH_RUNARTICLESCAN_SAFEBLOCKED Guarded first-pass parameter scan.
%
%   scanResult = RabiH_RunArticleScan_SafeBlocked(scan, opts)
%
% This is a conservative data-pipeline scaffold.  It is useful for debugging
% trends, seed dependence, gauge/current observables, and file output.  It is
% not intended as the final large-D article engine; Dmax>=3 on a 2x2 unit cell
% requires the Stage4C factored/multi-site CTM backend.

if nargin < 1 || isempty(scan)
    [~,~,scan] = RabiH_DefaultArticleParams();
end
if nargin < 2 || isempty(opts)
    opts = struct();
end

paramsBase = local_get(scan,'paramsBase',struct());
optsBase = local_get(scan,'optsBase',struct());
optsBase = local_merge_structs(optsBase, opts);

gRList = local_get(scan,'gRList',RabiH_GetOpt(paramsBase,'gR',0.3));
tList = local_get(scan,'tList',RabiH_GetOpt(paramsBase,'t',0.05));
PhiList = local_get(scan,'PhiList',RabiH_GetOpt(paramsBase,'Phi',0));
alphaList = local_get(scan,'alphaList',RabiH_GetOpt(paramsBase,'alphaSeed',0));
tag = local_get(scan,'tag',datestr(now,'yyyymmdd_HHMMSS'));

outDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,['results_rabih_' tag]));
if ~exist(outDir,'dir')
    mkdir(outDir);
end

nTot = numel(gRList)*numel(tList)*numel(PhiList)*numel(alphaList);
records = repmat(local_empty_record(), nTot, 1);
raw = cell(nTot,1);
ptr = 0;

for ig = 1:numel(gRList)
    for it = 1:numel(tList)
        for ip = 1:numel(PhiList)
            for ia = 1:numel(alphaList)
                ptr = ptr + 1;
                params = paramsBase;
                params.gR = gRList(ig);
                params.t = tList(it);
                params.tX = tList(it);
                params.tY = tList(it);
                params.Phi = PhiList(ip);
                params.alphaSeed = alphaList(ia);

                pointOpts = optsBase;
                pointOpts.alpha = alphaList(ia);
                pointOpts.ctmBackend = RabiH_GetOpt(pointOpts,'ctmBackend','auto');
                records(ptr).index = ptr;
                records(ptr).gR = params.gR;
                records(ptr).t = params.t;
                records(ptr).Phi = params.Phi;
                records(ptr).alphaSeed = pointOpts.alpha;
                records(ptr).status = 'started';

                try
                    res = RabiH_RunOnePoint_AutoBackend(params, pointOpts);
                    raw{ptr} = res;
                    records(ptr).status = 'ok';
                    records(ptr).energyPerSite = real(res.energyPerSite);
                    records(ptr).superradiantDensity = real(res.superradiantDensity);
                    records(ptr).meanPhotonNumber = real(res.obs.meanPhotonNumber);
                    records(ptr).meanAbsCurrent = real(res.obs.meanAbsCurrent);
                    records(ptr).meanAbsChirality = real(res.obs.meanAbsChirality);
                    records(ptr).runtimeSeconds = res.runtimeSeconds;
                    records(ptr).blockedTensorMB = res.backendInfo.risk.blockedTensorMB;
                    records(ptr).blockedInterMB = res.backendInfo.risk.estimatedNormIntermediateMB;
                    records(ptr).errorMessage = '';
                catch ME
                    records(ptr).status = 'failed';
                    records(ptr).errorMessage = ME.message;
                    raw{ptr} = ME;
                end

                if RabiH_GetOpt(pointOpts,'saveEachPoint',true)
                    pointFile = fullfile(outDir,sprintf('point_%04d.mat',ptr));
                    record = records(ptr); %#ok<NASGU>
                    pointRaw = raw{ptr}; %#ok<NASGU>
                    save(pointFile,'record','pointRaw','params','pointOpts');
                end
            end
        end
    end
end

csvFile = fullfile(outDir,'scan_summary.csv');
RabiH_WriteScanCSV(records, csvFile);

scanResult = struct();
scanResult.records = records;
scanResult.raw = raw;
scanResult.outDir = outDir;
scanResult.csvFile = csvFile;
scanResult.scan = scan;
scanResult.opts = optsBase;
scanResult.note = 'v0_2 safe blocked-CTM article-pipeline scaffold';

save(fullfile(outDir,'scan_result.mat'),'scanResult');
end

function r = local_empty_record()
r = struct();
r.index = NaN;
r.gR = NaN;
r.t = NaN;
r.Phi = NaN;
r.alphaSeed = NaN;
r.status = '';
r.energyPerSite = NaN;
r.superradiantDensity = NaN;
r.meanPhotonNumber = NaN;
r.meanAbsCurrent = NaN;
r.meanAbsChirality = NaN;
r.runtimeSeconds = NaN;
r.blockedTensorMB = NaN;
r.blockedInterMB = NaN;
r.errorMessage = '';
end

function v = local_get(s, name, defaultVal)
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end

function out = local_merge_structs(a,b)
out = a;
if ~isstruct(b), return; end
f = fieldnames(b);
for k = 1:numel(f)
    out.(f{k}) = b.(f{k});
end
end
