function diag = RabiH_CurrentChiralityDiagnostics(obs)
%RABIH_CURRENTCHIRALITYDIAGNOSTICS Continuity and chirality diagnostics.
%
% The oriented current convention is jRight(y,x): (x,y)->(x+1,y) and
% jDown(y,x): (x,y)->(x,y+1).  A stationary circulating-current pattern
% should have small lattice divergence even when plaquette chirality is finite.

if nargin < 1 || isempty(obs)
    error('RabiH_CurrentChiralityDiagnostics:MissingObs','obs is required.');
end
if ~isfield(obs,'jRight') || ~isfield(obs,'jDown')
    error('RabiH_CurrentChiralityDiagnostics:MissingCurrents', ...
        'Observable struct must contain jRight and jDown.');
end

jR = obs.jRight;
jD = obs.jDown;
[Ly,Lx] = size(jR);
if ~isequal(size(jD),[Ly Lx])
    error('RabiH_CurrentChiralityDiagnostics:SizeMismatch','jRight and jDown sizes differ.');
end

div = zeros(Ly,Lx);
chirFromCurr = zeros(Ly,Lx);
for y = 1:Ly
    ym = mod(y-2,Ly)+1;
    yp = mod(y,Ly)+1;
    for x = 1:Lx
        xm = mod(x-2,Lx)+1;
        xp = mod(x,Lx)+1;
        div(y,x) = jR(y,x) - jR(y,xm) + jD(y,x) - jD(ym,x);
        chirFromCurr(y,x) = jR(y,x) + jD(y,xp) - jR(yp,x) - jD(y,x);
    end
end

if isfield(obs,'plaquetteChirality') && isequal(size(obs.plaquetteChirality),[Ly Lx])
    chirErr = chirFromCurr - obs.plaquetteChirality;
else
    chirErr = NaN(size(chirFromCurr));
end
allCurr = [jR(:); jD(:)];

diag = struct();
diag.currentDivergence = local_real_if_safe(div);
diag.maxCurrentDivergence = max(abs(div(:)));
diag.meanAbsCurrentDivergence = mean(abs(div(:)));
diag.chiralityFromCurrents = local_real_if_safe(chirFromCurr);
diag.maxChiralityDefinitionError = max(abs(chirErr(:)));
diag.meanAbsCurrent = mean(abs(allCurr));
diag.maxAbsCurrent = max(abs(allCurr));
diag.meanAbsChirality = mean(abs(chirFromCurr(:)));
diag.maxAbsChirality = max(abs(chirFromCurr(:)));
diag.netHorizontalCurrent = sum(jR(:));
diag.netVerticalCurrent = sum(jD(:));
diag.netPlaquetteChirality = sum(chirFromCurr(:));
diag.Lx = Lx;
diag.Ly = Ly;
end

function X = local_real_if_safe(X)
if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
    X = real(X);
end
end
