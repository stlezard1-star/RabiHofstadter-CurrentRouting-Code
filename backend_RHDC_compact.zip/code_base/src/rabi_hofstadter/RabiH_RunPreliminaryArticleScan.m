function prelim = RabiH_RunPreliminaryArticleScan(paramsBase, optsBase, scanSpec)
%RABIH_RUNPRELIMINARYARTICLESCAN Run StageRH4L seed-resolved parameter scan.
%
%   prelim = RabiH_RunPreliminaryArticleScan(paramsBase, optsBase, scanSpec)
%
% The routine delegates raw point evaluation to the StageRH4K convergence
% scanner, then selects the lowest-energy seed for each physical parameter
% group.  It writes both the raw convergence CSV and a compact best-seed CSV.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, scanSpec] = RabiH_Stage4L_DefaultPrelimScan();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(scanSpec)
    scanSpec = struct();
end

optsBase.ctmBackend = RabiH_GetOpt(optsBase,'ctmBackend','splitFactoredShared');
optsBase.splitBackendMode = 'shared';
scanSpec.backend = RabiH_GetOpt(scanSpec,'backend','splitFactoredShared');

outDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4L_prelim_scan'));
if exist(outDir,'dir') ~= 7
    mkdir(outDir);
end

raw = RabiH_RunConvergenceScan(paramsBase, optsBase, scanSpec);
rawCsv = fullfile(outDir,'stage4L_raw_points.csv');
RabiH_WriteConvergenceScanCSV(raw, rawCsv);

best = RabiH_SelectBestSeedRecords(raw, scanSpec);
bestCsv = fullfile(outDir,'stage4L_best_seed_points.csv');
RabiH_WriteBestSeedCSV(best, bestCsv);

prelim = struct();
prelim.stage = 'StageRH4L';
prelim.description = ['Seed-resolved preliminary article scan.  Raw points ' ...
    'are evaluated with the StageRH4J shared split CTM backend; best-seed ' ...
    'records are selected by lowest energy within each physical parameter group.'];
prelim.raw = raw;
prelim.best = best;
prelim.rawCsv = rawCsv;
prelim.bestCsv = bestCsv;
prelim.outputDir = outDir;
prelim.paramsBase = paramsBase;
prelim.optsBase = optsBase;
prelim.scanSpec = scanSpec;

save(fullfile(outDir,'stage4L_prelim_scan.mat'),'prelim');
end
