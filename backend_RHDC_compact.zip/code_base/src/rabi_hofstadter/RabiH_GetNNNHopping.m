function [J2, lambda2, includeNNN] = RabiH_GetNNNHopping(params)
%RABIH_GETNNNHOPPING Diagonal/NNN hopping amplitude and enable flag.
%   Supports aliases:
%       J2, t2                    explicit diagonal hopping
%       lambda2, lambda, J2overJ1 ratio to nearest-neighbor hopping
%       includeNNN                explicit boolean enable

    if nargin < 1 || isempty(params), params = struct(); end
    J1 = RabiH_GetNNHopping(params,'generic');
    lambda2 = RabiH_GetOpt(params,'lambda2',RabiH_GetOpt(params,'lambda',RabiH_GetOpt(params,'J2overJ1',0)));
    if isfield(params,'J2')
        J2 = params.J2;
        if abs(J1) > 0, lambda2 = J2/J1; end
    elseif isfield(params,'t2')
        J2 = params.t2;
        if abs(J1) > 0, lambda2 = J2/J1; end
    else
        J2 = lambda2 * J1;
    end
    includeNNN = RabiH_GetOpt(params,'includeNNN',abs(J2) > 0);
end
