function summary = RabiH_SummarizeConvergenceScan(records)
%RABIH_SUMMARIZECONVERGENCESCAN Compact summary for StageRH4K records.

if nargin < 1 || isempty(records)
    summary = struct('numRecords',0,'numOK',0,'numError',0);
    return;
end
ok = arrayfun(@(r) strcmpi(r.status,'ok'), records);
energies = [records.energyPerSite];
rhos = [records.superradiantDensity];
divs = [records.maxCurrentDivergence];
chirErrs = [records.maxChiralityDefinitionError];

summary = struct();
summary.numRecords = numel(records);
summary.numOK = sum(ok);
summary.numError = sum(~ok);
summary.allOK = all(ok);
summary.energyRange = local_range(energies(ok));
summary.rhoSRRange = local_range(rhos(ok));
summary.maxCurrentDivergence = local_max(divs(ok));
summary.maxChiralityDefinitionError = local_max(chirErrs(ok));
summary.maxRuntimeSeconds = local_max([records.runtimeSeconds]);
summary.meanRuntimeSeconds = local_mean([records.runtimeSeconds]);
summary.maxAbsEnergyDeltaVsFirstOK = NaN;
summary.maxAbsRhoDeltaVsFirstOK = NaN;
idx = find(ok,1,'first');
if ~isempty(idx)
    summary.referenceIndex = records(idx).index;
    summary.referenceEnergy = records(idx).energyPerSite;
    summary.referenceRhoSR = records(idx).superradiantDensity;
    summary.maxAbsEnergyDeltaVsFirstOK = max(abs(energies(ok) - summary.referenceEnergy));
    summary.maxAbsRhoDeltaVsFirstOK = max(abs(rhos(ok) - summary.referenceRhoSR));
else
    summary.referenceIndex = NaN;
    summary.referenceEnergy = NaN;
    summary.referenceRhoSR = NaN;
end
end

function r = local_range(x)
if isempty(x)
    r = [NaN NaN];
else
    r = [min(x) max(x)];
end
end

function m = local_max(x)
x = x(~isnan(x));
if isempty(x), m = NaN; else, m = max(x); end
end

function m = local_mean(x)
x = x(~isnan(x));
if isempty(x), m = NaN; else, m = mean(x); end
end
