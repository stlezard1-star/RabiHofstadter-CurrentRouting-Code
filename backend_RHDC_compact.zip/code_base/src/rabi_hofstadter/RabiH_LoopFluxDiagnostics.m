function flux = RabiH_LoopFluxDiagnostics(params, x, y)
%RABIH_LOOPFLUXDIAGNOSTICS Gauge-invariant square and triangular loop fluxes.
%   Plaquette corners: 1=(x,y), 2=(x+1,y), 3=(x+1,y+1), 4=(x,y+1).

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(x), x = 1; end
    if nargin < 3 || isempty(y), y = 1; end

    A12 = RabiH_GaugePhase(x,y,'right',params);
    A23 = RabiH_GaugePhase(x+1,y,'down',params);
    A34 = -RabiH_GaugePhase(x,y+1,'right',params);
    A41 = -RabiH_GaugePhase(x,y,'down',params);
    B13 = RabiH_NNNPhase(x,y,'diagp',params);
    % B24 is the oriented phase 2 -> 4.  It is the reverse of diagm from 4 -> 2.
    B24 = -RabiH_NNNPhase(x,y+1,'diagm',params);

    flux = struct();
    flux.PhiSquare = local_wrap(A12 + A23 + A34 + A41);
    flux.PhiTri123 = local_wrap(A12 + A23 - B13);
    flux.PhiTri134 = local_wrap(B13 + A34 + A41);
    flux.PhiTri124 = local_wrap(A12 + B24 + A41);
    flux.PhiTri234 = local_wrap(A23 + A34 - B24);
    flux.delta13 = local_wrap(0.5*(flux.PhiTri123 - flux.PhiTri134));
    flux.delta24 = local_wrap(0.5*(flux.PhiTri124 - flux.PhiTri234));
    flux.identityErr13 = abs(local_wrap(flux.PhiTri123 + flux.PhiTri134 - flux.PhiSquare));
    flux.identityErr24 = abs(local_wrap(flux.PhiTri124 + flux.PhiTri234 - flux.PhiSquare));
end

function y = local_wrap(x)
    y = atan2(sin(x),cos(x));
end
