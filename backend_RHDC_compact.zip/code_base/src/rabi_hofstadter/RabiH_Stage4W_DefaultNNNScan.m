function [params, opts, spec] = RabiH_Stage4W_DefaultNNNScan()
%RABIH_STAGE4W_DEFAULTNNNSCAN Defaults for NNN hopping/current-pattern diagnostics.
%
% StageRH4W is a preliminary diagnostic layer: NN simple update is still used
% for state optimization, while NNN hopping enters energy, branch selection,
% and full current-pattern observables through the exact small-cell backend.

params = struct();
params.dph = 4;
params.omega = 1.0;
params.Delta = 1.0;
params.gR = 1.0;
params.g = params.gR;
params.J1 = 0.08;
params.t = params.J1;
params.tX = params.J1;
params.tY = params.J1;
params.lambda = 0.2;
params.J2 = params.lambda * params.J1;
params.t2 = params.J2;
params.includeNNN = true;
params.Phi = pi/2;
params.nnnPhaseMode = 'lineIntegral';
params.thetaTri = 0;
params.alphaSeed = 0.8;
params.alphaPattern = 'uniform';
params.spinSeed = 'down';

opts = struct();
opts.Lx = 2;
opts.Ly = 2;
opts.Dmax = 2;
opts.chiMax = 6;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;
opts.svdCutoff = 1e-12;
opts.cacheGates = true;
opts.checkAfter = true;
opts.alpha = params.alphaSeed;
opts.alphaPattern = params.alphaPattern;
opts.spinState = params.spinSeed;
opts.ctmBackend = 'splitFactoredExact';
opts.enableSplitExactTorus = true;
opts.exactLx = 2;
opts.exactLy = 2;
opts.outputDir = fullfile(pwd,'results_stage4W_nnn_current_pattern');
opts.saveEachPoint = true;
opts.verbose = false;

spec = struct();
spec.name = 'StageRH4W_NNN_current_pattern_scan';
spec.description = ['Preliminary NNN hopping and full current-pattern scan.  ' ...
    'The state is optimized with the existing NN simple-update schedule; NNN ' ...
    'terms enter exact-small-cell energy, branch selection, and current diagnostics.'];
spec.gList = [1.0 1.4];
spec.J1List = [0.08 0.16];
spec.lambdaList = [0 0.2 0.4 0.6];
spec.PhiList = pi/2;
spec.thetaTriList = 0;
spec.alphaSeedList = [0 0.8];
spec.alphaPatternList = {'uniform','vortex2x2'};
spec.dphList = 4;
spec.DmaxList = 2;
spec.chiMaxList = 6;
spec.backend = 'splitFactoredExact';
spec.bestSeedCriterion = 'minEnergy';
spec.stopOnError = false;
spec.maxPoints = Inf;
spec.makePlots = false;
spec.tag = datestr(now,'yyyymmdd_HHMMSS');
end
