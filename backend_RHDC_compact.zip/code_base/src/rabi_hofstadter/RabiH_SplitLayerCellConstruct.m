function scell = RabiH_SplitLayerCellConstruct(unitCell, opts)
%RABIH_SPLITLAYERCELLCONSTRUCT Build a split ket/bra cell container.
%
%   scell = RabiH_SplitLayerCellConstruct(unitCell, opts)
%
% StageRH4F purpose:
%   This is the split/factored CTM input container.  It deliberately keeps
%   the PEPS ket tensors A and the bra tensors conj(A) separate.  No local
%   double-layer cell and no 2x2 blocked tensor are allocated here.
%
%   Local double-layer tensors can be materialized lazily with
%       RabiH_SplitLayerLocalDoubleLayer(scell,x,y,op)
%   only when a small validation or local kernel requires it.

    if nargin < 2 || isempty(opts), opts = struct(); end

    iPEPS_CheckUnitCell(unitCell);
    [Ly,Lx] = size(unitCell.A);

    ketDims = zeros(Ly,Lx,5);
    ketElems = zeros(Ly,Lx);
    localDmax = 1;
    localD2max = 1;
    for y = 1:Ly
        for x = 1:Lx
            sz = PEPS_FullSize(unitCell.A{y,x},5);
            ketDims(y,x,:) = sz;
            ketElems(y,x) = prod(double(sz));
            localDmax = max(localDmax, max(sz(2:5)));
            localD2max = max(localD2max, max(sz(2:5)).^2);
        end
    end

    risk = RabiH_BlockedCTMRiskEstimate(unitCell, opts);

    scell = struct();
    scell.type = 'RabiH_StageRH4F_split_layer_cell';
    scell.backend = 'split_factored_ctm_prototype';
    scell.Aket = unitCell.A;
    scell.Abra = local_conj_cell(unitCell.A);
    scell.Lx = Lx;
    scell.Ly = Ly;
    scell.d = unitCell.d;
    scell.Dmax = localDmax;
    scell.maxDoubleLayerLegDim = localD2max;
    scell.ketDims = ketDims;
    scell.ketElements = ketElems;
    scell.maxKetElements = max(ketElems(:));
    scell.totalKetElements = sum(ketElems(:));
    scell.hasBlockedTensor = false;
    scell.hasLocalDoubleLayerCell = false;
    scell.blockedTensorElementsEstimate = risk.blockedTensorElements;
    scell.blockedTensorMBEstimate = risk.blockedTensorMB;
    scell.estimatedNormIntermediateMB = risk.estimatedNormIntermediateMB;
    scell.memoryRatioBlockedOverKet = risk.blockedTensorElements / max(1,scell.totalKetElements);
    scell.isProductionCTM = false;
    scell.note = ['StageRH4F split-layer container.  Ket and bra layers are ' ...
                  'stored separately; local double layers are constructed lazily; ' ...
                  'no blocked unit-cell tensor is allocated.'];
end

function B = local_conj_cell(A)
    B = cell(size(A));
    for yy = 1:size(A,1)
        for xx = 1:size(A,2)
            B{yy,xx} = conj(A{yy,xx});
        end
    end
end
