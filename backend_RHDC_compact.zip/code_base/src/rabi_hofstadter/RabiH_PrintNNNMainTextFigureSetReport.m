function RabiH_PrintNNNMainTextFigureSetReport(figSet)
%RABIH_PRINTNNNMAINTEXTFIGURESETREPORT Print Stage4AC figure-set summary.
fprintf('--- RabiH StageRH4AC main-text NNN figure-set report ---\n');
fprintf('target g, J1          : %.6g, %.6g\n',figSet.targetG,figSet.targetJ1);
fprintf('target records        : %d\n',figSet.numTargetRecords);
fprintf('labels                : ');
for k = 1:numel(figSet.labels), fprintf('%s ',figSet.labels{k}); end
fprintf('\n');
fprintf('triRatio range        : [%.6g, %.6g]\n',figSet.triRatioRange(1),figSet.triRatioRange(2));
fprintf('diagSelection range   : [%.6g, %.6g]\n',figSet.diagSelectionRange(1),figSet.diagSelectionRange(2));
fprintf('strength figure       : %s\n',figSet.strengthFigurePng);
fprintf('signed figure         : %s\n',figSet.signedFigurePng);
fprintf('arrow figure          : %s\n',figSet.arrowFigurePng);
fprintf('selected CSV          : %s\n',figSet.selectedCsv);
fprintf('LaTeX snippet         : %s\n',figSet.snippetFile);
fprintf('selected records:\n');
for k = 1:numel(figSet.selected)
    r = figSet.selected(k).record;
    fprintf('  lambda=% .3f theta/pi=% .3f label=%s triRatio=%.3f diagSel=%.3f j13=% .3e j24=% .3e\n', ...
        r.lambda,r.thetaTri/pi,r.patternLabelRefined,r.triRatio,r.diagSelectionRatio,r.j13,r.j24);
end
end
