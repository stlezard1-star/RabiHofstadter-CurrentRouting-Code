function RabiH_SC_WriteAnalyticBenchmarkCSV(out, outputDir)
%RabiH_SC_WriteAnalyticBenchmarkCSV Write StageRH4AG CSV tables.
if ~exist(outputDir,'dir'), mkdir(outputDir); end
critFile = fullfile(outputDir,'stage4AG_critical_gc_map.csv');
fid = fopen(critFile,'w');
fprintf(fid,'lambda,PhiOverPi,gc,status,minEigAtZero\n');
crit = out.criticalMap;
for a=1:numel(crit.lambdaList)
    for b=1:numel(crit.PhiList)
        fprintf(fid,'%.16g,%.16g,%.16g,%s,%.16g\n',crit.lambdaList(a),crit.PhiList(b)/pi,crit.Gc(a,b),crit.status{a,b},crit.minEigAtZero(a,b));
    end
end
fclose(fid);

phaseFile = fullfile(outputDir,'stage4AG_meanfield_phase_maps.csv');
fid = fopen(phaseFile,'w');
phase = out.phaseMap;
fprintf(fid,'map,lambda,g,thetaTriOverPi,rhoSR,chiSquareAbs,chiTriangleMeanAbs,I13,I24,diagSelection,phaseCode,label\n');
for a=1:numel(phase.lambdaList)
    for b=1:numel(phase.gList)
        fprintf(fid,'g_lambda,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,NaN,NaN,NaN,%.16g,%s\n', ...
            phase.lambdaList(a), phase.gList(b), 0, phase.rhoGL(a,b), phase.chiSqGL(a,b), phase.chiTriGL(a,b), phase.phaseCodeGL(a,b), phase.labelGL{a,b});
    end
end
for a=1:numel(phase.lambdaList)
    for b=1:numel(phase.thetaTriList)
        fprintf(fid,'lambda_theta,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%s\n', ...
            phase.lambdaList(a), phase.fixedG, phase.thetaTriList(b)/pi, phase.rhoLT(a,b), phase.chiSqLT(a,b), phase.chiTriLT(a,b), phase.I13LT(a,b), phase.I24LT(a,b), phase.DiagSelLT(a,b), phase.phaseCodeLT(a,b), phase.labelLT{a,b});
    end
end
fclose(fid);
outFile = fullfile(outputDir,'stage4AG_summary.txt');
fid = fopen(outFile,'w');
fprintf(fid,'StageRH4AG analytic/semi-classical benchmark summary\n');
fprintf(fid,'gc range             : [%.8g, %.8g]\n',out.summary.gcMin,out.summary.gcMax);
fprintf(fid,'max rhoSR GL         : %.8g\n',out.summary.maxRhoGL);
fprintf(fid,'max |chiSquare| GL   : %.8g\n',out.summary.maxChiSqGL);
fprintf(fid,'max mean |chiTri| GL : %.8g\n',out.summary.maxChiTriGL);
fprintf(fid,'max |I13| LT         : %.8g\n',out.summary.maxAbsI13LT);
fprintf(fid,'max |I24| LT         : %.8g\n',out.summary.maxAbsI24LT);
fprintf(fid,'has diag sign change : %d\n',out.summary.hasDiagSignChange);
fclose(fid);
end
