function [params, opts, spec] = RabiH_Stage4Q_DefaultOverlay()
%RABIH_STAGE4Q_DEFAULTOVERLAY Defaults for StageRH4Q accuracy/convergence overlay.
%
% StageRH4Q addresses the main limitation of the present article pipeline:
% the state is optimized by simple update.  Instead of claiming full-update
% accuracy, this diagnostic overlays the StageRH4P/4O representative
% branches with resource and imaginary-time-schedule checks:
%   Dmax, chiMax, dph, sharedBoundaryMix, and SU schedule.
%
% The default is deliberately small but nontrivial.  Enlarge dphList/DmaxList
% only after the demo passes.

[params, opts, ~] = RabiH_Stage4N_DefaultBranchStability();

params.dph = 5;
params.gR = 1.0;
params.t = 0.08;
params.tX = params.t;
params.tY = params.t;
params.Phi = pi/2;
params.alphaSeed = 0.8;
params.alphaPattern = 'uniform';
params.sourceEta = 0;
params.sourcePhase = 0;

opts.Dmax = 2;
opts.chiMax = 6;
opts.ctmBackend = 'splitFactoredShared';
opts.splitBackendMode = 'shared';
opts.sharedBoundaryMix = 0;
opts.outputDir = fullfile(pwd,'results_stage4Q_accuracy_overlay');
opts.saveEachPoint = true;
opts.maxIter = 6;
opts.sharedMaxIter = 6;
opts.svdCutoff = 1e-12;
opts.skipCTMNormHistory = true;
opts.tauList = [0.05 0.025 0.0125];
opts.nSweeps = 2;

spec = struct();
spec.stage = 'StageRH4Q';
spec.name = 'StageRH4Q_accuracy_overlay';
spec.description = ['Accuracy overlay for simple-update article data: ' ...
    'representative branches are recomputed across D, chi, dph, and SU schedules.'];
spec.backend = 'splitFactoredShared';
spec.representativePoints = RabiH_Stage4Q_RepresentativePoints();
spec.DmaxList = [2 3];
spec.chiMaxList = [6 8];
spec.dphList = [5 6];
spec.sharedBoundaryMixList = 0;
spec.sourceEtaList = 0;
spec.sourcePhaseList = 0;
spec.tauSchedules = local_default_schedules();
spec.phaseThresholds = struct('rhoSR',1e-4,'current',1e-5,'chirality',1e-5);
spec.stopOnError = false;
spec.maxRecords = Inf;
spec.outputDir = opts.outputDir;
spec.writeCSV = true;
spec.tag = datestr(now,'yyyymmdd_HHMMSS');
end

function sched = local_default_schedules()
sched = repmat(struct('name','','tauList',[],'nSweeps',[],'maxIter',[],'sharedMaxIter',[]),1,2);
sched(1).name = 'base';
sched(1).tauList = [0.05 0.025 0.0125];
sched(1).nSweeps = 2;
sched(1).maxIter = 6;
sched(1).sharedMaxIter = 6;

sched(2).name = 'refine';
sched(2).tauList = [0.05 0.025 0.0125 0.00625];
sched(2).nSweeps = 3;
sched(2).maxIter = 8;
sched(2).sharedMaxIter = 8;
end
