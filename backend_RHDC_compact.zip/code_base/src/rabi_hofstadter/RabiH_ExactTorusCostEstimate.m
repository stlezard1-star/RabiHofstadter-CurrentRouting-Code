function est = RabiH_ExactTorusCostEstimate(unitCell, opts)
%RABIH_EXACTTORUSCOSTESTIMATE Conservative guard for factored exact-torus contraction.
%
%   est = RabiH_ExactTorusCostEstimate(unitCell, opts)
%
% This guard is used only for StageRH4E benchmark/reference contractions.
% It deliberately avoids CTM_BlockUnitCell.  The estimate is intentionally
% conservative: for an Lx-by-Ly torus with maximum double-layer leg q, the
% naive closed-network bond-state count is q^(2*Lx*Ly).
%
% Default policy:
%   - allow very small exact torus references, e.g. D=2 on a 2x2 cell;
%   - reject D=3 on a 2x2 cell, because q=9 gives q^8 = 4.3e7 states.
%
% This is a benchmark backend, not the production infinite-PEPS CTM backend.

    if nargin < 1
        unitCell = [];
    end
    if nargin < 2 || isempty(opts)
        opts = struct();
    end

    if isempty(unitCell)
        Lx0 = RabiH_GetOpt(opts,'Lx',2);
        Ly0 = RabiH_GetOpt(opts,'Ly',2);
        Dmax = RabiH_GetOpt(opts,'Dmax',2);
        maxLeg = Dmax * Dmax;
        fcell = [];
    else
        fcell = RabiH_FactoredCellConstruct(unitCell, opts);
        Lx0 = fcell.Lx;
        Ly0 = fcell.Ly;
        Dmax = fcell.Dmax;
        maxLeg = fcell.maxDoubleLayerLegDim;
    end

    Lx = RabiH_GetOpt(opts,'exactLx',RabiH_GetOpt(opts,'Lx',Lx0));
    Ly = RabiH_GetOpt(opts,'exactLy',RabiH_GetOpt(opts,'Ly',Ly0));
    nSites = Lx * Ly;
    nBonds = 2 * nSites;

    log10Elements = nBonds * log10(max(1,double(maxLeg)));
    if log10Elements > 300
        naiveElements = Inf;
    else
        naiveElements = double(maxLeg) ^ nBonds;
    end
    bytesPerElement = RabiH_GetOpt(opts,'exactBytesPerElement',16); % complex double default
    naiveMB = naiveElements * bytesPerElement / 1024^2;

    maxSites = RabiH_GetOpt(opts,'maxExactTorusSites',4);
    maxElements = RabiH_GetOpt(opts,'maxExactTorusElements',2e7);
    maxMB = RabiH_GetOpt(opts,'maxExactTorusMB',512);

    isSafe = (nSites <= maxSites) && (naiveElements <= maxElements) && (naiveMB <= maxMB);

    if nSites > maxSites
        reason = sprintf('site count %d exceeds maxExactTorusSites=%d', nSites, maxSites);
    elseif naiveElements > maxElements
        reason = sprintf('naive exact elements %.6g exceeds maxExactTorusElements=%.6g', naiveElements, maxElements);
    elseif naiveMB > maxMB
        reason = sprintf('naive exact memory %.3f MB exceeds maxExactTorusMB=%.3f MB', naiveMB, maxMB);
    else
        reason = 'safe for StageRH4E factored exact-torus benchmark';
    end

    est = struct();
    est.stage = 'StageRH4E';
    est.backend = 'factored_exact_torus_benchmark';
    est.Lx = Lx;
    est.Ly = Ly;
    est.nSites = nSites;
    est.nBonds = nBonds;
    est.Dmax = Dmax;
    est.maxDoubleLayerLegDim = maxLeg;
    est.naiveBondStateElements = naiveElements;
    est.naiveBondStateLog10 = log10Elements;
    est.naiveMemoryMB = naiveMB;
    est.maxExactTorusSites = maxSites;
    est.maxExactTorusElements = maxElements;
    est.maxExactTorusMB = maxMB;
    est.isSafe = isSafe;
    est.reason = reason;
    est.hasBlockedTensor = false;
    est.factoredCell = fcell;
end
