function result = RabiH_RunOnePoint_CoherentNNNMF_SplitFactoredExact(params, opts)
%RABIH_RUNONEPOINT_COHERENTNNNMF_SPLITFACTOREDEXACT Stage4X one-point runner.
    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end
    Lx = RabiH_GetOpt(opts,'Lx',2); Ly = RabiH_GetOpt(opts,'Ly',2);
    seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
    if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
    if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
    if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

    uc = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
    [uc, suInfo] = RabiH_RunNNNMeanFieldSU_Schedule(uc,params,opts);

    splitOpts = opts;
    splitOpts.enableSplitExactTorus = true;
    splitOpts.splitBackendMode = 'exactSmallCell';
    splitOpts.exactLx = RabiH_GetOpt(opts,'exactLx',Lx);
    splitOpts.exactLy = RabiH_GetOpt(opts,'exactLy',Ly);
    obs = RabiH_CTMObservables_SplitFactored(uc,params,splitOpts);

    result = struct();
    result.unitCell = uc; result.suInfo = suInfo; result.obs = obs;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanPhotonNumber = obs.meanPhotonNumber;
    result.meanAbsCurrent = obs.meanAbsCurrent;
    if isfield(obs,'meanAbsChirality'), result.meanAbsChirality = obs.meanAbsChirality; end
    result.alphaSeed = uc.alphaSeed;
    result.backend = 'split_factored_exact_torus_nnn_mean_field_su';
    result.pipelineStage = 'RabiH_v0_6_1_StageRH4X_NNN_mean_field_one_point';
end
