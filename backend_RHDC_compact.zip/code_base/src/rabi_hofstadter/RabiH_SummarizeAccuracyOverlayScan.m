function summary = RabiH_SummarizeAccuracyOverlayScan(records)
%RABIH_SUMMARIZEACCURACYOVERLAYSCAN Summarize StageRH4Q overlay records.

if nargin < 1 || isempty(records)
    summary = struct('numRecords',0,'numOK',0,'numError',0);
    return;
end
okMask = arrayfun(@(r) strcmpi(r.status,'ok'), records);
ok = records(okMask);
summary = struct();
summary.numRecords = numel(records);
summary.numOK = sum(okMask);
summary.numError = summary.numRecords - summary.numOK;
if isempty(ok)
    summary.energyRange = [NaN NaN];
    summary.rhoRange = [NaN NaN];
    summary.maxCurrent = NaN;
    summary.maxChirality = NaN;
    summary.maxCurrentDivergence = NaN;
    summary.maxChiralityDefinitionError = NaN;
    summary.targetMatchFraction = NaN;
    summary.maxBranchDE = NaN;
    summary.maxBranchDRho = NaN;
    summary.maxBranchDCurrent = NaN;
    summary.maxBranchDChirality = NaN;
    summary.branchTable = struct([]);
    return;
end
E = [ok.energyPerSite];
rho = [ok.superradiantDensity];
cur = [ok.meanAbsCurrent];
chi = [ok.meanAbsChirality];
summary.energyRange = [min(E) max(E)];
summary.rhoRange = [min(rho) max(rho)];
summary.maxCurrent = max(cur);
summary.maxChirality = max(chi);
summary.maxCurrentDivergence = max([ok.maxCurrentDivergence]);
summary.maxChiralityDefinitionError = max([ok.maxChiralityDefinitionError]);
summary.targetMatchFraction = mean([ok.matchesTarget]);

branches = unique({ok.branchName});
branchTable = repmat(local_empty_branch(),1,numel(branches));
maxDE = 0; maxDR = 0; maxDJ = 0; maxDC = 0;
for ib = 1:numel(branches)
    b = branches{ib};
    mask = strcmp({ok.branchName},b);
    rr = ok(mask);
    Eb = [rr.energyPerSite]; rhob = [rr.superradiantDensity]; Jb = [rr.meanAbsCurrent]; Cb = [rr.meanAbsChirality];
    branchTable(ib).branchName = b;
    branchTable(ib).numRecords = numel(rr);
    branchTable(ib).targetPhase = rr(1).targetPhase;
    branchTable(ib).phaseLabels = local_join_unique({rr.phaseLabel});
    branchTable(ib).energyRange = [min(Eb) max(Eb)];
    branchTable(ib).rhoRange = [min(rhob) max(rhob)];
    branchTable(ib).currentRange = [min(Jb) max(Jb)];
    branchTable(ib).chiralityRange = [min(Cb) max(Cb)];
    branchTable(ib).targetMatchFraction = mean([rr.matchesTarget]);
    maxDE = max(maxDE, max(Eb)-min(Eb));
    maxDR = max(maxDR, max(rhob)-min(rhob));
    maxDJ = max(maxDJ, max(Jb)-min(Jb));
    maxDC = max(maxDC, max(Cb)-min(Cb));
end
summary.branchTable = branchTable;
summary.maxBranchDE = maxDE;
summary.maxBranchDRho = maxDR;
summary.maxBranchDCurrent = maxDJ;
summary.maxBranchDChirality = maxDC;
end

function b = local_empty_branch()
b = struct('branchName','','targetPhase','','numRecords',0,'phaseLabels','', ...
    'energyRange',[NaN NaN],'rhoRange',[NaN NaN],'currentRange',[NaN NaN], ...
    'chiralityRange',[NaN NaN],'targetMatchFraction',NaN);
end

function s = local_join_unique(c)
if isempty(c), s = ''; return; end
u = unique(c);
s = u{1};
for k = 2:numel(u)
    s = [s '|' u{k}]; %#ok<AGROW>
end
end
