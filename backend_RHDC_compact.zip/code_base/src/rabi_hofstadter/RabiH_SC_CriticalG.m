function crit = RabiH_SC_CriticalG(params, opts)
%RabiH_SC_CriticalG Semianalytic normal-to-SR instability from Hessian.
%   Computes g_c by solving min eig H^(2)(g_c)=0 using the analytic
%   quadratic Hessian.  This is a benchmark for the normal/SR boundary.
if nargin < 2 || isempty(opts), opts = struct(); end
Delta = local_get(params,'Delta',1.0);

tol = local_get(opts,'tol',1e-8);
maxIter = local_get(opts,'maxIter',80);
gMax = local_get(opts,'gMax',4.0);

p0 = params; p0.g = 0;
[~,info0] = RabiH_SC_QuadraticHessian(p0);
if info0.minEig <= 0
    crit = local_pack(0, info0.minEig, info0.minEig, 0, params, 'already_unstable');
    return;
end

lo = 0; hi = gMax;
phi = params;
phi.g = hi;
[~,infoHi] = RabiH_SC_QuadraticHessian(phi);
ngrow = 0;
while infoHi.minEig > 0 && ngrow < 20
    hi = 2*hi;
    phi.g = hi;
    [~,infoHi] = RabiH_SC_QuadraticHessian(phi);
    ngrow = ngrow + 1;
end
if infoHi.minEig > 0
    crit = local_pack(NaN, info0.minEig, infoHi.minEig, ngrow, params, 'not_found');
    return;
end

for it=1:maxIter
    mid = 0.5*(lo+hi);
    pm = params; pm.g = mid;
    [~,infoM] = RabiH_SC_QuadraticHessian(pm);
    if infoM.minEig > 0
        lo = mid;
    else
        hi = mid;
    end
    if abs(hi-lo) < tol
        break;
    end
end

gc = 0.5*(lo+hi);
pc = params; pc.g = gc;
[~,infoC] = RabiH_SC_QuadraticHessian(pc);
crit = local_pack(gc, info0.minEig, infoC.minEig, it, params, 'ok');
crit.Delta = Delta;
end

function crit = local_pack(gc, min0, minC, nIter, params, status)
crit = struct();
crit.gc = gc;
crit.minEigAtZero = min0;
crit.minEigAtGc = minC;
crit.nIter = nIter;
crit.status = status;
crit.params = params;
end

function v = local_get(s,name,defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
