function best = RabiH_SelectBestSeedRecords(scanResult, scanSpec)
%RABIH_SELECTBESTSEEDRECORDS Select lowest-energy seed per physical point.

if nargin < 2 || isempty(scanSpec), scanSpec = struct(); end
records = scanResult.records;
if isempty(records)
    best = struct('records',[],'numGroups',0,'numOKRaw',0,'groupByFields',{{}},'summary',struct());
    return;
end

groupBy = local_get(scanSpec,'groupByFields',{'dph','Dmax','chiMax','sharedBoundaryMix','gR','t','Phi'});
if ischar(groupBy), groupBy = {groupBy}; end
thresholds = local_get(scanSpec,'phaseThresholds',struct());

n = numel(records);
status = cell(1,n);
keys = cell(1,n);
for k = 1:n
    status{k} = records(k).status;
    keys{k} = local_group_key(records(k), groupBy);
end
okMask = strcmpi(status,'ok');
okIdx = find(okMask);
if isempty(okIdx)
    bestRecords = [];
else
    uniqueKeys = unique(keys(okIdx),'stable');
    bestRecords = [];
    for ik = 1:numel(uniqueKeys)
        key = uniqueKeys{ik};
        cand = okIdx(strcmp(keys(okIdx), key));
        E = arrayfun(@(ii) records(ii).energyPerSite, cand);
        [Emin,loc] = min(E); %#ok<ASGLU>
        bestIdx = cand(loc);
        sortedE = sort(E(:));
        if numel(sortedE) >= 2
            gap = sortedE(2) - sortedE(1);
        else
            gap = NaN;
        end
        r = records(bestIdx);
        r.groupKey = key;
        r.numSeedCandidates = numel(cand);
        r.energyGapToNextSeed = gap;
        r.phaseLabel = RabiH_ClassifyPhaseFromRecord(r, thresholds);
        if isempty(bestRecords)
            bestRecords = r;
        else
            bestRecords(end+1) = r; %#ok<AGROW>
        end
    end
end

summary = local_summary(bestRecords, records, groupBy);
best = struct();
best.records = bestRecords;
best.numGroups = numel(bestRecords);
best.numOKRaw = numel(okIdx);
best.groupByFields = {groupBy};
best.summary = summary;
best.rawSummary = scanResult.summary;
end

function key = local_group_key(r, fields)
parts = cell(1,numel(fields));
for i = 1:numel(fields)
    f = fields{i};
    if isfield(r,f)
        v = r.(f);
    else
        v = NaN;
    end
    if isnumeric(v)
        parts{i} = sprintf('%s=%.12g',f,v);
    elseif ischar(v)
        parts{i} = sprintf('%s=%s',f,v);
    else
        parts{i} = sprintf('%s=%s',f,mat2str(v));
    end
end
key = strjoin(parts,'|');
end

function s = local_summary(bestRecords, rawRecords, groupBy)
s = struct();
s.numBestRecords = numel(bestRecords);
s.numRawRecords = numel(rawRecords);
s.groupByFields = {groupBy};
if isempty(bestRecords)
    s.energyRange = [NaN NaN];
    s.rhoSRRange = [NaN NaN];
    s.maxAbsCurrent = NaN;
    s.maxAbsChirality = NaN;
    s.phaseLabels = {};
    return;
end
E = arrayfun(@(r) r.energyPerSite, bestRecords);
rho = arrayfun(@(r) r.superradiantDensity, bestRecords);
cur = arrayfun(@(r) r.meanAbsCurrent, bestRecords);
chi = arrayfun(@(r) r.meanAbsChirality, bestRecords);
labels = cell(1,numel(bestRecords));
for k = 1:numel(bestRecords), labels{k} = bestRecords(k).phaseLabel; end
s.energyRange = [min(E) max(E)];
s.rhoSRRange = [min(rho) max(rho)];
s.maxAbsCurrent = max(abs(cur));
s.maxAbsChirality = max(abs(chi));
s.phaseLabels = unique(labels,'stable');
end

function val = local_get(S, name, defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
