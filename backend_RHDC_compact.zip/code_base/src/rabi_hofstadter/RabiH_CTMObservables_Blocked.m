function obs = RabiH_CTMObservables_Blocked(unitCell, params, opts)
%RABIH_CTMOBSERVABLES_BLOCKED Blocked-CTM observables for Rabi-Hofstadter iPEPS.
%   Measures energy, alpha=<a>, photon number, spin components, NN currents,
%   and plaquette chirality.  This routine is for diagnostics and first scans;
%   hot-loop acceptance should call RabiH_CTMEnergy_Blocked instead.

    if nargin < 3 || isempty(opts), opts = struct(); end
    ctx = RabiH_GetOpt(opts,'ctmContext',[]);
    if isempty(ctx)
        ctx = RabiH_CTMRunBlocked(unitCell, opts);
    end
    dph = RabiH_GetOpt(params,'dph',4);
    ops = RabiH_SiteOps(dph);
    Lx = unitCell.Lx; Ly = unitCell.Ly;

    alpha = zeros(Ly,Lx); nph = zeros(Ly,Lx);
    sx = zeros(Ly,Lx); sy = zeros(Ly,Lx); sz = zeros(Ly,Lx);
    for y = 1:Ly
        for x = 1:Lx
            alpha(y,x) = local_onesite(unitCell, ctx, ops.a,  x,y);
            nph(y,x)   = local_onesite(unitCell, ctx, ops.N,  x,y);
            sx(y,x)    = local_onesite(unitCell, ctx, ops.sx, x,y);
            sy(y,x)    = local_onesite(unitCell, ctx, ops.sy, x,y);
            sz(y,x)    = local_onesite(unitCell, ctx, ops.sz, x,y);
        end
    end

    jRight = zeros(Ly,Lx); jDown = zeros(Ly,Lx);
    for y = 1:Ly
        for x = 1:Lx
            jRight(y,x) = local_current(unitCell, params, ctx, x,y,'right');
            jDown(y,x)  = local_current(unitCell, params, ctx, x,y,'down');
        end
    end
    chirality = zeros(Ly,Lx);
    for y = 1:Ly
        yp = mod(y,Ly)+1;
        for x = 1:Lx
            xp = mod(x,Lx)+1;
            chirality(y,x) = jRight(y,x) + jDown(y,xp) - jRight(yp,x) - jDown(y,x);
        end
    end
    energy = RabiH_CTMEnergy_Blocked(unitCell, params, setfield(opts,'ctmContext',ctx)); %#ok<SFLD>

    obs = struct();
    obs.energyPerSite = energy.energyPerSite;
    obs.energyDetails = energy;
    obs.alpha = alpha;
    obs.photonNumber = local_real_if_safe(nph);
    obs.sx = local_real_if_safe(sx);
    obs.sy = local_real_if_safe(sy);
    obs.sz = local_real_if_safe(sz);
    obs.jRight = local_real_if_safe(jRight);
    obs.jDown = local_real_if_safe(jDown);
    obs.plaquetteChirality = local_real_if_safe(chirality);
    obs.superradiantDensity = mean(abs(alpha(:)).^2);
    obs.meanPhotonNumber = mean(real(nph(:)));
    obs.meanAbsCurrent = mean(abs([jRight(:); jDown(:)]));
    obs.meanAbsChirality = mean(abs(chirality(:)));
    obs.ctx = ctx;
    obs.description = 'StageRH2 blocked-CTM Rabi-Hofstadter observable summary';
end

function val = local_onesite(unitCell, ctx, op, x, y)
    Bop = CTM_BlockUnitCell_OneSiteOp(unitCell, op, x, y);
    val = CTM_EvaluateNorm_Fast(Bop, ctx.W) / ctx.denOne;
    val = local_real_if_safe(val);
end

function val = local_current(unitCell, params, ctx, x, y, direction)
    Lx = unitCell.Lx; Ly = unitCell.Ly;
    switch lower(direction)
        case {'right','x','horizontal'}
            x2 = mod(x,Lx)+1; y2 = y;
            phase = RabiH_GaugePhase(x,y,'right',params);
            tval = RabiH_GetOpt(params,'tX',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denH;
            isInternal = x < Lx;
            pairFun = @CTM_EvaluateHorizontalPair;
        case {'down','y','vertical'}
            x2 = x; y2 = mod(y,Ly)+1;
            phase = RabiH_GaugePhase(x,y,'down',params);
            tval = RabiH_GetOpt(params,'tY',RabiH_GetOpt(params,'t',0.05));
            denPair = ctx.denV;
            isInternal = y < Ly;
            pairFun = @CTM_EvaluateVerticalPair;
        otherwise
            error('RabiH_CTMObservables_Blocked:UnknownDirection','Unknown direction.');
    end
    terms = RabiH_CurrentTerms(params, phase, tval);
    if isInternal
        Bop = CTM_BlockUnitCell_ProductOpTerms(unitCell, terms, x,y,x2,y2);
        val = CTM_EvaluateNorm_Fast(Bop, ctx.W) / ctx.denOne;
    else
        num = 0;
        for k = 1:numel(terms)
            BA = CTM_BlockUnitCell_OneSiteOp(unitCell, terms(k).opA, x, y);
            BB = CTM_BlockUnitCell_OneSiteOp(unitCell, terms(k).opB, x2, y2);
            num = num + terms(k).coeff * pairFun(BA, BB, ctx.env);
        end
        val = num / denPair;
    end
    val = local_real_if_safe(val);
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
