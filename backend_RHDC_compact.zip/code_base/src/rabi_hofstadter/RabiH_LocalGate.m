function [G, Hloc] = RabiH_LocalGate(params, tau)
%RABIH_LOCALGATE Imaginary-time one-site Rabi gate exp(-tau Hloc).
    if nargin < 2 || isempty(tau)
        tau = RabiH_GetOpt(params,'tau',0.01);
    end
    [Hloc,~] = RabiH_LocalHamiltonian(params);
    G = expm(-tau*Hloc);
    G = 0.5*(G + G');
end
