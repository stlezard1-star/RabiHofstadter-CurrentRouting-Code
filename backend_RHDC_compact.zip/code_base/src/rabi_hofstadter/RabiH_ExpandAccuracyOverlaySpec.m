function points = RabiH_ExpandAccuracyOverlaySpec(spec, optsBase, paramsBase)
%RABIH_EXPANDACCURACYOVERLAYSPEC Expand StageRH4Q representative/schedule grid.

if nargin < 1 || isempty(spec), spec = struct(); end
if nargin < 2 || isempty(optsBase), optsBase = struct(); end
if nargin < 3 || isempty(paramsBase), paramsBase = struct(); end

reps = local_get(spec,'representativePoints',RabiH_Stage4Q_RepresentativePoints());
DmaxList = local_get(spec,'DmaxList',RabiH_GetOpt(optsBase,'Dmax',2));
chiMaxList = local_get(spec,'chiMaxList',RabiH_GetOpt(optsBase,'chiMax',6));
dphList = local_get(spec,'dphList',RabiH_GetOpt(paramsBase,'dph',5));
mixList = local_get(spec,'sharedBoundaryMixList',RabiH_GetOpt(optsBase,'sharedBoundaryMix',0));
sourceEtaList = local_get(spec,'sourceEtaList',RabiH_GetOpt(paramsBase,'sourceEta',0));
sourcePhaseList = local_get(spec,'sourcePhaseList',RabiH_GetOpt(paramsBase,'sourcePhase',0));
schedules = local_get(spec,'tauSchedules',local_default_schedules(optsBase));
maxRecords = local_get(spec,'maxRecords',Inf);

points = repmat(local_empty_point(),1,0);
idx = 0;
for ir = 1:numel(reps)
for idph = 1:numel(dphList)
for iD = 1:numel(DmaxList)
for ic = 1:numel(chiMaxList)
for im = 1:numel(mixList)
for ie = 1:numel(sourceEtaList)
for ip = 1:numel(sourcePhaseList)
for is = 1:numel(schedules)
    idx = idx + 1;
    p = local_empty_point();
    p.index = idx;
    p.branchName = reps(ir).name;
    p.targetPhase = reps(ir).targetPhase;
    p.gR = reps(ir).gR;
    p.t = reps(ir).t;
    p.Phi = reps(ir).Phi;
    p.alphaSeed = reps(ir).alphaSeed;
    p.alphaPattern = reps(ir).alphaPattern;
    p.dph = dphList(idph);
    p.Dmax = DmaxList(iD);
    p.chiMax = chiMaxList(ic);
    p.sharedBoundaryMix = mixList(im);
    p.sourceEta = sourceEtaList(ie);
    p.sourcePhase = sourcePhaseList(ip);
    p.scheduleName = schedules(is).name;
    p.tauList = schedules(is).tauList;
    p.nSweeps = schedules(is).nSweeps;
    p.maxIter = schedules(is).maxIter;
    p.sharedMaxIter = schedules(is).sharedMaxIter;
    p.label = sprintf('q%04d_%s_dph%d_D%d_chi%d_%s_mix%.3g', ...
        p.index, p.branchName, p.dph, p.Dmax, p.chiMax, p.scheduleName, p.sharedBoundaryMix);
    points(end+1) = p; %#ok<AGROW>
    if numel(points) >= maxRecords
        return;
    end
end
end
end
end
end
end
end
end
end

function p = local_empty_point()
p = struct();
p.index = NaN;
p.label = '';
p.branchName = '';
p.targetPhase = '';
p.gR = NaN;
p.t = NaN;
p.Phi = NaN;
p.alphaSeed = NaN;
p.alphaPattern = '';
p.dph = NaN;
p.Dmax = NaN;
p.chiMax = NaN;
p.sharedBoundaryMix = NaN;
p.sourceEta = 0;
p.sourcePhase = 0;
p.scheduleName = '';
p.tauList = [];
p.nSweeps = NaN;
p.maxIter = NaN;
p.sharedMaxIter = NaN;
end

function sched = local_default_schedules(optsBase)
sched = struct('name','base','tauList',RabiH_GetOpt(optsBase,'tauList',[0.05 0.025 0.0125]), ...
    'nSweeps',RabiH_GetOpt(optsBase,'nSweeps',2), ...
    'maxIter',RabiH_GetOpt(optsBase,'maxIter',6), ...
    'sharedMaxIter',RabiH_GetOpt(optsBase,'sharedMaxIter',6));
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
