function ctx = RabiH_CTMRunSplitFactoredPeriodic(unitCell, opts)
%RABIH_CTMRUNSPLITFACTOREDPERIODIC StageRH4H periodic split/factored CTM v0.
%
% This is the first periodic multi-site split/factored CTM prototype.  It
% still uses the dense one-site CTM move kernels internally, but the local
% environment around each inequivalent tensor is updated by absorbing the
% corresponding periodic-neighbor tensors rather than repeatedly absorbing
% only the same local tensor as in StageRH4G.
%
% Important scope:
%   - No 2x2 blocked rank-4 tensor is allocated.
%   - Local double layers are built lazily from the split bra/ket cell.
%   - The update is a conservative v0 periodic-neighbor sweep.  It is an
%     accuracy upgrade over the StageRH4G site-wise kernel, but it is not yet
%     a fully optimized split-CTMRG implementation with shared boundary rows
%     and columns.

    if nargin < 2 || isempty(opts), opts = struct(); end

    scell = RabiH_SplitLayerCellConstruct(unitCell, opts);
    splitCost = RabiH_SplitFactoredCTMCostEstimate(unitCell, opts);
    if ~splitCost.isSafe
        error('RabiH_CTMRunSplitFactoredPeriodic:UnsafeSplitCost', ...
            'Split/factored CTM guard refused this point: %s', splitCost.reason);
    end

    chiMax = RabiH_GetOpt(opts,'chiMax',16);
    maxIter = RabiH_GetOpt(opts,'maxIter',RabiH_GetOpt(opts,'periodicMaxIter',20));
    tol = RabiH_GetOpt(opts,'tol',1e-9);
    verbose = RabiH_GetOpt(opts,'verbose',false);

    envOpts = opts;
    envOpts.chiMax = chiMax;
    envOpts.maxIter = maxIter;
    envOpts.tol = tol;
    envOpts.skipNormHistory = RabiH_GetOpt(opts,'skipCTMNormHistory',true) || ...
                              RabiH_GetOpt(opts,'skipNormHistory',false) || ...
                              RabiH_GetOpt(opts,'skipIterNorm',false);

    Lx = scell.Lx;
    Ly = scell.Ly;
    Ecell = cell(Ly,Lx);
    envCell = cell(Ly,Lx);
    WCell = cell(Ly,Lx);
    denOne = zeros(Ly,Lx);
    denH = zeros(Ly,Lx);
    denV = zeros(Ly,Lx);
    histCell = cell(Ly,Lx);
    localDoubleLayerElements = zeros(Ly,Lx);

    for y = 1:Ly
        for x = 1:Lx
            Ecell{y,x} = RabiH_SplitLayerLocalDoubleLayer(scell,x,y);
            localDoubleLayerElements(y,x) = numel(Ecell{y,x});
        end
    end

    for y = 1:Ly
        for x = 1:Lx
            env0 = CTM_InitUniform(Ecell{y,x}, envOpts);
            [env, hist] = local_periodic_iterate(Ecell, env0, x, y, envOpts);
            envCell{y,x} = env;
            histCell{y,x} = hist;
            W = CTM_BuildOneSiteEnvironment(env);
            WCell{y,x} = W;
            denOne(y,x) = CTM_EvaluateNorm_Fast(Ecell{y,x}, W);
            if abs(denOne(y,x)) < eps
                error('RabiH_CTMRunSplitFactoredPeriodic:ZeroNorm', ...
                    'Encountered zero periodic CTM one-site norm at site (%d,%d).', x, y);
            end
        end
    end

    for y = 1:Ly
        for x = 1:Lx
            xp = mod(x,Lx)+1;
            yp = mod(y,Ly)+1;
            denH(y,x) = CTM_EvaluateHorizontalPair(Ecell{y,x}, Ecell{y,xp}, envCell{y,x});
            denV(y,x) = CTM_EvaluateVerticalPair(Ecell{y,x}, Ecell{yp,x}, envCell{y,x});
            if abs(denH(y,x)) < eps || abs(denV(y,x)) < eps
                error('RabiH_CTMRunSplitFactoredPeriodic:ZeroPairNorm', ...
                    'Encountered zero periodic CTM pair norm at site (%d,%d).', x, y);
            end
        end
    end

    ctx = struct();
    ctx.stage = 'StageRH4H';
    ctx.backend = 'split_factored_ctm_v0_periodic_neighbor';
    ctx.description = ['StageRH4H periodic split/factored CTM v0.  ' ...
        'No blocked unit-cell tensor is allocated.  Each inequivalent site ' ...
        'has a local CTM environment updated by periodic-neighbor absorption.'];
    ctx.splitCell = scell;
    ctx.cost = splitCost;
    ctx.hasBlockedTensor = false;
    ctx.hasLocalDoubleLayerCell = true;
    ctx.isProductionCTM = true;
    ctx.productionLevel = 'StageRH4H_v0_periodic_neighbor_split_ctm';
    ctx.Ecell = Ecell;
    ctx.envCell = envCell;
    ctx.WCell = WCell;
    ctx.denOne = local_real_if_safe(denOne);
    ctx.denH = local_real_if_safe(denH);
    ctx.denV = local_real_if_safe(denV);
    ctx.histCell = histCell;
    ctx.localDoubleLayerElements = localDoubleLayerElements;
    ctx.maxLocalDoubleLayerElements = max(localDoubleLayerElements(:));
    ctx.chiMax = chiMax;
    ctx.maxIter = maxIter;
    ctx.tol = tol;
    ctx.absorptionPolicy = 'periodic-neighbor sweep: left/right/up/down absorb adjacent unit-cell tensors';
    ctx.warning = ['StageRH4H is the first periodic-neighbor split/factored CTM ' ...
        'kernel.  Use it for accuracy upgrades over StageRH4G and convergence ' ...
        'tests.  Final production data should still be checked against later ' ...
        'optimized shared-boundary split-CTMRG when available.'];

    if verbose
        fprintf('[StageRH4H] periodic split/factored CTM v0 built. max local DL elems=%g, chiMax=%d\n', ...
            ctx.maxLocalDoubleLayerElements, chiMax);
    end
end

function [env, history] = local_periodic_iterate(Ecell, env, x, y, opts)
    maxIter = CTM_GetOpt(opts,'maxIter',20);
    tol = CTM_GetOpt(opts,'tol',1e-9);
    verbose = CTM_GetOpt(opts,'verbose',false);
    skipNormHistory = CTM_GetOpt(opts,'skipNormHistory',true) || ...
                      CTM_GetOpt(opts,'skipIterNorm',false) || ...
                      CTM_GetOpt(opts,'skipCTMNormHistory',false);

    history = zeros(maxIter,2);
    for it = 1:maxIter
        oldEnv = CTM_NormalizeEnv(env);
        [env,~] = local_periodic_one_cycle(Ecell, env, x, y, opts);
        env = CTM_NormalizeEnv(env);
        diffVal = CTM_EnvDiff(env, oldEnv);
        if skipNormHistory
            normVal = NaN;
        else
            normVal = CTM_EvaluateNorm(Ecell{y,x}, env);
        end
        history(it,:) = [diffVal, normVal];
        env.lastDiff = diffVal;
        env.history = history(1:it,:);
        env.iter = it;
        if verbose
            if skipNormHistory
                fprintf('[StageRH4H-CTM] site(%d,%d) iter %4d: diff = %.3e, norm = skipped\n', ...
                    x, y, it, diffVal);
            else
                fprintf('[StageRH4H-CTM] site(%d,%d) iter %4d: diff = %.3e, norm = %.12e\n', ...
                    x, y, it, diffVal, normVal);
            end
        end
        if diffVal < tol
            history = history(1:it,:);
            env.history = history;
            return;
        end
    end
    history = history(1:maxIter,:);
    env.history = history;
end

function [env, info] = local_periodic_one_cycle(Ecell, env, x, y, opts)
    [Ly,Lx] = size(Ecell);
    xm = mod(x-2,Lx)+1;
    xp = mod(x,Lx)+1;
    ym = mod(y-2,Ly)+1;
    yp = mod(y,Ly)+1;

    [env, infoL] = CTM_MoveLeft(Ecell{y,xm}, env, opts);
    [env, infoR] = CTM_MoveRight(Ecell{y,xp}, env, opts);
    [env, infoU] = CTM_MoveUp(Ecell{ym,x}, env, opts);
    [env, infoD] = CTM_MoveDown(Ecell{yp,x}, env, opts);
    env = CTM_NormalizeEnv(env);
    CTM_CheckEnv(env);

    info = struct();
    info.left = infoL;
    info.right = infoR;
    info.up = infoU;
    info.down = infoD;
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
