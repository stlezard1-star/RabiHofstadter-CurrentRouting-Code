function out = RabiH_WriteCitationAuditReport(spec)
%RabiH_WriteCitationAuditReport  Write StageRH4AE citation/scope-audit notes.
if nargin<1 || isempty(spec)
    spec = RabiH_Stage4AE_DefaultSpec();
end
if ~isfield(spec,'outputDir') || isempty(spec.outputDir)
    spec.outputDir = fullfile(pwd,'results_stage4AE_citation_audit');
end
if ~exist(spec.outputDir,'dir'), mkdir(spec.outputDir); end

mdFile = fullfile(spec.outputDir,'StageRH4AE_citation_scope_audit.md');
fid = fopen(mdFile,'w');
assert(fid>0,'Could not open audit report for writing.');
fprintf(fid,'# StageRH4AE citation and scope audit\n\n');
fprintf(fid,'Manuscript version: `%s`\n\n',spec.manuscriptVersion);
fprintf(fid,'## Scope checklist\n\n');
for k=1:numel(spec.scopeItems)
    fprintf(fid,'- [x] %s\n',spec.scopeItems{k});
end
fprintf(fid,'\n## Manuscript positioning\n\n');
fprintf(fid,['The finite Rabi-ring, Dicke-triangle, Rabi-hexagon, and Rabi-square literature already establishes finite-loop chiral superradiance or finite-cluster frustrated superradiance. ', ...
    'The manuscript should therefore frame the present result as a thermodynamic two-dimensional loop-current texture controlled by square plaquette flux and triangular-loop frustration.\n\n']);
fprintf(fid,'## Recommended novelty statement\n\n');
fprintf(fid,['Nearest-neighbor flux stabilizes a square-loop chiral superradiant background, while diagonal next-nearest-neighbor hopping and triangular-flux imbalance redistribute the current between square and triangular subloops, producing square-dominant, triangular-enhanced, diagonal-selected, and mixed chiral superradiant patterns.\n\n']);
fprintf(fid,'## Numerical caveat\n\n');
fprintf(fid,['The diagonal NNN update is an explicit path-gate update and should not be described as a full variational plaquette update. ', ...
    'The manuscript should focus on robust current-pattern classification rather than critical exponents.\n']);
fclose(fid);

out = struct();
out.auditFile = mdFile;
out.readyForManuscriptV3 = spec.readyForManuscriptV3;
out.numScopeItems = numel(spec.scopeItems);
end
