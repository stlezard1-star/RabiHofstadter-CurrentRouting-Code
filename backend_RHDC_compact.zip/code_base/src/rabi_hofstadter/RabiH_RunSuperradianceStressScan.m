function stress = RabiH_RunSuperradianceStressScan(paramsBase, optsBase, spec)
%RABIH_RUNSUPERRADIANCESTRESSSCAN Run StageRH4M seed-resolved stress scan.
%
% This is a wrapper around the StageRH4L preliminary scan machinery, with a
% separate summary focused on whether the best branch remains alpha=0.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4M_DefaultStressScan();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec)
    spec = struct();
end

optsBase.ctmBackend = RabiH_GetOpt(optsBase,'ctmBackend','splitFactoredShared');
optsBase.splitBackendMode = 'shared';
spec.backend = RabiH_GetOpt(spec,'backend','splitFactoredShared');

outDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4M_sr_stress'));
if exist(outDir,'dir') ~= 7
    mkdir(outDir);
end

prelim = RabiH_RunPreliminaryArticleScan(paramsBase, optsBase, spec);
summary = RabiH_SummarizeSuperradianceStressScan(prelim.best);

stress = struct();
stress.stage = 'StageRH4M';
stress.description = ['Superradiance stress scan: high-gR/high-seed diagnostic ' ...
    'for locating nonzero-alpha branches and checking whether Stage4L only ' ...
    'sampled the normal phase.'];
stress.prelim = prelim;
stress.raw = prelim.raw;
stress.best = prelim.best;
stress.summary = summary;
stress.outputDir = outDir;
stress.rawCsv = prelim.rawCsv;
stress.bestCsv = prelim.bestCsv;
stress.paramsBase = paramsBase;
stress.optsBase = optsBase;
stress.scanSpec = spec;

save(fullfile(outDir,'stage4M_sr_stress_scan.mat'),'stress');
end
