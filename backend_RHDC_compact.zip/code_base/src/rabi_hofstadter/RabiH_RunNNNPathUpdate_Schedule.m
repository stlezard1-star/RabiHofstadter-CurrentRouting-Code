function [unitCell, info] = RabiH_RunNNNPathUpdate_Schedule(unitCell, params, opts)
%RABIH_RUNNNNPATHUPDATE_SCHEDULE NN simple update plus explicit diagonal path gates.
%
%   StageRH4Y update kernel.  NNN diagonal two-site gates are applied using
%   SU_ApplyThreeSiteEndGate_Path on a three-site NN path, routing the
%   diagonal correlation through the existing PEPS graph.  This goes beyond
%   the StageRH4X mean-field source update: J2 now enters the tensor update
%   through actual two-site physical gates.
%
%   Supported diagonal paths:
%       diagP: (x,y) -> (x+1,y+1), routed through (x+1,y)
%       diagM: (x,y) -> (x+1,y-1), routed through (x+1,y)

    if nargin < 3 || isempty(opts), opts = struct(); end
    tauList = RabiH_GetOpt(opts,'tauList',RabiH_GetOpt(params,'tauList',[0.04 0.02 0.01]));
    nSweeps = RabiH_GetOpt(opts,'nSweeps',1);
    Dmax = RabiH_GetOpt(opts,'Dmax',unitCell.D);
    checkAfter = RabiH_GetOpt(opts,'checkAfter',true);
    includeNNN = RabiH_GetOpt(params,'includeNNN',true);
    [J2,~,include2] = RabiH_GetNNNHopping(params);
    includeNNN = includeNNN && include2 && abs(J2) > 0;
    applyNN = RabiH_GetOpt(opts,'applyNNGates',true);
    applyDiagP = RabiH_GetOpt(opts,'applyDiagPGates',true);
    applyDiagM = RabiH_GetOpt(opts,'applyDiagMGates',true);

    Lx = unitCell.Lx; Ly = unitCell.Ly;
    info = struct();
    info.stage = 'StageRH4Y';
    info.note = 'NN simple update plus explicit NNN path-gate update.';
    info.tauList = tauList; info.nSweeps = nSweeps; info.Dmax = Dmax;
    info.includeNNN = includeNNN;
    info.relDiscardedWeight = [];
    info.keep = [];
    info.diagRelDiscardedWeight = [];
    info.diagKeep = [];
    info.step = struct('tau',{},'sweep',{},'meanNNDiscarded',{},'meanDiagDiscarded',{},'maxKeep',{});

    stepPtr=0;
    for kt=1:numel(tauList)
        tau = tauList(kt);
        nnGates = RabiH_PrecomputeNNGates(params,tau,Lx,Ly);
        for sw=1:nSweeps
            unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, nnGates.GlocHalf);
            nnDW=[]; nnKeep=[]; dgDW=[]; dgKeep=[];

            if applyNN
                for y=1:Ly
                    for x=1:Lx
                        xp=mod(x,Lx)+1;
                        [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x},unitCell.A{y,xp},'right',nnGates.Gx{y,x},Dmax,opts);
                        unitCell.A{y,x}=Anew; unitCell.A{y,xp}=Bnew;
                        nnDW(end+1)=local_get(sinfo,'relDiscardedWeight',NaN); %#ok<AGROW>
                        nnKeep(end+1)=local_get(sinfo,'keep',NaN); %#ok<AGROW>
                    end
                end
                for y=1:Ly
                    yp=mod(y,Ly)+1;
                    for x=1:Lx
                        [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x},unitCell.A{yp,x},'down',nnGates.Gy{y,x},Dmax,opts);
                        unitCell.A{y,x}=Anew; unitCell.A{yp,x}=Bnew;
                        nnDW(end+1)=local_get(sinfo,'relDiscardedWeight',NaN); %#ok<AGROW>
                        nnKeep(end+1)=local_get(sinfo,'keep',NaN); %#ok<AGROW>
                    end
                end
            end

            if includeNNN
                if applyDiagP
                    for y=1:Ly
                        yp=mod(y,Ly)+1;
                        for x=1:Lx
                            xp=mod(x,Lx)+1;
                            G = RabiH_DiagonalHoppingGate(params,x,y,'diagp',tau);
                            [Anew,Bnew,Cnew,sinfo] = SU_ApplyThreeSiteEndGate_Path(unitCell.A{y,x},unitCell.A{y,xp},unitCell.A{yp,xp},'right_down',G,Dmax,opts);
                            unitCell.A{y,x}=Anew; unitCell.A{y,xp}=Bnew; unitCell.A{yp,xp}=Cnew;
                            dgDW(end+1)=local_get(sinfo,'relDiscardedWeight',NaN); %#ok<AGROW>
                            dgKeep(end+1)=local_get(sinfo,'maxKeep',NaN); %#ok<AGROW>
                        end
                    end
                end
                if applyDiagM
                    for y=1:Ly
                        ym=mod(y-2,Ly)+1;
                        for x=1:Lx
                            xp=mod(x,Lx)+1;
                            G = RabiH_DiagonalHoppingGate(params,x,y,'diagm',tau);
                            [Anew,Bnew,Cnew,sinfo] = SU_ApplyThreeSiteEndGate_Path(unitCell.A{y,x},unitCell.A{y,xp},unitCell.A{ym,xp},'right_up',G,Dmax,opts);
                            unitCell.A{y,x}=Anew; unitCell.A{y,xp}=Bnew; unitCell.A{ym,xp}=Cnew;
                            dgDW(end+1)=local_get(sinfo,'relDiscardedWeight',NaN); %#ok<AGROW>
                            dgKeep(end+1)=local_get(sinfo,'maxKeep',NaN); %#ok<AGROW>
                        end
                    end
                end
            end
            unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, nnGates.GlocHalf);
            unitCell = iPEPS_NormalizeUnitCell(unitCell);
            info.relDiscardedWeight = [info.relDiscardedWeight; local_row(nnDW)]; %#ok<AGROW>
            info.keep = [info.keep; local_row(nnKeep)]; %#ok<AGROW>
            info.diagRelDiscardedWeight = [info.diagRelDiscardedWeight; local_row(dgDW)]; %#ok<AGROW>
            info.diagKeep = [info.diagKeep; local_row(dgKeep)]; %#ok<AGROW>
            stepPtr=stepPtr+1;
            info.step(stepPtr).tau=tau; info.step(stepPtr).sweep=sw;
            info.step(stepPtr).meanNNDiscarded=local_nanmean(nnDW);
            info.step(stepPtr).meanDiagDiscarded=local_nanmean(dgDW);
            info.step(stepPtr).maxKeep=max([nnKeep(:); dgKeep(:); NaN]);
        end
    end
    unitCell.stage='RabiH_StageRH4Y_NNN_path_update';
    unitCell.D=local_maxD(unitCell);
    if checkAfter, iPEPS_CheckUnitCell(unitCell); end
end

function v=local_get(s,name,defaultVal)
    if isstruct(s) && isfield(s,name) && ~isempty(s.(name)), v=s.(name); else, v=defaultVal; end
end
function row=local_row(v)
    if isempty(v), row=NaN; else, row=v(:).'; end
end
function m=local_nanmean(v)
    v=v(isfinite(v)); if isempty(v), m=NaN; else, m=mean(v); end
end
function D=local_maxD(unitCell)
    D=1;
    for y=1:unitCell.Ly
        for x=1:unitCell.Lx
            sz=PEPS_FullSize(unitCell.A{y,x},5); D=max(D,max(sz(2:5)));
        end
    end
end
