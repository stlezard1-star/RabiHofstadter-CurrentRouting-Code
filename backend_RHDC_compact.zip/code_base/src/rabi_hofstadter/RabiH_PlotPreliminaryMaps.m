function RabiH_PlotPreliminaryMaps(prelim, outDir)
%RABIH_PLOTPRELIMINARYMAPS Generate simple StageRH4L map figures.
%
% The function uses saveas/print instead of exportgraphics for MATLAB 2018
% compatibility.  It creates one heat map per observable for each t value
% found in the best-seed records.

if nargin < 2 || isempty(outDir)
    if isfield(prelim,'outputDir'), outDir = prelim.outputDir; else, outDir = pwd; end
end
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
if isfield(prelim,'best'), records = prelim.best.records; else, records = prelim.records; end
if isempty(records), return; end

obsList = {'energyPerSite','superradiantDensity','meanAbsCurrent','meanAbsChirality'};
tVals = unique(arrayfun(@(r) r.t, records));
for it = 1:numel(tVals)
    tval = tVals(it);
    sub = records(abs(arrayfun(@(r) r.t, records)-tval) < 1e-12);
    gVals = unique(arrayfun(@(r) r.gR, sub));
    phiVals = unique(arrayfun(@(r) r.Phi, sub));
    for io = 1:numel(obsList)
        obsName = obsList{io};
        Z = NaN(numel(gVals),numel(phiVals));
        for kg = 1:numel(gVals)
            for kp = 1:numel(phiVals)
                mask = abs(arrayfun(@(r) r.gR, sub)-gVals(kg)) < 1e-12 & ...
                       abs(arrayfun(@(r) r.Phi, sub)-phiVals(kp)) < 1e-12;
                if any(mask)
                    idx = find(mask,1,'first');
                    Z(kg,kp) = sub(idx).(obsName);
                end
            end
        end
        fig = figure('Visible','off');
        imagesc(phiVals/pi, gVals, Z);
        set(gca,'YDir','normal');
        xlabel('\Phi/\pi'); ylabel('g_R');
        title(sprintf('%s, t=%.4g', obsName, tval),'Interpreter','none');
        colorbar;
        base = sprintf('stage4L_map_%s_t%.4g', obsName, tval);
        base = regexprep(base,'[^a-zA-Z0-9_\.-]','_');
        saveas(fig, fullfile(outDir,[base '.fig']));
        print(fig, fullfile(outDir,[base '.png']), '-dpng', '-r200');
        close(fig);
    end
end
end
