function RabiH_PrintPreliminaryScanReport(prelim)
%RABIH_PRINTPRELIMINARYSCANREPORT Print StageRH4L best-seed summary.

if isfield(prelim,'best')
    best = prelim.best;
else
    best = prelim;
end
records = best.records;
summary = best.summary;

fprintf('--- RabiH StageRH4L preliminary article scan report ---\n');
fprintf('best physical points : %d\n', numel(records));
fprintf('raw ok records       : %d\n', best.numOKRaw);
fprintf('energy range         : [%.12g, %.12g]\n', summary.energyRange(1), summary.energyRange(2));
fprintf('rhoSR range          : [%.12g, %.12g]\n', summary.rhoSRRange(1), summary.rhoSRRange(2));
fprintf('max |current|        : %.6e\n', summary.maxAbsCurrent);
fprintf('max |chirality|      : %.6e\n', summary.maxAbsChirality);
if isfield(prelim,'bestCsv')
    fprintf('best-seed CSV        : %s\n', prelim.bestCsv);
end
fprintf('label       gR       t      Phi/pi    E/site          rhoSR       |J|       |chi|     seed pattern\n');
for k = 1:numel(records)
    r = records(k);
    fprintf('%-9s %6.3g %6.3g %8.3f %16.9g %11.4e %9.2e %9.2e %6.3g %s\n', ...
        local_trunc(local_field(r,'phaseLabel',''),9), r.gR, r.t, r.Phi/pi, ...
        r.energyPerSite, r.superradiantDensity, r.meanAbsCurrent, r.meanAbsChirality, ...
        r.alphaSeed, r.alphaPattern);
end
end

function s = local_trunc(s,n)
if numel(s) > n, s = s(1:n); end
end

function v = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end
