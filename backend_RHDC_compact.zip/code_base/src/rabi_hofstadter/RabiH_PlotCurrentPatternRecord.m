function RabiH_PlotCurrentPatternRecord(rec)
%RABIH_PLOTCURRENTPATTERNRECORD Plot directed NN/NNN currents on one square plaquette.
coords = [0 0; 1 0; 1 1; 0 1];
plot([coords(:,1);coords(1,1)],[coords(:,2);coords(1,2)],'k-','LineWidth',1); hold on;
plot([0 1],[0 1],'k:','LineWidth',0.8); plot([1 0],[0 1],'k:','LineWidth',0.8);
axis equal off; xlim([-0.25 1.25]); ylim([-0.25 1.25]);
text(coords(:,1)-0.04,coords(:,2)-0.06,{'1','2','3','4'});
I = [getnum(rec,'j12'), getnum(rec,'j23'), getnum(rec,'j34'), getnum(rec,'j41'), getnum(rec,'j13'), getnum(rec,'j24')];
maxI = max(abs(I(isfinite(I)))); if isempty(maxI) || maxI==0, maxI=1; end
local_arrow(coords(1,:),coords(2,:),getnum(rec,'j12'),maxI);
local_arrow(coords(2,:),coords(3,:),getnum(rec,'j23'),maxI);
local_arrow(coords(3,:),coords(4,:),getnum(rec,'j34'),maxI);
local_arrow(coords(4,:),coords(1,:),getnum(rec,'j41'),maxI);
local_arrow(coords(1,:),coords(3,:),getnum(rec,'j13'),maxI);
local_arrow(coords(2,:),coords(4,:),getnum(rec,'j24'),maxI);
text(0.02,1.15,sprintf('|chiSq|=%.2g, |chiTri|=%.2g',abs(getnum(rec,'chiSquare')),getnum(rec,'meanAbsTriangularChirality')),'FontSize',8);
end
function local_arrow(p1,p2,I,maxI)
if ~isfinite(I) || abs(I)<1e-14, return; end
if I<0, tmp=p1; p1=p2; p2=tmp; I=-I; end
mid = 0.5*(p1+p2); vec = p2-p1; L = norm(vec); if L==0, return; end
vec = vec/L; scale = 0.35 + 0.35*min(1,abs(I)/maxI);
start = mid - 0.5*scale*vec; dv = scale*vec;
quiver(start(1),start(2),dv(1),dv(2),0,'LineWidth',1.4,'MaxHeadSize',0.5);
end
function v=getnum(r,name)
if isstruct(r) && isfield(r,name) && ~isempty(r.(name)), v=real(r.(name)); else, v=NaN; end
end
