function env = RabiH_SplitCTMInitMinimal(scell, opts)
%RABIH_SPLITCTMINITMINIMAL Minimal placeholder environment for StageRH4F.
%
% This is not yet a production CTMRG environment.  It records dimensions and
% local absorption plans so that the split/factored backend can be routed,
% profiled, and tested without allocating blocked tensors.

    if nargin < 2 || isempty(opts), opts = struct(); end
    chiMax = RabiH_GetOpt(opts,'chiMax',RabiH_GetOpt(opts,'chiCTM',16));
    env = struct();
    env.stage = 'StageRH4F';
    env.backend = 'split_factored_ctm_prototype_env';
    env.Lx = scell.Lx;
    env.Ly = scell.Ly;
    env.Dmax = scell.Dmax;
    env.maxDoubleLayerLegDim = scell.maxDoubleLayerLegDim;
    env.chiMax = chiMax;
    env.hasBlockedTensor = false;
    env.isProductionCTM = false;
    env.plans.left  = RabiH_SplitCTMAbsorbPlan(scell,'left',opts);
    env.plans.right = RabiH_SplitCTMAbsorbPlan(scell,'right',opts);
    env.plans.up    = RabiH_SplitCTMAbsorbPlan(scell,'up',opts);
    env.plans.down  = RabiH_SplitCTMAbsorbPlan(scell,'down',opts);
    env.iter = 0;
    env.history = [];
    env.note = ['Minimal split/factored CTM environment.  It is a safe route ' ...
                'and interface test; production absorption/truncation is the ' ...
                'next implementation target.'];
end
