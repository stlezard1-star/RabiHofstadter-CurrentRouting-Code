function RabiH_PrintAppendixConvergenceReport(pack)
%RABIH_PRINTAPPENDIXCONVERGENCEREPORT Print StageRH4U summary.
if isfield(pack,'summaryU')
    s = pack.summaryU;
else
    s = RabiH_SummarizeAppendixConvergencePack(pack);
end
fprintf('--- RabiH StageRH4U Appendix convergence pack report ---\n');
fprintf('Stage4Q phase match           : %.3f\n', s.stage4QPhaseMatch);
fprintf('Stage4Q max current div       : %.6e\n', s.stage4QMaxCurrentDivergence);
fprintf('Stage4Q max chirality err     : %.6e\n', s.stage4QMaxChiralityError);
fprintf('Stage4Q max branch |dE|       : %.6e\n', s.stage4QMaxBranchDE);
fprintf('Stage4Q max branch |dRho|     : %.6e\n', s.stage4QMaxBranchDRho);
fprintf('Stage4Q max branch |dJ|       : %.6e\n', s.stage4QMaxBranchDCurrent);
fprintf('Stage4Q max branch |dChi|     : %.6e\n', s.stage4QMaxBranchDChirality);
fprintf('Stage4T phase match           : %.3f\n', s.stage4TPhaseMatch);
fprintf('Stage4T phase-label errors    : %d\n', s.stage4TPhaseErrors);
fprintf('Stage4T max |dE| full/LBO     : %.6e\n', s.stage4TMaxAbsDE);
fprintf('Stage4T max rel d rhoSR       : %.6e\n', s.stage4TMaxRelRhoSR);
fprintf('Stage4T max rel d |J|         : %.6e\n', s.stage4TMaxRelCurrent);
fprintf('Stage4T max rel d |chi|       : %.6e\n', s.stage4TMaxRelChirality);
fprintf('Stage4T mean speedup          : %.3f\n', s.stage4TMeanSpeedup);
fprintf('Stage4T hop-dim reduction     : [%.3g, %.3g]\n', s.stage4THopDimReduction(1), s.stage4THopDimReduction(2));
fprintf('ready for Appendix            : %d\n', double(s.readyForAppendix));
fprintf('recommendation                : %s\n', s.recommendation);
if isfield(pack,'csvFiles') && isfield(pack.csvFiles,'summary')
    fprintf('summary CSV                   : %s\n', pack.csvFiles.summary);
end
if isfield(pack,'figureFiles') && isfield(pack.figureFiles,'accuracyOverlay')
    fprintf('accuracy figure               : %s\n', pack.figureFiles.accuracyOverlayPNG);
    fprintf('LBO figure                    : %s\n', pack.figureFiles.lboPNG);
end
end
