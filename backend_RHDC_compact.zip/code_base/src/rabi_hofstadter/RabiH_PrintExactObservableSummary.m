function RabiH_PrintExactObservableSummary(obs)
%RABIH_PRINTEXACTOBSERVABLESUMMARY Compact StageRH1 observable printout.
    fprintf('--- RabiH StageRH1 exact observable summary ---\n');
    fprintf('Lx=%d, Ly=%d, E/site=%.12g\n', obs.Lx, obs.Ly, real(obs.energyPerSite));
    fprintf('rhoSR=%.3e, meanN=%.3e, mean|J|=%.3e, mean|chi|=%.3e\n', ...
        real(obs.superradiantDensity), real(obs.meanPhotonNumber), real(obs.meanAbsCurrent), real(obs.meanAbsChirality));
end
