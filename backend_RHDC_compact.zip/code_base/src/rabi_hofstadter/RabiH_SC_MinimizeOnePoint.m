function result = RabiH_SC_MinimizeOnePoint(params, opts)
%RabiH_SC_MinimizeOnePoint  Multi-start fminsearch minimization of E_cl.
if nargin < 2 || isempty(opts)
    opts = struct();
end
if isfield(opts,'randomSeed') && ~isempty(opts.randomSeed)
    rng(opts.randomSeed);
end
amplitudes = local_get(opts,'amplitudes',[0 0.05 0.2 0.6 1.0 1.4]);
randomStarts = local_get(opts,'randomStarts',8);
maxIter = local_get(opts,'maxIter',5000);
maxFunEvals = local_get(opts,'maxFunEvals',20000);
tolX = local_get(opts,'tolX',1e-8);
tolFun = local_get(opts,'tolFun',1e-10);

x0s = local_seed_list(amplitudes, randomStarts);
options = optimset('Display','off','MaxIter',maxIter,'MaxFunEvals',maxFunEvals, ...
    'TolX',tolX,'TolFun',tolFun);

bestE = inf;
bestX = x0s(1,:);
bestExit = NaN;
bestOut = struct();
for k = 1:size(x0s,1)
    x0 = x0s(k,:);
    [xopt, Eopt, exitflag, output] = fminsearch(@(x) RabiH_SC_Energy(x,params), x0, options);
    if isfinite(Eopt) && Eopt < bestE
        bestE = Eopt;
        bestX = xopt;
        bestExit = exitflag;
        bestOut = output;
    end
end
alpha = bestX(1:4) + 1i*bestX(5:8);
obs = RabiH_SC_Observables(alpha, params);

result = struct();
result.status = 'ok';
result.message = '';
result.params = params;
result.alpha = alpha;
result.x = bestX;
result.energy = bestE;
result.energyPerSite = bestE/4;
result.obs = obs;
result.exitflag = bestExit;
result.output = bestOut;
result.numStarts = size(x0s,1);
result.patternLabel = obs.patternLabel;
result.patternCode = obs.patternCode;
end

function x0s = local_seed_list(amplitudes, randomStarts)
phasePatterns = [ ...
    0 0 0 0; ...
    0 pi/2 pi 3*pi/2; ...
    0 -pi/2 -pi -3*pi/2; ...
    0 pi 0 pi; ...
    0 0 pi pi; ...
    0 pi pi 0];
rows = {};
for a = amplitudes(:).'
    for p = 1:size(phasePatterns,1)
        alpha = a * exp(1i*phasePatterns(p,:));
        rows{end+1,1} = [real(alpha) imag(alpha)]; %#ok<AGROW>
    end
end
for k = 1:randomStarts
    amp = 1.5*rand(1,4);
    ph = 2*pi*rand(1,4);
    alpha = amp .* exp(1i*ph);
    rows{end+1,1} = [real(alpha) imag(alpha)]; %#ok<AGROW>
end
x0s = zeros(numel(rows),8);
for k = 1:numel(rows)
    x0s(k,:) = rows{k};
end
end

function v = local_get(s, name, defaultVal)
if isfield(s,name) && ~isempty(s.(name))
    v = s.(name);
else
    v = defaultVal;
end
end
