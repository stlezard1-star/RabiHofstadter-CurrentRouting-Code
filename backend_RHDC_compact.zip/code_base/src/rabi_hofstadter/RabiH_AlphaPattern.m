function alphaCell = RabiH_AlphaPattern(Lx, Ly, pattern, alpha0, params)
%RABIH_ALPHAPATTERN Build simple coherent-photon seed patterns.
%
%   pattern may be a string, numeric scalar, numeric Ly-by-Lx matrix, or a
%   cell array Ly-by-Lx.  Supported string patterns:
%       zero, uniform, checkerboard, columnarX, columnarY,
%       vortex2x2, landau.

    if nargin < 3 || isempty(pattern), pattern = 'uniform'; end
    if nargin < 4 || isempty(alpha0), alpha0 = 0; end
    if nargin < 5 || isempty(params), params = struct(); end

    if isnumeric(pattern)
        if isscalar(pattern)
            alphaCell = pattern * ones(Ly,Lx);
        else
            if ~isequal(size(pattern),[Ly Lx])
                error('RabiH_AlphaPattern:SizeMismatch','Numeric alpha pattern must be Ly-by-Lx.');
            end
            alphaCell = pattern;
        end
        return;
    end
    if iscell(pattern)
        if ~isequal(size(pattern),[Ly Lx])
            error('RabiH_AlphaPattern:CellSizeMismatch','Cell alpha pattern must be Ly-by-Lx.');
        end
        alphaCell = zeros(Ly,Lx);
        for yy = 1:Ly
            for xx = 1:Lx
                alphaCell(yy,xx) = pattern{yy,xx};
            end
        end
        return;
    end

    alphaCell = zeros(Ly,Lx);
    pat = lower(pattern);
    switch pat
        case {'zero','none','vacuum'}
            alphaCell(:) = 0;
        case {'uniform','ferro','ferrosr'}
            alphaCell(:) = alpha0;
        case {'checkerboard','antiferro','af','afsr'}
            for yy = 1:Ly
                for xx = 1:Lx
                    alphaCell(yy,xx) = alpha0 * (-1)^(xx+yy);
                end
            end
        case {'columnarx','stripex'}
            for yy = 1:Ly
                for xx = 1:Lx
                    alphaCell(yy,xx) = alpha0 * (-1)^xx;
                end
            end
        case {'columnary','stripey'}
            for yy = 1:Ly
                for xx = 1:Lx
                    alphaCell(yy,xx) = alpha0 * (-1)^yy;
                end
            end
        case {'vortex','vortex2x2','chiral'}
            phases = [0, pi/2; -pi/2, pi];
            for yy = 1:Ly
                for xx = 1:Lx
                    alphaCell(yy,xx) = alpha0 * exp(1i*phases(mod(yy-1,2)+1, mod(xx-1,2)+1));
                end
            end
        case {'landau','hofstadter'}
            Phi = RabiH_GetOpt(params,'Phi',0);
            for yy = 1:Ly
                for xx = 1:Lx
                    alphaCell(yy,xx) = alpha0 * exp(1i*Phi*(xx-1)*(yy-1));
                end
            end
        otherwise
            error('RabiH_AlphaPattern:UnknownPattern','Unknown alpha pattern: %s.', pattern);
    end
end
