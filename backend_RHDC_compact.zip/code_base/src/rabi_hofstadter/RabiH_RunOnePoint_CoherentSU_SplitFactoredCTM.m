function result = RabiH_RunOnePoint_CoherentSU_SplitFactoredCTM(params, opts)
%RABIH_RUNONEPOINT_COHERENTSU_SPLITFACTOREDCTM Coherent SU + StageRH4G CTM.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(opts), opts = struct(); end

    Lx = RabiH_GetOpt(opts,'Lx',2);
    Ly = RabiH_GetOpt(opts,'Ly',2);
    seedOpts = RabiH_GetOpt(opts,'seedOpts',struct());
    if isfield(opts,'alpha') && ~isfield(seedOpts,'alpha'), seedOpts.alpha = opts.alpha; end
    if isfield(opts,'alphaPattern') && ~isfield(seedOpts,'pattern'), seedOpts.pattern = opts.alphaPattern; end
    if isfield(opts,'spinState') && ~isfield(seedOpts,'spinState'), seedOpts.spinState = opts.spinState; end

    unitCell0 = RabiH_InitCoherentUnitCell(Lx,Ly,params,seedOpts);
    [unitCell, suInfo] = RabiH_RunNNSimpleUpdate_Schedule(unitCell0, params, opts);

    ctmOpts = opts;
    ctmOpts.ctmBackend = 'splitFactored';
    ctmOpts.splitBackendMode = 'production';
    obs = RabiH_CTMObservables_SplitFactoredProduction(unitCell, params, ctmOpts);

    result = struct();
    result.unitCell = unitCell;
    result.obs = obs;
    result.suInfo = suInfo;
    result.energyPerSite = obs.energyPerSite;
    result.superradiantDensity = obs.superradiantDensity;
    result.meanPhotonNumber = obs.meanPhotonNumber;
    result.meanAbsCurrent = obs.meanAbsCurrent;
    result.meanAbsChirality = obs.meanAbsChirality;
    result.backend = 'split_factored_ctm_v1_sitewise';
    result.stage = 'StageRH4G';
    result.note = ['Coherent seed + NN simple update + StageRH4G split/factored ' ...
                   'CTM v1.  Use for non-blocked smoke/profiling and early scans.'];
end
