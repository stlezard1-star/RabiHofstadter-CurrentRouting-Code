function ctx = RabiH_CTMRunSplitFactoredProduction(unitCell, opts)
%RABIH_CTMRUNSPLITFACTOREDPRODUCTION StageRH4G executable split/factored CTM v1.
%
% This is the first executable non-blocked CTM kernel for the clean
% Rabi-Hofstadter package.  It never constructs CTM_BlockUnitCell.  Instead,
% it stores the split ket/bra cell, builds local double layers lazily per
% site, and runs a local uniform CTM environment for each inequivalent site.
%
% Important limitation:
%   This StageRH4G kernel is a production *route* and memory-safe CTM v1, not
%   the final periodic multi-site CTMRG algorithm.  It is intended to replace
%   blocked CTM in high-D smoke/profiling runs and to provide observables for
%   early scans.  Final paper data should later be checked against the full
%   periodic split-CTMRG backend.

    if nargin < 2 || isempty(opts), opts = struct(); end

    scell = RabiH_SplitLayerCellConstruct(unitCell, opts);
    splitCost = RabiH_SplitFactoredCTMCostEstimate(unitCell, opts);
    if ~splitCost.isSafe
        error('RabiH_CTMRunSplitFactoredProduction:UnsafeSplitCost', ...
            'Split/factored CTM guard refused this point: %s', splitCost.reason);
    end

    chiMax = RabiH_GetOpt(opts,'chiMax',16);
    maxIter = RabiH_GetOpt(opts,'maxIter',20);
    tol = RabiH_GetOpt(opts,'tol',1e-9);
    verbose = RabiH_GetOpt(opts,'verbose',false);

    envOpts = opts;
    envOpts.chiMax = chiMax;
    envOpts.maxIter = maxIter;
    envOpts.tol = tol;
    envOpts.skipNormHistory = RabiH_GetOpt(opts,'skipCTMNormHistory',true) || ...
                              RabiH_GetOpt(opts,'skipNormHistory',false) || ...
                              RabiH_GetOpt(opts,'skipIterNorm',false);

    Lx = scell.Lx;
    Ly = scell.Ly;
    Ecell = cell(Ly,Lx);
    envCell = cell(Ly,Lx);
    WCell = cell(Ly,Lx);
    denOne = zeros(Ly,Lx);
    histCell = cell(Ly,Lx);
    localDoubleLayerElements = zeros(Ly,Lx);

    for y = 1:Ly
        for x = 1:Lx
            E = RabiH_SplitLayerLocalDoubleLayer(scell,x,y);
            Ecell{y,x} = E;
            localDoubleLayerElements(y,x) = numel(E);
            env0 = CTM_InitUniform(E, envOpts);
            [env, hist] = CTM_Iterate(E, env0, envOpts);
            envCell{y,x} = env;
            histCell{y,x} = hist;
            W = CTM_BuildOneSiteEnvironment(env);
            WCell{y,x} = W;
            denOne(y,x) = CTM_EvaluateNorm_Fast(E, W);
            if abs(denOne(y,x)) < eps
                error('RabiH_CTMRunSplitFactoredProduction:ZeroNorm', ...
                    'Encountered zero one-site CTM norm at site (%d,%d).', x, y);
            end
        end
    end

    denH = zeros(Ly,Lx);
    denV = zeros(Ly,Lx);
    for y = 1:Ly
        for x = 1:Lx
            xp = mod(x,Lx)+1;
            yp = mod(y,Ly)+1;
            denH(y,x) = CTM_EvaluateHorizontalPair(Ecell{y,x}, Ecell{y,xp}, envCell{y,x});
            denV(y,x) = CTM_EvaluateVerticalPair(Ecell{y,x}, Ecell{yp,x}, envCell{y,x});
            if abs(denH(y,x)) < eps || abs(denV(y,x)) < eps
                error('RabiH_CTMRunSplitFactoredProduction:ZeroPairNorm', ...
                    'Encountered zero pair CTM norm at site (%d,%d).', x, y);
            end
        end
    end

    ctx = struct();
    ctx.stage = 'StageRH4G';
    ctx.backend = 'split_factored_ctm_v1_sitewise';
    ctx.description = ['StageRH4G executable split/factored CTM v1.  ' ...
        'No blocked unit-cell tensor is allocated.  Each local double-layer ' ...
        'tensor is absorbed into a local uniform CTM environment.  This is a ' ...
        'memory-safe first kernel, not yet the final periodic multi-site split-CTMRG.'];
    ctx.splitCell = scell;
    ctx.cost = splitCost;
    ctx.hasBlockedTensor = false;
    ctx.hasLocalDoubleLayerCell = true;
    ctx.isProductionCTM = true;
    ctx.productionLevel = 'StageRH4G_v1_sitewise_split_ctm';
    ctx.Ecell = Ecell;
    ctx.envCell = envCell;
    ctx.WCell = WCell;
    ctx.denOne = local_real_if_safe(denOne);
    ctx.denH = local_real_if_safe(denH);
    ctx.denV = local_real_if_safe(denV);
    ctx.histCell = histCell;
    ctx.localDoubleLayerElements = localDoubleLayerElements;
    ctx.maxLocalDoubleLayerElements = max(localDoubleLayerElements(:));
    ctx.chiMax = chiMax;
    ctx.maxIter = maxIter;
    ctx.tol = tol;
    ctx.warning = ['Use this backend for safe high-D development/profiling and ' ...
        'early exploratory scans.  For final paper plots, repeat key points ' ...
        'with the later periodic split-CTMRG backend and convergence checks.'];

    if verbose
        fprintf('[StageRH4G] split/factored CTM v1 built. max local DL elems=%g, chiMax=%d\n', ...
            ctx.maxLocalDoubleLayerElements, chiMax);
    end
end

function X = local_real_if_safe(X)
    if max(abs(imag(X(:)))) < 1e-12 * max(1,max(abs(real(X(:)))))
        X = real(X);
    end
end
