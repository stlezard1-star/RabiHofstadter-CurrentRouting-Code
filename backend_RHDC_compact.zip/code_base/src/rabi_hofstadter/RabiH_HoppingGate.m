function [G, Hhop] = RabiH_HoppingGate(params, phase, tval, tau)
%RABIH_HOPPINGGATE Imaginary-time two-site photon hopping gate.
    if nargin < 4 || isempty(tau)
        tau = RabiH_GetOpt(params,'tau',0.01);
    end
    [Hhop,~] = RabiH_HoppingHamiltonian(params, phase, tval);
    G = expm(-tau*Hhop);
    G = 0.5*(G + G');
end
