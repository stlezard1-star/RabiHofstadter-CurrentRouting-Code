function est = RabiH_AssertFactoredExactSafe(unitCell, opts)
%RABIH_ASSERTFACTOREDEXACTSAFE Guard StageRH4E exact factored-torus benchmark.
%
% The exact-torus backend is useful for D=2 validation of the factored
% observable path, but it must not silently replace the production CTM
% backend at larger D.  This function throws when the conservative guard is
% unsafe.

    if nargin < 1
        unitCell = [];
    end
    if nargin < 2 || isempty(opts)
        opts = struct();
    end

    est = RabiH_ExactTorusCostEstimate(unitCell, opts);
    if ~est.isSafe
        error('RabiH_AssertFactoredExactSafe:UnsafeExactTorus', ...
            ['StageRH4E factored exact-torus benchmark refused this contraction.\n' ...
             'Lx=%d, Ly=%d, Dmax=%d, q=%d, q^(2N)=%.6g, estMB=%.3f.\n%s'], ...
            est.Lx, est.Ly, est.Dmax, est.maxDoubleLayerLegDim, ...
            est.naiveBondStateElements, est.naiveMemoryMB, est.reason);
    end
end
