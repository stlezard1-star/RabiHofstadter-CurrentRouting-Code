function [unitCell, info] = RabiH_RunNNSimpleUpdate_Schedule(unitCell, params, opts)
%RABIH_RUNNNSIMPLEUPDATE_SCHEDULE Gate-cached NN simple-update schedule.
%
%   [unitCell,info] = RabiH_RunNNSimpleUpdate_Schedule(unitCell,params,opts)
%   applies local Rabi half gates and right/down photon hopping gates over a
%   tau schedule.  This is the first production-oriented algorithm layer for
%   the site-boson Rabi-Hofstadter iPEPS branch.
%
%   opts fields:
%       tauList       default [0.04 0.02 0.01]
%       nSweeps       default 1
%       Dmax          default unitCell.D
%       svdCutoff     forwarded to SU_ApplyTwoSiteGate
%       cacheGates    default true
%       checkAfter    default true

    if nargin < 3 || isempty(opts), opts = struct(); end
    tauList = RabiH_GetOpt(opts,'tauList',RabiH_GetOpt(params,'tauList',[0.04 0.02 0.01]));
    nSweeps = RabiH_GetOpt(opts,'nSweeps',1);
    Dmax = RabiH_GetOpt(opts,'Dmax',unitCell.D);
    cacheGates = RabiH_GetOpt(opts,'cacheGates',true);
    checkAfter = RabiH_GetOpt(opts,'checkAfter',true);

    Lx = unitCell.Lx;
    Ly = unitCell.Ly;
    info = struct();
    info.tauList = tauList;
    info.nSweeps = nSweeps;
    info.Dmax = Dmax;
    info.relDiscardedWeight = [];
    info.keep = [];
    info.step = struct('tau',{},'sweep',{},'meanDiscarded',{},'maxKeep',{});
    info.note = 'StageRH2 gate-cached NN Rabi-Hofstadter simple-update schedule.';

    gateCaches = cell(1,numel(tauList));
    if cacheGates
        for kt = 1:numel(tauList)
            gateCaches{kt} = RabiH_PrecomputeNNGates(params, tauList(kt), Lx, Ly);
        end
    end

    stepPtr = 0;
    for kt = 1:numel(tauList)
        tau = tauList(kt);
        if cacheGates
            gates = gateCaches{kt};
        else
            gates = RabiH_PrecomputeNNGates(params, tau, Lx, Ly);
        end
        for sw = 1:nSweeps
            unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, gates.GlocHalf);
            bcnt = 0;
            dw = zeros(1,2*Lx*Ly);
            kp = zeros(1,2*Lx*Ly);

            for y = 1:Ly
                for x = 1:Lx
                    xp = mod(x,Lx)+1;
                    [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x}, unitCell.A{y,xp}, 'right', gates.Gx{y,x}, Dmax, opts);
                    unitCell.A{y,x} = Anew;
                    unitCell.A{y,xp} = Bnew;
                    bcnt = bcnt + 1;
                    dw(bcnt) = local_getfield(sinfo,'relDiscardedWeight',NaN);
                    kp(bcnt) = local_getfield(sinfo,'keep',NaN);
                end
            end
            for y = 1:Ly
                yp = mod(y,Ly)+1;
                for x = 1:Lx
                    [Anew,Bnew,~,sinfo] = SU_ApplyTwoSiteGate(unitCell.A{y,x}, unitCell.A{yp,x}, 'down', gates.Gy{y,x}, Dmax, opts);
                    unitCell.A{y,x} = Anew;
                    unitCell.A{yp,x} = Bnew;
                    bcnt = bcnt + 1;
                    dw(bcnt) = local_getfield(sinfo,'relDiscardedWeight',NaN);
                    kp(bcnt) = local_getfield(sinfo,'keep',NaN);
                end
            end
            unitCell = RabiH_ApplyLocalGate_UnitCell(unitCell, gates.GlocHalf);
            unitCell = iPEPS_NormalizeUnitCell(unitCell);
            info.relDiscardedWeight = [info.relDiscardedWeight; dw]; %#ok<AGROW>
            info.keep = [info.keep; kp]; %#ok<AGROW>
            stepPtr = stepPtr + 1;
            info.step(stepPtr).tau = tau;
            info.step(stepPtr).sweep = sw;
            info.step(stepPtr).meanDiscarded = mean(dw(isfinite(dw)));
            info.step(stepPtr).maxKeep = max(kp(isfinite(kp)));
        end
    end
    unitCell.stage = 'RabiH_StageRH2_gate_cached_SU_schedule';
    unitCell.D = local_maxD(unitCell);
    if checkAfter
        iPEPS_CheckUnitCell(unitCell);
    end
end

function val = local_getfield(s, name, defaultVal)
    if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
        val = s.(name);
    else
        val = defaultVal;
    end
end

function D = local_maxD(unitCell)
    D = 1;
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            sz = PEPS_FullSize(unitCell.A{y,x},5);
            D = max(D, max(sz(2:5)));
        end
    end
end
