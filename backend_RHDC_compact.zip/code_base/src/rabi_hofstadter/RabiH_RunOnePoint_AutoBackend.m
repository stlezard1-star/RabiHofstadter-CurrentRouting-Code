function result = RabiH_RunOnePoint_AutoBackend(params, opts)
%RABIH_RUNONEPOINT_AUTOBACKEND Article-pipeline one-point runner with backend guard.
%
% This wrapper protects long parameter scans from accidentally entering an
% unsafe blocked-CTM run.
%
% Implemented measurement backends:
%   blocked              : coherent seed + SU + blocked CTM, only when safe.
%   factoredExact        : coherent seed + SU + StageRH4E guarded exact-small-cell benchmark.
%   splitFactoredExact   : coherent seed + SU + StageRH4F split/factored exact-small-cell benchmark.
%
% Prototype-only routes such as splitFactoredPrototype are intentionally not
% used for article data because they do not yet compute production observables.

if nargin < 1 || isempty(params), params = struct(); end
if nargin < 2 || isempty(opts), opts = struct(); end

backendInfo = RabiH_CheckCTMBackendReady([], opts);
if ~backendInfo.isReady
    error('RabiH_RunOnePoint_AutoBackend:BackendNotReady', ...
        ['CTM backend is not ready for this point.\n' ...
         'requested=%s, selected=%s, risk=%s, blockedMB=%.3f, interMB=%.3f\n%s'], ...
        backendInfo.requested, backendInfo.selected, backendInfo.risk.level, ...
        backendInfo.risk.blockedTensorMB, backendInfo.risk.estimatedNormIntermediateMB, ...
        backendInfo.message);
end

startTime = tic;
switch backendInfo.selected
    case 'blocked'
        result = RabiH_RunOnePoint_CoherentSU_CTM(params, opts);
    case 'factored_exact'
        result = RabiH_RunOnePoint_CoherentSU_FactoredExact(params, opts);
    case 'split_factored_exact'
        result = RabiH_RunOnePoint_CoherentSU_SplitFactoredExact(params, opts);
    case 'split_factored_prototype'
        error('RabiH_RunOnePoint_AutoBackend:PrototypeHasNoObservables', ...
            ['splitFactoredPrototype is only a routing/interface backend.  ' ...
             'Use ctmBackend=''splitFactoredExact'' for guarded small-cell validation, ' ...
             'or ctmBackend=''splitFactored'' for the StageRH4G executable CTM v1.']);
    case 'split_factored'
        result = RabiH_RunOnePoint_CoherentSU_SplitFactoredCTM(params, opts);
    case 'split_periodic'
        result = RabiH_RunOnePoint_CoherentSU_SplitPeriodicCTM(params, opts);
    case 'split_shared'
        result = RabiH_RunOnePoint_CoherentSU_SplitSharedCTM(params, opts);
    otherwise
        error('RabiH_RunOnePoint_AutoBackend:InternalBackendError', ...
            'Selected backend is not implemented for one-point observable data: %s.', backendInfo.selected);
end
runtime = toc(startTime);

result.backendInfo = backendInfo;
result.runtimeSeconds = runtime;
result.params = params;
result.opts = opts;
result.pipelineStage = 'RabiH_v0_4_0_article_guarded_one_point';
end
