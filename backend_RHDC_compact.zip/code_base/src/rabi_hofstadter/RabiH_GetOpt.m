function val = RabiH_GetOpt(s, fieldName, defaultVal)
%RABIH_GETOPT Small struct option helper for Rabi-Hofstadter routines.
    if nargin < 3
        defaultVal = [];
    end
    if isstruct(s) && isfield(s, fieldName) && ~isempty(s.(fieldName))
        val = s.(fieldName);
    else
        val = defaultVal;
    end
end
