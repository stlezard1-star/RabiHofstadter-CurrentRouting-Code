function RabiH_PrintSeedSelectionSummary(selection)
%RABIH_PRINTSEEDSELECTIONSUMMARY Compact coherent-seed selection output.
    fprintf('--- RabiH StageRH3 coherent-seed selection ---\n');
    fprintf('candidates=%d, best alpha=%g%+gi, pattern=%s, E/site=%.12g\n', ...
        numel(selection.rows), real(selection.bestAlpha), imag(selection.bestAlpha), ...
        selection.bestPattern, real(selection.bestEnergyPerSite));
end
