function S = RabiH_SummarizeNNNProductionPatternScan(bestRecords, rawRecords)
%RABIH_SUMMARIZENNNPRODUCTIONPATTERNSCAN StageRH4Z summary diagnostics.

    if nargin < 1, bestRecords = struct([]); end
    if nargin < 2, rawRecords = bestRecords; end
    base = RabiH_SummarizeNNNCurrentPatternScan(bestRecords, rawRecords);
    S = base;
    S.stage = 'StageRH4Z';
    ok = strcmp({bestRecords.status},'ok');
    B = bestRecords(ok);
    if isempty(B)
        S.hasNegativeLambda = false;
        S.hasPositiveLambda = false;
        S.hasThetaImbalance = false;
        S.lambdaRange = [NaN NaN];
        S.thetaTriRange = [NaN NaN];
        S.hasDiagCurrentSignReversal = false;
        S.hasSquareChiralitySignReversal = false;
        S.hasTriangularChiralitySignReversal = false;
        S.perTheta = [];
        S.perLambdaTheta = [];
        return;
    end

    lam = [B.lambda];
    theta = [B.thetaTri];
    S.hasNegativeLambda = any(lam < -1e-12);
    S.hasPositiveLambda = any(lam > 1e-12);
    S.hasThetaImbalance = any(abs(theta) > 1e-12);
    S.lambdaRange = [min(lam) max(lam)];
    S.thetaTriRange = [min(theta) max(theta)];
    S.maxAbsSignedDiagCurrent = max(abs([B.j13 B.j24]));
    S.maxAbsSignedSquareChirality = max(abs([B.chiSquare]));
    S.maxAbsSignedTriangularChirality = max(abs([B.chiTri123 B.chiTri134 B.chiTri124 B.chiTri234]));

    valsDiag = [B.j13 B.j24]; valsDiag = valsDiag(isfinite(valsDiag));
    valsSq = [B.chiSquare]; valsSq = valsSq(isfinite(valsSq));
    valsTri = [B.chiTri123 B.chiTri134 B.chiTri124 B.chiTri234]; valsTri = valsTri(isfinite(valsTri));
    S.hasDiagCurrentSignReversal = local_has_both_signs(valsDiag);
    S.hasSquareChiralitySignReversal = local_has_both_signs(valsSq);
    S.hasTriangularChiralitySignReversal = local_has_both_signs(valsTri);

    thetaVals = unique(theta);
    perT = repmat(struct('thetaTri',NaN,'thetaOverPi',NaN,'n',0, ...
        'maxSquareChi',NaN,'maxTriChi',NaN,'maxDiagCurrent',NaN, ...
        'maxImbalance',NaN,'labels',''),1,numel(thetaVals));
    for k=1:numel(thetaVals)
        idx = abs(theta-thetaVals(k)) < 1e-12;
        R = B(idx);
        perT(k).thetaTri = thetaVals(k);
        perT(k).thetaOverPi = thetaVals(k)/pi;
        perT(k).n = numel(R);
        perT(k).maxSquareChi = max([R.meanAbsSquareChirality]);
        perT(k).maxTriChi = max([R.meanAbsTriangularChirality]);
        perT(k).maxDiagCurrent = max([R.meanAbsDiagCurrent]);
        perT(k).maxImbalance = max([R.triangularImbalance]);
        perT(k).labels = strjoin(unique({R.patternLabel}),'|');
    end
    S.perTheta = perT;

    lamVals = unique(lam);
    combos = repmat(struct('lambda',NaN,'thetaTri',NaN,'thetaOverPi',NaN,'n',0, ...
        'maxSquareChi',NaN,'maxTriChi',NaN,'maxDiagCurrent',NaN, ...
        'maxImbalance',NaN,'meanSignedDiagP',NaN,'meanSignedDiagM',NaN, ...
        'meanSignedSquareChi',NaN,'labels',''),1,numel(lamVals)*numel(thetaVals));
    c=0;
    for il=1:numel(lamVals)
        for it=1:numel(thetaVals)
            idx = abs(lam-lamVals(il)) < 1e-12 & abs(theta-thetaVals(it)) < 1e-12;
            R = B(idx);
            c=c+1;
            combos(c).lambda = lamVals(il);
            combos(c).thetaTri = thetaVals(it);
            combos(c).thetaOverPi = thetaVals(it)/pi;
            combos(c).n = numel(R);
            if ~isempty(R)
                combos(c).maxSquareChi = max([R.meanAbsSquareChirality]);
                combos(c).maxTriChi = max([R.meanAbsTriangularChirality]);
                combos(c).maxDiagCurrent = max([R.meanAbsDiagCurrent]);
                combos(c).maxImbalance = max([R.triangularImbalance]);
                combos(c).meanSignedDiagP = mean([R.j13]);
                combos(c).meanSignedDiagM = mean([R.j24]);
                combos(c).meanSignedSquareChi = mean([R.chiSquare]);
                combos(c).labels = strjoin(unique({R.patternLabel}),'|');
            end
        end
    end
    S.perLambdaTheta = combos;

    S.readyForNNNMainText = S.numBestOK > 0 && S.hasNegativeLambda && S.hasPositiveLambda && S.hasThetaImbalance;
    S.recommendation = local_recommendation(S);
end

function tf = local_has_both_signs(v)
    if isempty(v), tf=false; return; end
    tol = 1e-10;
    tf = any(v > tol) && any(v < -tol);
end

function rec = local_recommendation(S)
    if ~S.readyForNNNMainText
        rec = 'Run a scan including negative/positive lambda and nonzero thetaTri before drawing main-text conclusions.';
    elseif S.hasTriangularChiralitySignReversal || S.hasDiagCurrentSignReversal || S.hasSquareChiralitySignReversal
        rec = 'Sign reversal detected; prioritize current-pattern maps and representative arrow plots.';
    elseif S.maxTriangularImbalance > 0.1*S.maxAbsTriangularChirality
        rec = 'Triangular imbalance is significant; include triangular-loop imbalance maps in the main text.';
    else
        rec = 'NNN/triangular-flux scan is stable; use it as robustness/current-redistribution evidence.';
    end
end
