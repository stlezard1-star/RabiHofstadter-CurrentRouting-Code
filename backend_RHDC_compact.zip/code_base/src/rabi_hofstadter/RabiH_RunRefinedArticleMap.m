function articleMap = RabiH_RunRefinedArticleMap(paramsBase, optsBase, spec)
%RABIH_RUNREFINEDARTICLEMAP Run StageRH4O refined SR/chiralSR article map.
%
% The implementation intentionally reuses the StageRH4L raw-scan and
% best-seed selection machinery.  StageRH4O then adds map-oriented summary,
% phase-count tables, and optional figures.

if nargin < 1 || isempty(paramsBase)
    [paramsBase, optsBase, spec] = RabiH_Stage4O_DefaultArticleMap();
elseif nargin < 2 || isempty(optsBase)
    optsBase = struct();
end
if nargin < 3 || isempty(spec)
    spec = struct();
end

optsBase.ctmBackend = RabiH_GetOpt(optsBase,'ctmBackend','splitFactoredShared');
optsBase.splitBackendMode = 'shared';
spec.backend = RabiH_GetOpt(spec,'backend','splitFactoredShared');

outDir = RabiH_GetOpt(optsBase,'outputDir',fullfile(pwd,'results_stage4O_article_map'));
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
optsBase.outputDir = outDir;

prelim = RabiH_RunPreliminaryArticleScan(paramsBase, optsBase, spec);
summary = RabiH_SummarizeArticleMap(prelim.best.records, spec);
summaryCsv = fullfile(outDir,'stage4O_article_map_summary.csv');
RabiH_WriteArticleMapSummaryCSV(summary, summaryCsv);

articleMap = struct();
articleMap.stage = 'StageRH4O';
articleMap.description = ['Refined article-map scan around the SR/chiralSR ' ...
    'window.  Raw point data are in prelim.raw; best-seed physical points ' ...
    'are in prelim.best.'];
articleMap.prelim = prelim;
articleMap.best = prelim.best;
articleMap.summary = summary;
articleMap.summaryCsv = summaryCsv;
articleMap.rawCsv = prelim.rawCsv;
articleMap.bestCsv = prelim.bestCsv;
articleMap.outputDir = outDir;
articleMap.paramsBase = paramsBase;
articleMap.optsBase = optsBase;
articleMap.scanSpec = spec;

save(fullfile(outDir,'stage4O_article_map.mat'),'articleMap');

makePlots = local_get(spec,'makePlots',false);
if makePlots
    try
        RabiH_PlotArticleMaps(articleMap, outDir);
    catch ME
        warning('RabiH_RunRefinedArticleMap:PlotFailed', ...
            'Stage4O plot generation failed: %s', ME.message);
    end
end
end

function val = local_get(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    val = S.(name);
else
    val = defaultVal;
end
end
