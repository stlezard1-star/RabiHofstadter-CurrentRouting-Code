function J1 = RabiH_GetNNHopping(params, direction)
%RABIH_GETNNHOPPING Nearest-neighbor photon hopping amplitude with aliases.
%   J1 = RabiH_GetNNHopping(params) returns params.J1 if present, otherwise
%   params.t.  Direction-specific aliases tX/tY override the isotropic value.

    if nargin < 1 || isempty(params), params = struct(); end
    if nargin < 2 || isempty(direction), direction = 'generic'; end
    Jbase = RabiH_GetOpt(params,'J1',RabiH_GetOpt(params,'t',0.05));
    switch lower(direction)
        case {'right','x','horizontal'}
            J1 = RabiH_GetOpt(params,'tX',Jbase);
        case {'down','y','vertical'}
            J1 = RabiH_GetOpt(params,'tY',Jbase);
        otherwise
            J1 = Jbase;
    end
end
