function phase = RabiH_GaugePhase(x, y, direction, params)
%RABIH_GAUGEPHASE Peierls phase in Landau gauge on a square lattice.
%
%   Coordinates x,y are one-based unit-cell coordinates. The implemented
%   Landau gauge is A_x=0, A_y=Phi*x0 with x0=x-1.
%
%   direction values:
%       'right' : (x,y)->(x+1,y), phase 0
%       'down'  : (x,y)->(x,y+1), phase Phi*(x-1)
%       'diagp' : (x,y)->(x+1,y+1), phase Phi*((x-1)+1/2)
%       'diagm' : (x,y)->(x+1,y-1), phase -Phi*((x-1)+1/2)
%
%   The diagonal phases are line integrals of A_y=Phi*x along straight
%   diagonal links. They are included for model bookkeeping; StageRH0 simple
%   update only supports nearest-neighbor right/down gates.

    if nargin < 4 || isempty(params)
        params = struct();
    end
    Phi = RabiH_GetOpt(params,'Phi',0.0);
    x0 = x - 1;

    dir = lower(direction);
    switch dir
        case {'right','x','horizontal'}
            phase = 0;
        case {'down','y','vertical'}
            phase = Phi*x0;
        case {'diagp','diagplus','crossp'}
            phase = Phi*(x0 + 0.5);
        case {'diagm','diagminus','crossm'}
            phase = -Phi*(x0 + 0.5);
        otherwise
            error('RabiH_GaugePhase:UnknownDirection','Unknown direction: %s.', direction);
    end
end
