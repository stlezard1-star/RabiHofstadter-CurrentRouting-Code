function summary = RabiH_SC_SummarizeScan(scan)
records = scan.records;
ok = strcmp({records.status},'ok');
summary = struct();
summary.numRecords = numel(records);
summary.numOK = sum(ok);
summary.numError = summary.numRecords - summary.numOK;
if summary.numOK == 0
    summary.energyRange = [NaN NaN];
    summary.rhoRange = [NaN NaN];
    summary.maxAbsChiSquare = NaN;
    summary.maxAbsChiTri = NaN;
    summary.maxAbsIDiag = NaN;
    summary.maxTriangleIdentityErr = NaN;
    summary.labels = '';
    return;
end
r = records(ok);
summary.energyRange = [min([r.energyPerSite]) max([r.energyPerSite])];
summary.rhoRange = [min([r.rhoSR]) max([r.rhoSR])];
summary.maxAbsChiSquare = max(abs([r.chiSquare]));
summary.maxAbsChiTri = max([r.meanAbsChiTri]);
summary.maxAbsIDiag = max([r.absIDiag]);
summary.maxTriImbalance = max([r.triangularImbalance]);
summary.maxCurrentDivergence = max([r.maxCurrentDivergence]);
summary.maxTriangleIdentityErr = max([r.maxTriangleIdentityErr]);
labels = unique({r.patternLabel});
summary.labels = strjoin(labels,' ');
end
