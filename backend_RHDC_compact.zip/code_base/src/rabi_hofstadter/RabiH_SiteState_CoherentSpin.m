function v = RabiH_SiteState_CoherentSpin(dph, alpha, spinState)
%RABIH_SITESTATE_COHERENTSPIN Site state |alpha>_photon \otimes |spin>.
%   Physical basis convention inherited from RabiH_SiteOps:
%       p = s + 2*n, s=1,2, n=0,...,dph-1.

    if nargin < 3 || isempty(spinState), spinState = 'down'; end
    c = RabiH_CoherentVector(dph, alpha);
    s = RabiH_SpinVector(spinState);
    v = kron(c, s);
    v = v/norm(v);
end
