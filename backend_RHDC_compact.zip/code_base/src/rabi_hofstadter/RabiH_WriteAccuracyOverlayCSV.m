function csvFile = RabiH_WriteAccuracyOverlayCSV(scan, csvFile)
%RABIH_WRITEACCURACYOVERLAYCSV Write StageRH4Q records to CSV.

if nargin < 2 || isempty(csvFile)
    if isfield(scan,'outputDir') && ~isempty(scan.outputDir)
        outDir = scan.outputDir;
    else
        outDir = fullfile(pwd,'results_stage4Q_accuracy_overlay');
    end
    if exist(outDir,'dir') ~= 7, mkdir(outDir); end
    csvFile = fullfile(outDir,'stage4Q_accuracy_overlay.csv');
end
fid = fopen(csvFile,'w');
if fid < 0, error('RabiH_WriteAccuracyOverlayCSV:OpenFailed','Cannot open CSV file.'); end
fprintf(fid,['index,label,status,branchName,targetPhase,phaseLabel,matchesTarget,' ...
    'scheduleName,nSweeps,tauList,dph,Dmax,chiMax,sharedBoundaryMix,' ...
    'gR,t,Phi,sourceEta,alphaSeed,alphaPattern,Esite,rhoSR,meanN,meanAbsCurrent,' ...
    'meanAbsChirality,maxCurrentDivergence,maxChiralityDefinitionError,runtimeSeconds,errorMessage\n']);
for k = 1:numel(scan.records)
    r = scan.records(k);
    fprintf(fid,'%d,%s,%s,%s,%s,%s,%d,%s,%g,%s,%g,%g,%g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%s,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.16g,%.6g,%s\n', ...
        r.index, local_str(r.label), local_str(r.status), local_str(r.branchName), local_str(r.targetPhase), ...
        local_str(r.phaseLabel), local_bool(r.matchesTarget), local_str(r.scheduleName), r.nSweeps, local_str(r.tauListString), ...
        r.dph, r.Dmax, r.chiMax, r.sharedBoundaryMix, r.gR, r.t, r.Phi, r.sourceEta, r.alphaSeed, ...
        local_str(r.alphaPattern), r.energyPerSite, r.superradiantDensity, r.meanPhotonNumber, r.meanAbsCurrent, ...
        r.meanAbsChirality, r.maxCurrentDivergence, r.maxChiralityDefinitionError, r.runtimeSeconds, local_str(r.errorMessage));
end
fclose(fid);
end

function s = local_str(x)
if isempty(x), s = ''; else, s = char(x); end
s = strrep(s,',',';');
s = strrep(s,sprintf('\n'),' ');
end
function b = local_bool(x)
b = double(logical(x));
end
