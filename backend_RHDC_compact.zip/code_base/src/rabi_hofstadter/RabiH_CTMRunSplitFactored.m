function ctx = RabiH_CTMRunSplitFactored(unitCell, opts)
%RABIH_CTMRUNSPLITFACTORED StageRH4F split/factored CTM prototype context.
%
% Implemented modes:
%   prototype / skeleton : split-layer cell + minimal environment + plans.
%   exactSmallCell       : guarded exact-torus benchmark routed through the
%                          split/factored observable interface.
%
% This routine never calls CTM_BlockUnitCell and never stores a blocked rank-4
% unit-cell tensor.

    if nargin < 2 || isempty(opts), opts = struct(); end

    mode = lower(RabiH_GetOpt(opts,'splitBackendMode',RabiH_GetOpt(opts,'factoredBackendMode','prototype')));
    ctmBackend = lower(RabiH_GetOpt(opts,'ctmBackend',''));

    useShared = RabiH_GetOpt(opts,'requireSharedSplitCTM',false) || ...
                any(strcmp(mode,{'shared','sharedctm','sharedctmrg','sharedperiodic','cached','cachedperiodic'})) || ...
                any(strcmp(ctmBackend,{'splitfactoredshared','splitshared','sharedsplitctm','splitcachedctm','splitfactoredcached'}));
    if useShared
        ctx = RabiH_CTMRunSplitFactoredShared(unitCell, opts);
        return;
    end

    usePeriodic = RabiH_GetOpt(opts,'requirePeriodicSplitCTM',false) || ...
                  any(strcmp(mode,{'periodic','periodicctm','periodicctmrg','multisiteperiodic'})) || ...
                  any(strcmp(ctmBackend,{'splitfactoredperiodic','splitperiodic','periodicsplitctm','splitperiodicctm'}));
    if usePeriodic
        ctx = RabiH_CTMRunSplitFactoredPeriodic(unitCell, opts);
        return;
    end

    useProduction = RabiH_GetOpt(opts,'requireProductionSplitCTM',false) || ...
                    RabiH_GetOpt(opts,'requireProductionFactoredCTM',false) || ...
                    any(strcmp(mode,{'production','ctm','ctmrg','splitctm','splitctmrg'})) || ...
                    any(strcmp(ctmBackend,{'splitfactored','splitfactoredctm','splitctm','splitmultisite'}));
    if useProduction
        ctx = RabiH_CTMRunSplitFactoredProduction(unitCell, opts);
        return;
    end

    scell = RabiH_SplitLayerCellConstruct(unitCell, opts);
    cost = RabiH_SplitFactoredCTMCostEstimate(unitCell, opts);
    useExact = RabiH_GetOpt(opts,'enableSplitExactTorus',false) || ...
               RabiH_GetOpt(opts,'enableFactoredExactTorus',false) || ...
               any(strcmp(mode,{'exact','exactsmallcell','exacttorus','smallcell'})) || ...
               any(strcmp(ctmBackend,{'splitfactoredexact','splitexact','factoredexact','exacttorus'}));

    ctx = struct();
    ctx.stage = 'StageRH4F';
    ctx.backend = 'split_factored_prototype';
    ctx.splitCell = scell;
    ctx.cost = cost;
    ctx.hasBlockedTensor = false;
    ctx.hasLocalDoubleLayerCell = false;
    ctx.isProductionCTM = false;
    ctx.env = [];
    ctx.hist = [];

    if useExact
        exactRisk = RabiH_AssertFactoredExactSafe(unitCell, opts);
        ctx.backend = 'split_factored_exact_torus';
        ctx.exactTorusCost = exactRisk;
        ctx.note = ['StageRH4F split/factored exact-small-cell benchmark.  ' ...
                    'Useful for D=2 validation; not production infinite-PEPS CTM.'];
        return;
    end

    if ~cost.isSafe
        error('RabiH_CTMRunSplitFactored:UnsafeSplitPrototype', ...
            ['StageRH4F split/factored prototype guard refused this point: %s'], cost.reason);
    end

    ctx.env = RabiH_SplitCTMInitMinimal(scell, opts);
    ctx.note = ['StageRH4F split/factored CTM prototype: split-layer cell, ' ...
                'lazy local double-layer kernel, and absorption-plan interface.  ' ...
                'Production row/column absorption and truncation remain next.'];
end
