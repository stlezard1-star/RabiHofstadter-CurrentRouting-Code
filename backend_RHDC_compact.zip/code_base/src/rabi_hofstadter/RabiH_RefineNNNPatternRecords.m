function R2 = RabiH_RefineNNNPatternRecords(R, spec)
%RABIH_REFINENNNPATTERNRECORDS Add refined labels and signed-current features.
if nargin < 2 || isempty(spec), spec = struct(); end
R2 = R;
for k = 1:numel(R2)
    [lbl,tags] = RabiH_ClassifyNNNCurrentPattern_Refined(R2(k), spec);
    R2(k).patternLabelRefined = lbl;
    R2(k).triRatio = tags.triRatio;
    R2(k).diagSelectionRatio = tags.diagSelectionRatio;
    R2(k).diagMeanSigned = tags.diagMeanSigned;
    R2(k).j13Minusj24 = tags.j13Minusj24;
    R2(k).chiTriSigned13 = tags.chiTriSigned13;
    R2(k).chiTriSigned24 = tags.chiTriSigned24;
    R2(k).chiTriPairMeanSigned = tags.chiTriPairMeanSigned;
    R2(k).isTriEnhanced = double(tags.isTriEnhanced);
    R2(k).isSquareDominant = double(tags.isSquareDominant);
    R2(k).isDiagSelected = double(tags.isDiagSelected);
    R2(k).isDiagSignReversed = double(tags.isDiagSignReversed);
end
end
