function obs = RabiH_CTMObservables_SplitFactoredShared(unitCell, params, opts)
%RABIH_CTMOBSERVABLES_SPLITFACTOREDSHARED StageRH4J observables.
%
% Reuses the StageRH4G observable evaluator with a StageRH4J shared/cached
% split/factored CTM context.  Observable contractions are intentionally kept
% identical so that backend differences only reflect the environment kernel.

    if nargin < 3 || isempty(opts), opts = struct(); end
    ctx = RabiH_GetOpt(opts,'ctmContext',[]);
    if isempty(ctx)
        ctx = RabiH_CTMRunSplitFactoredShared(unitCell, opts);
    end

    obsOpts = opts;
    obsOpts.ctmContext = ctx;
    obs = RabiH_CTMObservables_SplitFactoredProduction(unitCell, params, obsOpts);
    obs.backend = ctx.backend;
    obs.stage = ctx.stage;
    obs.description = ['StageRH4J shared/cached split/factored CTM observable summary.  ' ...
                       'No blocked tensor is allocated; local double layers are cached ' ...
                       'and CTM environments are evolved through global periodic sweeps.'];
end
