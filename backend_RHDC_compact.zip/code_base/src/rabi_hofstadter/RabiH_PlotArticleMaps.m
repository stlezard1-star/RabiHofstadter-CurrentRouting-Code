function RabiH_PlotArticleMaps(articleMap, outDir)
%RABIH_PLOTARTICLEMAPS Generate StageRH4O preliminary map figures.
%
% MATLAB 2018 compatible: saveas/print, no tiledlayout/exportgraphics.

if nargin < 2 || isempty(outDir)
    if isfield(articleMap,'outputDir'), outDir = articleMap.outputDir; else, outDir = pwd; end
end
if exist(outDir,'dir') ~= 7, mkdir(outDir); end

% Reuse Stage4L map plots for scalar observables.
try
    RabiH_PlotPreliminaryMaps(articleMap.prelim, outDir);
catch ME
    warning('RabiH_PlotArticleMaps:ScalarMapFailed','Scalar map plots failed: %s', ME.message);
end

records = articleMap.best.records;
if isempty(records), return; end

tVals = unique(arrayfun(@(r) r.t, records));
for it = 1:numel(tVals)
    tval = tVals(it);
    sub = records(abs(arrayfun(@(r) r.t, records)-tval) < 1e-12);
    gVals = unique(arrayfun(@(r) r.gR, sub));
    phiVals = unique(arrayfun(@(r) r.Phi, sub));
    phaseZ = NaN(numel(gVals),numel(phiVals));
    alphaZ = NaN(numel(gVals),numel(phiVals));
    for ig = 1:numel(gVals)
        for ip = 1:numel(phiVals)
            mask = abs(arrayfun(@(r) r.gR, sub)-gVals(ig)) < 1e-12 & ...
                   abs(arrayfun(@(r) r.Phi, sub)-phiVals(ip)) < 1e-12;
            if any(mask)
                r = sub(find(mask,1,'first'));
                phaseZ(ig,ip) = local_phase_code(local_field(r,'phaseLabel',''));
                alphaZ(ig,ip) = local_field(r,'alphaSeed',NaN);
            end
        end
    end
    fig = figure('Visible','off');
    imagesc(phiVals/pi, gVals, phaseZ); set(gca,'YDir','normal');
    xlabel('\Phi/\pi'); ylabel('g_R');
    title(sprintf('phase label code, t=%.4g', tval),'Interpreter','none');
    colorbar;
    base = sprintf('stage4O_map_phaseCode_t%.4g',tval);
    base = regexprep(base,'[^a-zA-Z0-9_\.-]','_');
    saveas(fig, fullfile(outDir,[base '.fig']));
    print(fig, fullfile(outDir,[base '.png']), '-dpng', '-r200');
    close(fig);

    fig = figure('Visible','off');
    imagesc(phiVals/pi, gVals, alphaZ); set(gca,'YDir','normal');
    xlabel('\Phi/\pi'); ylabel('g_R');
    title(sprintf('best alpha seed, t=%.4g', tval),'Interpreter','none');
    colorbar;
    base = sprintf('stage4O_map_bestAlpha_t%.4g',tval);
    base = regexprep(base,'[^a-zA-Z0-9_\.-]','_');
    saveas(fig, fullfile(outDir,[base '.fig']));
    print(fig, fullfile(outDir,[base '.png']), '-dpng', '-r200');
    close(fig);
end
end

function code = local_phase_code(label)
switch label
    case 'normal'
        code = 0;
    case 'SR'
        code = 1;
    case 'currentSR'
        code = 2;
    case 'chiralSR'
        code = 3;
    otherwise
        code = NaN;
end
end

function v = local_field(S,name,defaultVal)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name))
    v = S.(name);
else
    v = defaultVal;
end
end
