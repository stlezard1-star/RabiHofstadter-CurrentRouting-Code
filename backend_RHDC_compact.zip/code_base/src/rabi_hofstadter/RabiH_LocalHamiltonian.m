function [Hloc, ops] = RabiH_LocalHamiltonian(params)
%RABIH_LOCALHAMILTONIAN One-site quantum Rabi Hamiltonian.
%
% Supports both the original truncated photon Fock basis and the StageRH4S
% projected photon LBO basis.  Set params.useLBO=true and provide either
% params.lboBasis or params.dphFull/params.dphEff to activate the LBO route.

    if nargin < 1 || isempty(params)
        params = struct();
    end

    if RabiH_IsLBOEnabled(params)
        basis = RabiH_GetLBOBasis(params);
        [Hloc, ops] = RabiH_LocalHamiltonianLBO(params,basis);
        return;
    end

    dph   = RabiH_GetOpt(params,'dph',4);
    omega = RabiH_GetOpt(params,'omega',1.0);
    Delta = RabiH_GetOpt(params,'Delta',1.0);
    gR    = RabiH_GetOpt(params,'gR',RabiH_GetOpt(params,'g',0.2));

    ops = RabiH_SiteOps(dph);
    Hloc = omega*ops.N + 0.5*Delta*ops.sz + gR*(ops.Q*ops.sx);

    eta = RabiH_GetOpt(params,'sourceEta',0);
    if isreal(eta)
        eta = eta * exp(1i*RabiH_GetOpt(params,'sourcePhase',0));
    end
    if abs(eta) > 0
        Hloc = Hloc - (conj(eta)*ops.a + eta*ops.adag);
    end

    Hloc = 0.5*(Hloc + Hloc');
end
