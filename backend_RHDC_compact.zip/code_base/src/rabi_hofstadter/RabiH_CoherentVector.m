function v = RabiH_CoherentVector(dph, alpha)
%RABIH_COHERENTVECTOR Normalized truncated coherent-state vector.
%
%   v(n+1) = exp(-|alpha|^2/2) alpha^n/sqrt(n!), then renormalized after
%   truncation.  This is an initialization utility in the original photon
%   Fock basis, not a shifted-basis representation.

    if nargin < 1 || isempty(dph), dph = 4; end
    if nargin < 2 || isempty(alpha), alpha = 0; end
    if dph < 1 || round(dph) ~= dph
        error('RabiH_CoherentVector:InvalidDim','dph must be a positive integer.');
    end
    v = zeros(dph,1);
    amp = exp(-0.5*abs(alpha)^2);
    v(1) = amp;
    for n = 1:(dph-1)
        v(n+1) = v(n) * alpha / sqrt(n);
    end
    nv = norm(v);
    if nv == 0 || ~isfinite(nv)
        error('RabiH_CoherentVector:BadVector','Coherent vector norm is invalid.');
    end
    v = v / nv;
end
