function figFiles = RabiH_PlotAppendixConvergencePack(pack, outDir)
%RABIH_PLOTAPPENDIXCONVERGENCEPACK Make StageRH4U Appendix diagnostic plots.
if nargin < 2 || isempty(outDir), outDir = pack.outputDir; end
if exist(outDir,'dir') ~= 7, mkdir(outDir); end
figFiles = struct();
figFiles.accuracyOverlayFIG = fullfile(outDir,'FigA_stage4U_accuracy_overlay.fig');
figFiles.accuracyOverlayPNG = fullfile(outDir,'FigA_stage4U_accuracy_overlay.png');
figFiles.lboFIG = fullfile(outDir,'FigB_stage4U_highdph_lbo.fig');
figFiles.lboPNG = fullfile(outDir,'FigB_stage4U_highdph_lbo.png');
local_plot_q(pack, figFiles.accuracyOverlayFIG, figFiles.accuracyOverlayPNG);
local_plot_t(pack, figFiles.lboFIG, figFiles.lboPNG);
end

function local_plot_q(pack, figFile, pngFile)
q = pack.summaryU.stage4Q;
if ~isfield(q,'branchTable') || isempty(q.branchTable)
    return;
end
bt = q.branchTable;
n = numel(bt);
labels = cell(1,n);
drho = zeros(1,n); dj = zeros(1,n); dchi = zeros(1,n);
for k = 1:n
    labels{k} = bt(k).branchName;
    drho(k) = bt(k).rhoRange(2)-bt(k).rhoRange(1);
    dj(k) = bt(k).currentRange(2)-bt(k).currentRange(1);
    dchi(k) = bt(k).chiralityRange(2)-bt(k).chiralityRange(1);
end
h = figure('Visible','off');
subplot(1,3,1); bar(drho); title('\Delta \rho_{SR}'); ylabel('range'); set(gca,'XTick',1:n,'XTickLabel',labels); xtickangle_safe(35);
subplot(1,3,2); bar(dj); title('\Delta |J|'); set(gca,'XTick',1:n,'XTickLabel',labels); xtickangle_safe(35);
subplot(1,3,3); bar(dchi); title('\Delta |\chi|'); set(gca,'XTick',1:n,'XTickLabel',labels); xtickangle_safe(35);
set(h,'Position',[100 100 1100 350]);
saveas(h,figFile);
saveas(h,pngFile);
close(h);
end

function local_plot_t(pack, figFile, pngFile)
t = pack.summaryU.stage4T;
if ~isfield(t,'branchSummary') || isempty(t.branchSummary)
    return;
end
bt = t.branchSummary;
n = numel(bt);
labels = cell(1,n);
err = zeros(n,3); speed = zeros(1,n);
for k = 1:n
    labels{k} = bt(k).branch;
    err(k,1) = bt(k).maxRelRhoSR;
    err(k,2) = bt(k).maxRelCurrent;
    err(k,3) = bt(k).maxRelChirality;
    speed(k) = bt(k).meanSpeedup;
end
h = figure('Visible','off');
subplot(1,2,1); bar(err); title('Full-Fock vs LBO relative errors'); ylabel('max relative error');
set(gca,'XTick',1:n,'XTickLabel',labels); xtickangle_safe(35); legend({'\rho_{SR}','|J|','|\chi|'},'Location','NorthWest');
subplot(1,2,2); bar(speed); title('LBO speedup'); ylabel('full/LBO runtime');
set(gca,'XTick',1:n,'XTickLabel',labels); xtickangle_safe(35);
set(h,'Position',[100 100 1000 380]);
saveas(h,figFile);
saveas(h,pngFile);
close(h);
end

function xtickangle_safe(a)
if exist('xtickangle','file') == 2 || exist('xtickangle','builtin') == 5
    xtickangle(a);
end
end
