function err = PEPS_RelErr(A,B)
%PEPS_RELERR Relative Frobenius error between two arrays.

    denom = norm(B(:));
    if denom == 0
        denom = 1;
    end
    err = norm(A(:)-B(:))/denom;
end
