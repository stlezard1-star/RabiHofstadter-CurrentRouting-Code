function [Anew, Bnew, lambda, info] = SU_ApplyTwoSiteGate(A, B, direction, gate, Dmax, opts)
%SU_APPLYTWOSITEGATE Apply a two-site physical gate and split by SVD.
%
%   [Anew,Bnew,lambda,info] = SU_ApplyTwoSiteGate(A,B,direction,gate,Dmax,opts)
%
%   Tensor convention:
%       A(s,l,r,u,d), B(s,l,r,u,d).
%
%   Supported direction values:
%       'right' : B is the right neighbor of A.  Contract A.r with B.l.
%       'down'  : B is the lower neighbor of A.  Contract A.d with B.u.
%
%   The output tensors keep the same external virtual dimensions and replace
%   the updated bond by the truncated SVD bond.  Singular values are split as
%   sqrt(S) into both tensors.  This keeps the returned PEPS self-contained;
%   the returned lambda is diagnostic and can later be promoted to a canonical
%   simple-update weight.
%
%   Stage-4 scope:
%       dense tensors, no symmetry sectors, no explicit lambda environment.

    if nargin < 6
        opts = struct();
    end
    doNormalize = SU_GetOpt(opts,'normalize',true);
    svdCutoff   = SU_GetOpt(opts,'svdCutoff',0.0);

    A = reshape(A, PEPS_FullSize(A,5));
    B = reshape(B, PEPS_FullSize(B,5));
    szA = PEPS_FullSize(A,5); szB = PEPS_FullSize(B,5);
    dA = szA(1); dB = szB(1);
    if dA ~= dB
        error('SU_ApplyTwoSiteGate:PhysicalDimMismatch','Physical dimensions of A and B differ.');
    end
    d = dA;
    if ~isequal(size(gate), [d*d d*d])
        error('SU_ApplyTwoSiteGate:GateSizeMismatch','Gate must have size d^2-by-d^2.');
    end

    dir = lower(direction);
    switch dir
        case {'right','r','x'}
            % Contract A.r with B.l.
            if szA(3) ~= szB(2)
                error('SU_ApplyTwoSiteGate:BondMismatch','A.r and B.l dimensions do not match.');
            end
            theta = PEPS_ContractPair_Fast(A, B, 3, 2, [], 5, 5);
            % theta order: A[s,l,u,d], B[s,r,u,d]
            theta = reshape(theta, [szA(1), szA(2), szA(4), szA(5), szB(1), szB(3), szB(4), szB(5)]);
            theta = apply_gate_to_theta(theta, gate, d, [1 5]);
            leftDims  = [szA(1), szA(2), szA(4), szA(5)];
            rightDims = [szB(1), szB(3), szB(4), szB(5)];
            thetaMat = reshape(permute(theta,[1 2 3 4 5 6 7 8]), prod(leftDims), prod(rightDims));
            [Anew, Bnew, lambda, info] = split_matrix(thetaMat, leftDims, rightDims, Dmax, svdCutoff);
            % Anew current order: [s,l,u,d,bond] -> [s,l,r,u,d]
            Anew = permute(Anew, [1 2 5 3 4]);
            % Bnew current order: [bond,s,r,u,d] after helper -> [s,l,r,u,d]
            Bnew = permute(Bnew, [2 1 3 4 5]);

        case {'down','d','y'}
            % Contract A.d with B.u.
            if szA(5) ~= szB(4)
                error('SU_ApplyTwoSiteGate:BondMismatch','A.d and B.u dimensions do not match.');
            end
            theta = PEPS_ContractPair_Fast(A, B, 5, 4, [], 5, 5);
            % theta order: A[s,l,r,u], B[s,l,r,d]
            theta = reshape(theta, [szA(1), szA(2), szA(3), szA(4), szB(1), szB(2), szB(3), szB(5)]);
            theta = apply_gate_to_theta(theta, gate, d, [1 5]);
            leftDims  = [szA(1), szA(2), szA(3), szA(4)];
            rightDims = [szB(1), szB(2), szB(3), szB(5)];
            thetaMat = reshape(permute(theta,[1 2 3 4 5 6 7 8]), prod(leftDims), prod(rightDims));
            [Anew, Bnew, lambda, info] = split_matrix(thetaMat, leftDims, rightDims, Dmax, svdCutoff);
            % Anew current order: [s,l,r,u,bond] -> [s,l,r,u,d]
            % no permute needed except keep explicit reshape
            % Bnew current order: [bond,s,l,r,d] -> [s,l,r,u,d]
            Bnew = permute(Bnew, [2 3 4 1 5]);

        otherwise
            error('SU_ApplyTwoSiteGate:UnknownDirection','Unknown direction: %s', direction);
    end

    if doNormalize
        Anew = iPEPS_NormalizeTensor(Anew);
        Bnew = iPEPS_NormalizeTensor(Bnew);
    end
end

function theta = apply_gate_to_theta(theta, gate, d, physPos)
%APPLY_GATE_TO_THETA Apply a d^2-by-d^2 physical gate on two physical legs.
    ord = ndims(theta);
    % ndims can drop trailing singleton legs, enforce using size vector.
    sz = size(theta);
    if numel(sz) < 8
        sz = [sz ones(1,8-numel(sz))];
    end
    other = 1:8;
    other(physPos) = [];
    perm = [physPos other];
    invperm(perm) = 1:8;
    X = permute(reshape(theta, sz), perm);
    X = reshape(X, d*d, []);
    X = gate * X;
    X = reshape(X, [d d sz(other)]);
    theta = permute(X, invperm);
end

function [Afac, Bfac, lambda, info] = split_matrix(M, leftDims, rightDims, Dmax, svdCutoff)
%SPLIT_MATRIX SVD split with sqrt singular values absorbed into both sides.
    [U,S,V] = svd(M,'econ');
    sval = diag(S);
    if isempty(sval)
        error('SU_ApplyTwoSiteGate:EmptySVD','SVD returned no singular values.');
    end
    keep = min(Dmax, numel(sval));
    if svdCutoff > 0
        keep2 = sum(sval > svdCutoff * max(sval));
        keep = min(keep, max(1,keep2));
    end
    svalKeep = sval(1:keep);
    U = U(:,1:keep);
    V = V(:,1:keep);

    sqrtS = sqrt(svalKeep(:));
    AfacMat = bsxfun(@times, U, sqrtS.');
    BfacMat = bsxfun(@times, sqrtS, V');

    Afac = reshape(AfacMat, [leftDims keep]);
    Bfac = reshape(BfacMat, [keep rightDims]);

    nrm = norm(svalKeep);
    if nrm > 0
        lambda = svalKeep(:) / nrm;
    else
        lambda = svalKeep(:);
    end
    info = struct();
    info.singularValues = sval;
    info.keptSingularValues = svalKeep;
    info.keep = keep;
    info.discardedWeight = sum(sval(keep+1:end).^2);
    info.relDiscardedWeight = info.discardedWeight / max(sum(sval.^2), eps);
end
