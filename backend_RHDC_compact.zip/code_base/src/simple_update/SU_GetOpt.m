function val = SU_GetOpt(opts, name, defaultVal)
%SU_GETOPT Small helper for option structs.
    if nargin < 1 || isempty(opts) || ~isstruct(opts) || ~isfield(opts,name) || isempty(opts.(name))
        val = defaultVal;
    else
        val = opts.(name);
    end
end
