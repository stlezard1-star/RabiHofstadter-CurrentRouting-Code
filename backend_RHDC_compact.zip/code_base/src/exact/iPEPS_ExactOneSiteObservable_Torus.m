function [expVal, numerator, denominator] = iPEPS_ExactOneSiteObservable_Torus(unitCell,op,targetX,targetY,Lx,Ly)
%IPEPS_EXACTONESITEOBSERVABLE_TORUS Exact one-site observable on a small torus.
%
%   The operator is inserted at lattice coordinate (targetX,targetY), while
%   all other sites carry norm double-layer tensors.

    Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell);
    A0 = iPEPS_GetTensor(unitCell,targetX,targetY);
    Eop = iPEPS_BuildDoubleLayerTensor(A0,op);

    tensorList = cell(1,Lx*Ly);
    for y = 1:Ly
        for x = 1:Lx
            siteID = (y-1)*Lx + x;
            if x == targetX && y == targetY
                tensorList{siteID} = Eop;
            else
                tensorList{siteID} = iPEPS_GetCellTensor(Ecell,x,y);
            end
        end
    end

    [legLinks, sequence] = iPEPS_MakeTorusLegLinks(Lx,Ly);
    numerator = ncon(tensorList,legLinks,sequence);
    denominator = iPEPS_ExactContractDoubleLayer_Torus(Ecell,Lx,Ly);
    expVal = numerator / denominator;
end
