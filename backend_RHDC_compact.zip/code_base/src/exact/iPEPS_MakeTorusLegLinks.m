function [legLinks, sequence, hLabels, vLabels] = iPEPS_MakeTorusLegLinks(Lx,Ly)
%IPEPS_MAKETORUSLEGLINKS Make periodic torus leg labels for 4-leg PEPS tensors.
%
%   Leg convention for every tensor:
%       [left, right, up, down].
%
%   Horizontal label hLabels(y,x) connects:
%       right leg of site (x,y) to left leg of site (x+1,y).
%
%   Vertical label vLabels(y,x) connects:
%       down leg of site (x,y) to up leg of site (x,y+1).
%
%   Site order in the returned cell array is row-major:
%       siteID = (y-1)*Lx + x.

    if Lx < 1 || Ly < 1
        error('iPEPS_MakeTorusLegLinks:InvalidSize', 'Lx and Ly must be positive.');
    end

    hLabels = zeros(Ly,Lx);
    vLabels = zeros(Ly,Lx);
    nextLabel = 1;

    for y = 1:Ly
        for x = 1:Lx
            hLabels(y,x) = nextLabel;
            nextLabel = nextLabel + 1;
        end
    end
    for y = 1:Ly
        for x = 1:Lx
            vLabels(y,x) = nextLabel;
            nextLabel = nextLabel + 1;
        end
    end

    legLinks = cell(1,Lx*Ly);
    for y = 1:Ly
        for x = 1:Lx
            siteID = (y-1)*Lx + x;
            xm1 = mod(x-2,Lx) + 1;
            ym1 = mod(y-2,Ly) + 1;
            leftLabel  = hLabels(y,xm1);
            rightLabel = hLabels(y,x);
            upLabel    = vLabels(ym1,x);
            downLabel  = vLabels(y,x);
            legLinks{siteID} = [leftLabel, rightLabel, upLabel, downLabel];
        end
    end

    sequence = 1:(nextLabel-1);
end
