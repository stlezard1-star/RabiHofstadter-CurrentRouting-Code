function val = iPEPS_ExactContractDoubleLayer_Torus(Ecell,Lx,Ly)
%IPEPS_EXACTCONTRACTDOUBLELAYER_TORUS Exact contraction of a small periodic double-layer network.
%
%   val = iPEPS_ExactContractDoubleLayer_Torus(Ecell,Lx,Ly)
%
%   Ecell is a finite unit cell of 4-leg double-layer tensors with leg order
%   [left,right,up,down].  The unit cell is repeated over an Lx-by-Ly torus.
%
%   This function is for Stage-1 correctness tests only.  It scales
%   exponentially with system size and must not be used as a production
%   PEPS contraction method.

    tensorList = cell(1,Lx*Ly);
    for y = 1:Ly
        for x = 1:Lx
            siteID = (y-1)*Lx + x;
            tensorList{siteID} = iPEPS_GetCellTensor(Ecell,x,y);
        end
    end

    [legLinks, sequence] = iPEPS_MakeTorusLegLinks(Lx,Ly);
    val = ncon(tensorList,legLinks,sequence);
end
