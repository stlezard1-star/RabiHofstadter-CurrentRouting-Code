function [expVal, numerator, denominator] = iPEPS_ExactProductOpTerms_Torus(unitCell, terms, x1, y1, x2, y2, Lx, Ly)
%IPEPS_EXACTPRODUCTOPTERMS_TORUS Exact two-site observable given as product-op terms.
%
%   terms(t).coeff * terms(t).opA at (x1,y1) * terms(t).opB at (x2,y2).
%   This is sufficient for Heisenberg bonds and most Stage-3 tests.

    if nargin < 8
        error('iPEPS_ExactProductOpTerms_Torus:NotEnoughInputs','Need unitCell, terms, two coordinates, Lx, Ly.');
    end
    if x1 == x2 && y1 == y2
        error('iPEPS_ExactProductOpTerms_Torus:SameSite','Use one-site observable for same-site operators.');
    end

    Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell);
    denominator = iPEPS_ExactContractDoubleLayer_Torus(Ecell,Lx,Ly);
    numerator = 0;

    [legLinks, sequence] = iPEPS_MakeTorusLegLinks(Lx,Ly);

    for t = 1:numel(terms)
        tensorList = cell(1,Lx*Ly);
        for y = 1:Ly
            for x = 1:Lx
                siteID = (y-1)*Lx + x;
                if x == x1 && y == y1
                    A0 = iPEPS_GetTensor(unitCell,x,y);
                    tensorList{siteID} = iPEPS_BuildDoubleLayerTensor(A0, terms(t).opA);
                elseif x == x2 && y == y2
                    A0 = iPEPS_GetTensor(unitCell,x,y);
                    tensorList{siteID} = iPEPS_BuildDoubleLayerTensor(A0, terms(t).opB);
                else
                    tensorList{siteID} = iPEPS_GetCellTensor(Ecell,x,y);
                end
            end
        end
        val = ncon(tensorList, legLinks, sequence);
        numerator = numerator + terms(t).coeff * val;
    end

    expVal = numerator / denominator;
    if abs(imag(expVal)) < 1e-12 * max(1,abs(real(expVal)))
        expVal = real(expVal);
    end
end
