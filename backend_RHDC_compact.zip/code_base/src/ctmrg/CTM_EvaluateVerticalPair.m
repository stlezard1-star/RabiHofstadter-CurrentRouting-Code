function val = CTM_EvaluateVerticalPair(Aup, Adown, env)
%CTM_EVALUATEVERTICALPAIR Contract a two-block vertical impurity cluster.
%
% Stage-9E optimized implementation.  The original vertical ncon sequence
% was correct but expensive for the safe16 benchmark: profiler data showed
% that CTM_EvaluateVerticalPair dominated the total runtime.  This routine
% maps the vertical pair to a horizontal pair by a counter-clockwise rotation
% of both the central impurity tensors and the uniform CTM environment, then
% reuses the faster horizontal pair contraction kernel.
%
% Aup/Adown leg order: [left,right,up,down].

    Aup   = reshape(Aup,   PEPS_FullSize(Aup,4));
    Adown = reshape(Adown, PEPS_FullSize(Adown,4));

    % Counter-clockwise rotation of a rank-4 block tensor:
    % new [left,right,up,down] = old [up,down,right,left].
    Aleft  = permute(Aup,   [3 4 2 1]);
    Aright = permute(Adown, [3 4 2 1]);

    envR = CTM_RotateEnvCCW(env);
    val = CTM_EvaluateHorizontalPair(Aleft, Aright, envR);
end
