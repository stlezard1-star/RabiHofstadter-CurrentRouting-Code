function [env, info] = CTM_MoveUp(A, env, opts)
%CTM_MOVEUP Absorb one row into the upper CTM boundary.

    if nargin < 3
        opts = struct();
    end
    chiMax = CTM_GetOpt(opts,'chiMax',env.chiMax);
    cutoff = CTM_GetOpt(opts,'svdCutoff',0);

    qD = size(A,4); qL = size(A,1); qR = size(A,2);

    % C1tilde: C1[down,right] with T4[up,l,down] over down/up.
    X1 = PEPS_ContractPair_Fast(env.C1, env.T4, 1, 1, [], 2, 3);
    % X1 order: [C1.right, T4.l, T4.down]
    sx1 = PEPS_FullSize(X1,3);
    X1 = permute(X1,[3 1 2]);
    C1t = reshape(X1, [sx1(3), sx1(1)*sx1(2)]); % [newDown, (oldRight,l)]

    % C2tilde: C2[left,down] with T2[up,r,down] over down/up.
    X2 = PEPS_ContractPair_Fast(env.C2, env.T2, 2, 1, [], 2, 3);
    % X2 default order: [C2.left, T2.r, T2.down].
    % For the projector construction below, both enlarged corners must be
    % stored as [newVertical, enlargedHorizontal].  This matches C1t and
    % makes M = C1t' * C2t well-defined even when chi and q are unequal.
    sx2 = PEPS_FullSize(X2,3);
    X2 = permute(X2,[3 1 2]);
    C2t = reshape(X2, [sx2(3), sx2(1)*sx2(2)]); % [newDown, (oldLeft,r)]

    % T1tilde: T1[left,u,right] with A[l,r,u,d] over u.
    X = PEPS_ContractPair_Fast(env.T1, A, 2, 3, [], 3, 4);
    % X order: [T1.left, T1.right, A.l, A.r, A.d]
    sx = PEPS_FullSize(X,5);
    X = permute(X,[1 3 5 2 4]);
    T1t = reshape(X, [sx(1)*sx(3), qD, sx(2)*sx(4)]); % [(oldLeft,l), d, (oldRight,r)]

    M = C1t' * C2t; % [leftEnlarged,rightEnlarged]
    [Pleft,Pright,sval] = CTM_TruncateSVD(M, chiMax, cutoff);

    env.C1 = C1t * Pleft;              % [newDown, chi]
    env.C2 = (C2t * Pright).';          % [chi, newDown]
    Y = PEPS_ContractPair_Fast(Pleft', T1t, 2, 1, [], 2, 3);
    Y = PEPS_ContractPair_Fast(Y, Pright, 3, 1, [], 3, 2);
    env.T1 = Y;

    [env.C1,~] = CTM_FroNormalize(env.C1);
    [env.C2,~] = CTM_FroNormalize(env.C2);
    [env.T1,~] = CTM_FroNormalize(env.T1);

    info = struct();
    info.direction = 'up';
    info.singularValues = sval;
    info.chi = size(env.C1,2);
end
