function W = CTM_BuildOneSiteEnvironment(env)
%CTM_BUILDONESITEENVIRONMENT Build the open one-site CTM environment.
%
%   W = CTM_BuildOneSiteEnvironment(env) contracts the 3x3 CTM frame
%   without the central rank-4 tensor A.  The returned tensor W has the same
%   leg order as the central double-layer tensor,
%
%       W(left,right,up,down),
%
%   so that repeated one-site expectation values can be evaluated as
%
%       val = sum(W(:).*A(:)).
%
%   This is useful in observable routines where many impurity tensors are
%   measured with the same CTM environment.  It avoids rebuilding the same
%   ncon environment for each impurity.

    tensorList = {env.C1, env.T1, env.C2, env.T2, env.C3, env.T3, env.C4, env.T4};
    legLinks = { ...
        [1 2], ...          % C1 [down,right]
        [2 -3 3], ...       % T1 [left,up,right]; open up -> A.up
        [3 4], ...          % C2 [left,down]
        [4 -2 5], ...       % T2 [up,right,down]; open right -> A.right
        [5 6], ...          % C3 [up,left]
        [7 -4 6], ...       % T3 [left,down,right]; open down -> A.down
        [8 7], ...          % C4 [up,right]
        [1 -1 8] ...        % T4 [up,left,down]; open left -> A.left
        };
    % Negative legs are returned in order [-1 -2 -3 -4] = [L R U D].
    W = ncon(tensorList, legLinks, 1:8, [-1 -2 -3 -4]);
end
