function [env, info] = CTM_MoveRight(A, env, opts)
%CTM_MOVERIGHT Absorb one column into the right CTM boundary.

    if nargin < 3
        opts = struct();
    end
    chiMax = CTM_GetOpt(opts,'chiMax',env.chiMax);
    cutoff = CTM_GetOpt(opts,'svdCutoff',0);

    qL = size(A,1); qU = size(A,3); qD = size(A,4);

    % C2tilde: C2[left,down] with T1[left,u,right] over C2.left/T1.right.
    X2 = PEPS_ContractPair_Fast(env.C2, env.T1, 1, 3, [], 2, 3);
    % X2 order: [C2.down, T1.left, T1.u]
    sx2 = PEPS_FullSize(X2,3);
    X2 = permute(X2,[2 3 1]);
    C2t = reshape(X2, [sx2(2), sx2(3)*sx2(1)]); % [topLeft, (u,oldDown)]

    % C3tilde: C3[up,left] with T3[left,d,right] over C3.left/T3.right.
    X3 = PEPS_ContractPair_Fast(env.C3, env.T3, 2, 3, [], 2, 3);
    % X3 order: [C3.up, T3.left, T3.d]
    sx3 = PEPS_FullSize(X3,3);
    X3 = permute(X3,[2 3 1]);
    C3t = reshape(X3, [sx3(2), sx3(3)*sx3(1)]); % [bottomLeft, (d,oldUp)]

    % T2tilde: T2[up,r,down] with A[l,r,u,d] over r.
    X = PEPS_ContractPair_Fast(env.T2, A, 2, 2, [], 3, 4);
    % X order: [T2.up, T2.down, A.l, A.u, A.d]
    sx = PEPS_FullSize(X,5);
    X = permute(X,[4 1 3 5 2]);
    T2t = reshape(X, [sx(4)*sx(1), qL, sx(5)*sx(2)]); % [(u,oldUp), l, (d,oldDown)]

    M = C2t' * C3t; % [(u,oldDown), (d,oldUp)]
    [Ptop,Pbot,sval] = CTM_TruncateSVD(M, chiMax, cutoff);

    env.C2 = C2t * Ptop;
    env.C3 = (C3t * Pbot).';
    Y = PEPS_ContractPair_Fast(Ptop', T2t, 2, 1, [], 2, 3);
    Y = PEPS_ContractPair_Fast(Y, Pbot, 3, 1, [], 3, 2);
    env.T2 = Y;

    [env.C2,~] = CTM_FroNormalize(env.C2);
    [env.C3,~] = CTM_FroNormalize(env.C3);
    [env.T2,~] = CTM_FroNormalize(env.T2);

    info = struct();
    info.direction = 'right';
    info.singularValues = sval;
    info.chi = size(env.C2,2);
end
