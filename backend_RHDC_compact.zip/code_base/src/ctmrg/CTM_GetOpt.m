function val = CTM_GetOpt(opts, name, defaultVal)
%CTM_GETOPT Read an option field with a default value.
    if nargin < 1 || isempty(opts) || ~isstruct(opts) || ~isfield(opts,name) || isempty(opts.(name))
        val = defaultVal;
    else
        val = opts.(name);
    end
end
