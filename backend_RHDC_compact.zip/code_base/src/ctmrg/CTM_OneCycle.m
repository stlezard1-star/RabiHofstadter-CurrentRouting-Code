function [env, info] = CTM_OneCycle(A, env, opts)
%CTM_ONECYCLE Perform one left-right-up-down CTM update cycle.
    [env, infoL] = CTM_MoveLeft(A, env, opts);
    [env, infoR] = CTM_MoveRight(A, env, opts);
    [env, infoU] = CTM_MoveUp(A, env, opts);
    [env, infoD] = CTM_MoveDown(A, env, opts);
    env = CTM_NormalizeEnv(env);
    CTM_CheckEnv(env);
    env.iter = env.iter + 1;
    info = struct();
    info.left = infoL;
    info.right = infoR;
    info.up = infoU;
    info.down = infoD;
end
