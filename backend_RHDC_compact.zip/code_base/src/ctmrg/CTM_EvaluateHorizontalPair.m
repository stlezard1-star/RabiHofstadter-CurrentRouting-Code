function val = CTM_EvaluateHorizontalPair(Aleft, Aright, env)
%CTM_EVALUATEHORIZONTALPAIR Contract a two-block horizontal impurity cluster.
%
% Layout:
%   C1--T1L--T1R--C2
%   |    |    |    |
%   T4-- AL-- AR --T2
%   |    |    |    |
%   C4--T3L--T3R--C3
%
% Aleft/Aright leg order: [left,right,up,down].
%
% This is a Stage-5 dense reference kernel.  It is intentionally explicit
% and uses ncon to reduce index-order mistakes.  Later performance stages
% can specialize this contraction.

    tensorList = {env.C1, env.T1, env.T1, env.C2, env.T2, env.C3, ...
                  env.T3, env.T3, env.C4, env.T4, Aleft, Aright};
    legLinks = { ...
        [11 1], ...          % C1 [down,right]
        [1 14 2], ...        % T1 left block [left,up,right]
        [2 15 3], ...        % T1 right block
        [3 4], ...           % C2 [left,down]
        [4 13 5], ...        % T2 [up,right,down]
        [5 7], ...           % C3 [up,left]
        [8 17 7], ...        % T3 right block [left,down,right]
        [9 16 8], ...        % T3 left block
        [10 9], ...          % C4 [up,right]
        [11 12 10], ...      % T4 [up,left,down]
        [12 18 14 16], ...   % Aleft [left,right,up,down]
        [18 13 15 17] ...    % Aright
        };
    % Use a contraction sequence that first builds the top and bottom
    % boundary rows, then absorbs the left impurity block and finally the
    % right impurity block.  The naive ascending sequence produces a very
    % large intermediate for q > 1 because it postpones several parallel
    % links between the same effective tensors.  Index 6 is intentionally
    % unused in this layout.
    sequence = [1 2 3 ...      % top row: C1--T1L--T1R--C2
                9 8 7 ...      % bottom row: C4--T3L--T3R--C3
                11 ...         % attach left boundary T4 to top row
                12 14 ...      % absorb Aleft through T4/top links
                10 16 ...      % absorb bottom links of Aleft
                4 5 ...        % attach right boundary T2
                13 15 17 18];  % close Aright
    val = ncon(tensorList, legLinks, sequence);
    if abs(imag(val)) < 1e-12 * max(1,abs(real(val)))
        val = real(val);
    end
end
