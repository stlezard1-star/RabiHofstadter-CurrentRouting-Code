function diffVal = CTM_EnvDiff(envA, envB)
%CTM_ENVDIFF Relative difference between two normalized CTM environments.
%
%   diffVal = CTM_EnvDiff(envA,envB)
%
%   During the first few CTMRG iterations the environment bond dimension may
%   grow from chi=1 to the requested chiMax.  In that growth regime the tensor
%   sizes are not directly comparable.  This should be treated as "not yet
%   converged", but it must remain finite so that convergence histories and
%   automated tests do not contain Inf values.

    fields = {'C1','C2','C3','C4','T1','T2','T3','T4'};
    diffVal = 0;
    sizeChanged = false;

    for k = 1:numel(fields)
        f = fields{k};
        if ~isequal(size(envA.(f)), size(envB.(f)))
            sizeChanged = true;
            continue;
        end
        d = PEPS_RelErr(envA.(f), envB.(f));
        if ~isfinite(d)
            % Keep a finite but unmistakably non-converged value.  Non-finite
            % values here usually indicate zero/zero relative-error estimates
            % or transient gauge changes during early CTMRG growth.
            d = 1;
        end
        diffVal = max(diffVal, d);
    end

    if sizeChanged
        % The environment grew or changed chi.  It is not converged, but the
        % history should remain finite.  A value of 1 is conservative and
        % prevents premature convergence for any realistic tolerance.
        diffVal = max(diffVal, 1);
    end
end
