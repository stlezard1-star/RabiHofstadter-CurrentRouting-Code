function env = CTM_InitUniform(A, opts)
%CTM_INITUNIFORM Initialize a one-site CTM environment for a 4-leg tensor.
%
%   env = CTM_InitUniform(A, opts)
%
%   A leg order is [left,right,up,down].  The Stage-2 CTMRG code starts
%   from minimal chi=1 boundary tensors and grows/truncates them by
%   directional moves.

    if nargin < 2
        opts = struct();
    end
    chiMax = CTM_GetOpt(opts,'chiMax',16);
    if chiMax < 1
        error('CTM_InitUniform:InvalidChi','chiMax must be positive.');
    end

    sz = PEPS_FullSize(A,4);
    qL = sz(1); qR = sz(2); qU = sz(3); qD = sz(4);
    if qL ~= qR || qU ~= qD
        error('CTM_InitUniform:UnsupportedDims', ...
              'Stage-2 uniform CTMRG expects qL=qR and qU=qD. Got [%d %d %d %d].', qL,qR,qU,qD);
    end

    env = struct();
    env.chiMax = chiMax;
    env.tensorSize = sz;
    env.C1 = 1;
    env.C2 = 1;
    env.C3 = 1;
    env.C4 = 1;
    env.T1 = ones(1,qU,1); % top    [left, up-leg, right]
    env.T2 = ones(1,qR,1); % right  [up, right-leg, down]
    env.T3 = ones(1,qD,1); % bottom [left, down-leg, right]
    env.T4 = ones(1,qL,1); % left   [up, left-leg, down]
    env.iter = 0;
    env.lastDiff = Inf;
    env.history = [];
    env.stage = 'Stage2_uniform_CTM';
end
