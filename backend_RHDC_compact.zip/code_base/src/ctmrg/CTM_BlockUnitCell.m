function B = CTM_BlockUnitCell(Ecell)
%CTM_BLOCKUNITCELL Block a finite unit-cell of double-layer tensors into one 4-leg tensor.
%
%   B = CTM_BlockUnitCell(Ecell)
%
%   Ecell is a Ly-by-Lx cell array.  Each tensor has leg order
%       [left, right, up, down].
%
%   The returned blocked tensor B has leg order
%       [leftBlock, rightBlock, upBlock, downBlock].
%
%   Boundary-leg ordering inside each block index:
%       leftBlock  : y = 1..Ly, original left legs of x=1 column
%       rightBlock : y = 1..Ly, original right legs of x=Lx column
%       upBlock    : x = 1..Lx, original up legs of y=1 row
%       downBlock  : x = 1..Lx, original down legs of y=Ly row
%
%   This is a conservative Stage-2 implementation.  It lets the initial
%   CTMRG code treat a finite unit cell as one effective uniform tensor.
%   It is not the final high-performance multi-site CTMRG representation.

    if ~iscell(Ecell) || isempty(Ecell)
        error('CTM_BlockUnitCell:InvalidInput','Ecell must be a non-empty cell array.');
    end
    [Ly,Lx] = size(Ecell);

    tensorList = cell(1,Lx*Ly);
    legLinks = cell(1,Lx*Ly);

    % Positive labels for internal bonds only.
    hLabels = zeros(Ly,max(Lx-1,0));
    vLabels = zeros(max(Ly-1,0),Lx);
    nextPositive = 1;
    for y = 1:Ly
        for x = 1:(Lx-1)
            hLabels(y,x) = nextPositive;
            nextPositive = nextPositive + 1;
        end
    end
    for y = 1:(Ly-1)
        for x = 1:Lx
            vLabels(y,x) = nextPositive;
            nextPositive = nextPositive + 1;
        end
    end

    % Negative labels for external boundaries.
    leftNeg  = zeros(1,Ly);
    rightNeg = zeros(1,Ly);
    upNeg    = zeros(1,Lx);
    downNeg  = zeros(1,Lx);
    nextNegative = -1;
    for y = 1:Ly
        leftNeg(y) = nextNegative;
        nextNegative = nextNegative - 1;
    end
    for y = 1:Ly
        rightNeg(y) = nextNegative;
        nextNegative = nextNegative - 1;
    end
    for x = 1:Lx
        upNeg(x) = nextNegative;
        nextNegative = nextNegative - 1;
    end
    for x = 1:Lx
        downNeg(x) = nextNegative;
        nextNegative = nextNegative - 1;
    end

    for y = 1:Ly
        for x = 1:Lx
            siteID = (y-1)*Lx + x;
            T = Ecell{y,x};
            sz = PEPS_FullSize(T,4);
            if numel(sz) ~= 4
                error('CTM_BlockUnitCell:TensorRank','Each E tensor must have four legs.');
            end
            tensorList{siteID} = T;

            if x == 1
                lLab = leftNeg(y);
            else
                lLab = hLabels(y,x-1);
            end
            if x == Lx
                rLab = rightNeg(y);
            else
                rLab = hLabels(y,x);
            end
            if y == 1
                uLab = upNeg(x);
            else
                uLab = vLabels(y-1,x);
            end
            if y == Ly
                dLab = downNeg(x);
            else
                dLab = vLabels(y,x);
            end
            legLinks{siteID} = [lLab rLab uLab dLab];
        end
    end

    sequence = 1:(nextPositive-1);
    finalOrder = [leftNeg rightNeg upNeg downNeg];
    Tout = ncon(tensorList, legLinks, sequence, finalOrder);

    % Compute grouped dimensions using the boundary tensors.
    leftDims = zeros(1,Ly);
    rightDims = zeros(1,Ly);
    for y = 1:Ly
        leftDims(y) = size(Ecell{y,1},1);
        rightDims(y) = size(Ecell{y,Lx},2);
    end
    upDims = zeros(1,Lx);
    downDims = zeros(1,Lx);
    for x = 1:Lx
        upDims(x) = size(Ecell{1,x},3);
        downDims(x) = size(Ecell{Ly,x},4);
    end

    B = reshape(Tout, [prod(leftDims), prod(rightDims), prod(upDims), prod(downDims)]);
end
