function envR = CTM_RotateEnvCCW(env)
%CTM_ROTATEENVCCW Rotate a uniform CTM environment by 90 degrees counter-clockwise.
%
% CTM conventions:
%   C1 [down,right], C2 [left,down], C3 [up,left], C4 [up,right]
%   T1 [left,up,right], T2 [up,right,down], T3 [left,down,right], T4 [up,left,down]
%
% Under a counter-clockwise rotation of the physical network:
%   new left  = old up
%   new right = old down
%   new up    = old right
%   new down  = old left
%
% This utility is used to evaluate vertical pair clusters by mapping them
% to the already optimized horizontal pair contraction kernel.

    C1 = reshape(env.C1, PEPS_FullSize(env.C1,2));
    C2 = reshape(env.C2, PEPS_FullSize(env.C2,2));
    C3 = reshape(env.C3, PEPS_FullSize(env.C3,2));
    C4 = reshape(env.C4, PEPS_FullSize(env.C4,2));

    T1 = reshape(env.T1, PEPS_FullSize(env.T1,3));
    T2 = reshape(env.T2, PEPS_FullSize(env.T2,3));
    T3 = reshape(env.T3, PEPS_FullSize(env.T3,3));
    T4 = reshape(env.T4, PEPS_FullSize(env.T4,3));

    envR.C1 = C2;
    envR.C2 = C3;
    envR.C3 = permute(C4,[2 1]);
    envR.C4 = permute(C1,[2 1]);

    envR.T1 = T2;
    envR.T2 = permute(T3,[3 2 1]);
    envR.T3 = T4;
    envR.T4 = permute(T1,[3 2 1]);
end
