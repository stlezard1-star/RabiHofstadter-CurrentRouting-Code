function Bop = CTM_BlockUnitCell_ProductOpTerms(unitCell, terms, x1, y1, x2, y2)
%CTM_BLOCKUNITCELL_PRODUCTOPTERMS Block unit cell with a two-site operator insertion.
%
%   Bop = CTM_BlockUnitCell_ProductOpTerms(unitCell, terms, x1,y1,x2,y2)
%
%   terms(t).coeff * terms(t).opA(x1,y1) * terms(t).opB(x2,y2)
%
%   This routine assumes the two target physical sites are inside the same
%   finite unit cell.  It constructs the blocked impurity tensor by summing
%   product-operator decomposed one-site double layers before the finite
%   unit-cell blocking contraction.
%
%   The returned tensor has the same external block legs as CTM_BlockUnitCell.

    if x1 == x2 && y1 == y2
        error('CTM_BlockUnitCell_ProductOpTerms:SameSite', ...
              'Use CTM_BlockUnitCell_OneSiteOp for a same-site operator.');
    end
    iPEPS_CheckUnitCell(unitCell);
    x1 = mod(x1-1, unitCell.Lx) + 1;
    x2 = mod(x2-1, unitCell.Lx) + 1;
    y1 = mod(y1-1, unitCell.Ly) + 1;
    y2 = mod(y2-1, unitCell.Ly) + 1;

    Bop = [];
    for t = 1:numel(terms)
        Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell);
        A1 = iPEPS_GetTensor(unitCell,x1,y1);
        A2 = iPEPS_GetTensor(unitCell,x2,y2);
        Ecell{y1,x1} = iPEPS_BuildDoubleLayerTensor(A1, terms(t).opA);
        Ecell{y2,x2} = iPEPS_BuildDoubleLayerTensor(A2, terms(t).opB);
        Bt = CTM_BlockUnitCell(Ecell);
        if isempty(Bop)
            Bop = terms(t).coeff * Bt;
        else
            Bop = Bop + terms(t).coeff * Bt;
        end
    end
end
