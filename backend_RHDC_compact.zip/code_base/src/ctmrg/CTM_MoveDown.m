function [env, info] = CTM_MoveDown(A, env, opts)
%CTM_MOVEDOWN Absorb one row into the lower CTM boundary.

    if nargin < 3
        opts = struct();
    end
    chiMax = CTM_GetOpt(opts,'chiMax',env.chiMax);
    cutoff = CTM_GetOpt(opts,'svdCutoff',0);

    qU = size(A,3); qL = size(A,1); qR = size(A,2);

    % C4tilde: C4[up,right] with T4[up,l,down] over up/down.
    X4 = PEPS_ContractPair_Fast(env.C4, env.T4, 1, 3, [], 2, 3);
    % X4 order: [C4.right, T4.up, T4.l]
    sx4 = PEPS_FullSize(X4,3);
    X4 = permute(X4,[2 1 3]);
    C4t = reshape(X4, [sx4(2), sx4(1)*sx4(3)]); % [newUp, (oldRight,l)]

    % C3tilde: C3[up,left] with T2[up,r,down] over up/down.
    X3 = PEPS_ContractPair_Fast(env.C3, env.T2, 1, 3, [], 2, 3);
    % X3 order: [C3.left, T2.up, T2.r]
    sx3 = PEPS_FullSize(X3,3);
    X3 = permute(X3,[2 1 3]);
    C3t = reshape(X3, [sx3(2), sx3(1)*sx3(3)]); % [newUp, (oldLeft,r)]

    % T3tilde: T3[left,d,right] with A[l,r,u,d] over d.
    X = PEPS_ContractPair_Fast(env.T3, A, 2, 4, [], 3, 4);
    % X order: [T3.left, T3.right, A.l, A.r, A.u]
    sx = PEPS_FullSize(X,5);
    X = permute(X,[1 3 5 2 4]);
    T3t = reshape(X, [sx(1)*sx(3), qU, sx(2)*sx(4)]); % [(oldLeft,l), u, (oldRight,r)]

    M = C4t' * C3t; % [leftEnlarged,rightEnlarged]
    [Pleft,Pright,sval] = CTM_TruncateSVD(M, chiMax, cutoff);

    env.C4 = C4t * Pleft;
    env.C3 = C3t * Pright;
    Y = PEPS_ContractPair_Fast(Pleft', T3t, 2, 1, [], 2, 3);
    Y = PEPS_ContractPair_Fast(Y, Pright, 3, 1, [], 3, 2);
    env.T3 = Y;

    [env.C4,~] = CTM_FroNormalize(env.C4);
    [env.C3,~] = CTM_FroNormalize(env.C3);
    [env.T3,~] = CTM_FroNormalize(env.T3);

    info = struct();
    info.direction = 'down';
    info.singularValues = sval;
    info.chi = size(env.C4,2);
end
