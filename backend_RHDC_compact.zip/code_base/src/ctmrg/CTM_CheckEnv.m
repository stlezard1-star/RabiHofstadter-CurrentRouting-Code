function CTM_CheckEnv(env)
%CTM_CHECKENV Basic consistency checks for Stage-2 CTM environment.
    req = {'C1','C2','C3','C4','T1','T2','T3','T4'};
    for k = 1:numel(req)
        if ~isfield(env,req{k})
            error('CTM_CheckEnv:MissingField','Missing field %s.',req{k});
        end
        X = env.(req{k});
        if any(~isfinite(X(:)))
            error('CTM_CheckEnv:NonFinite','Field %s contains non-finite entries.',req{k});
        end
    end
    if ndims(env.T1) > 3 || ndims(env.T2) > 3 || ndims(env.T3) > 3 || ndims(env.T4) > 3
        error('CTM_CheckEnv:BadEdgeRank','Edge tensors should be rank-3.');
    end
end
