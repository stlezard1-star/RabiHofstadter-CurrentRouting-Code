function [X,scale] = CTM_FroNormalize(X)
%CTM_FRONORMALIZE Normalize tensor by Frobenius norm, keeping zero tensors stable.
    scale = norm(X(:));
    if scale > 0
        X = X / scale;
    else
        scale = 1;
    end
end
