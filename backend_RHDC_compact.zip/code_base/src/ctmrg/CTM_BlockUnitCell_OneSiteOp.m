function Bop = CTM_BlockUnitCell_OneSiteOp(unitCell, op, targetX, targetY)
%CTM_BLOCKUNITCELL_ONESITEOP Block unit cell with one one-site operator insertion.
%
%   The impurity tensor is meant to be contracted with a converged CTM
%   environment of the corresponding norm blocked tensor.

    Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell);
    A0 = iPEPS_GetTensor(unitCell,targetX,targetY);
    Ecell{mod(targetY-1,unitCell.Ly)+1, mod(targetX-1,unitCell.Lx)+1} = iPEPS_BuildDoubleLayerTensor(A0,op);
    Bop = CTM_BlockUnitCell(Ecell);
end
