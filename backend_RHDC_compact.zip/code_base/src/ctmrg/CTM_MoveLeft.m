function [env, info] = CTM_MoveLeft(A, env, opts)
%CTM_MOVELEFT Absorb one column into the left CTM boundary.
%   Tensor A leg order: [left,right,up,down].

    if nargin < 3
        opts = struct();
    end
    chiMax = CTM_GetOpt(opts,'chiMax',env.chiMax);
    cutoff = CTM_GetOpt(opts,'svdCutoff',0);

    qR = size(A,2); qU = size(A,3); qD = size(A,4);

    % C1tilde: [oldDown, Aup, topRight] -> [(oldDown,Aup), topRight]
    X1 = PEPS_ContractPair_Fast(env.C1, env.T1, 2, 1, [], 2, 3);
    szX1 = PEPS_FullSize(X1,3);
    C1t = reshape(X1, [szX1(1)*szX1(2), szX1(3)]);

    % C4tilde: [oldUp, Adown, bottomRight] -> [(oldUp,Adown), bottomRight]
    X4 = PEPS_ContractPair_Fast(env.C4, env.T3, 2, 1, [], 2, 3);
    szX4 = PEPS_FullSize(X4,3);
    C4t = reshape(X4, [szX4(1)*szX4(2), szX4(3)]);

    % T4tilde: T4[up,l,down] with A[l,r,u,d]
    X = PEPS_ContractPair_Fast(env.T4, A, 2, 1, [], 3, 4);
    % X order: [T4.up, T4.down, A.r, A.u, A.d]
    sx = PEPS_FullSize(X,5);
    X = permute(X,[1 4 3 2 5]);
    T4t = reshape(X, [sx(1)*sx(4), qR, sx(2)*sx(5)]);

    M = C1t * C4t';
    [Ptop,Pbot,sval] = CTM_TruncateSVD(M, chiMax, cutoff);

    env.C1 = Ptop' * C1t;
    env.C4 = Pbot' * C4t;
    Y = PEPS_ContractPair_Fast(Ptop', T4t, 2, 1, [], 2, 3);
    % Y order [newTop, physical, oldBottom]
    Y = PEPS_ContractPair_Fast(Y, Pbot, 3, 1, [], 3, 2);
    % order [newTop, physical, newBottom]
    env.T4 = Y;

    [env.C1,~] = CTM_FroNormalize(env.C1);
    [env.C4,~] = CTM_FroNormalize(env.C4);
    [env.T4,~] = CTM_FroNormalize(env.T4);

    info = struct();
    info.direction = 'left';
    info.singularValues = sval;
    info.chi = size(env.C1,1);
end
