function env = CTM_NormalizeEnv(env)
%CTM_NORMALIZEENV Normalize all CTM boundary tensors to avoid overflow.
    [env.C1,~] = CTM_FroNormalize(env.C1);
    [env.C2,~] = CTM_FroNormalize(env.C2);
    [env.C3,~] = CTM_FroNormalize(env.C3);
    [env.C4,~] = CTM_FroNormalize(env.C4);
    [env.T1,~] = CTM_FroNormalize(env.T1);
    [env.T2,~] = CTM_FroNormalize(env.T2);
    [env.T3,~] = CTM_FroNormalize(env.T3);
    [env.T4,~] = CTM_FroNormalize(env.T4);
end
