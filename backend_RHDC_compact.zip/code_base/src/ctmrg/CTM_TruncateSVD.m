function [Pleft, Pright, sval] = CTM_TruncateSVD(M, chiMax, cutoff)
%CTM_TRUNCATESVD Compute two projectors from the SVD of an enlarged corner product.
%
%   M = U*S*V'.  Pleft = U(:,1:chi), Pright = V(:,1:chi).

    if nargin < 3 || isempty(cutoff)
        cutoff = 0;
    end
    [U,S,V] = svd(M,'econ');
    sval = diag(S);
    if isempty(sval)
        chi = 1;
    else
        chi = min(chiMax, numel(sval));
        if cutoff > 0 && sval(1) > 0
            keep = find(sval/sval(1) > cutoff);
            if ~isempty(keep)
                chi = min(chi, keep(end));
            end
        end
    end
    Pleft = U(:,1:chi);
    Pright = V(:,1:chi);
end
