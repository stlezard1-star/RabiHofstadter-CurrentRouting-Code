function val = CTM_EvaluateNorm_Fast(A, W)
%CTM_EVALUATENORM_FAST Evaluate one-site CTM contraction using cached W.
%   A and W are rank-4 tensors with leg order [left,right,up,down].

    szA = PEPS_FullSize(A,4);
    szW = PEPS_FullSize(W,4);
    if ~isequal(szA,szW)
        error('CTM_EvaluateNorm_Fast:sizeMismatch', ...
            'A and cached environment W have incompatible sizes.');
    end
    A = reshape(A,szA);
    W = reshape(W,szW);
    val = sum(W(:).*A(:));
    if abs(imag(val)) < 1e-12 * max(1,abs(real(val)))
        val = real(val);
    end
end
