function [env, history] = CTM_Iterate(A, env, opts)
%CTM_ITERATE Iterate one-site CTMRG to convergence.
%
% StageRH4B addition:
%   opts.skipNormHistory = true
% skips the expensive diagnostic CTM_EvaluateNorm(A,env) inside each CTM
% iteration.  The norm history is diagnostic only and is not used by the CTM
% move.  This option prevents large blocked tensors from triggering huge
% ncon/tcontract intermediates during diagnostics.

    if nargin < 3
        opts = struct();
    end
    maxIter = CTM_GetOpt(opts,'maxIter',50);
    tol = CTM_GetOpt(opts,'tol',1e-10);
    verbose = CTM_GetOpt(opts,'verbose',false);
    % StageRH4A/4B compatibility:
    %   skipNormHistory      : canonical option name
    %   skipIterNorm         : older test/driver alias
    %   skipCTMNormHistory   : high-level RabiH driver alias
    % If any of these flags is true, skip the expensive diagnostic norm
    % evaluation inside the CTM iteration.  The norm column is then filled
    % with NaN by design.
    skipNormHistory = CTM_GetOpt(opts,'skipNormHistory',false);
    skipNormHistory = skipNormHistory || CTM_GetOpt(opts,'skipIterNorm',false);
    skipNormHistory = skipNormHistory || CTM_GetOpt(opts,'skipCTMNormHistory',false);

    history = zeros(maxIter,2);
    for it = 1:maxIter
        oldEnv = CTM_NormalizeEnv(env);
        [env,~] = CTM_OneCycle(A, env, opts);
        env = CTM_NormalizeEnv(env);
        diffVal = CTM_EnvDiff(env, oldEnv);
        if skipNormHistory
            normVal = NaN;
        else
            normVal = CTM_EvaluateNorm(A, env);
        end
        history(it,:) = [diffVal, normVal];
        env.lastDiff = diffVal;
        env.history = history(1:it,:);
        if verbose
            if skipNormHistory
                fprintf('[CTM] iter %4d: diff = %.3e, norm = skipped\n', it, diffVal);
            else
                fprintf('[CTM] iter %4d: diff = %.3e, norm = %.12e\n', it, diffVal, normVal);
            end
        end
        if diffVal < tol
            history = history(1:it,:);
            env.history = history;
            return;
        end
    end
    history = history(1:maxIter,:);
    env.history = history;
end
