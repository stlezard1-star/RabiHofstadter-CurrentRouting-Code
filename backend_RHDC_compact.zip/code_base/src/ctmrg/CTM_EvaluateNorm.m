function val = CTM_EvaluateNorm(A, env)
%CTM_EVALUATENORM Contract the 3x3 CTM environment with one central tensor.
%
% Layout:
%   C1--T1--C2
%   |   |   |
%   T4--A --T2
%   |   |   |
%   C4--T3--C3
%
% A leg order: [left,right,up,down].

    tensorList = {env.C1, env.T1, env.C2, env.T2, env.C3, env.T3, env.C4, env.T4, A};
    legLinks = { ...
        [1 2], ...          % C1 [down,right]
        [2 9 3], ...        % T1 [left,up,right]
        [3 4], ...          % C2 [left,down]
        [4 10 5], ...       % T2 [up,right,down]
        [5 6], ...          % C3 [up,left]
        [7 11 6], ...       % T3 [left,down,right]
        [8 7], ...          % C4 [up,right]
        [1 12 8], ...       % T4 [up,left,down]
        [12 10 9 11] ...    % A [left,right,up,down]
        };
    sequence = 1:12;
    val = ncon(tensorList, legLinks, sequence);
    if abs(imag(val)) < 1e-12 * max(1,abs(real(val)))
        val = real(val);
    end
end
