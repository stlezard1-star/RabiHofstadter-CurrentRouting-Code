function sz = PEPS_FullSize(A, ord)
%PEPS_FULLSIZE Return size(A) padded by trailing singleton dimensions.

    sz = size(A);
    if numel(sz) < ord
        sz(numel(sz)+1:ord) = 1;
    end
end
