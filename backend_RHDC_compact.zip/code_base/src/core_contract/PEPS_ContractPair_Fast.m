function C = PEPS_ContractPair_Fast(A,B,idxA,idxB,permOut,ordA,ordB)
%PEPS_CONTRACTPAIR_FAST Fast two-tensor contraction kernel.
%
%   C = PEPS_ContractPair_Fast(A,B,idxA,idxB)
%   contracts tensor A with tensor B over the legs specified by the position
%   lists idxA and idxB.
%
%   Leg convention:
%       idxA(k) is contracted with idxB(k).
%
%   Output leg order:
%       [free legs of A in original order, free legs of B in original order]
%
%   C = PEPS_ContractPair_Fast(A,B,idxA,idxB,permOut)
%   applies a final permute(C,permOut).  This is useful when a CTMRG kernel
%   expects a fixed non-default output ordering.
%
%   C = PEPS_ContractPair_Fast(A,B,idxA,idxB,permOut,ordA,ordB)
%   explicitly supplies the effective ranks of A and B.  This is important
%   for PEPS/CTMRG tensors with trailing singleton legs, because MATLAB
%   suppresses such legs in ndims(A), although size(A,k) remains valid.
%
%   This function is intentionally much less general than ncon.  It is meant
%   for PEPS/CTMRG hot loops after the network pattern has already been fixed
%   and tested against ncon.
%
%   MATLAB compatibility: R2018-style syntax.

    if nargin < 5
        permOut = [];
    end
    if nargin < 6
        ordA = [];
    end
    if nargin < 7
        ordB = [];
    end

    idxA = idxA(:).';
    idxB = idxB(:).';

    if numel(idxA) ~= numel(idxB)
        error('PEPS_ContractPair_Fast:IndexLengthMismatch', ...
              'idxA and idxB must have the same number of contracted legs.');
    end

    if isempty(ordA)
        ordA = PEPS_TensorOrder(A, idxA);
    else
        ordA = max([ordA, idxA(:).', 1]);
    end
    if isempty(ordB)
        ordB = PEPS_TensorOrder(B, idxB);
    else
        ordB = max([ordB, idxB(:).', 1]);
    end
    sizeA = PEPS_FullSize(A, ordA);
    sizeB = PEPS_FullSize(B, ordB);

    PEPS_CheckContractLegs(sizeA,sizeB,idxA,idxB,ordA,ordB);

    freeA = PEPS_FreeIndicesFast(ordA, idxA);
    freeB = PEPS_FreeIndicesFast(ordB, idxB);

    permA = [freeA, idxA];
    permB = [idxB, freeB];

    dimFreeA = PEPS_ProdDims(sizeA, freeA);
    dimFreeB = PEPS_ProdDims(sizeB, freeB);
    dimLink  = PEPS_ProdDims(sizeA, idxA);

    A_mat = reshape(permute(A,permA), dimFreeA, dimLink);
    B_mat = reshape(permute(B,permB), dimLink, dimFreeB);

    C_mat = A_mat * B_mat;

    outSize = [sizeA(freeA), sizeB(freeB)];
    if isempty(outSize)
        C = C_mat;
    else
        C = reshape(C_mat, outSize);
    end

    if ~isempty(permOut)
        C = permute(C,permOut);
    end
end
