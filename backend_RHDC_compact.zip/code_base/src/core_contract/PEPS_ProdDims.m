function p = PEPS_ProdDims(sz, idx)
%PEPS_PRODDIMS Product of dimensions sz(idx), with prod([])=1 convention.

    if isempty(idx)
        p = 1;
    else
        p = prod(sz(idx));
    end
end
