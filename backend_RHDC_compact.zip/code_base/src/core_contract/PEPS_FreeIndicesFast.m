function freeIdx = PEPS_FreeIndicesFast(ord, idx)
%PEPS_FREEINDICESFAST Fast stable complement of index positions.
%   freeIdx = PEPS_FreeIndicesFast(ord,idx) returns the stable complement of
%   idx in 1:ord, equivalent to setdiff(1:ord,idx,'stable') up to vector
%   orientation.  It avoids MATLAB's general setdiff/unique overhead in PEPS
%   contraction hot loops.
%
%   MATLAB R2018 compatible.

    if ord < 1
        freeIdx = zeros(1,0);
        return;
    end

    if isempty(idx)
        freeIdx = 1:ord;
        return;
    end

    mask = true(1,ord);
    idx = idx(:).';
    for k = 1:numel(idx)
        ik = idx(k);
        if ik >= 1 && ik <= ord && ik == round(ik)
            mask(ik) = false;
        end
    end
    freeIdx = find(mask);  % row vector with stable order
end
