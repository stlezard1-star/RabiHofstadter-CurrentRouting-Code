function ord = PEPS_TensorOrder(A, requestedLegs)
%PEPS_TENSORORDER Return effective tensor order including requested legs.
%
%   MATLAB suppresses trailing singleton dimensions in ndims/size output.  In
%   PEPS code we often still want to refer to those legs explicitly.  This
%   helper restores the effective order from the tensor and requested leg list.

    if nargin < 2 || isempty(requestedLegs)
        requestedLegs = 1;
    end
    ord = max([ndims(A), requestedLegs(:).', 1]);
end
