function PEPS_CheckContractLegs(sizeA,sizeB,idxA,idxB,ordA,ordB)
%PEPS_CHECKCONTRACTLEGS Basic checks for pair contractions.

    if any(idxA < 1) || any(idxA > ordA) || any(idxB < 1) || any(idxB > ordB)
        error('PEPS_CheckContractLegs:IndexOutOfRange', ...
              'Contracted leg position out of range.');
    end
    if numel(unique(idxA)) ~= numel(idxA) || numel(unique(idxB)) ~= numel(idxB)
        error('PEPS_CheckContractLegs:RepeatedLeg', ...
              'Repeated contracted leg positions are not allowed.');
    end
    if ~isempty(idxA) && any(sizeA(idxA) ~= sizeB(idxB))
        error('PEPS_CheckContractLegs:DimensionMismatch', ...
              'Contracted leg dimensions do not match.');
    end
end
