function A = iPEPS_GetTensor(unitCell,x,y)
%IPEPS_GETTENSOR Return unit-cell tensor at infinite-lattice coordinate (x,y).
%   Coordinates are one-based.  Periodic wrapping over the finite unit cell
%   is applied internally.

    ux = mod(x-1, unitCell.Lx) + 1;
    uy = mod(y-1, unitCell.Ly) + 1;
    A = unitCell.A{uy,ux};
end
