function T = iPEPS_GetCellTensor(cellArray,x,y)
%IPEPS_GETCELLTENSOR Return a tensor from a periodically repeated cell array.

    Ly = size(cellArray,1);
    Lx = size(cellArray,2);
    ux = mod(x-1,Lx) + 1;
    uy = mod(y-1,Ly) + 1;
    T = cellArray{uy,ux};
end
