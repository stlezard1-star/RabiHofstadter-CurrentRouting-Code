function unitCell = iPEPS_NormalizeUnitCell(unitCell)
%IPEPS_NORMALIZEUNITCELL Normalize each tensor in an iPEPS unit cell.

    iPEPS_CheckUnitCell(unitCell);
    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            unitCell.A{y,x} = iPEPS_NormalizeTensor(unitCell.A{y,x});
        end
    end
end
