function Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell, opCell)
%IPEPS_BUILDDOUBLELAYERUNITCELL Build double-layer tensors for all unit-cell sites.
%
%   Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell)
%   builds norm double layers.
%
%   Ecell = iPEPS_BuildDoubleLayerUnitCell(unitCell, opCell)
%   accepts either:
%       - a single d-by-d operator applied to all sites;
%       - a Ly-by-Lx cell array of d-by-d operators or [] entries.

    if nargin < 2
        opCell = [];
    end

    iPEPS_CheckUnitCell(unitCell);
    Ecell = cell(unitCell.Ly, unitCell.Lx);

    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            A = unitCell.A{y,x};
            if isempty(opCell)
                op = [];
            elseif iscell(opCell)
                op = opCell{y,x};
            else
                op = opCell;
            end
            Ecell{y,x} = iPEPS_BuildDoubleLayerTensor(A,op);
        end
    end
end
