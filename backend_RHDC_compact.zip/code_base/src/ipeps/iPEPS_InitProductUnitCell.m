function unitCell = iPEPS_InitProductUnitCell(statePattern, opts)
%IPEPS_INITPRODUCTUNITCELL Build a D=1 product-state finite-unit-cell iPEPS.
%
%   unitCell = iPEPS_InitProductUnitCell(statePattern, opts)
%
%   statePattern can be either:
%       (i)  a Ly-by-Lx numeric matrix of physical basis labels 1..d, or
%       (ii) a Ly-by-Lx cell array of dense local state vectors.
%
%   The returned site tensor has convention A(s,l,r,u,d), with all virtual
%   dimensions equal to one.  This helper is mainly used for exact observable
%   checks and biased initial states in later stages.

    if nargin < 2
        opts = struct();
    end
    d = iPEPS_GetOpt(opts,'d',2);
    doNormalize = iPEPS_GetOpt(opts,'normalize',true);

    if isnumeric(statePattern)
        [Ly,Lx] = size(statePattern);
        A = cell(Ly,Lx);
        for y = 1:Ly
            for x = 1:Lx
                label = statePattern(y,x);
                if label < 1 || label > d || round(label) ~= label
                    error('iPEPS_InitProductUnitCell:InvalidLabel', ...
                          'Physical label at (%d,%d) is invalid.', x,y);
                end
                v = zeros(d,1);
                v(label) = 1;
                A{y,x} = reshape(v,[d 1 1 1 1]);
            end
        end
    elseif iscell(statePattern)
        [Ly,Lx] = size(statePattern);
        A = cell(Ly,Lx);
        for y = 1:Ly
            for x = 1:Lx
                v = statePattern{y,x};
                v = v(:);
                if numel(v) ~= d
                    error('iPEPS_InitProductUnitCell:VectorSizeMismatch', ...
                          'Local state vector at (%d,%d) must have length d=%d.', x,y,d);
                end
                if doNormalize
                    nv = norm(v);
                    if nv == 0
                        error('iPEPS_InitProductUnitCell:ZeroVector', ...
                              'Local state vector at (%d,%d) is zero.', x,y);
                    end
                    v = v / nv;
                end
                A{y,x} = reshape(v,[d 1 1 1 1]);
            end
        end
    else
        error('iPEPS_InitProductUnitCell:InvalidPattern', ...
              'statePattern must be a numeric label matrix or a cell array of state vectors.');
    end

    unitCell = struct();
    unitCell.A = A;
    unitCell.Lx = Lx;
    unitCell.Ly = Ly;
    unitCell.d = d;
    unitCell.D = 1;
    unitCell.legOrder = {'s','l','r','u','d'};
    unitCell.stage = 'Stage3_product_unit_cell';

    iPEPS_CheckUnitCell(unitCell);
end
