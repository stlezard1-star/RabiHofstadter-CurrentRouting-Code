function E = iPEPS_BuildDoubleLayerTensor(A, op)
%IPEPS_BUILDDOUBLELAYERTENSOR Build one double-layer tensor from an iPEPS tensor.
%
%   E = iPEPS_BuildDoubleLayerTensor(A)
%   builds the norm double layer
%
%       E_{(l,l'),(r,r'),(u,u'),(d,d')}
%       = sum_s A_{s,l,r,u,d} conj(A_{s,l',r',u',d'}).
%
%   E = iPEPS_BuildDoubleLayerTensor(A, op)
%   inserts a one-site physical operator op:
%
%       E^op = sum_{s,s'} conj(A_{s',l',r',u',d'}) op(s',s) A_{s,l,r,u,d}.
%
%   Leg order of E:
%       [left-double, right-double, up-double, down-double].
%
%   Combined-leg convention:
%       combined index = ket index + (bra index-1)*ketDimension.
%
%   This routine is intentionally explicit and conservative.  It is used in
%   Stage 1 for correctness; later CTMRG kernels may use more specialized
%   versions.

    sz = PEPS_FullSize(A,5);
    d  = sz(1);
    Dl = sz(2);
    Dr = sz(3);
    Du = sz(4);
    Dd = sz(5);

    if nargin < 2 || isempty(op)
        op = eye(d);
    end
    if ~isequal(size(op),[d d])
        error('iPEPS_BuildDoubleLayerTensor:OperatorSizeMismatch', ...
              'Operator must have size d-by-d with d=%d.', d);
    end

    E8 = zeros(Dl,Dl,Dr,Dr,Du,Du,Dd,Dd);
    if ~isreal(A) || ~isreal(op)
        E8 = complex(E8);
    end

    for sp = 1:d
        bra = reshape(conj(A(sp,:,:,:,:)), [Dl Dr Du Dd]);
        bra8 = reshape(bra, [1 Dl 1 Dr 1 Du 1 Dd]);
        for s = 1:d
            coeff = op(sp,s);
            if coeff ~= 0
                ket = reshape(A(s,:,:,:,:), [Dl Dr Du Dd]);
                ket8 = reshape(ket, [Dl 1 Dr 1 Du 1 Dd 1]);
                E8 = E8 + coeff * bsxfun(@times, ket8, bra8);
            end
        end
    end

    E = reshape(E8, [Dl*Dl, Dr*Dr, Du*Du, Dd*Dd]);
end
