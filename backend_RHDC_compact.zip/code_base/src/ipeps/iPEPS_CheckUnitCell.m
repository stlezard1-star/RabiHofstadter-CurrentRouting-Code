function iPEPS_CheckUnitCell(unitCell)
%IPEPS_CHECKUNITCELL Basic structural checks for a finite-unit-cell iPEPS.

    required = {'A','Lx','Ly','d','D'};
    for k = 1:numel(required)
        if ~isfield(unitCell,required{k})
            error('iPEPS_CheckUnitCell:MissingField', 'Missing field unitCell.%s.', required{k});
        end
    end

    if ~iscell(unitCell.A) || size(unitCell.A,1) ~= unitCell.Ly || size(unitCell.A,2) ~= unitCell.Lx
        error('iPEPS_CheckUnitCell:InvalidCellArray', 'unitCell.A must be a Ly-by-Lx cell array.');
    end

    for y = 1:unitCell.Ly
        for x = 1:unitCell.Lx
            A = unitCell.A{y,x};
            if ~isnumeric(A)
                error('iPEPS_CheckUnitCell:NonNumericTensor', 'A{%d,%d} is not numeric.', y, x);
            end
            sz = PEPS_FullSize(A,5);
            if sz(1) ~= unitCell.d
                error('iPEPS_CheckUnitCell:PhysicalDimMismatch', 'A{%d,%d} has physical dim %d, expected %d.', y, x, sz(1), unitCell.d);
            end
            if any(sz(2:5) < 1)
                error('iPEPS_CheckUnitCell:InvalidVirtualDim', 'A{%d,%d} has invalid virtual dimensions.', y, x);
            end
        end
    end
end
