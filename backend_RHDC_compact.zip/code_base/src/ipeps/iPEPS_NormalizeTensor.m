function A = iPEPS_NormalizeTensor(A)
%IPEPS_NORMALIZETENSOR Normalize tensor by its Frobenius norm.
%   This is only a gauge-neutral numerical normalization used during early
%   development.  It is not a canonical-gauge operation.

    nrm = sqrt(sum(abs(A(:)).^2));
    if nrm > 0
        A = A / nrm;
    end
end
