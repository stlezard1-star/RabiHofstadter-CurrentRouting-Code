function val = iPEPS_GetOpt(opts, fieldName, defaultVal)
%IPEPS_GETOPT Return opts.(fieldName) if it exists; otherwise defaultVal.

    if isfield(opts,fieldName) && ~isempty(opts.(fieldName))
        val = opts.(fieldName);
    else
        val = defaultVal;
    end
end
